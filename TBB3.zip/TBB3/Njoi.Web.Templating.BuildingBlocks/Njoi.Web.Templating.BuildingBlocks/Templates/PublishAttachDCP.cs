﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Emaar.Web.Tridion.System;
using Tridion.ContentManager.ContentManagement;
using Tridion.Extensions.ContentManager.Templating;
using Tridion.ContentManager;


namespace Njoi.Web.Templating.BuildingBlocks.Templates
{
  [TcmTemplateTitle("Publish Attached DCP")]
    public class PublishAttachDCP : TemplateBase
    {
        public override void Transform(Engine engine, Package package)
        {
            base.Transform(engine, package);
            //IComponentPresentationList componentPresentations = package.ItemAsComponentList(Package.ComponentsName);
            if (Page.ComponentPresentations.Count > 0)
            {
                Component component = Page.ComponentPresentations[0].Component;
                String schemaTitle = component.Schema.Title;
                if (component != null)
                {
                    switch (schemaTitle)
                    {
                        case "Njoi - Attractions":
                            engine.RenderComponentPresentation(component.Id, new TcmUri(82188, ItemType.ComponentTemplate, Publication.Id.ItemId));
                            break;
                        default:
                            break;
                    }

                }
            }

        }
    }
}
