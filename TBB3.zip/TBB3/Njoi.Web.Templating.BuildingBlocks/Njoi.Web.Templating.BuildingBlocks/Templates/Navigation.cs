﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Tridion.Extensions.ContentManager.Templating;
using Emaar.Web.Tridion.System;
using Tridion.ContentManager.Templating.Assembly;

namespace Njoi.Web.Templating.BuildingBlocks
{
    [TcmTemplateTitle("Navigation")] 
    public class Navigation : Emaar.Web.Tridion.System.Navigation
    {

        private List<String> mFields;
        private List<String> mLinks;


        public Navigation()
            : base()
        {
            mLinks = new List<String>();
            mLinks.Add("hero");
        
        }

        protected override bool IncludeMetadata(String FieldName)
        {
            return !(mLinks.Contains(FieldName));
        }

        protected override bool AsComponentLink(String FieldName)
        {
            return mLinks.Contains(FieldName);
        }
    }
}
