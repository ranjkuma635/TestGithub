﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Tridion.Extensions.ContentManager.Templating;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.ContentManagement.Fields;
using Tridion.ContentManager.ContentManagement;
using Emaar.Web.Tridion.System.Extensions;
using Tridion.ContentManager.Publishing;
using System.IO;
using System.Xml;
using Tridion.ContentManager.CommunicationManagement;
using Tridion.ContentManager;

namespace Njoi.Web.Templating.BuildingBlocks.Templates
{
    [TcmTemplateTitle("DCPXML")]
    public class DCPItem : TemplateBase
    {
              //<summary>
        //Transforms the current component.
        //</summary>
        //<param name="engine">The engine.</param>
        //<param name="package">The package.</param>
        public override void Transform(Engine engine, Package package)
        {
            base.Transform(engine, package);



            using (StringWriter sw = new StringWriter())
            {

                using (XmlTextWriter xml = new XmlTextWriter(sw))
                {
                    string itemId = Component.Id;

                    if (Component != null)
                    {

                        /* Start of Njoi - Attractions DCP */
                        if (Component.Schema.Title.Equals("Njoi - Attractions"))
                        {
                            //DateTime startDate = Component.DateMetaValue("publishdate");
                            //string strStartDate = "";
                            //string year = "";
                            //string month = "";

                            //if (startDate.ToString("dd/MM/yyyy") != "01/01/0001")
                            //{
                            //    strStartDate = startDate.ToString("dd/MM/yyyy");
                            //    year = startDate.ToString("yyyy");
                            //    month = startDate.ToString("MM");
                            //}

                            xml.WriteStartElement("item");

                            xml.WriteAttributeString("uri", Component.Id);
                            
                            xml.WriteAttributeString("id", itemId.Split('-')[1]);
                            xml.WriteAttributeString("schema", Component.Schema.Title.Split('-')[1].TrimStart().Replace(" ", ""));
                            xml.WriteAttributeString("displayOrder", GetSortTitle(Component.Title));
                            if (!string.IsNullOrEmpty(Component.StringValue("heading")))
                            xml.WriteAttributeString("heading", Component.StringValue("heading"));

                            if (!string.IsNullOrEmpty(Component.StringValue("introText")))
                                xml.WriteAttributeString("introText", Component.StringValue("introText"));

                            if (!string.IsNullOrEmpty(Component.StringValue("description")))
                                xml.WriteAttributeString("description", Component.StringValue("description"));

                            if (Component.ComponentValue("carouselImage") != null)
                            {
                                xml.WriteStartElement("carouselImage");

                                foreach (Component com in Component.ComponentValues("carouselImage")) {
                                    xml.WriteStartElement("image");

                                    xml.WriteAttributeString("src", PublishBinary(com));
                                    xml.WriteEndElement();
                                }

                                xml.WriteEndElement(); // end carouselImage
                            }

                            if (Component.EmbeddedValues("Callouts") != null)
                            {
                                xml.WriteStartElement("callouts");

                                foreach (ItemFields com in Component.EmbeddedValues("Callouts"))
                                {
                                    if (com.ComponentValue("indexImage") != null)
                                        xml.WriteAttributeString("indexImgSrc", PublishBinary(com.ComponentValue("indexImage")));

                                    if (com.ComponentValue("image")!=null)
                                    xml.WriteAttributeString("innerImgSrc", PublishBinary(com.ComponentValue("image")));
                                    
                                    if (!string.IsNullOrEmpty(com.StringValue("text")))
                                    xml.WriteAttributeString("text", com.StringValue("text"));
                                    
                                    if (!string.IsNullOrEmpty(com.StringValue("bgColor")))
                                    xml.WriteAttributeString("bgColor", com.StringValue("bgColor")); 

                                }
                                

                                xml.WriteEndElement(); //end callouts
                            }
                              


                            //xml.WriteAttributeString("publishDate", strStartDate);
                            //xml.WriteAttributeString("sortDate", GetSortDate(strStartDate));
                            //xml.WriteAttributeString("year", year);
                            //xml.WriteAttributeString("month", month);
                            //if (Component.KeywordValue("period") != null)
                            //{
                            //    xml.WriteAttributeString("period", Component.KeywordValue("period").Description);
                            //}
                            //else
                            //{
                            //    //To handle Disclosures and Governance components
                            //    xml.WriteAttributeString("period", month);
                            //}
                            //if (Component.KeywordValue("document") != null)
                            //{
                            //    xml.WriteAttributeString("documentkey", Component.KeywordValue("document").Key);
                            //    xml.WriteAttributeString("document", Component.KeywordValue("document").Description);
                            //}
                            //if (Component.KeywordValue("documentdisclosures") != null)
                            //{
                            //    xml.WriteAttributeString("documentdisclosureskey", Component.KeywordValue("documentdisclosures").Key);
                            //    xml.WriteAttributeString("documentdisclosures", Component.KeywordValue("documentdisclosures").Description);
                            //}
                            //if (Component.KeywordValue("documentgovernance") != null)
                            //{
                            //    xml.WriteAttributeString("documentgovernancekey", Component.KeywordValue("documentgovernance").Key);
                            //    xml.WriteAttributeString("documentgovernance", Component.KeywordValue("documentgovernance").Description);
                            //}
                            //if (Component.KeywordValue("documentotherresources") != null)
                            //{
                            //    xml.WriteAttributeString("documentotherresourceskey", Component.KeywordValue("documentotherresources").Key);
                            //    xml.WriteAttributeString("documentotherresources", Component.KeywordValue("documentotherresources").Description);
                            //}



                            //if (Component.ComponentValue("download") != null)
                            //{
                            //    xml.WriteAttributeString("download", PublishBinary(Component.ComponentValue("download")));
                            //}

                            xml.WriteEndElement();//item

                        }

                        if (Component.Schema.Title.Equals("Njoi - Hero Banner") && Component.StringMetaValue("bannerType") == "Promotions")
                        {

                            xml.WriteStartElement("item");

                            xml.WriteAttributeString("uri", Component.Id);

                            xml.WriteAttributeString("id", itemId.Split('-')[1]);
                            xml.WriteAttributeString("schema", Component.Schema.Title.Split('-')[1].TrimStart().Replace(" ", ""));

                            if (!string.IsNullOrEmpty(Component.StringValue("title")))
                                xml.WriteAttributeString("title", Component.StringValue("title"));

                            if (!string.IsNullOrEmpty(Component.StringValue("description")))
                                xml.WriteAttributeString("description", Component.StringValue("description"));

                            if (!string.IsNullOrEmpty(Component.StringValue("textColor")))
                                xml.WriteAttributeString("textColor", Component.StringValue("textColor"));

                            if (Component.ComponentValue("image") != null)
                                xml.WriteAttributeString("imgsrc", PublishBinary(Component.ComponentValue("image")));
                            if (Component.EmbeddedValues("linkto") != null) 
                            {

                                foreach (ItemFields f in Component.EmbeddedValues("linkto")) 
                                {

                                    if (!string.IsNullOrEmpty(f.StringValue("flinkText")))
                                    { xml.WriteAttributeString("flinkText", f.StringValue("flinkText")); }

                                    if (f.ComponentValue("fcomponentLink") != null) { xml.WriteAttributeString("fcomponentLink", f.ComponentValue("fcomponentLink").Id); xml.WriteAttributeString("nolink", "false"); }

                                    else if (!string.IsNullOrEmpty(f.StringValue("fexternalLink")))
                                    { xml.WriteAttributeString("fexternalLink", f.StringValue("fexternalLink")); xml.WriteAttributeString("nolink", "false"); }
                                    else { xml.WriteAttributeString("nolink", "true"); }

                                  
                                }

                            }

                            if (!string.IsNullOrEmpty(Component.StringMetaValue("altText"))) { 
                            xml.WriteAttributeString("altText",Component.StringMetaValue("altText"));

                            }
                            xml.WriteAttributeString("bannerType", Component.StringMetaValue("bannerType"));
                          
                            if (Component.DateMetaValue("startDate") != null)
                            {

                                DateTime startdate = Component.DateMetaValue("startDate");
                                xml.WriteAttributeString("startDate", startdate.ToString());

                                xml.WriteAttributeString("startDateFormat", startdate.ToString("dd/MM/yyyy"));
                                xml.WriteAttributeString("startTimeFormat", startdate.ToString("hh:mm:ss tt"));
                            
                            }
                          
                            if (Component.DateMetaValue("endDate") != null)
                            {
                                DateTime endDate = Component.DateMetaValue("endDate");
                                xml.WriteAttributeString("endDate", endDate.ToString());

                                xml.WriteAttributeString("endDateFormat", endDate.ToString("dd/MM/yyyy"));
                                xml.WriteAttributeString("endTimeFormat", endDate.ToString("hh:mm:ss tt"));
                            }
                            xml.WriteAttributeString("publishedDate", DateTime.Now.ToString());
                            xml.WriteEndElement();//item
                        
                        }


                        Package.AddXml(Package.OutputName, sw.ToString());
                        /* End of Njoi - Attractions DCP*/
                    }
                }
            }
        }

       private string GetSortDate(string strDate)
            {

                string strRetval = "";


                string[] datetime = strDate.Split(new char[] { '/' });

                string Year = datetime[2];
                string Month = datetime[1];
                string Day = datetime[0];

                if (Month.Length == 1)
                    Month = "0" + Month;

                if (Day.Length == 1)
                    Day = "0" + Day;

                strRetval = Day + "/" + Month+ "/" + Year;

                return strRetval;

            }


       private string GetSortTime(string strTime){

           string strRetval = "";


           string[] datetime = strTime.Split(new char[] { ' ' });

          string stime = datetime[1];
          string tt = datetime[2];
          string[] time = stime.Split(new char[] {':'});

           string hh = time[0];
           string mm = time[1];
           string ss = time[2];

           if (hh.Length == 1)
               hh = "0" + hh;

           if (mm.Length == 1)
               mm = "0" + mm;

           if (ss.Length == 1)
               ss = "0" + ss;

           strRetval = hh + ":" + mm + ":" + ss +" " + tt;

           return strRetval;
   
       }

       private string GetSortTitle(string strTitle) {
           string i;
           
           i = strTitle.Substring(0, 4);
           i = string.Join("", i.ToCharArray().Where(Char.IsDigit));

           i=  i.TrimStart('0').Length > 0 ? i.TrimStart('0') : "0";
           
           return i;
       }
 
    
    }
}
