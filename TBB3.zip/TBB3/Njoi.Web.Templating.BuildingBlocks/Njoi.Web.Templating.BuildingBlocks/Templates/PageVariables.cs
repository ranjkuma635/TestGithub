﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Tridion.ContentManager;
using Tridion.ContentManager.CommunicationManagement;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.ContentManagement.Fields;
using Tridion.ContentManager.ContentManagement;
using System.Text.RegularExpressions;
using Tridion.Extensions.ContentManager.Templating;
using Emaar.Web.Tridion.System.Extensions;
using Emaar.Web.Tridion.System;


namespace Njoi.Web.Templating.BuildingBlocks.Templates
{
    [TcmTemplateTitle("Page Variables")]
    public class PageVariables : PageVariablesTemplate
    {
        private List<String> mIncludeFields;
        private List<String> mInheritedFields;

        public PageVariables()
            : base()
        {
            mIncludeFields = new List<String>();
            mIncludeFields.Add("hero");
            mIncludeFields.Add("customPageTitle");
       

            mInheritedFields = new List<String>();
            mInheritedFields.Add("hero");
            mInheritedFields.Add("customPageTitle");
        }

        protected override bool IncludeMetadata(string FieldName)
        {
            return mIncludeFields.Contains(FieldName);
        }

        protected override bool InheritedMetadata(string FieldName)
        {
            return mInheritedFields.Contains(FieldName);
        }

        /// <summary>
        /// Returns wether the specified Schema should be used to generate a page title
        /// </summary>
        /// <returns></returns>
        protected override bool TitleTemplate(string Schema)
        {
            return true;
        }


    }
}
