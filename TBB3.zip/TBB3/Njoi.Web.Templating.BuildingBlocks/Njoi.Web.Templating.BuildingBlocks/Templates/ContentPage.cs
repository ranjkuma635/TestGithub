﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.Extensions.ContentManager.Templating;
using Tridion.ContentManager.ContentManagement;
using Emaar.Web.Tridion.System.Extensions;
using Tridion.ContentManager.ContentManagement.Fields;
using Tridion.ContentManager.CommunicationManagement;
using System.Xml;

namespace Njoi.Web.Templating.BuildingBlocks.Templates
{
     [TcmTemplateTitle("Content Page")]
    public class ContentPage : TemplateBase
    {

        public override void Transform(Engine engine, Package package)
        {
            base.Transform(engine, package);
            String seoImage = String.Empty; ;
            String seoDescription = String.Empty;
            String seoKeywords = String.Empty;
            String spageTitle = String.Empty;
            String spageMetaTitle = String.Empty;
            String strfulldesc = String.Empty;

            if (Page.ComponentPresentations.Count > 0)
            {
                Component component = Page.ComponentPresentations[0].Component;

           

                //Emaar - Community
                //if (Publication.PublicationUrl == "/ar")
                //{

                //    if(component.StringValue("title") != null)
                //        spageTitle = component.StringValue("title");

                //    if (component.StringValue("description") != null)
                //    {
                //        strfulldesc = "<content>" + component.StringValue("description") + "</content>";
                //        XmlDocument doc = new XmlDocument();
                //        doc.LoadXml(strfulldesc);
                //        seoDescription = doc.InnerText;
                //        if(doc.InnerText.Length > 149)
                //        seoDescription = doc.InnerText.Substring(1, 149);
                //    }

                //    if (component.Schema.Title == "Emaar - Corporate Content")
                //    {
                //        strfulldesc = "<content>" + component.StringValue("summary") + "</content>";
                //        XmlDocument doc = new XmlDocument();
                //        doc.LoadXml(strfulldesc);

                //        seoDescription = doc.InnerText;
                //        if (doc.InnerText.Length > 149)
                //            seoDescription = doc.InnerText.Substring(1, 149);

                //    }
                //    if (component.Schema.Title == "Emaar - Intro Content" || component.Schema.Title == "Emaar - Board")
                //    {
                //        if (component.StringValue("heading") != null)
                //            spageTitle = component.StringValue("heading");

                //        if (component.StringValue("content") != null)
                //        {
                //            strfulldesc = "<content>" + component.StringValue("content") + "</content>";
                //            XmlDocument doc = new XmlDocument();
                //            doc.LoadXml(strfulldesc);
                //            seoDescription = doc.InnerText;
                //            if (doc.InnerText.Length > 149)
                //                seoDescription = doc.InnerText.Substring(1, 149);
                //        }

                //    }
                //    if (component.Schema.Title == "Emaar - Content")
                //    {
                //        if (component.StringValue("h1") != null)
                //            spageTitle = component.StringValue("h1");

                //        if (component.StringValue("content") != null)
                //        {
                //            strfulldesc = "<content>" + component.StringValue("content") + "</content>";
                //            XmlDocument doc = new XmlDocument();
                //            doc.LoadXml(strfulldesc);
                //            seoDescription = doc.InnerText;
                //            if (doc.InnerText.Length > 149)
                //                seoDescription = doc.InnerText.Substring(1, 149);
                //        }

                //    }
                //    if (component.Schema.Title == "Emaar - List" || component.Schema.Title == "Emaar - Intro Panel")
                //    {
                //        if (component.StringValue("h1") != null)
                //            spageTitle = component.StringValue("h1");

                //    }
                //    if (component.Schema.Title == "Emaar - Fact Sheets")
                //    {
                //        if (component.StringValue("heading") != null)
                //            spageTitle = component.StringValue("heading");

                //    }


                //}


                if (component.EmbeddedMetaValue("seometadata") != null)
                {
                    ItemFields seoMetadata = component.EmbeddedMetaValue("seometadata");



                    //spageMetaTitle = seoMetadata.StringValue("fPageTitle");
                    spageMetaTitle = "";

                    if (seoMetadata.StringValue("fPageTitle") != null)
                    {
                        spageMetaTitle = seoMetadata.StringValue("fPageTitle");
                    }
                    else if (component.StringValue("title") != null)
                    {
                        spageMetaTitle = component.StringValue("title");
                    }

                    if (seoMetadata.StringValue("fSEOKeywords") != null)
                    {
                        seoKeywords = seoMetadata.StringValue("fSEOKeywords");
                    }
                    if (seoMetadata.ComponentValue("fSEOImage") != null)
                    {
                        seoImage = GenerateThumbnail(seoMetadata.ComponentValue("fSEOImage"), "seo", 600, 600);
                    }
                    if (seoMetadata.StringValue("fSEODescription") != null)
                    {
                        seoDescription = seoMetadata.StringValue("fSEODescription");
                    }



                }

                if (!string.IsNullOrEmpty(Page.StringMetaValue("customPageTitle")))
                    spageTitle = Page.StringMetaValue("customPageTitle");
                else if (!string.IsNullOrEmpty(spageMetaTitle))
                    spageTitle = spageMetaTitle;
                else
                {
                    if (Page.Title.IndexOf(".") != -1)
                        spageTitle = Page.Title.Substring(Page.Title.IndexOf(".")+1);
                    else
                        spageTitle = Page.Title;
                }
         /*       if (String.IsNullOrEmpty(seoImage))
                {
                    seoImage = calloutImage(Page);
                }
                if (String.IsNullOrEmpty(seoImage))
                {
                    seoImage = compImage(Page);
                }
                if (String.IsNullOrEmpty(seoImage))
                {
                    seoImage = bannerImage(Page);
                }
                if (String.IsNullOrEmpty(seoImage))
                {
                    seoImage = calloutParentImage(Page);
                }
                if (String.IsNullOrEmpty(seoImage))
                {
                    seoImage = bannerParentImage(Page);
                }
                */
                package.AddString("PageTitle", spageTitle);
                package.AddString("metaPageTitle", spageMetaTitle);
                package.AddString("SEODescription", seoDescription);


                //package.AddString("pub", Publication.PublicationUrl);

                package.AddString("SEOKeywords", seoKeywords);
                package.AddString("SEOImage", seoImage);

                package.AddString("NavPath", Page.PublishLocationUrl);

                if (package.GetByName("PageVariable.subscription") != null)
                {
                    Keyword k = engine.GetObject(package.GetByName("PageVariable.subscription").GetAsString()) as Keyword;
                    package.AddString("subscription", k.Description);
                    package.AddString("subscriptionKey", k.Key);
                }
            }
        }
/*
        private string compImage(Page Page)
        {

            StructureGroup sg = Page.OrganizationalItem as StructureGroup;
            XmlNode xImage = null;
            XmlNode xBanner = null;
            XmlNodeList xBannerList = null;
            string flag = "";
            if (Page.ComponentPresentations.Count > 0)
            {
                Component component = Page.ComponentPresentations[0].Component;
                if (component.Content != null)
                {
                    if (component.Content.SelectSingleNode("//node()[local-name() = 'image']") != null)
                    {
                        xImage = component.Content.SelectSingleNode("//node()[local-name() = 'image']");
                    }
                }
            }
            if (xImage != null)
            {

                String imageID = xImage.GetAttribute("xlink:href");
                if (!String.IsNullOrEmpty(imageID) && imageID.Contains("tcm:"))
                {
                    return GenerateThumbnail(GetComponent(imageID), "seo", 600, 600);

                }
            }
            return string.Empty;
        }

        private string calloutImage(Page Page)
        {

            StructureGroup sg = Page.OrganizationalItem as StructureGroup;
            XmlNode xImage = null;
            XmlNode xBanner = null;
            XmlNodeList xBannerList = null;
            if (xImage == null)
            {
                if (Page.Metadata != null)
                {
                    xBannerList = Page.Metadata.ChildNodes;
                    foreach (XmlNode item in xBannerList)
                    {
                        if (item.Name.Equals("fcalloutImage"))
                        {
                            xBanner = item;
                            break;
                        }

                    }
                }

                if (xBanner != null)
                {
                    if (xBanner.Attributes["xlink:href"] != null)
                    {
                        string heroID = xBanner.Attributes["xlink:href"].Value;


                        if (!String.IsNullOrEmpty(heroID) && heroID.Contains("tcm:"))
                        {
                            return GenerateThumbnail(GetComponent(heroID), "seo", 600, 600);
                        }
                    }
                }
            }
            return "";
        }

        private string calloutParentImage(Page Page)
        {

            StructureGroup sg = Page.OrganizationalItem as StructureGroup;
            XmlNode xImage = null;
            XmlNode xBanner = null;
            XmlNodeList xBannerList = null;

            do
            {
                if (sg.Metadata != null)
                {
                    xBannerList = sg.Metadata.ChildNodes;
                    foreach (XmlNode item in xBannerList)
                    {
                        if (item.Name.Equals("fcalloutImage"))
                        {
                            xBanner = item;
                            break;
                        }
                    }
                }
                if (sg.Title.Equals("Root"))
                {
                    break;
                }
                else
                {
                    sg = sg.OrganizationalItem as StructureGroup;
                }
            }
            while (xBanner == null);

            if (xBanner != null)
            {
                if (xBanner.Attributes["xlink:href"] != null)
                {
                    string heroID = xBanner.Attributes["xlink:href"].Value;


                    if (!String.IsNullOrEmpty(heroID) && heroID.Contains("tcm:"))
                    {
                        return GenerateThumbnail(GetComponent(heroID), "seo", 600, 600);
                    }
                }
            }
            return "";
        }

        private string bannerImage(Page Page)
        {

            StructureGroup sg = Page.OrganizationalItem as StructureGroup;
            XmlNode xImage = null;
            XmlNode xBanner = null;
            XmlNodeList xBannerList = null;

            if (Page.Metadata != null)
            {
                xBannerList = Page.Metadata.ChildNodes;
                foreach (XmlNode item in xBannerList)
                {

                    if (item.Name.Equals("hero"))
                    {
                        xBanner = item;
                        break;
                    }
                }
            }
            if (xBanner != null)
            {
                if (xBanner.Attributes["xlink:href"] != null)
                {
                    string heroID = xBanner.Attributes["xlink:href"].Value;
                    string imageID = string.Empty;


                    if (!String.IsNullOrEmpty(heroID) && heroID.Contains("tcm:"))
                    {
                        Component heroComp = GetComponent(heroID);
                        if (heroComp != null)
                        {
                            imageID = heroComp.EmbeddedValues("carousel").First().XHTMLValue("image");
                            foreach (ItemField field in heroComp.EmbeddedValue("carousel"))
                            {
                                if (field.Name.Equals("image"))
                                {
                                    imageID = field.ComponentValue().Id;
                                    break;
                                }
                            }
                        }
                    }
                    return GenerateThumbnail(GetComponent(imageID), "seo", 600, 600);
                }
            }
            return "";
        }

        private string bannerParentImage(Page Page)
        {

            StructureGroup sg = Page.OrganizationalItem as StructureGroup;
            XmlNode xImage = null;
            XmlNode xBanner = null;
            XmlNodeList xBannerList = null;
            do
            {
                if (sg.Metadata != null)
                {
                    xBannerList = sg.Metadata.ChildNodes;
                    foreach (XmlNode item in xBannerList)
                    {
                        if (item.Name.Equals("hero"))
                        {
                            xBanner = item;
                            break;
                        }
                    }
                }
                if (sg.Title.Equals("Root"))
                {
                    break;
                }
                else
                {
                    sg = sg.OrganizationalItem as StructureGroup;
                }
            }
            while (xBanner == null);

            if (xBanner != null)
            {
                if (xBanner.Attributes["xlink:href"] != null)
                {
                    string heroID = xBanner.Attributes["xlink:href"].Value;
                    string imageID = string.Empty;


                    if (!String.IsNullOrEmpty(heroID) && heroID.Contains("tcm:"))
                    {
                        Component heroComp = GetComponent(heroID);
                        if (heroComp != null)
                        {
                            imageID = heroComp.EmbeddedValues("carousel").First().XHTMLValue("image");
                            foreach (ItemField field in heroComp.EmbeddedValue("carousel"))
                            {
                                if (field.Name.Equals("image"))
                                {
                                    imageID = field.ComponentValue().Id;
                                    break;
                                }
                            }
                        }
                    }
                    return GenerateThumbnail(GetComponent(imageID), "seo", 600, 600);
                }
            }
            return "";
        }

        */
    
    }
}
