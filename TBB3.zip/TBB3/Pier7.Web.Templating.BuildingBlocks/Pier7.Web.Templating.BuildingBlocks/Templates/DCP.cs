﻿using System;
using System.Xml;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.ContentManagement;
using Tridion.Extensions.ContentManager.Templating;
using Emaar.Web.Tridion.System.Extensions;
using System.IO;

namespace Pier7.Web.Templating.BuildingBlocks.Templates
{
    [TcmTemplateTitle("DCP")]
    public class DCP : TemplateBase
    {
        public override void Transform(Engine engine, Package package)
        {
            base.Transform(engine, package);

            using (StringWriter sw = new StringWriter())
            {
                using (XmlTextWriter xml = new XmlTextWriter(sw))
                {
                    xml.WriteStartElement("Data");
                    if (Component != null)
                    {
                        if (Component.Schema.Title.ToUpper().Contains("PRESS")) 
                        {
                            xml.WriteAttributeString("uri", Component.Id);

                            Component Thumbimage = Component.ComponentValue("fthumbimage");
                            if(Thumbimage!=null)
                                xml.WriteElementString("ThumbNailImage", PublishBinary(Thumbimage));

                            xml.WriteElementString("Summary", Component.StringValue("fsummarytext"));

                            xml.WriteElementString("Title", Component.StringValue("ftitle"));
                            xml.WriteElementString("Description", Component.XHTMLValue("fdescription"));

                            Component pdf = Component.ComponentValue("fpdf");
                            if (pdf != null)
                                xml.WriteElementString("pdf", PublishBinary(pdf));

                            xml.WriteElementString("Publishdate", Component.DateMetaValue("fpubdate").ToString("dd/MM/yyyy"));

                        }
                    }
                    xml.WriteEndElement();
                }

                Package.AddXml(Package.OutputName, sw.ToString());
            }

        }
    }
}
