﻿using System;
using System.Linq;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.ContentManagement.Fields;
using Tridion.Extensions.ContentManager.Templating;
using Tridion.ContentManager.ContentManagement;
using Emaar.Web.Tridion.System.Extensions;

namespace Pier7.Web.Templating.BuildingBlocks.Templates
{
    [TcmTemplateTitle("Content Page")]
    public class ContentPage : TemplateBase
    {

        public override void Transform(Engine engine, Package package)
        {
            base.Transform(engine, package);
            String seoImage = String.Empty; ;
            String seoDescription = String.Empty;
            String seoKeywords = String.Empty;
            String spageTitle = String.Empty;

            if (Page.ComponentPresentations.Count > 0)
            {
                Component component = Page.ComponentPresentations[0].Component;

                if (component.EmbeddedMetaValue("seometadata") != null)
                {
                    ItemFields seoMetadata = component.EmbeddedMetaValue("seometadata");
                    spageTitle = seoMetadata.StringValue("fPageTitle");
                    if (seoMetadata.StringValue("fPageTitle") != null)
                    {
                        spageTitle = seoMetadata.StringValue("fPageTitle");
                    }
                    else if (component.StringValue("title") != null)
                    {
                        spageTitle = component.StringValue("title");
                    }
                    if (seoMetadata.StringValue("fSEODescription") != null)
                    {
                        seoDescription = seoMetadata.StringValue("fSEODescription");
                    }

                    if (seoMetadata.StringValue("fSEOKeywords") != null)
                    {
                        seoKeywords = seoMetadata.StringValue("fSEOKeywords");
                    }

                }

                package.AddString("NavPath", Page.PublishLocationUrl);
                package.AddString("PageTitle", spageTitle);
                package.AddString("metaPageTitle", spageTitle);
                package.AddString("SEODescription", seoDescription);
                package.AddString("SEOKeywords", seoKeywords);
                package.AddString("NavPath", Page.PublishLocationUrl);
            }
        }
    }

}
