﻿using System.Collections.Generic;
using System.Xml;
using System.IO;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.Extensions.ContentManager.Templating;
using Publishing = Tridion.ContentManager.Publishing.Rendering;
using Tridion.ContentManager.ContentManagement;
using Emaar.Web.Tridion.System.Extensions;
using System;
using Tridion.ContentManager.ContentManagement.Fields;

namespace MDTD.Web.Tridion.BuildingBlocks.Templates
{
    public class Events : TemplateBase 
    {

        public override void Transform(Engine engine, Package package)
        {
            string strActive = string.Empty;
            base.Transform(engine, package);
            Engine m_Engine;
            m_Engine = engine;

            string sCharge = string.Empty;

            string strPubid = Page.ComponentPresentations[0].Component.Id.PublicationId.ToString();
            string strEvent = "tcm:" + strPubid + "-1404-2";
            OrganizationalItem EventFolder = m_Engine.GetObject(strEvent) as OrganizationalItem;
            String enddate = "";
            using (StringWriter sw = new StringWriter())
            {
                using (XmlTextWriter xml = new XmlTextWriter(sw))
                {
                    xml.WriteStartElement("Events");


                    IList<Component> componentsshop = EventFolder.Components(true);
                    foreach (Component c in componentsshop)
                    {
                        if (c.Schema.Title.Equals("MDTD - Events"))
                        {

                            String strdate = c.DateMetaValue("fstartDate").ToString("dd/MM/yyyy");

                            if (c.DateMetaValue("fenddate").ToString() != "")
                            {
                                enddate = c.DateMetaValue("fenddate").ToString("dd/MM/yyyy");
                            }

                            xml.WriteStartElement("Event");

                                xml.WriteElementString("Title", c.StringValue("ftitle"));
                                xml.WriteElementString("Description", c.XHTMLValue("fdescription"));
                                xml.WriteElementString("Summary", c.XHTMLValue("fsummary"));

                                xml.WriteElementString("Startdate", strdate);
                                xml.WriteElementString("Enddate", enddate);

                                IList<ItemFields> iFields = c.EmbeddedValues("fcharge");
                                foreach (ItemFields fields in iFields)
                                {
                                    IList<string> iFieldsinner = fields.StringValues("ftext");
                                    foreach (string fieldsinner in iFieldsinner)
                                    {
                                        sCharge = sCharge + fieldsinner.ToString();
                                    }
                                                                    
                                }


                                xml.WriteElementString("EntryCharges", sCharge);

                            //Event
                            xml.WriteEndElement();

                        }
                    }


                    xml.WriteEndElement();
                }
                Package.AddXml(Package.OutputName, sw.ToString());
            }

    
        }


    }
}
