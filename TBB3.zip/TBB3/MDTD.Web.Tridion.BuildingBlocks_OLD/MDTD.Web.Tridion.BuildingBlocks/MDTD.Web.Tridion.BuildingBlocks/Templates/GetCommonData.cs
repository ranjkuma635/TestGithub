﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
using System.Web;
using Tridion.ContentManager;
using Tridion.ContentManager.CommunicationManagement;
using Tridion.ContentManager.ContentManagement;
using Tridion.ContentManager.ContentManagement.Fields;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.Publishing;
using Tridion.Extensions.ContentManager.Templating;
using Tridion.ContentManager.Publishing.Rendering;

namespace MDTD.Web.Tridion.BuildingBlocks.Templates
{
    [TcmTemplateTitle("Get Common Data")]
    class GetCommonData : TemplateBase 
    {
        public override void Transform(Engine engine, Package package)
        {
            string seoDescription = string.Empty;
            string seoKeywords = string.Empty;

            base.Transform(engine, package);
            
            StructureGroup RootSG = (StructureGroup)Page.OrganizationalItem as StructureGroup;
            package.PushItem("StructureGroup", package.CreateStringItem(ContentType.Text, RootSG.Id.ToString()));
            package.PushItem("publicationurl", package.CreateStringItem(ContentType.Text, getPubURL(Page)));
            package.PushItem("publicationid", package.CreateStringItem(ContentType.Text, getPubID(Page)));
            package.PushItem("MainHeading", package.CreateStringItem(ContentType.Text, getMainHeading(Page)));
            package.PushItem("SubHeading", package.CreateStringItem(ContentType.Text, getSubHeading(Page)));

            if (Page.ComponentPresentations.Count > 0)
            {
                Component component = Page.ComponentPresentations[0].Component;
                if (component.Content != null)
                {

                    if (component.Schema.Title  == "MDTD - Generic")
                    {
                        ItemFields fields = new ItemFields(component.Content, component.Schema);

                        package.PushItem("SEOKeywords", package.CreateStringItem(ContentType.Text, fields["seoKeywords"].ToString()));
                        package.PushItem("SEODescription", package.CreateStringItem(ContentType.Text, fields["seoDescription"].ToString()));
                    }
                }
            }

        }
        private string getPubURL(Page page)
        {
            string pub = "tcm:0-" + page.Id.PublicationId + "-1";
            Publication publication;
            publication = Engine.GetObject(pub) as Publication;
            return publication.PublicationUrl.ToString();
        }

        private string getPubID(Page page)
        {
            string pub = "tcm:0-" + page.Id.PublicationId + "-1";
            Publication publication;
            publication = Engine.GetObject(pub) as Publication;
            return publication.Id.ToString().Split('-')[1].ToString();  
        }


        private string RenderParentSGRoot(OrganizationalItem oRecurSG, string strNameoftheMetaTag)
        {
            OrganizationalItem oParentSG;
            string strMetadataValue = "";
            ItemFields metadataFields;

            if (oRecurSG != null)
            {
                if (oRecurSG.Metadata != null)
                {
                    metadataFields = new ItemFields(oRecurSG.Metadata, oRecurSG.MetadataSchema);
                    strMetadataValue = metadataFields[strNameoftheMetaTag].ToString();
                    if (strMetadataValue != "")
                    {
                        metadataFields = new ItemFields(oRecurSG.Metadata, oRecurSG.MetadataSchema);
                        strMetadataValue = metadataFields[strNameoftheMetaTag].ToString();
                    }
                    else
                    {
                        oParentSG = oRecurSG.OrganizationalItem;
                        return RenderParentSGRoot(oParentSG, strNameoftheMetaTag);
                    }
                }
                else
                {
                    oParentSG = oRecurSG.OrganizationalItem;
                    return RenderParentSGRoot(oParentSG, strNameoftheMetaTag);
                }
            }
            return strMetadataValue;
        }

        private string getMainHeading(Page page)
        {
            string strVal = "";
            if (page.Metadata != null)
            {
                ItemFields metadataFields = new ItemFields(page.Metadata, page.MetadataSchema);
                if (metadataFields != null)
                {
                    strVal = metadataFields["fhead"].ToString();
                }
            }
            if(strVal == "")
            {
                strVal = RenderParentSGRoot((OrganizationalItem)page.OrganizationalItem,"fhead");
            }
            return strVal;
        }

        private string getSubHeading(Page page)
        {
            string strVal = "";
            if (page.Metadata != null)
            {
                ItemFields metadataFields = new ItemFields(page.Metadata, page.MetadataSchema);
                if (metadataFields != null)
                {
                    strVal = metadataFields["fhead"].ToString();
                }
            }
            if(strVal == "")
            {
                strVal = RenderParentSGRoot((OrganizationalItem)page.OrganizationalItem,"fsubhead");
            }
            return strVal;
        }





    }
}
