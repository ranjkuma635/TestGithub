﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
using System.Web;
using Tridion.ContentManager;
using Tridion.ContentManager.CommunicationManagement;
using Tridion.ContentManager.ContentManagement;
using Tridion.ContentManager.ContentManagement.Fields;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.Publishing;
using Tridion.Extensions.ContentManager.Templating;
using Tridion.ContentManager.Publishing.Rendering;

namespace MDTD.Web.Tridion.BuildingBlocks.Templates
{
    class Navigation : TemplateBase
    {

        StringBuilder strNav = new StringBuilder();
        StringBuilder strNavLoop = new StringBuilder();

        public override void Transform(Engine engine, Package package)
        {
            this.Initialize(engine, package);
            if (this.IsPage())
            {
                Publication publication = this.GetPublication();
                string rootSG = publication.RootStructureGroup.Id;

                strNav.Append("<Root>");
                GetFirstLevelSG(rootSG);
                strNav.Append(strNavLoop.ToString());

                strNav.Append("</Root>");

            }
            m_Package.PushItem("Navigation", m_Package.CreateStringItem(ContentType.Html, strNav.ToString()));
        }


        private void GetFirstLevelSG(string strRootSGID)
        {
            StructureGroup RootSG = m_Engine.GetObject(strRootSGID) as StructureGroup;

            Filter filter = new Filter();
            filter.Conditions["ItemType"] = ItemType.StructureGroup;

            Filter filterpages = new Filter();
            filterpages.Conditions["ItemType"] = ItemType.Page;
            IList<RepositoryLocalObject> listFistLevelStructureGroup = RootSG.GetItems(filter);
            StructureGroup SG;

            Page page;


            //This is the only 000.Page 
            //strNavLoop.Append("<node4 id = \"" + RootSG.Id.ToString() + "\"" + getIndexPage(RootSG.Id.ToString()) + "/>");

            if (listFistLevelStructureGroup.Count > 0)
            {
                foreach (RepositoryLocalObject RepositoryLocalObject in listFistLevelStructureGroup)
                {
                    SG = m_Engine.GetObject(RepositoryLocalObject.Id) as StructureGroup;

                    if (SG.Title.Contains("."))
                    {
                        strNavLoop.Append("<node title = \"" + ReplaceCdata(SG.Title.ToString()) + "\" id = \"" + SG.Id.ToString() + "\"" + getIndexPage(SG.Id.ToString()) + getMetaDataSG(SG) + ">");
                        IList<RepositoryLocalObject> listPages = SG.GetItems(filterpages);

                        if (listFistLevelStructureGroup.Count == 0)
                        {
                            foreach (RepositoryLocalObject RepositoryLocalObjectpages in listPages)
                            {
                                if (RepositoryLocalObjectpages.Title.Contains("."))
                                {
                                    page = m_Engine.GetObject(RepositoryLocalObjectpages.Id) as Page;
                               }
                            }
                        }
                        else
                        {
                            GetFirstLevelSG(SG.Id.ToString());
                        }
                        strNavLoop.Append("</node>");
                    }
                }
            }
            else
            {
                SG = m_Engine.GetObject(strRootSGID) as StructureGroup;
                IList<RepositoryLocalObject> listPages1 = SG.GetItems(filterpages);
                foreach (RepositoryLocalObject RepositoryLocalObjectpages in listPages1)
                {
                    if (RepositoryLocalObjectpages.Title.Contains("."))
                    {
                        page = m_Engine.GetObject(RepositoryLocalObjectpages.Id) as Page;
                        strNavLoop.Append("<node pageid = \"" + page.Id.ToString() + "\" page = \"" + page.FileName + ".aspx" + "\" url = \"" + ReplaceURL(page.PublishLocationPath) + "\" name = \"" + ReplaceCdata(page.Title.ToString()) + "\"" + getMetaDataPage(page) + "/>");
                    }

                }
            }
        }

        private string getIndexPage(string strSG)
        {
            Page page;
            ItemFields metadataFieldspage;

            Filter filter = new Filter();
            filter.Conditions["ItemType"] = ItemType.Page;

            string strMetaURL = "";
            string strHTML = "";
            StructureGroup SG;
            SG = m_Engine.GetObject(strSG) as StructureGroup;

            IList<RepositoryLocalObject> listPages = SG.GetItems(filter);

            foreach (RepositoryLocalObject RepositoryLocalObjectpages in listPages)
            {
                if (RepositoryLocalObjectpages.Title.StartsWith("000"))
                {
                    page = m_Engine.GetObject(RepositoryLocalObjectpages.Id) as Page;

                    if (page.Metadata != null)
                    {
                        metadataFieldspage = new ItemFields(page.Metadata, page.MetadataSchema);
                        if (metadataFieldspage != null)
                        {
                            if (metadataFieldspage["furi"].ToString() != "")
                            {
                                Page p = m_Engine.GetObject(metadataFieldspage["furi"].ToString()) as Page;
                                strMetaURL = p.PublishLocationUrl;
                            }
                        }
                    }

                    if (SG.Directory != "")
                        if(strMetaURL != "")
                            strHTML = " name = \"" + ReplaceCdata(page.Title.ToString()) + "\"  pageid = \"" + page.Id.ToString() + "\" url = \"" + ReplaceURL(strMetaURL) + "\"";
                        else
                            strHTML = " name = \"" + ReplaceCdata(page.Title.ToString()) + "\"  pageid = \"" + page.Id.ToString() + "\" url = \"" + ReplaceURL(page.PublishLocationPath) + "\"";
                }
            }
            return strHTML;
        }

        private string getMetaDataSG(StructureGroup sg)
        {
            string strHtml;
            string strClass = "";
            string strFriendlyTitle;
            strFriendlyTitle = sg.Title.Split('.')[1].ToString().Trim();
        
            if (sg.Metadata != null)
            {

                ItemFields metadataFields = new ItemFields(sg.Metadata, sg.MetadataSchema);
                if (metadataFields != null)
                {
                    strClass = metadataFields["fClass"].ToString();
                    if (!string.IsNullOrEmpty(metadataFields["ffriendlytitle"].ToString()))
                    {
                        strFriendlyTitle = ReplaceCdata(metadataFields["ffriendlytitle"].ToString());
                    }
                }
            }

            strHtml = " Class = \"" + strClass + "\" displaytitle = \"" + ReplaceCdata(strFriendlyTitle) + "\"";

            return strHtml;

        }


        private string GetDatafromSG(StructureGroup sg, string strType)
        {

            string strVal = "";

            if (sg.Metadata != null)
            {
                ItemFields metadataFields = new ItemFields(sg.Metadata, sg.MetadataSchema);
                if (metadataFields != null)
                {
                    strVal = metadataFields[strType].ToString();
                }
            }
            return strVal;

        }

        private string Getpage(Page page, string strType)
        {

            string strVal = "";

            if (page.Metadata != null)
            {
                ItemFields metadataFields = new ItemFields(page.Metadata, page.MetadataSchema);
                if (metadataFields != null)
                {
                    strVal = metadataFields[strType].ToString();
                }
            }
            return strVal;

        }

        private string ReplaceCdata(string cdata)
        {

            string decode = cdata;

            decode = decode.Replace("&", "&amp;amp;");

            return decode;

        }

        private string ReplaceURL(string strURL)
        {
            string url = strURL;
            url = url.Replace("\\", "/");
            return url;

        }

        private string getMetaDataPage(Page page)
        {
            string strHtml;
            string strURL = "";
            string strTitle = "";
            string sclass = "";
            string strFriendlyTitle = ReplaceCdata(page.Title.Split('.')[1].ToString().Trim()); 

            StructureGroup SG;

            if (page.Metadata != null)
            {
                ItemFields metadataFields = new ItemFields(page.Metadata, page.MetadataSchema);
                if (metadataFields != null)
                {
                    strURL = metadataFields["furl"].ToString();
                    strTitle = metadataFields["ftitle"].ToString();
                    sclass = metadataFields["fClass"].ToString();
                    if (!string.IsNullOrEmpty(metadataFields["ffriendlytitle"].ToString()))
                    {
                        strFriendlyTitle = ReplaceCdata(metadataFields["ffriendlytitle"].ToString());
                    }
                }
            }
            strHtml = " exturl = \"" + strURL + "\"  linktitle  = \"" + strTitle + "\" class  = \"" + sclass + "\" displaytitle = \"" + strFriendlyTitle + "\"";
            return strHtml;
        }
    }
}
