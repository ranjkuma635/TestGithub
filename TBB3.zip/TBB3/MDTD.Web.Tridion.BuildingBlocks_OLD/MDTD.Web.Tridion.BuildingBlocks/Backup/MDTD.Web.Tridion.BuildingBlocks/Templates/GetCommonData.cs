﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
using System.Web;
using Tridion.ContentManager;
using Tridion.ContentManager.CommunicationManagement;
using Tridion.ContentManager.ContentManagement;
using Tridion.ContentManager.ContentManagement.Fields;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.Publishing;
using Tridion.Extensions.ContentManager.Templating;
using Tridion.ContentManager.Publishing.Rendering;

namespace MDTD.Web.Tridion.BuildingBlocks.Templates
{
    [TcmTemplateTitle("Get Common Data")]
    class GetCommonData : TemplateBase 
    {
        public override void Transform(Engine engine, Package package)
        {
            this.Initialize(engine, package);
            Page page = GetPage();
            StructureGroup RootSG = (StructureGroup)page.OrganizationalItem as StructureGroup;
            m_Package.PushItem("StructureGroup", m_Package.CreateStringItem(ContentType.Text, RootSG.Id.ToString()));
            m_Package.PushItem("publicationurl", m_Package.CreateStringItem(ContentType.Text, getPubURL(page)));
            m_Package.PushItem("publicationid", m_Package.CreateStringItem(ContentType.Text, getPubID(page)));
            m_Package.PushItem("MainHeading", m_Package.CreateStringItem(ContentType.Text, getMainHeading(page)));
            m_Package.PushItem("SubHeading", m_Package.CreateStringItem(ContentType.Text, getSubHeading(page)));

        }
        private string getPubURL(Page page)
        {
            string pub = "tcm:0-" + page.Id.PublicationId + "-1";
            Publication publication;
            publication = m_Engine.GetObject(pub) as Publication;
            return publication.PublicationUrl.ToString();
        }

        private string getPubID(Page page)
        {
            string pub = "tcm:0-" + page.Id.PublicationId + "-1";
            Publication publication;
            publication = m_Engine.GetObject(pub) as Publication;
            return publication.Id.ToString().Split('-')[1].ToString();  
        }


        private string RenderParentSGRoot(OrganizationalItem oRecurSG, string strNameoftheMetaTag)
        {
            OrganizationalItem oParentSG;
            string strMetadataValue = "";
            ItemFields metadataFields;

            if (oRecurSG != null)
            {
                if (oRecurSG.Metadata != null)
                {
                    metadataFields = new ItemFields(oRecurSG.Metadata, oRecurSG.MetadataSchema);
                    strMetadataValue = metadataFields[strNameoftheMetaTag].ToString();
                    if (strMetadataValue != "")
                    {
                        metadataFields = new ItemFields(oRecurSG.Metadata, oRecurSG.MetadataSchema);
                        strMetadataValue = metadataFields[strNameoftheMetaTag].ToString();
                    }
                    else
                    {
                        oParentSG = oRecurSG.OrganizationalItem;
                        return RenderParentSGRoot(oParentSG, strNameoftheMetaTag);
                    }
                }
                else
                {
                    oParentSG = oRecurSG.OrganizationalItem;
                    return RenderParentSGRoot(oParentSG, strNameoftheMetaTag);
                }
            }
            return strMetadataValue;
        }

        private string getMainHeading(Page page)
        {
            string strVal = "";
            if (page.Metadata != null)
            {
                ItemFields metadataFields = new ItemFields(page.Metadata, page.MetadataSchema);
                if (metadataFields != null)
                {
                    strVal = metadataFields["fhead"].ToString();
                }
            }
            if(strVal == "")
            {
                strVal = RenderParentSGRoot((OrganizationalItem)page.OrganizationalItem,"fhead");
            }
            return strVal;
        }

        private string getSubHeading(Page page)
        {
            string strVal = "";
            if (page.Metadata != null)
            {
                ItemFields metadataFields = new ItemFields(page.Metadata, page.MetadataSchema);
                if (metadataFields != null)
                {
                    strVal = metadataFields["fhead"].ToString();
                }
            }
            if(strVal == "")
            {
                strVal = RenderParentSGRoot((OrganizationalItem)page.OrganizationalItem,"fsubhead");
            }
            return strVal;
        }




    }
}
