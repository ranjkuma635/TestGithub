﻿using System;
using System.Collections.Generic;
using Tridion.ContentManager.Templating.Assembly;

namespace MDTD.Web.Templating.BuildingBlocks.Templates
{
    [TcmTemplateTitle("Navigation XML")]
    public class Navigation : Emaar.Web.Tridion.System.Navigation
    {
        private List<String> mFields;
        private List<String> mLinks;


        public Navigation()
            : base()
        {
            mLinks = new List<String>();
            //mLinks.Add("hero");
            //mLinks.Add("writecallout");
            //mLinks.Add("subscription");
        }

        protected override bool IncludeMetadata(String FieldName)
        {
            return true;
        }

        protected override bool AsComponentLink(String FieldName)
        {
            return true;
        }
    }
}
