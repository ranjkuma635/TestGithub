﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml;
using System.IO;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.ContentManagement.Fields;
using Tridion.Extensions.ContentManager.Templating;
using Tridion.ContentManager.ContentManagement;
using Emaar.Web.Tridion.System.Extensions;
using Tridion.ContentManager.Publishing;
using System.Text.RegularExpressions;
using Tridion.ContentManager;

namespace MDTD.Web.Templating.BuildingBlocks.Templates
{

    [TcmTemplateTitle("DCPItem")]
    public class DCPItem : TemplateBase
    {
        //<summary>
        //Transforms the current component.
        //</summary>
        //<param name="engine">The engine.</param>
        //<param name="package">The package.</param>
        public override void Transform(Engine engine, Package package)
        {
            ItemFields gmaplocation;
            ItemFields addtocalandar;
            ItemFields socialmedia;
            string strPublishDate = string.Empty;
            string strStartDate = string.Empty;
            string strEndDate = string.Empty;
            string year = string.Empty;
            string month = string.Empty;

            try
            {
                base.Transform(engine, package);



                using (StringWriter sw = new StringWriter())
                {

                    using (XmlTextWriter xml = new XmlTextWriter(sw))
                    {
                        string itemId = Component.Id;

                        if (Component != null)
                        {
                            #region "MDTD - Quiz DCP"
                            /* Start of MDTD - Quiz DCP */
                            if (Component.Schema.Title.Equals("MDTD - Quiz"))
                            {
                                DateTime startDate = Component.DateMetaValue("publishdate");

                                if (startDate.ToString("dd/MM/yyyy") != "01/01/0001")
                                {
                                    strStartDate = startDate.ToString("dd/MM/yyyy");
                                    year = startDate.ToString("yyyy");
                                    month = startDate.ToString("MM");
                                }

                                xml.WriteStartElement("item");

                                xml.WriteAttributeString("uri", Component.Id);
                                xml.WriteAttributeString("id", itemId.Split('-')[1]);
                                xml.WriteAttributeString("schema", Component.Schema.Title.Split('-')[1].TrimStart().Replace(" ", ""));
                                xml.WriteAttributeString("title", Component.StringValue("title"));
                                xml.WriteAttributeString("publishDate", strStartDate);
                                xml.WriteAttributeString("sortDate", GetSortDate(strStartDate));
                                xml.WriteAttributeString("year", year);
                                xml.WriteAttributeString("month", month);

                                xml.WriteElementString("question", Component.StringValue("question"));
                                xml.WriteElementString("description", Component.StringValue("answer"));

                                foreach (ItemFields fields in Component.EmbeddedValues("option"))
                                {
                                    xml.WriteStartElement("option");
                                    xml.WriteAttributeString("value", fields.StringValue("value"));
                                    xml.WriteAttributeString("result", fields.StringValue("result"));
                                    xml.WriteEndElement();
                                }

                                xml.WriteEndElement();//item
                            }

                            /* End of MDTD - Quiz DCP*/
                            #endregion

                            #region "MDTD - Attractions/Art/Hotel/Spa DCP"
                            /* Start of MDTD - Attractions DCP */
                            if (Component.Schema.Title.Equals("MDTD - Attractions") ||
                                Component.Schema.Title.Equals("MDTD - Art") ||
                                Component.Schema.Title.Equals("MDTD - Hotel") ||
                                Component.Schema.Title.Equals("MDTD - Spa"))
                            {
                                DateTime startDate = Component.DateMetaValue("publishdate");

                                if (startDate.ToString("dd/MM/yyyy") != "01/01/0001")
                                {
                                    strStartDate = startDate.ToString("dd/MM/yyyy");
                                    year = startDate.ToString("yyyy");
                                    month = startDate.ToString("MM");
                                }

                                xml.WriteStartElement("item");

                                xml.WriteAttributeString("uri", Component.Id);
                                xml.WriteAttributeString("id", itemId.Split('-')[1]);
                                xml.WriteAttributeString("schema", Component.Schema.Title.Split('-')[1].TrimStart().Replace(" ", ""));
                                xml.WriteAttributeString("category", Component.Schema.Title.Split('-')[1].TrimStart().Replace(" ", ""));
                                xml.WriteAttributeString("publishDate", strStartDate);
                                xml.WriteAttributeString("sortDate", GetSortDate(strStartDate));
                                xml.WriteAttributeString("year", year);
                                xml.WriteAttributeString("month", month);

                                xml.WriteAttributeString("title", Component.StringValue("title"));
                                if (!String.IsNullOrEmpty(Component.StringMetaValue("showonhome")))
                                    xml.WriteAttributeString("showonhome", Component.StringMetaValue("showonhome"));
                                if (!String.IsNullOrEmpty(Component.StringMetaValue("book")))
                                    xml.WriteAttributeString("bookurl", Component.StringMetaValue("book"));
                                xml.WriteAttributeString("mood", String.Join(",", Component.KeywordMetaValues("mood").Select(kw => kw.Title)));
                                xml.WriteAttributeString("liketodo", String.Join(",", Component.KeywordMetaValues("liketodo").Select(kw => kw.Title)));
                                //xml.WriteAttributeString("category", String.Join(",", Component.KeywordMetaValues("liketodo").Select(kw => kw.Title)));
                                xml.WriteAttributeString("goingwith", String.Join(",", Component.StringMetaValues("goingwith")));
                                xml.WriteAttributeString("sortcriteria", String.Join(",", Component.StringMetaValues("sortcriteria")));
                                xml.WriteAttributeString("calloutimage", PublishBinary(Component.ComponentMetaValue("calloutimage")));

                                xml.WriteAttributeString("frequency", Component.StringValue("frequency"));
                                xml.WriteAttributeString("time", Component.StringValue("time"));
                                xml.WriteAttributeString("location", Component.StringValue("location"));
                                xml.WriteAttributeString("contacttext", Component.StringValue("contacttext"));
                                xml.WriteAttributeString("contactnumber", Component.StringValue("contactnumber"));
                                xml.WriteAttributeString("price", Component.StringValue("price"));
                                xml.WriteAttributeString("description", Component.StringValue("description"));

                                socialmedia = Component.EmbeddedValue("socialmedia");
                                if (socialmedia != null)
                                {
                                    if (!String.IsNullOrEmpty(socialmedia.StringValue("facebook")))
                                        xml.WriteAttributeString("facebook", socialmedia.StringValue("facebook"));

                                    if (!String.IsNullOrEmpty(socialmedia.StringValue("twitter")))
                                        xml.WriteAttributeString("twitter", socialmedia.StringValue("twitter"));

                                    if (!String.IsNullOrEmpty(socialmedia.StringValue("instagram")))
                                        xml.WriteAttributeString("instagram", socialmedia.StringValue("instagram"));
                                }

                                gmaplocation = Component.EmbeddedValue("gmaplocation");
                                if (gmaplocation != null)
                                {
                                    xml.WriteAttributeString("mapurl", gmaplocation.StringValue("mapurl"));
                                    xml.WriteAttributeString("gdtext", gmaplocation.StringValue("gdtext"));
                                    xml.WriteAttributeString("getdirections", gmaplocation.StringValue("getdirections"));
                                }

                                xml.WriteAttributeString("funfactimg", PublishBinary(Component.ComponentValue("funfactimg")));

                                foreach (ItemFields gallery in Component.EmbeddedValues("gallery"))
                                {
                                    xml.WriteStartElement("gallery");
                                    if (!String.IsNullOrEmpty(gallery.StringValue("videourl")))
                                        xml.WriteAttributeString("videourl", gallery.StringValue("videourl"));
                                    if (gallery.ComponentValue("image") != null)
                                        xml.WriteAttributeString("image", PublishBinary(gallery.ComponentValue("image")));
                                    if (!String.IsNullOrEmpty(gallery.StringValue("title")))
                                        xml.WriteAttributeString("title", gallery.StringValue("title"));
                                    if (!String.IsNullOrEmpty(gallery.StringValue("date")))
                                        xml.WriteAttributeString("date", gallery.StringValue("date"));
                                    if (!String.IsNullOrEmpty(gallery.StringValue("time")))
                                        xml.WriteAttributeString("time", gallery.StringValue("time"));
                                    if (!String.IsNullOrEmpty(gallery.StringValue("place")))
                                        xml.WriteAttributeString("place", gallery.StringValue("place"));
                                    if (gallery.ComponentValue("logoimage") != null)
                                        xml.WriteAttributeString("logoimage", PublishBinary(gallery.ComponentValue("logoimage")));
                                    xml.WriteEndElement();
                                }


                                foreach (ItemFields image in Component.EmbeddedValues("images"))
                                {
                                    xml.WriteStartElement("thumbimg");
                                    xml.WriteAttributeString("src", PublishBinary(image.ComponentValue("image")));
                                    xml.WriteAttributeString("description", image.StringValue("description"));
                                    xml.WriteEndElement();
                                }

                                foreach (ItemFields button in Component.EmbeddedValues("buttons"))
                                {
                                    try
                                    {
                                        xml.WriteStartElement("button");
                                        xml.WriteAttributeString("flinkText", button.StringValue("flinkText"));
                                        if (button.ComponentValue("fcomponentLink") != null)
                                        {
                                            xml.WriteAttributeString("fcomponentLink", button.ComponentValue("fcomponentLink").Id);
                                            xml.WriteEndElement();
                                        }
                                        if (button.ExternalLinkValue("fexternalLink") != null)
                                        {
                                            xml.WriteAttributeString("fexternalLink", button.ExternalLinkValue("fexternalLink"));
                                            xml.WriteEndElement();
                                        }
                                        if (button.ComponentValue("pdf") != null)
                                        {
                                            xml.WriteAttributeString("pdf", PublishBinary(button.ComponentValue("pdf")));
                                            xml.WriteEndElement();
                                        }
                                    }
                                    catch (Exception ex)
                                    {
                                        throw new Exception("More than one link provided in the component field: Different links (book, special collect, website)");
                                    }
                                }

                                xml.WriteEndElement();//item
                            }

                            /* End of MDTD - Attractions DCP*/
                            #endregion

                            #region "MDTD - Timeline"
                            /*MDTD - Timeline Start*/
                            if (Component.Schema.Title.Equals("MDTD - Timeline"))
                            {
                                DateTime startDate = Component.DateMetaValue("publishdate");


                                if (startDate.ToString("dd/MM/yyyy") != "01/01/0001")
                                {
                                    strStartDate = startDate.ToString("dd/MM/yyyy");
                                    year = startDate.ToString("yyyy");
                                    month = startDate.ToString("MM");
                                }

                                xml.WriteStartElement("item");

                                xml.WriteAttributeString("uri", Component.Id);
                                xml.WriteAttributeString("id", itemId.Split('-')[1]);
                                xml.WriteAttributeString("schema", Component.Schema.Title.Split('-')[1].TrimStart().Replace(" ", ""));
                                xml.WriteAttributeString("publishDate", strStartDate);
                                xml.WriteAttributeString("sortDate", GetSortDate(strStartDate));
                                xml.WriteAttributeString("year", year);
                                xml.WriteAttributeString("month", month);


                                xml.WriteAttributeString("title", Component.StringValue("title"));
                                xml.WriteAttributeString("summary", Component.XHTMLValue("summary"));
                                xml.WriteAttributeString("imagetype", Component.StringValue("imagetype"));
                                xml.WriteAttributeString("image", PublishBinary(Component.ComponentValue("image")));


                                xml.WriteEndElement();//item

                            }
                            /*MDTD - Timeline end*/
                            #endregion

                            #region "MDTD - Leasing"
                            if (Component.Schema.Title.Equals("MDTD - Leasing"))
                            {
                                DateTime startDate = Component.DateMetaValue("publishdate");

                                if (startDate.ToString("dd/MM/yyyy") != "01/01/0001")
                                {
                                    strStartDate = startDate.ToString("dd/MM/yyyy");
                                    year = startDate.ToString("yyyy");
                                    month = startDate.ToString("MM");
                                }
                                xml.WriteStartElement("item");

                                xml.WriteAttributeString("uri", Component.Id);
                                xml.WriteAttributeString("id", itemId.Split('-')[1]);
                                xml.WriteAttributeString("schema", Component.Schema.Title.Split('-')[1].TrimStart().Replace(" ", ""));
                                xml.WriteAttributeString("publishDate", strStartDate);
                                xml.WriteAttributeString("sortDate", GetSortDate(strStartDate));
                                xml.WriteAttributeString("year", year);
                                xml.WriteAttributeString("month", month);

                                xml.WriteAttributeString("buildingname", Component.StringValue("buildingname"));
                                xml.WriteAttributeString("image", PublishBinary(Component.ComponentValue("fimage")));
                                xml.WriteAttributeString("title", Component.StringValue("ftitle"));
                                xml.WriteAttributeString("description", Component.XHTMLValue("fdescription"));
                                xml.WriteAttributeString("link", Component.ExternalLinkValue("flink"));

                                xml.WriteAttributeString("type", Component.StringMetaValue("ftype"));
                                //xml.WriteAttributeString("listingorder", Component.StringMetaValue("flistingorder"));

                                xml.WriteEndElement();//item

                            }

                            #endregion

                            #region "MDTD - Live"
                            if (Component.Schema.Title.Equals("MDTD - Live"))
                            {
                                DateTime startDate = Component.DateMetaValue("publishdate");

                                if (startDate.ToString("dd/MM/yyyy") != "01/01/0001")
                                {
                                    strStartDate = startDate.ToString("dd/MM/yyyy");
                                    year = startDate.ToString("yyyy");
                                    month = startDate.ToString("MM");
                                }
                                xml.WriteStartElement("item");

                                xml.WriteAttributeString("uri", Component.Id);
                                xml.WriteAttributeString("id", itemId.Split('-')[1]);
                                xml.WriteAttributeString("schema", Component.Schema.Title.Split('-')[1].TrimStart().Replace(" ", ""));
                                xml.WriteAttributeString("publishDate", strStartDate);
                                xml.WriteAttributeString("sortDate", GetSortDate(strStartDate));
                                xml.WriteAttributeString("year", year);
                                xml.WriteAttributeString("month", month);

                                xml.WriteAttributeString("buildingname", Component.StringValue("buildingname"));
                                xml.WriteAttributeString("image", PublishBinary(Component.ComponentValue("image")));
                                xml.WriteAttributeString("title", Component.StringValue("title"));
                                xml.WriteAttributeString("description", Component.XHTMLValue("description"));
                                xml.WriteAttributeString("link", Component.ExternalLinkValue("link"));

                                xml.WriteEndElement();//item

                            }

                            #endregion

                            #region "MDTD - Portal Info"
                            if (Component.Schema.Title.Equals("MDTD - Portal Info"))
                            {
                                xml.WriteStartElement("item");

                                xml.WriteAttributeString("uri", Component.Id);
                                xml.WriteAttributeString("id", itemId.Split('-')[1]);
                                xml.WriteAttributeString("schema", Component.Schema.Title.Split('-')[1].TrimStart().Replace(" ", ""));

                                xml.WriteAttributeString("title", Component.XHTMLValue("title"));
                                xml.WriteAttributeString("summary", Component.XHTMLValue("summary"));
                                xml.WriteAttributeString("link", Component.ExternalLinkValue("link"));


                                xml.WriteEndElement();//item

                            }

                            #endregion

                            #region "MDTD - Events"
                            /* Start of MDTD - Events */
                            /*
                            if (Component.Schema.Title.Equals("MDTD - Events"))
                            {
                                DateTime publishDate = Component.DateMetaValue("fpubublishdate");

                                if (publishDate.ToString("dd/MM/yyyy") != "01/01/0001")
                                {
                                    strPublishDate = publishDate.ToString("dd/MM/yyyy");
                                    year = publishDate.ToString("yyyy");
                                    month = publishDate.ToString("MM");
                                }

                                xml.WriteStartElement("item");

                                xml.WriteAttributeString("uri", Component.Id);
                                xml.WriteAttributeString("id", itemId.Split('-')[1]);
                                xml.WriteAttributeString("schema", Component.Schema.Title.Split('-')[1].TrimStart().Replace(" ", ""));
                                xml.WriteAttributeString("publishDate", strPublishDate);
                                xml.WriteAttributeString("sortDate", GetSortDate(strPublishDate));
                                xml.WriteAttributeString("year", year);
                                xml.WriteAttributeString("month", month);
                                xml.WriteAttributeString("title", Component.StringMetaValue("ftitle"));
                                xml.WriteAttributeString("summary", Component.StringValue("fsummary"));
                                xml.WriteAttributeString("description", Component.XHTMLMetaValue("fdescription"));

                                DateTime startDate = Component.DateMetaValue("fstartDate");

                                if (startDate.ToString("dd/MM/yyyy") != "01/01/0001")
                                {
                                    strStartDate = startDate.ToString("dd MMM yyyy");
                                }
                                xml.WriteAttributeString("startdate", strStartDate);

                                DateTime endDate = Component.DateMetaValue("fendDate");

                                if (endDate.ToString("dd/MM/yyyy") != "01/01/0001")
                                {
                                    strEndDate = endDate.ToString("dd MMM yyyy");
                                    xml.WriteAttributeString("enddate", strEndDate);
                                }

                                xml.WriteAttributeString("isfeatured", Component.StringMetaValue("ffeature"));
                                xml.WriteAttributeString("isunderhighlights", Component.StringMetaValue("fHighlights"));
                                xml.WriteAttributeString("location", Component.KeywordMetaValue("flocation").Description);
                                xml.WriteAttributeString("category", Component.KeywordMetaValue("fcategory").Description);
                                xml.WriteAttributeString("isfeaturevideo", Component.StringMetaValue("ffeaturevedio"));

                                xml.WriteAttributeString("organizer", Component.StringValue("forganiser"));
                                xml.WriteAttributeString("volunteer", Component.StringValue("fvolunteer"));
                                xml.WriteAttributeString("mapimage", PublishBinary(Component.ComponentValue("fmap")));
                                xml.WriteAttributeString("website", Component.StringValue("fweb"));
                                xml.WriteAttributeString("calloutimage", PublishBinary(Component.ComponentMetaValue("calloutimage")));

                                socialmedia = Component.EmbeddedValue("socialmedia");
                                if (socialmedia != null)
                                {
                                    if (!String.IsNullOrEmpty(socialmedia.StringValue("facebook")))
                                        xml.WriteAttributeString("facebook", socialmedia.StringValue("facebook"));

                                    if (!String.IsNullOrEmpty(socialmedia.StringValue("twitter")))
                                        xml.WriteAttributeString("twitter", socialmedia.StringValue("twitter"));

                                    if (!String.IsNullOrEmpty(socialmedia.StringValue("instagram")))
                                        xml.WriteAttributeString("instagram", socialmedia.StringValue("instagram"));
                                }

                                gmaplocation = Component.EmbeddedValue("gmaplocation");
                                if (gmaplocation != null)
                                {
                                    xml.WriteAttributeString("mapurl", gmaplocation.StringValue("mapurl"));
                                    xml.WriteAttributeString("gdtext", gmaplocation.StringValue("gdtext"));
                                    xml.WriteAttributeString("getdirections", gmaplocation.StringValue("getdirections"));
                                }

                                foreach (ItemFields gallery in Component.EmbeddedValues("gallery"))
                                {
                                    xml.WriteStartElement("gallery");
                                    if (!String.IsNullOrEmpty(gallery.StringValue("videourl")))
                                        xml.WriteAttributeString("videourl", gallery.StringValue("videourl"));
                                    if (gallery.ComponentValue("image") != null)
                                        xml.WriteAttributeString("image", PublishBinary(gallery.ComponentValue("image")));
                                    if (!String.IsNullOrEmpty(gallery.StringValue("title")))
                                        xml.WriteAttributeString("title", gallery.StringValue("title"));
                                    if (!String.IsNullOrEmpty(gallery.StringValue("date")))
                                        xml.WriteAttributeString("date", gallery.StringValue("date"));
                                    if (!String.IsNullOrEmpty(gallery.StringValue("time")))
                                        xml.WriteAttributeString("time", gallery.StringValue("time"));
                                    if (!String.IsNullOrEmpty(gallery.StringValue("place")))
                                        xml.WriteAttributeString("place", gallery.StringValue("place"));
                                    if (gallery.ComponentValue("logoimage") != null)
                                        xml.WriteAttributeString("logoimage", PublishBinary(gallery.ComponentValue("logoimage")));
                                    xml.WriteEndElement();
                                }

                                foreach (ItemFields charge in Component.EmbeddedValues("fcharge"))
                                {
                                    xml.WriteElementString("entrycharge", charge.StringValue("ftext"));
                                }

                                foreach (ItemFields open in Component.EmbeddedValues("fopen"))
                                {
                                    xml.WriteElementString("openinghours", open.StringValue("ftext"));
                                }

                                foreach (ItemFields contact in Component.EmbeddedValues("fcontact"))
                                {
                                    xml.WriteElementString("contact", contact.StringValue("ftext"));
                                }

                                foreach (ItemFields parking in Component.EmbeddedValues("fparking"))
                                {
                                    xml.WriteElementString("parking", parking.StringValue("ftext"));
                                }

                                foreach (ItemFields pdf in Component.EmbeddedValues("fpdf"))
                                {
                                    xml.WriteElementString("pdfs", PublishBinary(pdf.ComponentValue("fimage")));
                                }

                                addtocalandar = Component.EmbeddedMetaValue("addtocalander");
                                if (addtocalandar != null)
                                {
                                    xml.WriteStartElement("calandar");
                                    startDate = addtocalandar.DateValue("startdate");

                                    if (startDate.ToString("dd/MM/yyyy") != "01/01/0001")
                                    {
                                        strStartDate = startDate.ToString("yyyy-MM-dd HH:mm:ss");
                                    }
                                    xml.WriteAttributeString("startdate", strStartDate);

                                    endDate = addtocalandar.DateValue("enddate");

                                    if (endDate.ToString("dd/MM/yyyy") != "01/01/0001")
                                    {
                                        strEndDate = endDate.ToString("yyyy-MM-dd HH:mm:ss");
                                        xml.WriteAttributeString("enddate", strEndDate);
                                    }

                                    xml.WriteAttributeString("timezone", addtocalandar.StringValue("timezone"));
                                    xml.WriteAttributeString("title", addtocalandar.StringValue("title"));
                                    xml.WriteAttributeString("summary", addtocalandar.StringValue("summary"));
                                    xml.WriteAttributeString("location", addtocalandar.StringValue("location"));
                                    xml.WriteAttributeString("organizer", addtocalandar.StringValue("organizer"));
                                    xml.WriteAttributeString("organizeremail", addtocalandar.StringValue("organizeremail"));

                                    xml.WriteEndElement();
                                }

                                xml.WriteEndElement();//item
                            }
                             */

                            /* End of MDTD - Events*/
                            #endregion

                            Package.AddXml(Package.OutputName, sw.ToString());
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                gmaplocation = null;
                socialmedia = null;
            }
        }





        private static string getHtml(string html)
        {
            return Utility.removeXHTMLtags(html);
        }


        private string GetSortDate(string strDate)
        {

            string strRetval = "";


            string[] datetime = strDate.Split(new char[] { '/' });

            string Year = datetime[2];
            string Month = datetime[1];
            string Day = datetime[0];

            if (Month.Length == 1)
                Month = "0" + Month;

            if (Day.Length == 1)
                Day = "0" + Day;

            strRetval = Year + Month + Day;

            return strRetval;

        }

        public bool checkshouldpublish(string metaval)
        {
            bool shouldadd = true;
            if (Engine.PublishingContext.PublicationTarget.Id.ToString() == "tcm:0-16-65537")
            {
                if (metaval == "Yes")
                    shouldadd = false;
            }
            return shouldadd;
        }


        public string GetYouTubeImage(string videoUrl)
        {
            int mInd = videoUrl.IndexOf("/v/");
            if (mInd < 0) { mInd = videoUrl.IndexOf("?v="); }
            if (mInd != -1)
            {
                string strVideoCode = videoUrl.Substring(videoUrl.IndexOf("?v=") + 3);
                int ind = strVideoCode.IndexOf("?");
                strVideoCode = strVideoCode.Substring(0, ind == -1 ? strVideoCode.Length : ind);
                return "https://img.youtube.com/vi/" + strVideoCode + "/hqdefault.jpg";
            }
            else
                return "not provided";
        }

    }
}
