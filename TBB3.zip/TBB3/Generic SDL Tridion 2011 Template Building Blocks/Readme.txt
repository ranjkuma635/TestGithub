README.txt

Tridion.Extensions.ContentManager.Templating.dll

These TBBs have been compiled and tested with SDL Tridion 2011 GA

- Force Unique Binary Filenames
- Get Breadcrumb
- Get Component Template Uris
- Get Design Elements
- Get Linked Components
- Get System Components
- Group Components by Template Type
- Template Base


