﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Tridion.ContentManager.CommunicationManagement;
using Tridion.ContentManager.Templating.Assembly;

namespace Tridion.Extensions.ContentManager.Templating
{
    /// <summary>
    /// This TBB iterates up the Structure Group hierarchy to create an HTML Breadcrumb 
    /// trail and add it to the package (named item: 'Breadcrumb')
    /// If a page has filename 'index' then the page title will not be shown in the breadcrumb
    /// The template can be used with parameters schemas which specify format strings
    /// for the link items and the page itself. The default formatters are as follows:
    /// BreadcrumbPattern : <li><a href=\"{0}\">{1}</a></li>
    /// BreadcrumbPatternPage : <li>{0}</li>
    /// </summary>
    [TcmTemplateTitle("Get Breadcrumb Trail")]
    public class GetBreadcrumb : TemplateBase
    {
        public override void Transform(Tridion.ContentManager.Templating.Engine engine, Tridion.ContentManager.Templating.Package package)
        {
            this.Initialize(engine, package);
            Page page = this.GetPage();
            
            //Check if this is an index page - if it is the format of the breadcrumb changes
            bool isIndex = false;
            if (page.FileName=="index")
                isIndex = true;

            //Read format strings from the package - if none there, use defaults
            String pattern = package.GetValue("BreadcrumbPattern");
            String pagePattern = package.GetValue("BreadcrumbPatternPage");

            if (pattern == null)
                pattern = "<li><a href=\"{0}\">{1}</a></li>";
				
            if (pagePattern == null)
                pagePattern = "<li>{0}</li>";

            //Create the final (non-link) part of the breadcrumb
            String result = "";
            //For section (index) pages we do not show the page title
            if (!isIndex)
                result = String.Format(pagePattern,this.GetPageTitle(page));

            //Loop up through all the parent Structure Groups writing them out as links
            StructureGroup sg = page.OrganizationalItem as StructureGroup;
            while (sg != null)
            {
                string title = this.GetStructureGroupTitle(sg);
                //First time round check if this is an index page, if not the title is shown plain text
                if (!isIndex)
                {
                    result = String.Format(pattern, sg.PublishLocationUrl, title) + result;
                }
                else
                {
                    result = String.Format(pagePattern, title);
                }
                sg = sg.OrganizationalItem as StructureGroup;
                isIndex = false;
            }
            package.PushItem("Breadcrumb", package.CreateHtmlItem(result));
        }
    }
}
