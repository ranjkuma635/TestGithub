﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Tridion.ContentManager.ContentManagement;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager;
using System.Xml;

namespace Tridion.Extensions.ContentManager.Templating
{
    /// <summary>
    /// Reads all components from a folder and pushes them into a package. 
    /// This is useful if you have system/configuration components in a 
    /// certain folder, which you want to reference in your templates
    /// (for example labels)
    /// </summary>
    [TcmTemplateTitle("Get System Components")]
    public class GetSystemComponents : TemplateBase
    {
        public override void Transform(Tridion.ContentManager.Templating.Engine engine, Tridion.ContentManager.Templating.Package package)
        {
            this.Initialize(engine, package);
            string sysfolderuri = package.GetValue("SystemComponentFolderWebdavUrl");            
            
            if (!String.IsNullOrEmpty(sysfolderuri))
            {
                if(!sysfolderuri.ToLower().StartsWith("/webdav/"))
                {
                    sysfolderuri = this.GetPublication().RootFolder.WebDavUrl + sysfolderuri;
                }
                if (!this.PushFromContextVariable(sysfolderuri))
                {
                    Dictionary<string,Item> items = new Dictionary<string,Item>();
                    Logger.Info(String.Format("Trying to access system folder: {0}",sysfolderuri));
                    try
                    {
                        Folder folder = engine.GetObject(sysfolderuri) as Folder;
                        foreach (KeyValuePair<TcmUri,string> item in GetOrganizationalItemContents(folder, ItemType.Component, false))
                        {
                            string title = item.Value;
                            if (!items.ContainsKey(title))
                                items.Add(title,package.CreateTridionItem(ContentType.Component, item.Key));
                        }
                    }
                    catch (Exception ex)
                    {
                        string msg = String.Format("Error in AddSystemComponents TBB: Error Reading system configuration folder {0}: {1}", sysfolderuri, ex.Message);
                        Logger.Error(msg);
                        throw new Exception(msg);
                    }
                    this.PushAndAddToContextVariables(items,sysfolderuri);
                }
            }
            this.PutMainComponentOnTop();
        }

        
    }

}
