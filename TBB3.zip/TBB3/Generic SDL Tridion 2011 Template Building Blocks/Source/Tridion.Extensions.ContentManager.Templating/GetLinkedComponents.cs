using System;
using System.Collections.Generic;
using System.Text;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.ContentManagement.Fields;
using Tridion.ContentManager;
using Tridion.ContentManager.CommunicationManagement;
using Tridion.ContentManager.ContentManagement;
using System.IO;

namespace Tridion.Extensions.ContentManager.Templating
{
    #region Prologue
    /// <summary>
    ///   AddLinkedComponentsToPackage
    /// </summary>
    /// <author>Will Price: will.price@sdltridion.com</author>
    /// <date>11/24/2008 20:33:37</date>

    //Unless explicitly acquired and licensed from Licensor under another
    //license, the contents of this file are subject to the Reciprocal Public
    //License ("RPL") Version 1.5, or subsequent versions as allowed by the RPL,
    //and You may not copy or use this file in either source code or executable
    //form, except in compliance with the terms and conditions of the RPL.

    //All software distributed under the RPL is provided strictly on an "AS
    //IS" basis, WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED, AND
    //LICENSOR HEREBY DISCLAIMS ALL SUCH WARRANTIES, INCLUDING WITHOUT
    //LIMITATION, ANY WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
    //PURPOSE, QUIET ENJOYMENT, OR NON-INFRINGEMENT. See the RPL for specific
    //language governing rights and limitations under the RPL.

    #endregion

    /// <summary>
    /// This TBB will push all linked components into the package. 
    /// This is useful for writing out linked images metadata (captions etc.) 
    /// and also links to linked components (getting the linked component heading field etc.)
    /// Finally if it finds an MM component which has a schema which is the same
    /// as the configured _flashSchemaTitle (default is <i>Flash</i>) then it will
    /// add this as a binary to the package, and add the resolved url with a 
    /// package name of the MM item postfixed with the _flashUrlPostfix
    /// 
    /// </summary>
    [TcmTemplateTitle("Get Linked Components")]
    public class GetLinkedComponents : TemplateBase
    {

        private string _flashSchemaTitle = "Flash";
        private string _flashUrlPostfix = "Url";

        #region ITemplate Members
        public override void Transform(Engine engine, Package package)
        {
            this.Initialize(engine, package);

            if (IsPageTemplate)
            {
                //Add linked components from metadata
                Logger.Info("Scanning Page Metadata for link fields...");
                AddLinkedComponents(GetContextItemFields(true), "MetaData.");
            }
            else
            {
                //Add both linked components from standard schema and metadata fields
                Logger.Info("Scanning Component for link fields...");
                AddLinkedComponents(GetContextItemFields(false), "");
                this.PutMainComponentOnTop();
                Logger.Info("Scanning Component Metadata for link fields...");
                AddLinkedComponents(GetContextItemFields(true), "MetaData.");
            }
            //The last thing we do is put the Component item back on top of the package (some other 
            //TBBs like SiteEdit rely on this)
            this.PutMainComponentOnTop();
        }

        #endregion

        /// <summary>
        /// Add linked components to the package from the given fields
        /// </summary>
        /// <param name="fields">The ItemFields to search for component links</param>
        /// <param name="packageKeyPostfix">Postfix to add to package item name</param>
        private void AddLinkedComponents(ItemFields fields, string packageKeyPrefix)
        {
            if (fields != null)
            {
                foreach (ItemField itemField in fields)
                {
                    if (itemField is ComponentLinkField)
                    {
                        ComponentLinkField field = itemField as ComponentLinkField;
                        Item item = null;
                        if (field.Definition.MaxOccurs == 1 && field.Value != null)
                        {
                            //If the field is single value, add it to the package as a component
                            Logger.Info("Found single value link field: " + field.Name);
                            item = m_Package.CreateTridionItem(ContentType.Component, field.Value.Id);
                            AddFlash(field.Value, packageKeyPrefix + field.Name);
                        }
                        else
                        {
                            //Otherwise create a uri list of all values
                            IList<TcmUri> uriList = new List<TcmUri>();
                            int i = 0;
                            foreach (Component linkedComp in field.Values)
                            {
                                uriList.Add(linkedComp.Id);
                                AddFlash(linkedComp, packageKeyPrefix + field.Name + i);
                                Logger.Info("Title: " + linkedComp.Title);
                                i++;
                            }
                            if (uriList.Count > 0)
                            {
                                Logger.Info("Found multivalue link field: " + field.Name);
                                item = m_Package.CreateComponentUriListItem(ContentType.ComponentArray, uriList);
                            }

                        }
                        if (item != null)
                            m_Package.PushItem(packageKeyPrefix + field.Name, item);
                    }
                    else if (itemField is EmbeddedSchemaField)
                    {
                        EmbeddedSchemaField field = itemField as EmbeddedSchemaField;
                        if (field.Definition.MaxOccurs == 1 && field.Value != null)
                        {
                            ItemFields embeddedFields = field.Value;
                            string prefix = itemField.Name + ".";
                            if (!String.IsNullOrEmpty(packageKeyPrefix))
                            {
                                prefix = packageKeyPrefix + prefix;
                                Logger.Info("Prefix: " + prefix);
                            }
                            AddLinkedComponents(embeddedFields, prefix);
                        }
                        else
                        {
                            int i = 0;
                            foreach (ItemFields embeddedFields in field.Values)
                            {
                                string prefix = itemField.Name + i + ".";
                                if (!String.IsNullOrEmpty(packageKeyPrefix))
                                {
                                    prefix = packageKeyPrefix + prefix;
                                    Logger.Info("Prefix: " + prefix);
                                }
                                AddLinkedComponents(embeddedFields, prefix);
                                i++;
                            }
                        }

                    }
                }
            }
        }

        /// <summary>
        /// Get the ItemFields for the context item
        /// </summary>
        /// <returns></returns>
        private ItemFields GetContextItemFields(bool meta)
        {
            ItemFields fields = null;
            if (IsPageTemplate)
            {
                Page page = this.GetPage();
                if (page != null && page.Metadata != null)
                {
                    fields = new ItemFields(page.Metadata, page.MetadataSchema);
                }
            }
            else
            {
                Component comp = this.GetComponent();
                if (comp != null)
                {
                    if (meta)
                    {
                        if (comp.Metadata != null)
                            fields = new ItemFields(comp.Metadata, comp.MetadataSchema);
                    }
                    else
                        fields = new ItemFields(comp.Content, comp.Schema);
                }
            }
            return fields;
        }
        
        private void AddFlash(Component comp, string urlItemName)
        {
            if (comp.ComponentType == ComponentType.Multimedia && comp.Schema.Title == _flashSchemaTitle)
            {
                MemoryStream ms = new MemoryStream();
                comp.BinaryContent.WriteToStream(ms);
                string filename = this.GetFilename(comp.BinaryContent.Filename);
                Logger.Debug(String.Format("Adding flash binary to package: {0}", filename));
                string res = m_Engine.AddBinary(comp.Id, TcmUri.UriNull, null, ms.ToArray(), filename);
                Logger.Debug(String.Format("Adding flash binary url to package. {0}: {1}", urlItemName + _flashUrlPostfix, res));
                m_Package.PushItem(urlItemName + _flashUrlPostfix, m_Package.CreateStringItem(ContentType.Text, res));
            }
        }
    }
}
