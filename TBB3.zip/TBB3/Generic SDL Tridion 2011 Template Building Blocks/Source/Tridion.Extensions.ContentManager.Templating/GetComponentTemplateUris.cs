﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Tridion.ContentManager.ContentManagement;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager;
using System.Xml;
using Tridion.Extensions.ContentManager.Templating;
using comm = Tridion.ContentManager.CommunicationManagement;

namespace Tridion.Extensions.ContentManager.Templating
{
    /// <summary>
    /// Add all component templates with uri to package. This is useful if you want to 
    /// render a specific CP from within a template, and want to refer to it by name
    /// The package item name is made from the template title with spaces removed, 
    /// prefixed with 'ComponentTemplate'. For example the uri for template with title
    /// 'Article Summary', is pushed into package as item 'ComponentTemplateArticleSummary'
    /// </summary>
    [TcmTemplateTitle("Get Component Template Uris")]
    public class GetComponentTemplateUris : TemplateBase
    {
        private const string PACKAGE_ITEM_PREFIX = "ComponentTemplate";

        public override void Transform(Engine engine, Package package)
        {
            this.Initialize(engine, package);

            //Push global package items (from cache if available)
            if (!this.PushFromContextVariable("GetComponentTemplateUris"))
            {
                Dictionary<string, Item> items = new Dictionary<string, Item>();
                comm.Publication pub = this.GetPublication();
                Filter filter = new Filter();
                filter.Conditions.Add("ItemType", ItemType.ComponentTemplate);
                filter.Conditions.Add("Recursive", true);
                foreach (XmlElement item in pub.GetListItems(filter))
                {
                    string title = item.Attributes["Title"].Value;
                    string id = item.Attributes["ID"].Value;
                    string componentTemplateTitle = String.Concat(PACKAGE_ITEM_PREFIX, title.Replace(" ", "").Trim());
                    
                    //It is possible that there are 2 templates with the same name - in which case we skip it with a warning
                    if (!items.ContainsKey(componentTemplateTitle))
                    {
                        items.Add(componentTemplateTitle, m_Package.CreateStringItem(ContentType.Text, id));
                    }
                    else
                    {
                        Logger.Warning(String.Format("Template with non-unique name found: {0} - this is skipped!", componentTemplateTitle));
                    }
                }
                this.PushAndAddToContextVariables(items, "GetComponentTemplateUris");
            }

        }
    }
}
