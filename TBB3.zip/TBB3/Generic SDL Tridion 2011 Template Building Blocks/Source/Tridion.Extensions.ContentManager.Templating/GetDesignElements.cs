﻿using System;
using System.Collections.Generic;
using System.Text;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.CommunicationManagement;
using Tridion.ContentManager;
using Tridion.ContentManager.ContentManagement;
using System.IO;

namespace Tridion.Extensions.ContentManager.Templating
{
    /// <summary>
    /// TBB used to publish website resources (css,js, design images+flash etc.) preserving
    /// the structure in which they have been uploaded to the CMS
    /// 
    /// NOTE: for this TBB to work properly you need to:
    /// 
    /// 1. Create the SG structure required to publish the resources into (so if you have a js folder,
    /// you need a js SG (the TBB uses the current page SG as the root to publish into)
    /// 
    /// 2. Pass the webdav url of the root folder containing the resources in as a parameter to this TBB
    /// (SystemComponentFolderWebdavUrl). This can be relative to the root folder (recommended - for publication independence)
    /// 
    /// </summary>
    [TcmTemplateTitle("Get Design Elements")]
    public class GetDesignElements : TemplateBase
    {
        #region ITemplate Members
        
        public override void Transform(Engine engine, Package package)
        {
            this.Initialize(engine, package);
            Page page = this.GetPage();

            //Set the root SG based on the current page
            string rootSGWebDavUrl = page.OrganizationalItem.WebDavUrl;

            //Locate the root folder to find images etc.
            Folder folder = null;
            string sysfolderuri = package.GetValue("DesignFolderWebdavUrl");
            if (sysfolderuri == null)
            {
                sysfolderuri = this.GetPublication().RootFolder.WebDavUrl + "/System/Design";
            }
            else
            {
                if (!sysfolderuri.ToLower().StartsWith("/webdav/"))
                {
                    sysfolderuri = this.GetPublication().RootFolder.WebDavUrl + sysfolderuri;
                }
            }
            Logger.Info(String.Format("Trying to access system folder: {0}", sysfolderuri));
            folder = engine.GetObject(sysfolderuri) as Folder;
            if (folder==null)
            {
                string msg = String.Format("System folder {0} does not exist", sysfolderuri);
                Logger.Error(msg);
                throw new Exception(msg);
            }
            Logger.Info(String.Format("Processing root folder: {0} ({1})", folder.Title, folder.Id));
            
            //Recursively add binaries from the folder and its subfolders
            AddBinariesFromFolder(rootSGWebDavUrl, folder, "");

            this.PutMainComponentOnTop();
        }
       
        #endregion
    }
}
