﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Tridion.ContentManager.CommunicationManagement;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.Templating;

namespace Tridion.Extensions.ContentManager.Templating
{
    /// <summary>
    /// This TBB will put the unique Id of images back to their filename to avoid image name clashes. 
    /// Should be added to a component template before the Default Finish Actions
    /// Originally created by Chris Summers (www.urbancherry.net)
    /// </summary>
    [TcmTemplateTitle("Force Unique Binary Filenames")]
    public class ForceUniqueBinaryFilenames : TemplateBase
    {
        public override void Transform(Tridion.ContentManager.Templating.Engine engine, Tridion.ContentManager.Templating.Package package)
        {
			this.Initialize(engine, package);
            foreach (Item item in m_Package.GetAllByType(new ContentType("*/*")))
            {

                if(item.Properties.ContainsKey(Item.ItemPropertyTcmUri) && item.Properties.ContainsKey(Item.ItemPropertyFileName))
                {
                    string suffix= item.Properties[Item.ItemPropertyTcmUri].Replace(":", "");
                    item.Properties[Item.ItemPropertyFileNameSuffix] = "_"+suffix;
                }
            }            
        }
    }
}
