﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Xml;
using System.IO;
using System.Web;
using Tridion.ContentManager;
using Tridion.ContentManager.CommunicationManagement;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Expression;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.Templating.Dreamweaver;
using Tridion;
using Tridion.ContentManager.ContentManagement.Fields;
using Tridion.Extensions.ContentManager.Templating;
using Publishing = Tridion.ContentManager.Publishing.Rendering;
using Tridion.ContentManager.ContentManagement;
using Tridion.ContentManager.Publishing.Rendering;
using System.Text.RegularExpressions;
using Emaar.Web.Tridion.System.Extensions;
using Emaar.Web.Tridion.System.Dreamweaver_Extension;

namespace Palace.Web.Templating.BuildingBlocks.Templates {
    [TcmTemplateTitle("ComponentDetailControl")]
    public class ComponentDetailControl : Emaar.Web.Tridion.System.ControlTemplate {
        /// <summary>
        /// Transforms the current component.
        /// </summary>
        /// <param name="engine">The engine.</param>
        /// <param name="package">The package.</param>
        public override void Transform(Engine engine, Package package) {

           // base.Transform(engine, package);

            mEngine = engine;
            mPackage = package;

            Emaar.Web.Tridion.System.Dreamweaver_Extension.Templating controlTag = new Emaar.Web.Tridion.System.Dreamweaver_Extension.Templating();

            string strItemId = Component.Id.ToString();
            string strPubid = Component.Id.PublicationId.ToString();

            string strDetailControl = "tcm:" + strPubid + "-12680-2";

            OrganizationalItem detailControlFolder = engine.GetObject(strDetailControl) as OrganizationalItem;

            IList<Component> compList = detailControlFolder.Components(true);
            foreach (Component comp in compList)  {
                if (comp != null && comp.Schema.Title.Equals("User Controls") && comp.Title.Equals("Apartment Detail Control")) {
                    package.AddString("ItemID", strItemId);
                    //Package.AddHtml(Package.OutputName, controlTag.GetControlTag(comp));
                }
            }
        }
    }
}