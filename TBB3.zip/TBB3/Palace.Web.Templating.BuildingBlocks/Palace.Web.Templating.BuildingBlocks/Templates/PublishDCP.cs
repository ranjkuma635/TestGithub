﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager;
using Tridion.ContentManager.ContentManagement;
using Emaar.Web.Tridion.System.Extensions;
using Tridion.Extensions.ContentManager.Templating;

namespace Palace.Web.Templating.BuildingBlocks.Templates
{
    [TcmTemplateTitle("Publish Attached DCP")]
    public class PublishDCP : TemplateBase
    {
        public override void Transform(Engine engine, Package package)
        {
            base.Transform(engine, package);
            IComponentPresentationList componentPresentations = package.ItemAsComponentList(Package.ComponentsName);

            foreach (ComponentPresentation componentPresentation in componentPresentations) {
                Component component = GetComponent(componentPresentation.ComponentUri);
                String schemaTitle = component.Schema.Title;
                Logger.Info(schemaTitle);
                if (component != null){
                    switch (schemaTitle) {
                        case "PALACE - Hotel":
                        case "PALACE - Room":
                        case "PALACE - Apartment":
                        case "PALACE - Residence Amenity":
                        case "PALACE - Residence":
                        case "PALACE - Restaurent":
                        case "PALACE - Spa":
                        case "PALACE - Treatment":
                        case "PALACE - Event":
                        case "PALACE - Offering":
                        case "PALACE - Location":
                        case "PALACE - Amenity":
                        case "PALACE - Offer":
                            engine.RenderComponentPresentation(component.Id, new TcmUri(111593, ItemType.ComponentTemplate, Publication.Id.ItemId));
                            break;
                        default:
                            break;
                    }
                }

            }
            
        }
    }
}
