﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Xml;
using System.IO;
using Tridion.ContentManager;
using Tridion.ContentManager.CommunicationManagement;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Expression;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.Templating.Dreamweaver;
using Tridion;
using Tridion.ContentManager.ContentManagement.Fields;
using Tridion.Extensions.ContentManager.Templating;
using Publishing = Tridion.ContentManager.Publishing.Rendering;
using Tridion.ContentManager.ContentManagement;
using Tridion.ContentManager.Publishing.Rendering;
using System.Text.RegularExpressions;
using Emaar.Web.Tridion.System.Extensions;

namespace Palace.Web.Templating.BuildingBlocks.Templates
{
    [TcmTemplateTitle("ImageGallery")]
    public class ImageGallery : TemplateBase {
        /// <summary>
        /// Transforms the current component.
        /// </summary>
        /// <param name="engine">The engine.</param>
        /// <param name="package">The package.</param>
        public override void Transform(Engine engine, Package package) {
            int i = 1;

            base.Transform(engine, package);

            Engine m_Engine;
            m_Engine = engine;

            string strPubid = Component.Id.PublicationId.ToString();

            string strHotel = "tcm:" + strPubid + "-4394-2";

            OrganizationalItem HotelsFolder = m_Engine.GetObject(strHotel) as OrganizationalItem;

            using (StringWriter sw = new StringWriter()) {
                using (XmlTextWriter xml = new XmlTextWriter(sw))  {
                    xml.WriteStartElement("list");
                    IList<Component> components = HotelsFolder.Components(true);
                    foreach (Component comp in components) {
                        if (comp.Schema.Title.Equals("PALACE - Hotel") || comp.Schema.Title.Equals("PALACE - Room")) {
                            Filter f = new Filter();
                            f.Conditions["ItemType"] = ItemType.Component;
                            
                            xml.WriteStartElement("item");
                            xml.WriteAttributeString("id", comp.Id);

                            xml.WriteAttributeString("hotel", comp.KeywordMetaValue("hotel").Description);
                            xml.WriteAttributeString("hotelId", comp.KeywordMetaValue("hotel").Key);
                            
                            IList<ItemFields> gallery = comp.EmbeddedValues("gallery");
                            foreach (ItemFields galleryModule in gallery) {
                                if (galleryModule.StringValue("type").Equals("Image")) {
                                Component imageComp = galleryModule.ComponentValue("component");
                                xml.WriteStartElement("module");
                                xml.WriteAttributeString("type", "image");
                                xml.WriteAttributeString("src", "/images/editorial/gallery/0.png");
                                xml.WriteAttributeString("data-src", PublishBinary(imageComp));
                                xml.WriteAttributeString("thumbnil", GenerateThumbnail(imageComp,"fthumb", 96, 79));
                                xml.WriteAttributeString("altText", imageComp.StringMetaValue("altText"));
                                xml.WriteEndElement(); //module
                                }
                   
                            }

                            xml.WriteEndElement();//item
                        }
                    }
                    xml.WriteEndElement();//list
                }
                Package.AddXml(Package.OutputName, sw.ToString());
            }
        }
    }
}
