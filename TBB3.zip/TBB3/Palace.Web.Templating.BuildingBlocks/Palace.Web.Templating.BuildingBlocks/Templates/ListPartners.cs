﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Linq;
using System.Linq;
using System.Xml;
using System.IO;
using Tridion.ContentManager;
using Tridion.ContentManager.CommunicationManagement;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Expression;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.Templating.Dreamweaver;
using Tridion;
using Tridion.ContentManager.ContentManagement.Fields;
using Tridion.Extensions.ContentManager.Templating;
using Publishing = Tridion.ContentManager.Publishing.Rendering;
using Tridion.ContentManager.ContentManagement;
using Tridion.ContentManager.Publishing.Rendering;
using System.Text.RegularExpressions;
using Emaar.Web.Tridion.System.Extensions;

namespace Palace.Web.Templating.BuildingBlocks.Templates
{
    [TcmTemplateTitle("ListPartners")]
    public class ListPartners : TemplateBase
    {
        /// <summary>
        /// Transforms the current component.
        /// </summary>
        /// <param name="engine">The engine.</param>
        /// <param name="package">The package.</param>
        public override void Transform(Engine engine, Package package)
        {
            int i = 1;

            base.Transform(engine, package);

            Engine m_Engine;
            m_Engine = engine;

            string strPubid = Component.Id.PublicationId.ToString();

            string strNews = "tcm:" + strPubid + "-12822-2";

            OrganizationalItem PartnersFolder = m_Engine.GetObject(strNews) as OrganizationalItem;

            using (StringWriter sw = new StringWriter())
            {
                using (XmlTextWriter xml = new XmlTextWriter(sw))
                {
                    xml.WriteStartElement("list");

                    i = 1;
                    IList<Component> newsList = PartnersFolder.Components(true);
                    foreach (Component comp in newsList)
                    {
                        if (comp.Schema.Title.Equals("PALACE - Callout Block"))
                        {
                            if (comp.Title.Split('.').Length > 1)
                            {
                                Filter filter = new Filter();
                                filter.Conditions["ItemType"] = ItemType.Component;
                                xml.WriteStartElement("item");
                                xml.WriteAttributeString("No", i.ToString());
                                xml.WriteAttributeString("id", comp.Id);
                                xml.WriteAttributeString("heading", comp.StringValue("heading"));
                                xml.WriteAttributeString("description", comp.StringValue("description"));
                                Component image = comp.ComponentValue("image");
                                if (image != null)
                                {
                                    xml.WriteAttributeString("src", GenerateThumbnail(image, "", 272, 259));
                                    xml.WriteAttributeString("altText", image.StringMetaValue("altText"));
                                }
                                ItemFields link = comp.EmbeddedValue("link");
                                if (link != null)
                                {
                                    xml.WriteAttributeString("linkText", link.StringValue("linkText"));
                                    xml.WriteAttributeString("externalLink ", link.ExternalLinkValue("externalLink"));
                                }

                                i++;
                                xml.WriteEndElement();
                            }
                        }
                    }

                    xml.WriteEndElement(); //list                
                }

                Package.AddXml(Package.OutputName, sw.ToString());
            }
        }
    }
}

