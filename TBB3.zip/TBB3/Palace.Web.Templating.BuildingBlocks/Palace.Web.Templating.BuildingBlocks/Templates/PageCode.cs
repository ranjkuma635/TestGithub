﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using Tridion.ContentManager;
using Tridion.ContentManager.CommunicationManagement;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Expression;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.Templating.Dreamweaver;
using Tridion;
using Tridion.ContentManager.ContentManagement.Fields;
using Tridion.Extensions.ContentManager.Templating;
using Publishing = Tridion.ContentManager.Publishing.Rendering;
using Tridion.ContentManager.ContentManagement;
using Tridion.ContentManager.Publishing.Rendering;
using System.Text.RegularExpressions;
using Emaar.Web.Tridion.System.Extensions;
using Emaar.Web.Tridion.System.Dreamweaver_Extension;
using System.Xml;

namespace Palace.Web.Templating.BuildingBlocks.Templates
{
    [TcmTemplateTitle("PageCode")]
    public class PageCode : TemplateBase
    {

        public override void Transform(Engine engine, Package package)
        {
            base.Transform(engine, package);
            int compId;
            string codeOutput = "";

            StructureGroup sg = Page.OrganizationalItem as StructureGroup;

            if (sg.KeywordMetaValue("fhotelName") == null)
            {
                sg = sg.OrganizationalItem as StructureGroup;
            }


            if (sg != null && sg.KeywordMetaValue("fhotelName") != null)
            {

                string schemaTitle = Page.ComponentPresentations[0].Component.Schema.Title;
                string compTitle = "";
                if (Page.ComponentPresentations.Count > 1)
                {
                    compTitle = Page.ComponentPresentations[1].Component.Title;
                }

                if (schemaTitle.Equals("PALACE - Hotel") || schemaTitle.Equals("PALACE - Room") || compTitle.Equals("Hotel Room List Control"))
                {

                    switch (sg.KeywordMetaValue("fhotelName").Key)
                    {
                        case "16954":
                            compId = 45988;
                            break;
                        case "17147":
                            compId = 45986;
                            break;
                        case "17035":
                            compId = 115574;
                            break;
                        default:
                            compId = 0;
                            break;
                    }
                    if (compId != 0)
                    {
                        TcmUri tcmuri = new TcmUri(compId, ItemType.Component, Publication.Id.ItemId);
                        Component component = new Component(tcmuri, engine.GetSession());
                        codeOutput = component.StringValue("content");
                        Logger.Info("code" + codeOutput);
                        package.AddXhtml("codeOutput", codeOutput);
                    }
                }
            }
        }
    }
}
