﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Xml;
using System.IO;
using Tridion.ContentManager;
using Tridion.ContentManager.CommunicationManagement;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Expression;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.Templating.Dreamweaver;
using Tridion;
using Tridion.ContentManager.ContentManagement.Fields;
using Tridion.Extensions.ContentManager.Templating;
using Publishing = Tridion.ContentManager.Publishing.Rendering;
using Tridion.ContentManager.ContentManagement;
using Tridion.ContentManager.Publishing.Rendering;
using System.Text.RegularExpressions;
using Emaar.Web.Tridion.System.Extensions;

namespace Palace.Web.Templating.BuildingBlocks.Templates
{
    [TcmTemplateTitle("LatestNews")]
    public class LatestNews : TemplateBase
    {
        /// <summary>
        /// Transforms the current component.
        /// </summary>
        /// <param name="engine">The engine.</param>
        /// <param name="package">The package.</param>
        public override void Transform(Engine engine, Package package) {
            int i = 1;

            base.Transform(engine, package);
            
            Engine  m_Engine;
            m_Engine = engine;

            string strPubid = Component.Id.PublicationId.ToString();
            string strCondition = Component.StringValue("box");

            string strNews= "tcm:"+strPubid+"-4394-2";
   
            OrganizationalItem NewsFolder = m_Engine.GetObject(strNews) as OrganizationalItem;

            using (StringWriter sw = new StringWriter()) {
                using (XmlTextWriter xml = new XmlTextWriter(sw)) {
                    xml.WriteStartElement("list");

                        i = 1;
                        IList<Component> newsList = NewsFolder.Components(true);
                        foreach (Component comp in newsList) {
                            if (comp.Schema.Title.Equals("PALACE - News")) {
                                Filter filter = new Filter();
                                filter.Conditions["ItemType"] = ItemType.Component;
                                string publishedDate = comp.DateMetaValue("publishedDate").ToString();

                                if (CheckShouldAdd(publishedDate, strCondition) && comp.StringMetaValue("show").Equals("Yes")){
                                    xml.WriteStartElement("news");
                                    xml.WriteAttributeString("No", i.ToString());
                                    xml.WriteAttributeString("id", comp.Id);
                                    xml.WriteElementString("title", comp.StringValue("title"));
                                    xml.WriteElementString("publishedDate", comp.DateMetaValue("publishedDate").ToString("dd/MM/yyyy"));
                                    xml.WriteElementString("summary", comp.StringValue("summary"));

                                    Component image = comp.ComponentValue("image");
                                    if (image != null) {
                                        xml.WriteElementString("image", PublishBinary(image));
                                        xml.WriteElementString("altText", image.StringMetaValue("altText"));
                                    }
                                 
                                    i++;
                                    xml.WriteEndElement(); //news
                                }
                            }
                        }
                    
                    xml.WriteEndElement(); //list              
                }

                Package.AddXml(Package.OutputName, sw.ToString());
            }
        }

        private bool CheckShouldAdd(string strDate, string strCondition) {
            bool retval = false;

            var today = DateTime.Today;
            var lastMonthDate = new DateTime(today.Year, today.Month-1, today.Day);
            
            if (strCondition.Equals("week")) {
                if (TridionDateToDateTime(strDate) >= DateTime.Now.AddDays(-7))
                    return true;
            }
            else if (strCondition.Equals("month")){
                if (TridionDateToDateTime(strDate) >= lastMonthDate)
                    return true;
            }

            return retval;
        }


        private static DateTime TridionDateToDateTime(string TridionDate) {
            try
            {
                string[] datetime = TridionDate.Split(new char[] { 'T' });
                string[] ymd = datetime[0].Split(new char[] { '-' });
                string[] hms = datetime[1].Split(new char[] { ':' });
                return new DateTime(int.Parse(ymd[0]), int.Parse(ymd[1]), int.Parse(ymd[2]));
            }
            catch
            {
                return DateTime.Now;
            }

        }

    }
}
