﻿using System;
using System.Text;
using Tridion.ContentManager.Templating;
using System.Text.RegularExpressions;
using Emaar.Web.Tridion.System.Extensions;

namespace Palace.Web.Templating.BuildingBlocks.Templates{
    public static class Utility {

             /// <summary>
        /// Log an error message
        /// </summary>
        /// <param name="format">Message format string</param>
        /// <param name="args">Format string parameters</param>
        public static string removeXHTMLtags(string format) {
            return format.Replace(" xmlns=" + "\"" + "http://www.w3.org/1999/xhtml" + "\"", "");
        }

        public static string removeParagraphs(string format)
        {
            format = format.Replace(" xmlns=" + "\"" + "http://www.w3.org/1999/xhtml" + "\"", "");
            if(format.EndsWith("</p>"))  {
                format = format.Replace("</p>","...</p>");
                return format;
            }
            else {
                format=format+"...</p>";
                return format;
            }
        }
    }
}
