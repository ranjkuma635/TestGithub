﻿using System;
using System.Collections.Generic;
using System.Linq;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.ContentManagement;
using Emaar.Web.Tridion.System.Extensions;

namespace Palace.Web.Templating.BuildingBlocks.Templates
{
    [TcmTemplateTitle("DetailControl")]
    public class DetailControl : Emaar.Web.Tridion.System.ControlTemplate {
        /// <summary>
        /// Transforms the current component.
        /// </summary>
        /// <param name="engine">The engine.</param>
        /// <param name="package">The package.</param>
        public override void Transform(Engine engine, Package package) {

           // base.Transform(engine, package);

            mEngine = engine;
            mPackage = package;

            Emaar.Web.Tridion.System.Dreamweaver_Extension.Templating controlTag = new Emaar.Web.Tridion.System.Dreamweaver_Extension.Templating();

            string strItemId = Component.Id.ToString();
            string strPubid = Component.Id.PublicationId.ToString();

            String detailXSLT="";
            String itemId = "";

            String componentID = Component.Id;

            switch (Component.Schema.Title) {
                case "PALACE - Room":
                    detailXSLT = "roomDetail.xslt";
                    break;
                case "PALACE - Residence":
                    detailXSLT = "residenceDetail.xslt";
                    break;
                case "PALACE - Spa":
                    detailXSLT = "spaDetail.xslt";
                    break;
                case "PALACE - Hotel":
                    detailXSLT = "hotelDetail.xslt";
                    break;
                case "PALACE - Offer":
                    detailXSLT = "offerDetail.xslt";
                    break;
                case "PALACE - Event Venue":
                    detailXSLT = "eventVenueDetail.xslt";
                    break;
                case "PALACE - Event":
                    detailXSLT = "eventDetail.xslt";
                    break;
                case "PALACE - Amenity":
                    detailXSLT = "amenityDetail.xslt";
                    break;
                case "PALACE - Restaurent":
                    detailXSLT = "dineDetail.xslt";
                    break;
                case "PALACE - Treatment":
                    detailXSLT = "treatmentDetail.xslt";
                    break;
                case "PALACE - Offering":
                    detailXSLT = "offeringDetail.xslt";
                    break;
                case "PALACE - Location":
                    detailXSLT = "locationDetail.xslt";
                    break;
                case "PALACE - Apartment":
                    detailXSLT = "stayDetail.xslt";
                    break;
                case "PALACE - Residence Amenity":
                    detailXSLT = "residenceAmenityDetail.xslt";
                    break;
                case "PALACE - News":
                    detailXSLT = "newsDetail.xslt";
                    break;
            }

            itemId = componentID;

            string strDetailControl = "tcm:" + strPubid + "-12680-2";

            OrganizationalItem detailControlFolder = engine.GetObject(strDetailControl) as OrganizationalItem;

            IList<Component> compList = detailControlFolder.Components(true);
            foreach (Component comp in compList)  {
                if (comp != null && comp.Schema.Title.Equals("User Controls") && comp.Title.Equals("Detail Control")) {
                    package.AddValue(ContentType.String,"ItemID", itemId);
                    package.AddValue(ContentType.String,"detailXSLT", detailXSLT);
                    //Package.AddHtml(Package.OutputName, controlTag.GetControlTag(comp));
                }
            }
        }
    }
}