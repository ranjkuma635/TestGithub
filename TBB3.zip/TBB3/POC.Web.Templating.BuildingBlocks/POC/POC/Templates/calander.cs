﻿using System.Collections.Generic;
using System.Xml;
using System.IO;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.Extensions.ContentManager.Templating;
using Publishing = Tridion.ContentManager.Publishing.Rendering;
using Tridion.ContentManager.ContentManagement;
using Emaar.Web.Tridion.System.Extensions;
using Tridion.ContentManager.ContentManagement.Fields;

namespace POC.Web.Templating.BuildingBlocks.Templates
{
    public class calander : TemplateBase
    {

        public override void Transform(Engine engine, Package package)
        {

            base.Transform(engine, package);

            Engine m_Engine;
            m_Engine = engine;

            string strPubid = Page.ComponentPresentations[0].Component.Id.PublicationId.ToString();


            string strNews = "tcm:" + strPubid + "-9620-2";
            string strEvents = "tcm:" + strPubid + "-9621-2";
            string strCal = "tcm:" + strPubid + "-9622-2";

            OrganizationalItem NewsFolder = m_Engine.GetObject(strNews) as OrganizationalItem;
            OrganizationalItem EventsFolder = m_Engine.GetObject(strEvents) as OrganizationalItem;
            //OrganizationalItem CalenderFolder = m_Engine.GetObject(strCal) as OrganizationalItem;

            OrganizationalItem CalenderFolder = Page.ComponentPresentations[0].Component.OrganizationalItem as OrganizationalItem;

            


            string strActive = string.Empty;
            base.Transform(engine, package);
            using (StringWriter sw = new StringWriter())
            {
                using (XmlTextWriter xml = new XmlTextWriter(sw))
                {
                    IList<Component> componentscalenderlist = Component.OrganizationalItem.Components(true);
                    //IList<Component> componentscalenderlist = CalenderFolder.Components(true);
                    xml.WriteStartElement("calendar");
                    foreach (Component componentscalender in componentscalenderlist)
                    {
                        xml.WriteStartElement("data");
                        if (componentscalender.Schema.Title.Equals("eServiceCalendar"))
                        {
                            xml.WriteElementString("GUID", componentscalender.Id.ToString());
                            xml.WriteElementString("CalendarTitle", componentscalender.StringValue("calendartitle"));
                            xml.WriteElementString("CalendarDescription", componentscalender.XHTMLValue("calendardescription").Replace("xmlns=\"http://www.w3.org/1999/xhtml\"", ""));
                            
                            xml.WriteElementString("CalendarDatesFrom", componentscalender.DateValue("calendardatesfrom").ToString("MM/dd/yyyy"));
                            xml.WriteElementString("CalendarEventTo", componentscalender.DateValue("calendareventTo").ToString("MM/dd/yyyy"));

                            xml.WriteElementString("CreatedDate", componentscalender.CreationDate.ToString("MM/dd/yyyy"));
                            xml.WriteElementString("ModifiedDate", componentscalender.RevisionDate.ToString("MM/dd/yyyy"));
                            xml.WriteElementString("Eventsdetail", componentscalender.XHTMLValue("eventsdetal").Replace("xmlns=\"http://www.w3.org/1999/xhtml\"", ""));
                             
                        }
                        xml.WriteEndElement();

                    }
                    xml.WriteEndElement();

                }

                package.AddXml(Package.OutputName, sw.ToString());

            }


        }

    }
}
