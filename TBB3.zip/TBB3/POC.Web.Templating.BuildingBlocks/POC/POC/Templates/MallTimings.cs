﻿using System.Collections.Generic;
using System.Xml;
using System.IO;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.Extensions.ContentManager.Templating;
using Publishing = Tridion.ContentManager.Publishing.Rendering;
using Tridion.ContentManager.ContentManagement;
using Emaar.Web.Tridion.System.Extensions;
using Tridion.ContentManager.ContentManagement.Fields;
using System;

namespace POC.Web.Templating.BuildingBlocks.Templates
{
    public class MallTimings : TemplateBase
    {
        public override void Transform(Engine engine, Package package)
        {

            base.Transform(engine, package);

            base.Transform(engine, package);
            using (StringWriter sw = new StringWriter())
            {
                using (XmlTextWriter xml = new XmlTextWriter(sw))
                {

                    IList<Component> componentsnews = Component.OrganizationalItem.Components(true);

                    xml.WriteStartElement("data");
                    xml.WriteStartElement("malltimings");
                    foreach (Component component in componentsnews)
                    {

                        xml.WriteStartElement("store");

                        if (component.Schema.Title.Equals("eServiceMalltimings"))
                        {

                            xml.WriteElementString("CorrespondsTo", component.StringValue("CorrespondsTo"));
                            xml.WriteElementString("DaysTime", component.StringValue("DaysTime"));
                            xml.WriteElementString("description", component.XHTMLValue("description").Replace("xmlns=\"http://www.w3.org/1999/xhtml\"", ""));
                            DateTime creationDate = component.CreationDate;
                            DateTime revisionDate = component.RevisionDate;
                            xml.WriteElementString("createddate", creationDate.ToString("dd/MM/yyyy"));
                            xml.WriteElementString("modifieddate", revisionDate.ToString("dd/MM/yyyy"));
                        }
                        xml.WriteEndElement();

                    }
                    xml.WriteEndElement();
                    xml.WriteEndElement();


                }

                package.AddXml(Package.OutputName, sw.ToString());

            }


        }

        private string GetSortDate(string strDate)
        {

            string strRetval = "";


            string[] datetime = strDate.Split(new char[] { '/' });

            string Year = datetime[2];
            string Month = datetime[1];
            string Day = datetime[0];

            if (Month.Length == 1)
                Month = "0" + Month;

            if (Day.Length == 1)
                Day = "0" + Day;

            strRetval = Year + Month + Day;

            return strRetval;

        }

    }

}

