﻿using System.Collections.Generic;
using System.Xml;
using System.IO;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.Extensions.ContentManager.Templating;
using Publishing = Tridion.ContentManager.Publishing.Rendering;
using Tridion.ContentManager.ContentManagement;
using Emaar.Web.Tridion.System.Extensions;
using Tridion.ContentManager.ContentManagement.Fields;


namespace POC.Web.Templating.BuildingBlocks.Templates 
{
    public class POC : TemplateBase
    {
        public override void Transform(Engine engine, Package package)
        { 
        
            string strActive = string.Empty;
            base.Transform(engine, package);
            using (StringWriter sw = new StringWriter())
            {
                using (XmlTextWriter xml = new XmlTextWriter(sw))
                {
                    xml.WriteStartElement("data");

                    Component component = Page.ComponentPresentations[0].Component;

                    if (component.Content != null)
                    {

                        xml.WriteElementString("title", component.StringValue("title"));

                        Component iconImage = component.ComponentValue("images");
                        if (iconImage != null && iconImage.BinaryContent != null)
                        {
                            xml.WriteElementString("image", PublishBinary(iconImage));
                        }

                        xml.WriteElementString("description", component.XHTMLValue("description"));

                        xml.WriteElementString("informationtitle", component.StringValue("informationtitle"));

                        xml.WriteStartElement("contact");

                            ItemFields fields = new ItemFields(component.Content, component.Schema);
                            EmbeddedSchemaField emb = (EmbeddedSchemaField)fields["contactinfor"];

                            foreach (ItemFields embeddedfields in emb.Values)
                            {
                                xml.WriteElementString("number", embeddedfields.StringValue("call"));
                                xml.WriteElementString("email", embeddedfields.StringValue("email"));
                                xml.WriteElementString("website", embeddedfields.ExternalLinkValue("website"));
                            }

                        xml.WriteEndElement();

                        xml.WriteElementString("additionainformation", component.XHTMLValue("additionalinfor"));
                    
                    }

                    xml.WriteEndElement();
                }

                package.AddXml(Package.OutputName, sw.ToString());
            }
        }
    }
}
