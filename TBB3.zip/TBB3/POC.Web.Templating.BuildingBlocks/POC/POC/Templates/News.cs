﻿using System.Collections.Generic;
using System.Xml;
using System.IO;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.Extensions.ContentManager.Templating;
using Publishing = Tridion.ContentManager.Publishing.Rendering;
using Tridion.ContentManager.ContentManagement;
using Emaar.Web.Tridion.System.Extensions;
using Tridion.ContentManager.ContentManagement.Fields;

namespace POC.Web.Templating.BuildingBlocks.Templates 
{
    public class News : TemplateBase 
    {
        public override void Transform(Engine engine, Package package)
        {

            base.Transform(engine, package);

            Engine m_Engine;
            m_Engine = engine;

            string strPubid = Page.ComponentPresentations[0].Component.Id.PublicationId.ToString();


            string strNews = "tcm:" + strPubid + "-9620-2";
            string strEvents = "tcm:" + strPubid + "-9621-2";
            string strCal = "tcm:" + strPubid + "-9622-2";

            OrganizationalItem NewsFolder = m_Engine.GetObject(strNews) as OrganizationalItem;
            OrganizationalItem EventsFolder = m_Engine.GetObject(strEvents) as OrganizationalItem;
            OrganizationalItem CalenderFolder = m_Engine.GetObject(strCal) as OrganizationalItem;



            string strActive = string.Empty;
            base.Transform(engine, package);
            using (StringWriter sw = new StringWriter())
            {
                using (XmlTextWriter xml = new XmlTextWriter(sw))
                {

                    IList<Component> componentsnews = Component.OrganizationalItem.Components(true);
                    xml.WriteStartElement("news");
                    foreach (Component componentnews in componentsnews)
                    {
                        xml.WriteStartElement("data");
                        if (componentnews.Schema.Title.Equals("eServiceNews"))
                        {
                            Component newslogo = componentnews.ComponentValue("logo");
                            if (newslogo != null && newslogo.BinaryContent != null)
                            {
                                xml.WriteElementString("NewsLogo", PublishBinary(newslogo));
                            }

                            xml.WriteElementString("GUID", componentnews.Id.ToString());
                            xml.WriteElementString("MallName", componentnews.StringValue("mallname"));
                            xml.WriteElementString("Subject", componentnews.StringValue("subject"));
                            xml.WriteElementString("NewsTitle", componentnews.StringValue("newstitle"));
                            xml.WriteElementString("NewsDate", componentnews.DateValue("newsdate").ToString("dd/MM/yyyy"));
                            xml.WriteElementString("NewsBrief", componentnews.XHTMLValue("newsbrief").Replace("xmlns=\"http://www.w3.org/1999/xhtml\"", ""));
                            xml.WriteElementString("NewsDescription", componentnews.XHTMLValue("newsdescription").Replace("xmlns=\"http://www.w3.org/1999/xhtml\"", ""));
                            xml.WriteElementString("NewsSource", componentnews.StringValue("newssource"));
                            xml.WriteElementString("NewsContactDetails", componentnews.XHTMLValue("newscontactdetails").Replace("xmlns=\"http://www.w3.org/1999/xhtml\"", ""));
                            xml.WriteElementString("CreatedDate", componentnews.CreationDate.ToString("dd/MM/yyyy"));
                            xml.WriteElementString("ModifiedDate", componentnews.RevisionDate.ToString("dd/MM/yyyy"));

                            if (componentnews.ComponentValues("imagegallery") != null)
                            {
                                xml.WriteStartElement("Imagegallery");
                                IList<Component> imagegallery = componentnews.ComponentValues("imagegallery");
                                foreach (Component image in imagegallery)
                                {
                                    xml.WriteElementString("image", PublishBinary(image));
                                }
                                xml.WriteEndElement();
                            }

                            Component imagec = componentnews.ComponentValue("NewsHeaderLogo");
                            if (imagec != null && imagec.BinaryContent != null)
                            {
                                xml.WriteElementString("NewsHeaderLogo", PublishBinary(imagec));
                            }


                        }

                        xml.WriteEndElement();

                    }
                    xml.WriteEndElement();

       

                    }

                package.AddXml(Package.OutputName, sw.ToString());

                }

                
            }

        }

    }

