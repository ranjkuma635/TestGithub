﻿using System.Collections.Generic;
using System.Xml;
using System.IO;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.Extensions.ContentManager.Templating;
using Publishing = Tridion.ContentManager.Publishing.Rendering;
using Tridion.ContentManager.ContentManagement;
using Emaar.Web.Tridion.System.Extensions;
using Tridion.ContentManager.ContentManagement.Fields;

namespace POC.Web.Templating.BuildingBlocks.Templates
{
    public class Memo : TemplateBase
    {
        public override void Transform(Engine engine, Package package)
        {

            base.Transform(engine, package);

            Engine m_Engine;
            m_Engine = engine;

            string strPubid = Page.ComponentPresentations[0].Component.Id.PublicationId.ToString();


            string strNews = "tcm:" + strPubid + "-9620-2";
            string strEvents = "tcm:" + strPubid + "-9621-2";
            string strCal = "tcm:" + strPubid + "-9622-2";

            OrganizationalItem NewsFolder = m_Engine.GetObject(strNews) as OrganizationalItem;
            OrganizationalItem EventsFolder = m_Engine.GetObject(strEvents) as OrganizationalItem;
            OrganizationalItem CalenderFolder = m_Engine.GetObject(strCal) as OrganizationalItem;



            string strActive = string.Empty;
            base.Transform(engine, package);
            using (StringWriter sw = new StringWriter())
            {
                using (XmlTextWriter xml = new XmlTextWriter(sw))
                {

                    IList<Component> componentsnews = Component.OrganizationalItem.Components(true);

                    xml.WriteStartElement("data");

                    foreach (Component component in componentsnews)
                    {

                        xml.WriteStartElement("circular");


                        xml.WriteElementString("guid", component.Id.ToString());

                        xml.WriteElementString("title", component.StringValue("title"));
                        Component imagec = component.ComponentValue("image");
                        if (imagec != null && imagec.BinaryContent != null)
                        {
                            xml.WriteElementString("logo", PublishBinary(imagec));
                        }

                        Logger.Info("titlet" + component.StringValue("title"));
                        xml.WriteElementString("to", component.StringValue("to"));
                        Logger.Info("to" + component.StringValue("to"));
                        xml.WriteElementString("from", component.StringValue("from"));
                        Logger.Info("from" + component.StringValue("from"));
                        xml.WriteElementString("re", component.StringValue("re"));
                        Logger.Info("re" + component.StringValue("re"));
                        xml.WriteElementString("ref", component.StringValue("ref"));
                        Logger.Info("ref" + component.StringValue("ref"));
                        xml.WriteElementString("date", Component.DateValue("date").ToString("dd/MM/yyyy"));
                        Logger.Info("date" + Component.DateValue("date").ToString("dd/MM/yyyy"));
                        //  xml.WriteElementString("createddate", component.CreationDate.ToString("dd/MM/yyyy"));
                        // xml.WriteElementString("modifieddate", DateTime.Now.ToString("dd/MM/yyyy"));


                        xml.WriteElementString("message", component.XHTMLValue("message").Replace("xmlns=\"http://www.w3.org/1999/xhtml\"", ""));

                        Logger.Info("message" + component.XHTMLValue("message").Replace("xmlns=\"http://www.w3.org/1999/xhtml\"", ""));
                        Component addresscomp = Component.ComponentValue("address");

                        if (addresscomp != null)
                        {
                            Logger.Info("inside addresscomp" + addresscomp);
                            xml.WriteStartElement("company");

                            xml.WriteElementString("title", addresscomp.StringValue("title"));
                            xml.WriteElementString("address", addresscomp.XHTMLValue("address").Replace("xmlns=\"http://www.w3.org/1999/xhtml\"", ""));
                            xml.WriteElementString("telephone", addresscomp.StringValue("telephone"));
                            xml.WriteElementString("faxnumber", addresscomp.StringValue("faxnumber"));
                            xml.WriteElementString("url", addresscomp.StringValue("url"));
                            Component logoimage = addresscomp.ComponentValue("logo");
                            if (logoimage != null && logoimage.BinaryContent != null)
                            {
                                xml.WriteElementString("logoimage", PublishBinary(logoimage));
                            }

                            xml.WriteEndElement();
                        }


                        xml.WriteEndElement();
                        
                        
                        


                        
                        
                        

                    }
                    
                    xml.WriteEndElement();


                }

                package.AddXml(Package.OutputName, sw.ToString());

            }


        }

    }

}

