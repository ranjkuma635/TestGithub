﻿using System;
using System.Collections.Generic;
using System.Text;
using Tridion.ContentManager.ContentManagement;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.Extensions.ContentManager.Templating;
using Emaar.Web.Tridion.System.Extensions;
using Tridion.ContentManager;
using System.Xml;

namespace Hamptons.Web.Templating.BuildingBlocks.Templates
{
    [TcmTemplateTitle("Content Page")]
    public class Contentpage : TemplateBase
    {
        String seoDescription = String.Empty;
        String seoKeywords = String.Empty;

        public override void Transform(Engine engine, Package package)
        {
            base.Transform(engine, package);
            if (Page.ComponentPresentations.Count > 0)
            {
                Component component = Page.ComponentPresentations[0].Component;

                seoDescription = component.StringMetaValue("seodescription");
                seoKeywords = component.StringMetaValue("seokeywords");

                package.AddString("SEODescription", seoDescription);
                package.AddString("SEOKeywords", seoKeywords);

                package.AddString("Metatitlecustom", component.StringValue("Metatitle"));
            }
            package.AddString("NavPath", Page.PublishLocationUrl);
        }
    }
}
