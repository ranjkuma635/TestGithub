﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
using System.Web;
using Tridion.ContentManager;
using Tridion.ContentManager.CommunicationManagement;
using Tridion.ContentManager.ContentManagement;
using Tridion.ContentManager.ContentManagement.Fields;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.Publishing;
using Tridion.Extensions.ContentManager.Templating;
using Tridion.ContentManager.Publishing.Rendering;

namespace Hamptons.Web.Templating.BuildingBlocks.Templates
{
    [TcmTemplateTitle("Publish DCP")]
    public class Publishdcp : TemplateBase
    {
        public override void Transform(Engine engine, Package package)
        {
            base.Transform(engine, package);

            if (Page.ComponentPresentations.Count > 0)
            {
                Component component = Page.ComponentPresentations[0].Component;
                if (component.Schema.Title == "HAMPT - News")
                {
                    //IList<IdentifiableObject> items = new List<IdentifiableObject>();
                    //items.Add(component);

                    //IList<PublicationTarget> targets = new List<PublicationTarget>();
                    //targets.Add(engine.PublishingContext.PublicationTarget);
                    //PublishEngine.Publish(items, engine.PublishingContext.PublishInstruction, targets);

                    engine.RenderComponentPresentation(component.Id, new TcmUri(28344, ItemType.ComponentTemplate, Publication.Id.ItemId));
                }
            }

            PublishCalloutsPage(Page, engine);

        }



        private void PublishCalloutsPage(Page page, Engine engine)
        {

            if (page.Metadata != null)
            {
                ItemFields metadataFields = new ItemFields(Page.Metadata, Page.MetadataSchema);
                ComponentLinkField featureField = null;
                featureField = (ComponentLinkField)metadataFields["rightdata"];

                IList<Component> listcom = featureField.Values;

                if (listcom.Count > 0)
                {
                    foreach (Component comp in listcom)
                    {
                        //IList<IdentifiableObject> items = new List<IdentifiableObject>();
                        //items.Add(comp);

                        //IList<PublicationTarget> targets = new List<PublicationTarget>();
                        //targets.Add(engine.PublishingContext.PublicationTarget);
                        //PublishEngine.Publish(items, engine.PublishingContext.PublishInstruction, targets);
                        engine.RenderComponentPresentation(comp.Id, new TcmUri(28311, ItemType.ComponentTemplate, Publication.Id.ItemId));
                    }
                }
            }

            PublishCalloutsSG(Page.OrganizationalItem, engine);

        }

        private void PublishCalloutsSG(OrganizationalItem oRecurSG, Engine engine)
        {
            OrganizationalItem oParentSG;

            if (oRecurSG != null)
            {
                if (oRecurSG.Metadata != null)
                {
                    ItemFields metadataFields = new ItemFields(oRecurSG.Metadata, oRecurSG.MetadataSchema);
                    ComponentLinkField featureField = null;

                    if (metadataFields["rightdata"] != null)
                    {
                        featureField = (ComponentLinkField)metadataFields["rightdata"];

                        IList<Component> listcom = featureField.Values;

                        if (listcom.Count > 0)
                        {
                            foreach (Component comp in listcom)
                            {
                                IList<IdentifiableObject> items = new List<IdentifiableObject>();
                                items.Add(comp);

                                IList<PublicationTarget> targets = new List<PublicationTarget>();
                                targets.Add(engine.PublishingContext.PublicationTarget);
                                PublishEngine.Publish(items, engine.PublishingContext.PublishInstruction, targets);
                                engine.RenderComponentPresentation(comp.Id, new TcmUri(28311, ItemType.ComponentTemplate, Publication.Id.ItemId));
                            }
                        }

                        oParentSG = oRecurSG.OrganizationalItem;
                        PublishCalloutsSG(oParentSG, engine);
                    }
                    else
                    {
                        oParentSG = oRecurSG.OrganizationalItem;
                        PublishCalloutsSG(oParentSG, engine);                    
                    }
                }
                else
                {
                    oParentSG = oRecurSG.OrganizationalItem;
                    PublishCalloutsSG(oParentSG, engine);
                }
            }
        }
    }
}
