﻿using System;
using System.Collections.Generic;
using Tridion.ContentManager;
using Tridion.ContentManager.CommunicationManagement;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.ContentManagement.Fields;

using Tridion.ContentManager.ContentManagement;
using Tridion.Extensions.ContentManager.Templating;
using Emaar.Web.Tridion.System.Extensions;
using Emaar.Web.Tridion.System;

namespace Hamptons.Web.Templating.BuildingBlocks.Templates
{
    [TcmTemplateTitle("Publication Variables")]
    public class PublicationVariables : PublicationVariablesTemplate
    {
        private List<String> mFields;

        public PublicationVariables()
            : base()
        {
            mFields = new List<String>();

            mFields.Add("Language");
            mFields.Add("Culture");
        }

        protected override bool IncludeMetadata(string FieldName)
        {
            return mFields.Contains(FieldName);
        }
    }
}
