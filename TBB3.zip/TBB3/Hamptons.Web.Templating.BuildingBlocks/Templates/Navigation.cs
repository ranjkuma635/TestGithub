﻿using System;
using System.Collections.Generic;
using System.Xml;
using Tridion.ContentManager.ContentManagement.Fields;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager;
using System.Collections;
using Tridion.ContentManager.ContentManagement;
using Tridion.ContentManager.CommunicationManagement;
using System.Xml.XPath;
using System.Web;
using Tridion.Extensions.ContentManager.Templating;
using Emaar.Web.Tridion.System.Extensions;
using System.Text.RegularExpressions;

namespace Hamptons.Web.Templating.BuildingBlocks.Templates
{
    [TcmTemplateTitle("Navigation XML")]
    public class Navigation : Emaar.Web.Tridion.System.Navigation
    {
        private List<String> mFields;
        private List<String> mLinks;

        public Navigation() : base()
        {
            mLinks = new List<String>();

            mLinks.Add("fcomponentlink");
        }

        protected override bool IncludeMetadata(String FieldName)
        {
            return true;
        }

        protected override bool AsComponentLink(String FieldName)
        {
            return mLinks.Contains(FieldName);
        }
    }
}
