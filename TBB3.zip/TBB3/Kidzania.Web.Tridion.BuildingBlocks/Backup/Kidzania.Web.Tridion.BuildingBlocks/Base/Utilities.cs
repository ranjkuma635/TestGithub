using System;
using System.Collections.Generic;
using System.IO;
using System.Text.RegularExpressions;
using System.Xml;
using Tridion.ContentManager;
using Tridion.ContentManager.CommunicationManagement;
using Tridion.ContentManager.ContentManagement;
using Tridion.ContentManager.ContentManagement.Fields;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using System.Text;

namespace Tridion.Extensions.ContentManager.Templating
{
	public class Utilities 
	{
		protected static Regex GetRegexForParameter(string parameter)
		{
			Regex result = null;
			if (!String.IsNullOrEmpty(parameter))
			{
				string pattern = parameter.Substring(parameter.IndexOf("("));
				pattern = pattern.Substring(1, pattern.Length - 2);
				//Logger.debug("GetRegexForParameter: " + pattern);
				result = new Regex(pattern);
			}
			return result;
		}

		protected static string GetOpeningTag(string tag, string cssClass)
		{
			string menu = "<" + tag;
			if (!String.IsNullOrEmpty(cssClass))
			{
				menu += " class='" + cssClass + "'";
			}
			menu += ">" + Environment.NewLine;
			return menu;
		}

		/// <summary>
		/// Return a list of objects of the requested type from the XML.
		/// </summary>
		/// <remarks>
		/// This method goes back to the database to retrieve more information. So it is NOT just
		/// a fast and convenient way to get a type safe list from the XML.
		/// </remarks>
		/// <typeparam name="T">The type of object to return, like Publication, User, Group, OrganizationalItem</typeparam>
		/// <param name="listElement">The XML from which to construct the list of objects</param>
		/// <returns>a list of objects of the requested type from the XML</returns>
		protected IList<T> GetObjectsFromXmlList<T>(Engine engine, XmlElement listElement) where T : IdentifiableObject
		{
			XmlNodeList itemElements = listElement.SelectNodes("*");
			List<T> result = new List<T>(itemElements.Count);
			foreach (XmlElement itemElement in itemElements)
			{
				result.Add(GetObjectFromXmlElement<T>(engine, itemElement));
			}
			result.Sort(delegate(T item1, T item2)
			{
				return item1.Title.CompareTo(item2.Title);
			});
			return result;
		}

		protected T GetObjectFromXmlElement<T>(Engine engine, XmlElement itemElement) where T : IdentifiableObject
		{
			return (T)engine.GetObject(itemElement.GetAttribute("ID"));
		}

		protected static string Encode(string value)
		{
			return System.Web.HttpUtility.HtmlEncode(value);
		}

		/// <summary>
		/// Returns the root structure group from the list of structure groups specified.
		/// </summary>
		/// <exception cref="InvalidDataException">when there is no root structure group in the list</exception>
		/// <param name="items">The list of structure groups to search.</param>
		/// <returns>the root structure group from the list of structure groups specified</returns>
		protected ListItem GetRootSG(IList<ListItem> items)
		{
			foreach (ListItem item in items)
			{
				if (item.ParentId.PublicationId == -1)
				{
					return item;
				}
			}
			throw new InvalidDataException("Could not find root structure group");
		}

		/// <summary>
		/// Returns the root structure group for the specified item
		/// </summary>
		/// <param name="item">Any item which resides in a publication</param>
		/// <returns>The Root Structure Group in the publication</returns>
		protected StructureGroup GetRootSG(RepositoryLocalObject item)
		{
			Repository pub = item.OwningRepository;

			return GetRootSG(pub);
		}

		/// <summary>
		/// Returns the root structure group for the specified publication
		/// </summary>		
		/// <returns>The Root Structure Group in the publication</returns>
		/// <remarks>copied and modified code from Repository.RootFolder :)</remarks>
		protected StructureGroup GetRootSG(Repository publication)
		{
			Filter filter = new Filter();
			filter.Conditions["ItemType"] = ItemType.StructureGroup;

			IList<RepositoryLocalObject> items = publication.GetItems(filter);

			if (items.Count == 0)
				return null;
			else
				return (StructureGroup)items[0];
		}

		protected Component GetComponentValue(String fieldNAme, ItemFields fields)
		{
			if (fields.Contains(fieldNAme))
			{
				ComponentLinkField field = fields[fieldNAme] as ComponentLinkField;
				return field.Value;
			}

			return null;
		}

		protected IList<Component> GetComponentValues(string fieldName, ItemFields fields)
		{
			if (fields.Contains(fieldName))
			{
				ComponentLinkField field = (ComponentLinkField)fields[fieldName];
				return (field.Values.Count > 0) ? field.Values : null;
			}
			else
			{
				return null;
			}
		}

		protected IList<DateTime> GetDateValues(string fieldName, ItemFields fields)
		{
			if (fields.Contains(fieldName))
			{
				DateField field = (DateField)fields[fieldName];
				return (field.Values.Count > 0) ? field.Values : null;
			}
			else
			{
				return null;
			}
		}

		protected IList<Keyword> GetKeywordValues(string fieldName, ItemFields fields)
		{
			if (fields.Contains(fieldName))
			{
				KeywordField field = (KeywordField)fields[fieldName];
				return (field.Values.Count > 0) ? field.Values : null;
			}
			else
			{
				return null;
			}
		}

		protected IList<double> GetNumberValues(string fieldName, ItemFields fields)
		{
			if (fields.Contains(fieldName))
			{
				NumberField field = (NumberField)fields[fieldName];
				return (field.Values.Count > 0) ? field.Values : null;
			}
			else
			{
				return null;
			}
		}

		protected IList<string> GetStringValues(string fieldName, ItemFields fields)
		{
			if (fields.Contains(fieldName))
			{
				TextField field = (TextField)fields[fieldName];
				return (field.Values.Count > 0) ? field.Values : null;
			}
			else
			{
				return null;
			}
		}

		protected String GetSingleStringValue(string fieldName, ItemFields fields)
		{
			if (fields.Contains(fieldName))
			{
				TextField field = fields[fieldName] as TextField;

				if (field != null) return field.Value;
			}

			return null;
		}

		/// <summary>
		/// Gets the type of the specified field in an enumeration
		/// </summary>		
		public static FieldType GetFieldType(ItemField field)
		{
			return GetFieldType(field, false);
		}

		/// <summary>
		/// Gets the type of the specified field in an enumeration
		/// </summary>		
		/// <param name="limitToBase">confines the result to the base type of the field such as returning a component link field type
		/// for a multimedia field</param>
		public static FieldType GetFieldType(ItemField field, bool limitToBase)
		{
			FieldType res;

			if (limitToBase)
			{
				if (field is EmbeddedSchemaField)
					res = FieldType.EmbeddedSchemaField;
				else if (field is NumberField)
					res = FieldType.NumberField;
				else if (field is ComponentLinkField)
					res = FieldType.ComponentLinkField;
				else if (field is KeywordField)
					res = FieldType.KeywordField;
				else
					res = FieldType.TextField;
			}
			else
			{
				if (field is ExternalLinkField)
					res = FieldType.ExternalLinkField;
				else if (field is EmbeddedSchemaField)
					res = FieldType.EmbeddedSchemaField;
				else if (field is MultimediaLinkField)
					res = FieldType.MultimediaLinkField;
				else if (field is ComponentLinkField)
					res = FieldType.ComponentLinkField;
				else if (field is XhtmlField)
					res = FieldType.XHtmlField;
				else if (field is MultiLineTextField)
					res = FieldType.MultiLineTextField;
				else if (field is NumberField)
					res = FieldType.NumberField;
				else
					res = FieldType.SingleLineTextField;
			}

			return res;
		}

		/// <summary>
		/// Converts a string to a memory stream
		/// </summary>
		public static Stream ConvertStringToStream(string str)
		{
			return new MemoryStream(Encoding.UTF8.GetBytes(str));
		}


        public static string RenderParentSGRoot(OrganizationalItem oRecurSG, string fieldName)
        {
            OrganizationalItem oParentSG;
            string strMetadataValue = "";
            ItemFields metadataFields;

            if (oRecurSG != null)
            {
                if (oRecurSG.Metadata != null)
                {
                    metadataFields = new ItemFields(oRecurSG.Metadata, oRecurSG.MetadataSchema);
                    strMetadataValue = metadataFields[fieldName].ToString();
                    if (strMetadataValue != "")
                    {
                        metadataFields = new ItemFields(oRecurSG.Metadata, oRecurSG.MetadataSchema);
                        strMetadataValue = metadataFields[fieldName].ToString();
                    }
                    else
                    {
                        oParentSG = oRecurSG.OrganizationalItem;
                        return RenderParentSGRoot(oParentSG, fieldName);
                    }
                }
                else
                {
                    oParentSG = oRecurSG.OrganizationalItem;
                    return RenderParentSGRoot(oParentSG, fieldName);
                }
            }
            return strMetadataValue;
        }

	}

	public enum FieldType
	{
		ExternalLinkField,
		EmbeddedSchemaField,
		MultimediaLinkField,
		ComponentLinkField,
		NumberField,
		MultiLineTextField,
		SingleLineTextField,
		XHtmlField,
		KeywordField,
		TextField
	}

}
