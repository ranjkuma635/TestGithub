﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.IO;

namespace Emaar.Tridion.Templating.Extensions
{
    public class XmlNoNamespaceWriter : XmlTextWriter
    {
        bool skipAttribute = false;

        /// <summary>
        /// Initializes a new instance of the <see cref="XmlNoNamespaceWriter"/> class.
        /// </summary>
        /// <param name="writer">The writer.</param>
        public XmlNoNamespaceWriter(TextWriter writer)
            : base(writer)
        {
        }

        public XmlNoNamespaceWriter(Stream w, Encoding encoding)
            : base(w, encoding)
        {
        }

        /// <summary>
        /// Overridden WriteStartDocument to prevent writing the XML processing instruction prolog.
        /// </summary>        
        public override void WriteStartDocument() { }

        /// <summary>
        /// Overridden WriteStartDocument to prevent writing the XML processing instruction prolog.
        /// </summary>
        public override void WriteStartDocument(bool standalone) { }

        /// <summary>
        /// Writes the specified start tag and associates it with the given namespace and prefix.
        /// </summary>
        /// <param name="prefix">The namespace prefix of the element.</param>
        /// <param name="localName">The local name of the element.</param>
        /// <param name="ns">The namespace URI to associate with the element. If this namespace is already in scope and has an associated prefix then the writer automatically writes that prefix also.</param>
        /// <exception cref="T:System.InvalidOperationException">
        /// The writer is closed.
        ///   </exception>
        public override void WriteStartElement(string prefix, string localName, string ns)
        {
            base.WriteStartElement(null, localName, null);
        }


        /// <summary>
        /// Writes the start of an attribute.
        /// </summary>
        /// <param name="prefix">Namespace prefix of the attribute.</param>
        /// <param name="localName">LocalName of the attribute.</param>
        /// <param name="ns">NamespaceURI of the attribute</param>
        /// <exception cref="T:System.ArgumentException">
        ///   <paramref name="localName"/> is either null or String.Empty.
        ///   </exception>
        public override void WriteStartAttribute(string prefix, string localName, string ns)
        {
            //If the prefix or localname are "xmlns", don't write it.
            if (prefix.CompareTo("xmlns") == 0 || localName.CompareTo("xmlns") == 0)
            {
                skipAttribute = true;
            }
            else
            {
                base.WriteStartAttribute(null, localName, null);
            }
        }

        /// <summary>
        /// Writes the given text content.
        /// </summary>
        /// <param name="text">Text to write.</param>
        /// <exception cref="T:System.ArgumentException">
        /// The text string contains an invalid surrogate pair.
        ///   </exception>
        public override void WriteString(string text)
        {
            //If we are writing an attribute, the text for the xmlns
            //or xmlns:prefix declaration would occur here.  Skip
            //it if this is the case.
            if (!skipAttribute)
            {
                base.WriteString(text);
            }
        }

        /// <summary>
        /// Closes the previous <see cref="M:System.Xml.XmlTextWriter.WriteStartAttribute(System.String,System.String,System.String)"/> call.
        /// </summary>
        public override void WriteEndAttribute()
        {
            // If we skipped the WriteStartAttribute call, we have to
            // skip the WriteEndAttribute call as well or else the XmlWriter
            // will have an invalid state.
            if (!skipAttribute)
            {
                base.WriteEndAttribute();
            }

            //reset the boolean for the next attribute.
            skipAttribute = false;
        }

        /// <summary>
        /// Writes out the namespace-qualified name. This method looks up the prefix that is in scope for the given namespace.
        /// </summary>
        /// <param name="localName">The local name to write.</param>
        /// <param name="ns">The namespace URI to associate with the name.</param>
        /// <exception cref="T:System.ArgumentException">
        ///   <paramref name="localName"/> is either null or String.Empty.
        ///   <paramref name="localName"/> is not a valid name according to the W3C Namespaces spec.
        ///   </exception>
        public override void WriteQualifiedName(string localName, string ns)
        {
            //Always write the qualified name using only the localname.
            base.WriteQualifiedName(localName, null);
        }
    }
}
