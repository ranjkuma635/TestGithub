﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
using System.Web;
using Tridion.ContentManager;
using Tridion.ContentManager.CommunicationManagement;
using Tridion.ContentManager.ContentManagement;
using Tridion.ContentManager.ContentManagement.Fields;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.Publishing;
using Tridion.Extensions.ContentManager.Templating;
using Tridion.ContentManager.Publishing.Rendering;

namespace Kidzania.Web.Tridion.BuildingBlocks
{
    [TcmTemplateTitle("Get SiteSpesific PageData")]
    class GetSiteSpesificPageData : TemplateBase
    {
        public override void Transform(Engine engine, Package package)
        {
            this.Initialize(engine, package);
            if (this.IsPage())
            {
                Page page = GetPage();

                //string c = page.ComponentPresentations[0].Component.Id;

                m_Package.PushItem("FriendlyTitle", m_Package.CreateStringItem(ContentType.Html, PageTitle(page)));
                m_Package.PushItem("SearchKeyword", m_Package.CreateStringItem(ContentType.Text, GetSearchItemsFromPage(page, "fkeyword")));
                m_Package.PushItem("MetaDescription", m_Package.CreateStringItem(ContentType.Text, GetSearchItemsFromPage(page, "fdescriptionmeta")));
            }


        }

        private string PageTitle(Page page)
        {


            string strFriendlyTitle = "";

            if (page.Title.Contains("."))
            {

                strFriendlyTitle = ReplaceCdata(page.Title.Split('.')[1].ToString().Trim());

                if (page.Metadata != null)
                {

                    ItemFields metadataFields = new ItemFields(page.Metadata, page.MetadataSchema);

                    if (metadataFields != null)
                    {
                        if (!string.IsNullOrEmpty(metadataFields["ffriendlytitle"].ToString()))
                        {
                            strFriendlyTitle = ReplaceCdata(metadataFields["ffriendlytitle"].ToString());
                        }
                    }

                }
            }
            else
            {
                strFriendlyTitle = page.Title.ToString();
            }


            return strFriendlyTitle;
        }

        private string ReplaceCdata(string cdata)
        {

            string decode = cdata;

            decode = decode.Replace("&", "&amp;amp;");
            decode = decode.Replace("<", "&lt;");
            decode = decode.Replace(">", "&gt;");

            return decode;

        }



        private string GetSearchItemsFromComponent(Page page, string strFieldName)
        {
            string strretVal = "";



            return strretVal;
        }

        private string GetSearchItemsFromPage(Page page, string strFieldName)
        {
            string strMetaDataValue = "";
            ItemFields metadataFields;

            if (page.Metadata != null)
            {
                metadataFields = new ItemFields(page.Metadata, page.MetadataSchema);
                if (metadataFields.Contains(strFieldName))
                {
                    if (!string.IsNullOrEmpty(metadataFields[strFieldName].ToString()))
                    {
                        strMetaDataValue = metadataFields[strFieldName].ToString();
                    }
                    else
                    {
                        strMetaDataValue = GetSearchItemsFromSG(page.OrganizationalItem, strFieldName);
                    }
                }
                else
                {
                    strMetaDataValue = GetSearchItemsFromSG(page.OrganizationalItem, strFieldName);
                }

            }
            else
            {
                strMetaDataValue = GetSearchItemsFromSG(page.OrganizationalItem, strFieldName);
            }

            return strMetaDataValue;

        }
        private string GetSearchItemsFromSG(OrganizationalItem oRecurSG, string strFieldName)
        {
            OrganizationalItem oParentSG;

            string strMetaDataValue = "";

            ItemFields metadataFields;

            if (oRecurSG != null)
            {
                if (oRecurSG.Metadata != null)
                {
                    metadataFields = new ItemFields(oRecurSG.Metadata, oRecurSG.MetadataSchema);

                    if (metadataFields.Contains(strFieldName))
                    {
                        if (!string.IsNullOrEmpty(metadataFields[strFieldName].ToString()))
                        {
                            strMetaDataValue = metadataFields[strFieldName].ToString();
                        }

                    }
                    else
                    {
                        oParentSG = oRecurSG.OrganizationalItem;
                        return GetSearchItemsFromSG(oParentSG, strFieldName);
                    }
                }
                else
                {
                    oParentSG = oRecurSG.OrganizationalItem;
                    return GetSearchItemsFromSG(oParentSG, strFieldName);
                }
            }
            return strMetaDataValue;
        }

        private String getSearchDescriptionPage(Page page)
        {

            string strRetVal = "";

            if (page.Metadata != null)
            {
                ItemFields metadataFields = new ItemFields(page.Metadata, page.MetadataSchema);
                if (metadataFields != null)
                {
                    if (!string.IsNullOrEmpty(metadataFields["fdescription"].ToString()))
                    {
                        strRetVal = metadataFields["fdescription"].ToString();
                    }
                }

            }

            if (strRetVal == "")
            {
                strRetVal = getSearchDescriptionComponent(page);
            }

            return strRetVal;

        }
        private String getSearchDescriptionComponent(Page page)
        {
            string strRetVal = "";
            if (page.ComponentPresentations.Count > 0)
            {
                Component comp = page.ComponentPresentations[0].Component as Component;

                if (comp.Schema.Id.ItemId == 13341)
                {

                    ItemFields Fields = new ItemFields(comp.Content, comp.Schema);
                    EmbeddedSchemaField fields = Fields["fdata"] as EmbeddedSchemaField;
                    IList<ItemFields> Description = fields.Values;
                    foreach (ItemFields innerFields in Description)
                    {
                        if (innerFields.Contains("fdescription"))
                        {
                            strRetVal = innerFields["fdescription"].ToString();
                        }
                    }

                }
            }
            return strRetVal;
        }

    }
}
