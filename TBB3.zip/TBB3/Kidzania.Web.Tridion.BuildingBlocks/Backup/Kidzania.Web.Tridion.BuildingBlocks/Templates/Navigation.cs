﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
using System.Web;
using Tridion.ContentManager;
using Tridion.ContentManager.CommunicationManagement;
using Tridion.ContentManager.ContentManagement;
using Tridion.ContentManager.ContentManagement.Fields;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.Publishing;
using Tridion.Extensions.ContentManager.Templating;
using Tridion.ContentManager.Publishing.Rendering;

namespace Kidzania.Web.Tridion.BuildingBlocks
{
    class Navigation : TemplateBase
    {

        StringBuilder strNav = new StringBuilder();
        StringBuilder strNavLoop = new StringBuilder();

        public override void Transform(Engine engine, Package package)
        {
            this.Initialize(engine, package);
            if (this.IsPage())
            {
                Publication publication = this.GetPublication();
                string rootSG = publication.RootStructureGroup.Id;

                strNav.Append("<Root>");
                GetHomePage(rootSG);
                NavigateSG(rootSG);
                strNav.Append(strNavLoop.ToString());

                strNav.Append("</Root>");

            }
            m_Package.PushItem("Navigation", m_Package.CreateStringItem(ContentType.Html, strNav.ToString()));
        }



        private void GetHomePage(string strRootSGID)
        {
            //This is the only 000.Page 
            StructureGroup RootSG = m_Engine.GetObject(strRootSGID) as StructureGroup;
            strNavLoop.Append("<node id = \"" + RootSG.Id.ToString() + "\"" + getHomePageData(RootSG.Id.ToString()) + "/>");

        }


        private void NavigateSG(string strRootSGID)
        {
            StructureGroup RootSG = m_Engine.GetObject(strRootSGID) as StructureGroup;

            Filter filter = new Filter();
            filter.Conditions["ItemType"] = ItemType.StructureGroup;

            Filter filter1 = new Filter();
            filter1.Conditions["ItemType"] = ItemType.StructureGroup;


            Filter filterpages = new Filter();
            filterpages.Conditions["ItemType"] = ItemType.Page;

            IList<RepositoryLocalObject> listFistLevelStructureGroup = RootSG.GetItems(filter);
            StructureGroup SG;

            Page page;

            string strImagePath = "";
            string strDisplayTop = "";
            string strYes = "Yes";

 
            if (listFistLevelStructureGroup.Count > 0)
            {
                foreach (RepositoryLocalObject RepositoryLocalObject in listFistLevelStructureGroup)
                {
                    SG = m_Engine.GetObject(RepositoryLocalObject.Id) as StructureGroup;

                    if (SG.Title.Contains("."))
                    {
                        strImagePath = "";

                        strNavLoop.Append("<node MainNode = \"" + strYes + "\"   MenuImage = \"" + strImagePath + "\"  DisplayTopMenu = \"" + strDisplayTop + "\"  title = \"" + ReplaceCdata(SG.Title.ToString()) + "\" id = \"" + SG.Id.ToString() + "\"" + getIndexPage(SG.Id.ToString()) + ">");
                        IList<RepositoryLocalObject> listPages = SG.GetItems(filterpages);

                        IList<RepositoryLocalObject> listPages1 = SG.GetItems(filterpages);
                        foreach (RepositoryLocalObject RepositoryLocalObjectpages in listPages1)
                        {
                            if (RepositoryLocalObjectpages.Title.Contains("."))
                            {
                                page = m_Engine.GetObject(RepositoryLocalObjectpages.Id) as Page;
                                strNavLoop.Append("<node pageid = \"" + page.Id.ToString() + "\" page = \"" + page.FileName + ".aspx" + "\" name = \"" + ReplaceCdata(page.Title.ToString()) + "\" title = \"" + ReplaceCdata(page.Title.ToString()) + "\"" + getMetaDataPage(page) + ">");

                                getComponentContent(page);

                                strNavLoop.Append("</node>");
                            }

                        }


                        IList<RepositoryLocalObject> listFistLevelStructureGroup1 = SG.GetItems(filter1);
                        if (listFistLevelStructureGroup1.Count > 0)
                        {

                            foreach (RepositoryLocalObject RepositoryLocalObject1 in listFistLevelStructureGroup1)
                            {
                                SG = m_Engine.GetObject(RepositoryLocalObject1.Id) as StructureGroup;
                                if (SG.Title.Contains("."))
                                {
                                    NavigateSG(SG.Id.ToString());
                                }
                            }
                        }

                        strNavLoop.Append("</node>");
                    }
                }
            }
            else
            {
                strNavLoop.Append("<node MainNode = \"" + strYes + "\"   title = \"" + ReplaceCdata(RootSG.Title.ToString()) + "\" id = \"" + RootSG.Id.ToString() + "\"" + getIndexPage(RootSG.Id.ToString()) + ">");

                IList<RepositoryLocalObject> listPages = RootSG.GetItems(filterpages);
                foreach (RepositoryLocalObject RepositoryLocalObjectpages in listPages)
                {
                    if (RepositoryLocalObjectpages.Title.Contains("."))
                    {
                        page = m_Engine.GetObject(RepositoryLocalObjectpages.Id) as Page;
                        strNavLoop.Append("<node pageid = \"" + page.Id.ToString() + "\" page = \"" + page.FileName + ".aspx" + "\" name = \"" + ReplaceCdata(page.Title.ToString()) + "\" title = \"" + ReplaceCdata(page.Title.ToString()) + "\"" + getMetaDataPage(page) + "/>");
                    }

                }

                strNavLoop.Append("</node>");
            }


        }

        private string getIndexPage(string strSG)
        {
            Page page;
            ItemFields metadataFieldspage;
            ItemFields metadataFieldsSG;
            ItemFields SGM;


            string strFriendlyTitle = string.Empty;
            Filter filter = new Filter();
            filter.Conditions["ItemType"] = ItemType.Page;

            string strMetaURL = "";
            string strHTML = "";
            string strpageTitle = "";

            string strURL = "";
            string strComponent = "";
            string strPageID = "";
            string strDisplaySitemap = "Yes";
            string strDisplayFooter = "Yes";

            string strDisplayTopRight = "No";

            string strDisplayBottom = "Yes";

            string strExternalURL = "";
            string strMainNavTitle = "";

            string strDisplayMainnav = "Yes";

            string strdisplayabovebottommenu = "No";

            string strBottommenusameastop = "No";

            

            StructureGroup SG;
            SG = m_Engine.GetObject(strSG) as StructureGroup;

            strFriendlyTitle = ReplaceCdata(SG.Title.Split('.')[1].ToString().Trim());
            strMainNavTitle = ReplaceCdata(SG.Title.Split('.')[1].ToString().Trim());
            if (SG.Metadata != null)
            {
                metadataFieldsSG = new ItemFields(SG.Metadata, SG.MetadataSchema);
                if (metadataFieldsSG != null)
                {
                    if(!String.IsNullOrEmpty(GetIndexPageMetaData(SG, "fmenutitle"))) 
                    strMainNavTitle = GetIndexPageMetaData(SG, "fmenutitle");

                    strDisplayBottom = GetIndexPageMetaData(SG, "fdisplaybottom");

                    if(!String.IsNullOrEmpty(GetIndexPageMetaData(SG, "fmenutitle"))) 
                    strMainNavTitle = GetIndexPageMetaData(SG, "fmenutitle");

                    if(!String.IsNullOrEmpty(GetIndexPageMetaData(SG, "fdisplaysitemap")))
                        strDisplaySitemap = GetIndexPageMetaData(SG, "fdisplaysitemap");

                    if (!String.IsNullOrEmpty(GetIndexPageMetaData(SG, "fdisplayonmainnav")))
                        strDisplayMainnav = GetIndexPageMetaData(SG, "fdisplayonmainnav");

                    if (!String.IsNullOrEmpty(GetIndexPageMetaData(SG, "fdisplayontopright")))
                        strDisplayTopRight = GetIndexPageMetaData(SG, "fdisplayontopright");


                }

            }

            IList<RepositoryLocalObject> listPages = SG.GetItems(filter);


            foreach (RepositoryLocalObject RepositoryLocalObjectpages in listPages)
            {
                if (RepositoryLocalObjectpages.Title.StartsWith("000"))
                {
                    page = m_Engine.GetObject(RepositoryLocalObjectpages.Id) as Page;

                    if (page.Metadata != null)
                    {
                        if (!String.IsNullOrEmpty(GetIndexPageMetaData(page, "fdisplaybottomway")))
                            strBottommenusameastop = GetIndexPageMetaData(page, "fdisplaybottomway");


                        if (!String.IsNullOrEmpty(GetIndexPageMetaData(page, "fdisplaysitemap")))
                            strDisplaySitemap = GetIndexPageMetaData(page, "fdisplaysitemap");

                        if (!String.IsNullOrEmpty(GetIndexPageMetaData(page, "fdisplayonmainnav")))
                            strDisplayMainnav = GetIndexPageMetaData(page, "fdisplayonmainnav");

                        if (!String.IsNullOrEmpty(GetIndexPageMetaData(page, "fdisplayontopright")))
                            strDisplayTopRight = GetIndexPageMetaData(page, "fdisplayontopright");

                        if (!String.IsNullOrEmpty(GetIndexPageMetaData(page, "fdisplayabovebottommenu")))
                            strdisplayabovebottommenu = GetIndexPageMetaData(page, "fdisplayabovebottommenu");

                        


                    }

                    if (SG.Directory != "")
                        if (strMetaURL != "")
                            strURL = ReplaceURL(strMetaURL);
                        else
                            strURL = ReplaceURL(page.PublishLocationPath);


                    strpageTitle = page.Title.ToString();

                }
            }



            strHTML = " url = \"" + strURL + "\"  pageid = \"" + strPageID + "\" name = \"" + ReplaceCdata(strpageTitle) + "\"  Mainnavtitle = \"" + strMainNavTitle + "\" displaytitle = \"" + strFriendlyTitle + "\"  ComponentLink = \"" + strComponent + "\"   exturl = \"" + strExternalURL + "\" DisplayBottom = \"" + strDisplayBottom + "\" Bottomsameastop = \"" + strBottommenusameastop + "\"  DisplayFooter = \"" + strDisplayFooter + "\"  Dispalysitemap = \"" + strDisplaySitemap + "\"   DispalyTopRight = \"" + strDisplayTopRight + "\"  DispalyAboveBottomMenu = \"" + strdisplayabovebottommenu + "\"  DispalyMainNav = \"" + strDisplayMainnav + "\"  DisplayrelatedLinks = \"" + "\"";
            return strHTML;
        }


        private string GetIndexPageMetaData(IdentifiableObject identifiableObjectm, string fieldname)
        {

            TcmUri tcmUri = null;
            tcmUri = identifiableObjectm.Id;

            Page page;
            StructureGroup SG;

            ItemFields metadataFieldspage;

            string strRetVal = "";

            if (identifiableObjectm is Page)
            {
                page = m_Engine.GetObject(tcmUri.ToString()) as Page;
                metadataFieldspage = new ItemFields(page.Metadata, page.MetadataSchema);
                if (metadataFieldspage != null)
                {
                    strRetVal = GetIndexPageMetaDataValues(metadataFieldspage, fieldname);
                }
            }
            if (identifiableObjectm is StructureGroup)
            {
                SG = m_Engine.GetObject(tcmUri.ToString()) as StructureGroup;
                metadataFieldspage = new ItemFields(SG.Metadata, SG.MetadataSchema);
                if (metadataFieldspage != null)
                {
                    strRetVal = GetIndexPageMetaDataValues(metadataFieldspage, fieldname);
                }
            }
            return strRetVal;
        }

        private string GetIndexPageMetaDataValues(ItemFields metadataField, string fieldname)
        {
            string strRetVal = "";
            ComponentLinkField componnetlink = null;
            TcmUri tcmUri = null;
            Component comp1 = null;

            if (metadataField != null)
            {
                Type type;
                type = metadataField[fieldname].Definition.GetType();

                switch (type.Name)
                {

                    case "SingleLineTextFieldDefinition":
                        if (!string.IsNullOrEmpty(metadataField[fieldname].ToString()))
                        {
                            strRetVal = ReplaceCdata(metadataField[fieldname].ToString());
                        }
                        break;

                    case "MultimediaLinkFieldDefinition":
                        componnetlink = (ComponentLinkField)metadataField[fieldname];
                        if (componnetlink.Value != null)
                        {
                            comp1 = (Component)componnetlink.Value;
                            if (comp1 != null)
                            {
                                tcmUri = comp1.Id;
                                Binary pubBinary = m_Engine.PublishingContext.RenderedItem.AddBinary(comp1);
                                strRetVal = pubBinary.Url;
                            }

                        }
                        break;
                }

            }

            return strRetVal;

            return strRetVal;
        }


        private string getHomePageData(string strSG)
        {
            Page page;
            ItemFields metadataFieldspage;
            
            string strImagePath = "";

            string strBottommenusameastop = String.Empty;
            string strDisplaySitemap = String.Empty;
            string strDisplayMainnav = String.Empty;
            string strDisplayTopRight = String.Empty;  

            string strFriendlyTitle = string.Empty;
            Filter filter = new Filter();
            filter.Conditions["ItemType"] = ItemType.Page;
            
            string strHTML = "";
            StructureGroup SG;
            SG = m_Engine.GetObject(strSG) as StructureGroup;
            
            IList<RepositoryLocalObject> listPages = SG.GetItems(filter);

            foreach (RepositoryLocalObject RepositoryLocalObjectpages in listPages)
            {
                if (RepositoryLocalObjectpages.Title.StartsWith("000"))
                {
                    page = m_Engine.GetObject(RepositoryLocalObjectpages.Id) as Page;

                    if (page.Metadata != null)
                    {
                        if (!String.IsNullOrEmpty(GetIndexPageMetaData(page, "fdisplaybottomway")))
                            strBottommenusameastop = GetIndexPageMetaData(page, "fdisplaybottomway");


                        if (!String.IsNullOrEmpty(GetIndexPageMetaData(page, "fdisplaysitemap")))
                            strDisplaySitemap = GetIndexPageMetaData(page, "fdisplaysitemap");

                        if (!String.IsNullOrEmpty(GetIndexPageMetaData(page, "fdisplayonmainnav")))
                            strDisplayMainnav = GetIndexPageMetaData(page, "fdisplayonmainnav");

                        if (!String.IsNullOrEmpty(GetIndexPageMetaData(page, "fdisplayontopright")))
                            strDisplayTopRight = GetIndexPageMetaData(page, "fdisplayontopright");

                    }

                    strFriendlyTitle = ReplaceCdata(page.Title.Split('.')[1].ToString().Trim());
                    strHTML = " Bottomsameastop = \"" + strBottommenusameastop + "\"  Dispalysitemap = \"" + strDisplaySitemap + "\"   DispalyTopRight = \"" + strDisplayTopRight + "\" MenuImage = \"" + strImagePath + "\" title = \"" + ReplaceCdata(page.Title.ToString()) + "\" name = \"" + ReplaceCdata(page.Title.ToString()) + "\"  pageid = \"" + page.Id.ToString() + "\"    displaytitle = \"" + strFriendlyTitle + "\"   url = \"" + ReplaceURL(page.PublishLocationPath) + "\"";

                }
            }
            return strHTML;
        }

        private string ReplaceCdata(string cdata)
        {

            string decode = cdata;

            decode = decode.Replace("&", "&amp;");            
            decode = decode.Replace("<", "&lt;");
            decode = decode.Replace(">", "&gt;");

            return decode;

        }

        private string ReplaceURL(string strURL)
        {
            string url = strURL;
            url = url.Replace("\\", "/");
            return url;

        }

        private string getMetaDataPage(Page page)
        {
            string strHtml;
            string strURL = "";

            string strTitle = "";
            string strDisplaySiteMap = "Yes";
            string strDisplaysiteMap = "Yes";

            string strSiteMapText = "";
            string strComponent = "";

            string strDisplayRelatedLinks = "Yes";
            string strImagePath = "";
            string strDisplayBottom = "Yes";
            string strDisplayRightNavidation = "Yes";


            string sclass = "";
            string strIndexPage = "No";
            string strVideofile = "";
            string strFriendlyTitle = ReplaceCdata(page.Title.Split('.')[1].ToString().Trim());


            StructureGroup SG;

            if (page.Title.StartsWith("000"))
                strIndexPage = "Yes";

            if (page.Metadata != null)
            {

                if (!String.IsNullOrEmpty(GetIndexPageMetaData(page, "fexternalURL")))
                    strURL = GetIndexPageMetaData(page, "fexternalURL");

                if (!String.IsNullOrEmpty(GetIndexPageMetaData(page, "fdisplaybottom")))
                    strDisplayBottom = GetIndexPageMetaData(page, "fdisplaybottom");
                
            }


            strHtml = " IndexPage = \"" + strIndexPage + "\"  url = \"" + ReplaceURL(page.PublishLocationPath) + "\"  exturl = \"" + strURL + "\"  ComponentLink = \"" + strComponent + "\"   linktitle  = \"" + strTitle + "\" class  = \"" + sclass + "\" displaytitle = \"" + strFriendlyTitle + "\" displaysitemap = \"" + strDisplaySiteMap + "\"  DisplayrelatedLinks = \"" + strDisplayRelatedLinks + "\" Dispalysitemap = \"" + strDisplaySiteMap + "\" Imagelink = \"" + strImagePath + "\" videofile = \"" + strVideofile + "\"  Displayonrightnavigation = \"" + strDisplayRightNavidation + "\"  DisplayBottom = \"" + strDisplayBottom + "\" sitemaptext = \"" + strSiteMapText + "\"";
            return strHtml;
        }


        private bool CheckSGPage(string strRootSGID)
        {

            bool retval = false;

            bool booSG = false;
            bool booPage = false;


            StructureGroup RootSG = m_Engine.GetObject(strRootSGID) as StructureGroup;

            Filter filter = new Filter();
            filter.Conditions["ItemType"] = ItemType.StructureGroup;

            Filter filterpages = new Filter();
            filterpages.Conditions["ItemType"] = ItemType.Page;


            IList<RepositoryLocalObject> listSG = RootSG.GetItems(filter);
            IList<RepositoryLocalObject> listPage = RootSG.GetItems(filterpages);

            if (listSG.Count > 0)
            {
                foreach (RepositoryLocalObject SG in listSG)
                {
                    if (SG.Title.Contains("."))
                    {
                        booSG = true;
                    }
                }
            }

            if (listPage.Count > 0)
            {
                foreach (RepositoryLocalObject Page in listSG)
                {
                    if (Page.Title.Contains("."))
                    {
                        booPage = true;
                    }
                }
            }

            if (booSG || booPage)
                retval = true;


            return retval;

        }

        private string PublishBinary(string compURI)
        {
            string publishPath = "";
            Component comp = m_Engine.GetObject(compURI) as Component;
            Binary pubBinary = m_Engine.PublishingContext.RenderedItem.AddBinary(comp);
            publishPath = pubBinary.Url;
            return publishPath;
        }


        private void getComponentContent(Page page)
        {
            string strRetVal = "";
            if (page.ComponentPresentations.Count > 0)
            {
                Component comp = page.ComponentPresentations[0].Component as Component;

                if (comp.Schema.Id.ItemId == 15845)
                {

                    ItemFields Fields = new ItemFields(comp.Content, comp.Schema);
                    EmbeddedSchemaField fields = Fields["fdata"] as EmbeddedSchemaField;
                    IList<ItemFields> Description = fields.Values;
                    if (fields.Values.Count > 1  )
                    {
                        foreach (ItemFields innerFields in Description)
                        {
                            if (innerFields.Contains("ftitle"))
                            {
                                strRetVal = innerFields["ftitle"].ToString();
                            }
                            strNavLoop.Append("<node url = \"" + strRetVal.Trim() + "\">");
                            strNavLoop.Append("</node>");
                        }
                    }
                }
            }
            
        }

    }
}
