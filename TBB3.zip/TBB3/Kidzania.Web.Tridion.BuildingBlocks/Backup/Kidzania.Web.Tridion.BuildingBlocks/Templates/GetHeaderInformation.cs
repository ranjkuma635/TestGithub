﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
using System.Web;
using Tridion.ContentManager;
using Tridion.ContentManager.CommunicationManagement;
using Tridion.ContentManager.ContentManagement;
using Tridion.ContentManager.ContentManagement.Fields;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.Publishing;
using Tridion.Extensions.ContentManager.Templating;
using Tridion.ContentManager.Publishing.Rendering;

namespace Kidzania.Web.Tridion.BuildingBlocks
{
    [TcmTemplateTitle("Get Header Information")]
    class GetHeaderInformation : TemplateBase
    {
        string strTitle = string.Empty;
        string strDesc = string.Empty;
        string strImage = string.Empty; 

        public override void Transform(Engine engine, Package package)
        {

            this.Initialize(engine, package);
            Page page = GetPage();


            if (page.Metadata != null)
            strTitle = GetMetaData(page, "ftitle");

            if (String.IsNullOrEmpty(strTitle))
                strTitle = RenderParentSGRoot((OrganizationalItem)page.OrganizationalItem, "ftitle");

            if (page.Metadata != null)
            strDesc = GetMetaData(page, "fdescription");

            if (String.IsNullOrEmpty(strDesc))
                strDesc = RenderParentSGRoot((OrganizationalItem)page.OrganizationalItem, "fdescription");

            if (page.Metadata != null)
            strImage = GetMetaData(page, "fimage");

            if (String.IsNullOrEmpty(strImage))
                strImage = RenderParentSGRoot((OrganizationalItem)page.OrganizationalItem, "fimage");


            m_Package.PushItem("HeaderTitle", m_Package.CreateStringItem(ContentType.Html, strTitle));
            m_Package.PushItem("HeaderDescription", m_Package.CreateStringItem(ContentType.Html, strDesc));
            m_Package.PushItem("HeaderImage", m_Package.CreateStringItem(ContentType.Text, strImage));

        }

        private string ReplaceCdata(string cdata)
        {

            string decode = cdata;

            decode = decode.Replace("&", "&amp;");

            return decode;

        }


        private string GetMetaData(IdentifiableObject identifiableObjectm, string fieldname)
        {

            TcmUri tcmUri = null;
            tcmUri = identifiableObjectm.Id;

            Page page;
            StructureGroup SG;

            ItemFields metadataFieldspage;

            string strRetVal = "";

            if (identifiableObjectm is Page)
            {
                page = m_Engine.GetObject(tcmUri.ToString()) as Page;
                metadataFieldspage = new ItemFields(page.Metadata, page.MetadataSchema);
                if (metadataFieldspage != null)
                {
                    strRetVal = GetMetaDataValues(metadataFieldspage, fieldname);
                }
            }
            if (identifiableObjectm is StructureGroup)
            {
                SG = m_Engine.GetObject(tcmUri.ToString()) as StructureGroup;
                metadataFieldspage = new ItemFields(SG.Metadata, SG.MetadataSchema);
                if (metadataFieldspage != null)
                {
                    strRetVal = GetMetaDataValues(metadataFieldspage, fieldname);
                }
            }
            return strRetVal;
        }

        private string GetMetaDataValues(ItemFields metadataField, string fieldname)
        {
            string strRetVal = "";
            ComponentLinkField componnetlink = null;
            TcmUri tcmUri = null;
            Component comp1 = null;

            if (metadataField != null)
            {
                Type type;
                type = metadataField[fieldname].Definition.GetType();

                switch (type.Name)
                {

                    case "SingleLineTextFieldDefinition":
                        if (!string.IsNullOrEmpty(metadataField[fieldname].ToString()))
                        {
                            strRetVal = ReplaceCdata(metadataField[fieldname].ToString());
                        }
                        break;

                    case "MultimediaLinkFieldDefinition":
                        componnetlink = (ComponentLinkField)metadataField[fieldname];
                        if (componnetlink.Value != null)
                        {
                            comp1 = (Component)componnetlink.Value;
                            if (comp1 != null)
                            {
                                tcmUri = comp1.Id;
                                Binary pubBinary = m_Engine.PublishingContext.RenderedItem.AddBinary(comp1);
                                strRetVal = pubBinary.Url;
                            }

                        }
                        break;
                }

            }

            return strRetVal;
        }


        public string PublishBinary(string compURI)
        {
            string publishPath = "";
            Component comp = m_Engine.GetObject(compURI) as Component;
            Binary pubBinary = m_Engine.PublishingContext.RenderedItem.AddBinary(comp);
            publishPath = pubBinary.Url;
            return publishPath;
        }

        private string RenderParentSGRoot(OrganizationalItem oRecurSG, string strFieldName)
        {
            OrganizationalItem oParentSG;

            string strMetadataValueImage = "";
            string retval = "";

            ItemFields metadataFields;

            if (oRecurSG != null)
            {
                if (oRecurSG.Metadata != null)
                {
                    metadataFields = new ItemFields(oRecurSG.Metadata, oRecurSG.MetadataSchema);

                    strMetadataValueImage = GetMetaData(oRecurSG, strFieldName);

                    if (strMetadataValueImage != "")
                    {
                        retval = strMetadataValueImage;
                    }
                    else
                    {
                        oParentSG = oRecurSG.OrganizationalItem;
                        return RenderParentSGRoot(oParentSG, strFieldName);
                    }
                }
                else
                {
                    oParentSG = oRecurSG.OrganizationalItem;
                    return RenderParentSGRoot(oParentSG, strFieldName);
                }
            }
            return retval;
        }
    }
}
