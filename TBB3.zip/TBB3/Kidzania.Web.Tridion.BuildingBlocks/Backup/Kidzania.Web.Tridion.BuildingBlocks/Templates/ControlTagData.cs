﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
using System.Web;
using Tridion.ContentManager;
using Tridion.ContentManager.CommunicationManagement;
using Tridion.ContentManager.ContentManagement;
using Tridion.ContentManager.ContentManagement.Fields;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.Publishing;
using Tridion.Extensions.ContentManager.Templating;
using Tridion.ContentManager.Publishing.Rendering;

namespace Kidzania.Web.Tridion.BuildingBlocks
{
    [TcmTemplateTitle("Control Tag Data")]
    class ControlTagData : TemplateBase
    {
        public override void Transform(Engine engine, Package package)
        {
            this.Initialize(engine, package);
            Page page = GetPage();
            StructureGroup RootSG = (StructureGroup)page.OrganizationalItem as StructureGroup;

            Item outputItem = m_Package.GetByName(Package.OutputName);

            string outputValue = outputItem.GetAsString();

            outputValue = outputValue.Replace("[*STRUCTUREGROUPID*]", RootSG.Id.ToString());
            m_Package.Remove(outputItem);
            outputItem.SetAsString(outputValue);
            package.PushItem(Package.OutputName, outputItem);

            outputValue = outputValue.Replace("[*PAGEID*]", page.Id.ToString());
            m_Package.Remove(outputItem);
            outputItem.SetAsString(outputValue);
            package.PushItem(Package.OutputName, outputItem);

        }

        private String getPageModeDivStyle(Page page)
        {
            //Short view
            string strDivStyle = "leftcontentddiv";


            if (page.Metadata != null)
            {

                ItemFields metadataFields = new ItemFields(page.Metadata, page.MetadataSchema);
                if (metadataFields != null)
                {
                    if (!string.IsNullOrEmpty(metadataFields["fpagemode"].ToString()))
                    {
                        if (metadataFields["fpagemode"].ToString() == "Full View")
                        {
                            strDivStyle = "ins-contentdiv";
                        }
                    }
                }

            }

            return strDivStyle;

        }


    }
}
