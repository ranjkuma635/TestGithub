﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
using System.Web;
using Tridion.ContentManager;
using Tridion.ContentManager.CommunicationManagement;
using Tridion.ContentManager.ContentManagement;
using Tridion.ContentManager.ContentManagement.Fields;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.Publishing;
using Tridion.Extensions.ContentManager.Templating;
using Tridion.ContentManager.Publishing.Rendering;

namespace Kidzania.Web.Tridion.BuildingBlocks
{
    [TcmTemplateTitle("Publish Navigation")]
    class PublishNavigation : TemplateBase
    {
        public override void Transform(Engine engine, Package package)
        {
            this.Initialize(engine, package);
            Page page = GetPage();

            if (this.IsPublishing)
            {

                string strPageID = "tcm:" + page.Id.PublicationId + "-15873-64";
                Page comppage = m_Engine.GetObject(strPageID) as Page;
                IList<IdentifiableObject> items = new List<IdentifiableObject>();
                items.Add(comppage);
                IList<PublicationTarget> targets = new List<PublicationTarget>();
                targets.Add(m_Engine.PublishingContext.PublicationTarget);
                PublishEngine.Publish(items, m_Engine.PublishingContext.PublishInstruction, targets);

            }
        }  

    }
}
