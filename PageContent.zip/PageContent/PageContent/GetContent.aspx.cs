﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using HtmlAgilityPack;
using System.Xml.Linq;
using Microsoft.Office.Interop.Excel;
using System.Runtime.InteropServices;

namespace PageContent
{
    public partial class GetContent : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            XDocument xmlDoc = XDocument.Load(Server.MapPath("~/App_Data/urls.xml"));
            var list = xmlDoc.Root.Elements("url").Select(element => element.Value).ToList();
            int i = 2;
            Microsoft.Office.Interop.Excel.Application xlApp = new Microsoft.Office.Interop.Excel.Application();
            Microsoft.Office.Interop.Excel.Workbook xlWorkBook;
            Microsoft.Office.Interop.Excel.Worksheet xlWorkSheet;
            object misValue = System.Reflection.Missing.Value;

            xlWorkBook = xlApp.Workbooks.Add(misValue);
            xlWorkSheet = (Microsoft.Office.Interop.Excel.Worksheet)xlWorkBook.Worksheets.get_Item(1);
            xlWorkSheet.Cells[1, 1] = "URL";
            xlWorkSheet.Cells[1, 2] = "Meta Title";
            xlWorkSheet.Cells[1, 3] = "Meta Description";
            xlWorkSheet.Cells[1, 4] = "Page Title";
            xlWorkSheet.Cells[1, 5] = "Page Description";

            foreach (string siteUrl in list)
            {
                GetValue(siteUrl, i, xlWorkSheet);
                i++;
            }
            string fileName = "d:\\EmaarContent" + DateTime.Now.ToFileTime() + ".xls";
            xlWorkBook.SaveAs(fileName, Microsoft.Office.Interop.Excel.XlFileFormat.xlWorkbookNormal, misValue, misValue, misValue, misValue, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);
            xlWorkBook.Close(true, misValue, misValue);
            xlApp.Quit();

            Marshal.ReleaseComObject(xlWorkSheet);
            Marshal.ReleaseComObject(xlWorkBook);
            Marshal.ReleaseComObject(xlApp);

            //String url = txtURL.Text;
            //WebClient x = new WebClient();
            //string sourcedata = x.DownloadString(url);
            //txtTitle.Text = Regex.Match(sourcedata, @"\<title\b[^>]*\>\s*(?<Title>[\s\S]*?)\</title\>", RegexOptions.IgnoreCase).Groups["Title"].Value;
            //GetMetaTagValue(url);
        }

        private void GetValue(string url, int row, Worksheet xlWorkSheet)
        {
            xlWorkSheet.Cells[row, 1] = url;
            var getHtmlDoc = new HtmlWeb();
            var document = getHtmlDoc.Load(url);
            if (document != null)
            {
                //var metaTags = document.DocumentNode.SelectNodes("//meta");
                //if (metaTags != null)
                //{
                //    foreach (var sitetag in metaTags)
                //    {
                //        if (sitetag.Attributes["name"] != null && sitetag.Attributes["content"] != null && sitetag.Attributes["name"].Value == "Title")
                //            xlWorkSheet.Cells[row, 2] = sitetag.Attributes["content"].Value;
                //        else if (sitetag.Attributes["name"] != null && sitetag.Attributes["content"] != null && sitetag.Attributes["name"].Value == "Description")
                //            xlWorkSheet.Cells[row, 3] = sitetag.Attributes["content"].Value;
                //    }
                //}
                var metaTitleNode = document.DocumentNode.SelectSingleNode("//meta[@name='Title']");
                if (metaTitleNode != null)
                    xlWorkSheet.Cells[row, 2] = metaTitleNode.GetAttributeValue("content", "");

                var metaTitleDesc = document.DocumentNode.SelectSingleNode("//meta[@name='Description']");
                if (metaTitleDesc != null)
                    xlWorkSheet.Cells[row, 3] = metaTitleDesc.GetAttributeValue("content", "");

                var h1Node = document.DocumentNode.SelectSingleNode("//h1[@class='section-title']");
                if (h1Node != null)
                    xlWorkSheet.Cells[row, 4] = h1Node.InnerText;

                var introNode = document.DocumentNode.SelectSingleNode("//div[@class='intro-copy']");
                if (introNode != null)
                    xlWorkSheet.Cells[row, 5] = introNode.InnerText;
            }
        }

        private void GetMetaTagValue(string url)
        {
            var getHtmlDoc = new HtmlWeb();
            var document = getHtmlDoc.Load(url);
            var metaTags = document.DocumentNode.SelectNodes("//meta");
            txtPageTitle.Text = document.DocumentNode.SelectSingleNode("//h1[@class='section-title']").InnerText;
            txtPageDescription.Text = document.DocumentNode.SelectSingleNode("//div[@class='intro-copy']").InnerText;
            if (metaTags != null)
            {
                foreach (var sitetag in metaTags)
                {
                    if (sitetag.Attributes["name"] != null && sitetag.Attributes["content"] != null && sitetag.Attributes["name"].Value == "Description")
                    {
                        txtDescription.Text = sitetag.Attributes["content"].Value;
                    }
                    if (sitetag.Attributes["name"] != null && sitetag.Attributes["content"] != null && sitetag.Attributes["name"].Value == "Title")
                    {
                        txtTitle.Text = sitetag.Attributes["content"].Value;
                    }
                }
            }
        }
    }
}