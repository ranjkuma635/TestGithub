﻿using System;
using System.Collections.Generic;
using System.Xml;
using Tridion.ContentManager.CommunicationManagement;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.ContentManagement;
using Emaar.Web.Tridion.System.Extensions;
using Emaar.Web.Tridion.System;


namespace DMYC.Web.Templating.BuildingBlocks.Templates {
   
    [TcmTemplateTitle("Page Variables")]
    public class PageVariables : PageVariablesTemplate  {

       private List<String> mIncludeFields;
       private List<String> mInheritedFields;

       public PageVariables(): base() {
            mIncludeFields = new List<String>();
            mIncludeFields.Add("fhideNavigation");
            mIncludeFields.Add("fhideFooter");
            mIncludeFields.Add("fSideBar");
            mIncludeFields.Add("fhideFromSearch");
            mIncludeFields.Add("fCarousels");

            mInheritedFields = new List<String>();
            mInheritedFields.Add("fhideNavigation");
            mInheritedFields.Add("fhideFooter");
            mInheritedFields.Add("fSideBar");
            mInheritedFields.Add("fCarousels");
       }


        protected override bool IncludeMetadata(string FieldName) {
            return mIncludeFields.Contains(FieldName);
        }

        protected override bool InheritedMetadata(string FieldName) {
            return mInheritedFields.Contains(FieldName);
        }

        /// <summary>
        /// Returns wether the specified Schema should be used to generate a page title
        /// </summary>
        /// <returns></returns>
        protected override bool TitleTemplate(string Schema) {
            return true;
        }

    }
}
