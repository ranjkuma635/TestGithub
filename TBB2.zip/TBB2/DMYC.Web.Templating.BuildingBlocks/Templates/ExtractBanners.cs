﻿using System;
using System.Linq;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager;
using Tridion.ContentManager.ContentManagement;
using Emaar.Web.Tridion.System.Extensions;
using Tridion.Extensions.ContentManager.Templating;
using System.Collections.Generic;

namespace DMYC.Web.Templating.BuildingBlocks.Templates
{
    [TcmTemplateTitle("ExtractBanners")]
    public class ExtractBanners : TemplateBase
    {
        public override void Transform(Engine engine, Package package)
        {
            base.Transform(engine, package);
            bool banners_large = false;
            try
            {
                string html = String.Empty;

                if (Page.ComponentPresentations.Count > 0)
                {
                    Tridion.ContentManager.CommunicationManagement.ComponentPresentation componentPresentation = Page.ComponentPresentations[0];
                    Component component = componentPresentation.Component;
                    if (component != null)
                    {
                        IList<Component> banners = component.ComponentMetaValues("banners");
                        foreach (Component bannerComp in banners)
                        {
                            if (bannerComp.Schema.Title.Contains("Banner"))
                            {
                                banners_large = true;
                                break;
                            }

                        }
                        if (banners.Count > 1)
                        {
                            if (banners_large) html = LargeBannersHTML(banners);
                            else html = BannersHTML(banners);
                            Package.AddHtml("Banners", html);
                        }
                        else if (banners.Count == 1)
                        {
                            html = BannerHTML(banners);
                            Package.AddHtml("Banner", html);
                        }
                    }
                }
            }
            catch (Exception ex)
            {

                if (banners_large)
                    throw new Exception("Error in Banner processing, Possible reason: Mismatch with different banners: " + ex.Message + ex.StackTrace);
                else
                    throw new Exception("Error in Banner processing: " + ex.Message + ex.StackTrace);

            }

        }

        private string LargeBannersHTML(IList<Component> banners)
        {
            string html = String.Empty;
            html = "<div class=\"slider-container mver\"><div class=\"page-main-slider owl-carousel\">";
            foreach (Component bannerComp in banners)
            {
                html = String.Format(
                        "{0}<div><img src=\"{1}\" class=\"desktop\" alt=\"{2}\"/><img src=\"{3}\" class=\"mobile_img\" alt=\"{2}\"/><div class=\"slider-caption {6}\">{4}<h4>{5}</h4></div></div>",
                        html, PublishBinary(bannerComp),
                        bannerComp.Title.ToLower().Replace('-', ' '),
                        PublishBinary(bannerComp.ComponentMetaValue("mobile")),
                        bannerComp.StringMetaValue("title"),
                        bannerComp.StringMetaValue("text"),
                        bannerComp.StringMetaValue("color")
                        );

            }
            html = String.Format(
                "{0}{1}",
                html,
                "</div><a href=\"#\" title=\"Previous\" class=\"slider-prev slider-nav\"><i class=\"icon-left-open-big\"><span> </span></i></a><a href=\"#\" class=\"slider-next slider-nav\" title=\"Next\"><i class=\"icon-right-open-big\"><span> </span></i></a></div>");

            return html;
        }

        private string BannersHTML(IList<Component> banners)
        {
            string html = String.Empty;
            html = "<div class=\"slider-container1 in_sl\"><div class=\"container\"><div class=\"inner_slider owl-carousel\">";
            foreach (Component bannerComp in banners)
            {
                html = String.Format(
                    "{0} <img src=\"{1}\" alt=\"{2}\"/>",
                    html,
                    PublishBinary(bannerComp),
                    bannerComp.Title.ToLower().Replace('-', ' ')
                    );
            }
            html = String.Format(
                "{0}{1}",
                html,
                "</div><a href=\"#\" title=\"Previous\" class=\"slider-prev1 slider-nav\"><i class=\"icon-left-open-big\"><span> </span></i></a><a href=\"#\" class=\"slider-next1 slider-nav\" title=\"Next\"><i class=\"icon-right-open-big\"><span> </span></i></a></div></div>"
                );
            return html;
        }

        private string BannerHTML(IList<Component> banners)
        {
            string html = String.Empty;
            html = "<div class=\"slider-container in_sl\"><div class=\"container\">";
            foreach (Component bannerComp in banners)
            {
                html = String.Format(
                  "{0} <img src=\"{1}\" class=\"fleft\" alt=\"{2}\"/>",
                  html,
                  PublishBinary(bannerComp),
                  bannerComp.Title.ToLower().Replace('-', ' ')
                  );
            }
            html = String.Format(
                "{0}{1}",
                html,
                "</div></div>"
                );
            return html;
        }
    }
}
