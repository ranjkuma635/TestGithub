﻿using System;
using System.Linq;
using System.Xml;
using System.IO;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.Extensions.ContentManager.Templating;
using Emaar.Web.Tridion.System.Extensions;

namespace DMYC.Web.Templating.BuildingBlocks.Templates
{

    [TcmTemplateTitle("DCPItem")]
    public class DCPItem : TemplateBase
    {
        /// <summary>
        /// Transforms the current component.
        /// </summary>
        /// <param name="engine">The engine.</param>
        /// <param name="package">The package.</param>
        public override void Transform(Engine engine, Package package)
        {
            base.Transform(engine, package);

            using (StringWriter sw = new StringWriter())
            {

                using (XmlTextWriter xml = new XmlTextWriter(sw))
                {

                    if (Component != null)
                    {

                        if (Component.Schema.Title.Equals("DMYC - Press Release"))
                        {

                            xml.WriteStartElement("item");//item
                            xml.WriteAttributeString("title", Component.StringValue("title"));
                            xml.WriteAttributeString("uri", Component.Id.ToString());

                            if (Component.ComponentValue("image") != null)
                                xml.WriteAttributeString("image", PublishBinary(Component.ComponentValue("image")));
                            else
                                xml.WriteAttributeString("image", "/img/press_default.jpg");

                            xml.WriteAttributeString("summary", Component.XHTMLValue("summary"));
                            DateTime pubDate = Component.DateMetaValue("publishdate");
                            if (pubDate.ToString("dd/MM/yyyy") != "01/01/0001")
                            {
                                string sortDate = GetSortDate(pubDate.ToString("dd/MM/yyyy"));
                                xml.WriteAttributeString("publishdate", pubDate.ToString("dd/MM/yyyy"));
                                xml.WriteAttributeString("sortdate", sortDate);
                                xml.WriteAttributeString("year", sortDate.Substring(0, 4));
                            }
                            xml.WriteAttributeString("download", PublishBinary(Component.ComponentMetaValue("download")));
                            xml.WriteEndElement();//item    
                        }

                        else if (Component.Schema.Title.Equals("DMYC - Media"))
                        {

                            xml.WriteStartElement("item");//item
                            xml.WriteAttributeString("image", PublishBinary(Component));
                            xml.WriteAttributeString("thumb", GenerateThumbnail(Component, "thumb", 225, 150));
                            xml.WriteAttributeString("uri", Component.Id.ToString());
                            xml.WriteAttributeString("album", Component.OrganizationalItem.Title);
                            xml.WriteAttributeString("uniquealbum", Component.OrganizationalItem.Title.Replace(' ', '-'));

                            if (!String.IsNullOrEmpty(Component.StringMetaValue("title")))
                                xml.WriteAttributeString("title", Component.StringMetaValue("title"));

                            DateTime pubDate = Component.DateMetaValue("publishdate");
                            if (pubDate.ToString("dd/MM/yyyy") != "01/01/0001")
                            {
                                string sortDate = GetSortDate(pubDate.ToString("dd/MM/yyyy"));
                                xml.WriteAttributeString("publishdate", pubDate.ToString("dd/MM/yyyy"));
                                xml.WriteAttributeString("sortdate", sortDate);
                                xml.WriteAttributeString("year", sortDate.Substring(0, 4));
                            }

                            xml.WriteEndElement();//item    
                        }



                        /*if (Component.Schema.Title.Equals("DMYC - Special"))
                        {

                            xml.WriteStartElement("item");
                            xml.WriteAttributeString("uri", Component.Id.ToString());
                            xml.WriteAttributeString("index", Component.Title.Substring(0, 3));
                            if (Component.EmbeddedMetaValue("callout").ComponentValue("image") != null)
                                xml.WriteAttributeString("src", PublishBinary(Component.EmbeddedMetaValue("callout").ComponentValue("image")));
                            else
                                xml.WriteAttributeString("src", PublishBinary(Component.ComponentValue("image")));
                            xml.WriteAttributeString("title", Component.EmbeddedMetaValue("callout").StringValue("title"));
                            xml.WriteAttributeString("intro", Component.EmbeddedMetaValue("callout").StringValue("value"));
                            // xml.WriteAttributeString("description", Component.StringValue("description"));
                            xml.WriteEndElement();//item    
                        }

                        if (Component.Schema.Title.Equals("DMYC - Image"))
                        {

                            if (Component.OrganizationalItem.Id.ItemId.ToString() == "6542")
                            {
                                xml.WriteStartElement("item");
                                xml.WriteAttributeString("uri", Component.Id.ToString());
                                xml.WriteAttributeString("src", PublishBinary(Component));
                                xml.WriteAttributeString("altText", Component.Title.Replace("-", " "));
                                xml.WriteEndElement();//item    
                            }
                        }


                        if (Component.Schema.Title.Equals("DMYC - Download"))
                        {

                            xml.WriteStartElement("item");
                            xml.WriteAttributeString("uri", Component.Id.ToString());
                            xml.WriteAttributeString("src", PublishBinary(Component));
                            xml.WriteAttributeString("title", Component.StringMetaValue("Title"));
                            DateTime pubDate = Component.DateMetaValue("publishDate");
                            if (pubDate.ToString("dd/MM/yyyy") != "01/01/0001")
                            {
                                string sortDate = GetSortDate(pubDate.ToString("dd/MM/yyyy"));
                                xml.WriteAttributeString("publishDate", pubDate.ToString("dd/MM/yyyy"));
                                xml.WriteAttributeString("sortDate", sortDate);
                                xml.WriteAttributeString("year", sortDate.Substring(0, 4));
                            }
                            xml.WriteEndElement();//item    
                        }


                        if (Component.Schema.Title.Equals("DMYC - Event"))
                        {

                            xml.WriteStartElement("item");
                            if (Component.ComponentValue("image") != null)
                            {
                                xml.WriteElementString("src", PublishBinary(Component.ComponentValue("image")));
                            }
                            xml.WriteElementString("title", Component.StringValue("title"));
                            xml.WriteElementString("uri", Component.Id);
                            xml.WriteElementString("description", Component.StringValue("summary"));
                            xml.WriteElementString("detail", Component.StringValue("description"));
                            xml.WriteElementString("duration", Component.StringMetaValue("duration"));
                            DateTime startDate = Component.DateMetaValue("startDate");
                            DateTime endDate = Component.DateMetaValue("endDate");
                            if (startDate.ToString("dd/MM/yyyy") != "01/01/0001")
                            {
                                xml.WriteElementString("date", startDate.ToString("dd/MM/yyyy"));
                                xml.WriteElementString("sortdate", GetSortDate(startDate.ToString("dd/MM/yyyy")));
                            }
                            if (endDate.ToString("dd/MM/yyyy") != "01/01/0001")
                            {
                                xml.WriteElementString("endDate", endDate.ToString("dd/MM/yyyy"));
                            }

                            xml.WriteEndElement();//item
                        }*/
                    }

                    Package.AddXml(Package.OutputName, sw.ToString());
                }
            }
        }

        private static string getHtml(string html)
        {
            return Utility.removeXHTMLtags(html);
        }


        private string GetSortDate(string strDate)
        {

            string strRetval = "";


            string[] datetime = strDate.Split(new char[] { '/' });

            string Year = datetime[2];
            string Month = datetime[1];
            string Day = datetime[0];

            if (Month.Length == 1)
                Month = "0" + Month;

            if (Day.Length == 1)
                Day = "0" + Day;

            strRetval = Year + Month + Day;

            return strRetval;

        }
    }
}