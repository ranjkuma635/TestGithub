﻿using System;
using System.Collections.Generic;
using Tridion.ContentManager.Templating.Assembly;
using Emaar.Web.Tridion.System;

namespace DMYC.Web.Templating.BuildingBlocks.Templates
{
    [TcmTemplateTitle("Publication Variables")]
    public class PublicationVariables : PublicationVariablesTemplate
    {
        private List<String> mFields;

        public PublicationVariables() : base()
        {
            mFields = new List<String>();

            mFields.Add("language");
            mFields.Add("culture");
            mFields.Add("class");
        }

        protected override bool IncludeMetadata(string FieldName)
        {
            return mFields.Contains(FieldName);
        }
    }
}
