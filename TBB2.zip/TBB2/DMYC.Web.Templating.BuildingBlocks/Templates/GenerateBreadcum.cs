﻿using System;
using System.Collections.Generic;
using System.Linq;
using Tridion.ContentManager;
using Tridion.ContentManager.CommunicationManagement;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.Extensions.ContentManager.Templating;
using Tridion.ContentManager.ContentManagement;
using Tridion.ContentManager.Publishing.Rendering;

namespace DMYC.Web.Templating.BuildingBlocks.Templates
{
    [TcmTemplateTitle("GenerateBreadcum")] 
    public class GenerateBreadcum : TemplateBase {
        /// <summary>
        /// Transforms the current component.
        /// </summary>
        /// <param name="engine">The engine.</param>
        /// <param name="package">The package.</param>
        public override void Transform(Engine engine, Package package)
        {

            base.Transform(engine, package);

            Engine m_Engine;
            m_Engine = engine;
            Page page = this.GetPage(engine, package);

            //Check if this is an index page - if it is the format of the breadcrumb changes
            bool isIndex = false;
            if (page.FileName == "index")
                isIndex = true;

            //Read format strings from the package - if none there, use defaults
            String pattern = package.GetValue("BreadcrumbPattern");
            String pagePattern = package.GetValue("BreadcrumbPatternPage");

            if (pattern == null)
                pattern = "<li><a href=\"{0}\">{1}</a></li>";

            if (pagePattern == null)
                pagePattern = "<li>{0}</li>";

            //Create the final (non-link) part of the breadcrumb
            String result = "";
            //For section (index) pages we do not show the page title
            if (!isIndex)
                result = String.Format(pagePattern, this.GetPageTitle(page));

            //Loop up through all the parent Structure Groups writing them out as links
            StructureGroup sg = page.OrganizationalItem as StructureGroup;
            while (sg != null)
            {
                string title = this.GetStructureGroupTitle(sg);
                //First time round check if this is an index page, if not the title is shown plain text
                if (!isIndex)
                {
                    result = String.Format(pattern, sg.PublishLocationUrl, title) + result;
                }
                else
                {
                    result = String.Format(pagePattern, title);
                }
                sg = sg.OrganizationalItem as StructureGroup;
                isIndex = false;
            }
            package.PushItem("Breadcrumb", package.CreateHtmlItem(result));
        }


        /// <summary>
        /// Returns the page object that is defined in the package for this template.
        /// </summary>
        /// <remarks>
        /// This method should only be called when there is an actual Page item in the package. 
        /// It does not currently handle the situation where no such item is available.
        /// </remarks>
        /// <returns>the page object that is defined in the package for this template.</returns>
        protected Page GetPage(Engine engine, Package package)
        {
            CheckInitialized();
            //first try to get from the render context
            RenderContext renderContext = engine.PublishingContext.RenderContext;
            if (renderContext != null)
            {
                Page contextPage = renderContext.ContextItem as Page;
                if (contextPage != null)
                    return contextPage;
            }
            Item pageItem = package.GetByType(ContentType.Page);
            if (pageItem != null)
                return (Page)engine.GetObject(pageItem.GetAsSource().GetValue("ID"));

            return null;
        }

        protected string GetPageOrStructureGroupTitle(RepositoryLocalObject pageOrSg)
        {
            if (pageOrSg is Page)
                return GetPageTitle(pageOrSg as Page);
            else
                return GetStructureGroupTitle(pageOrSg as StructureGroup);
        }

        protected string GetPageTitle(Page page){
            return ComponentTitle(page);
        }

        protected string GetStructureGroupTitle(StructureGroup sg)
        {
            Filter filter = new Filter();
            filter.Conditions["ItemType"] = ItemType.Page;

            filter.BaseColumns = ListBaseColumns.Extended;

            IList<RepositoryLocalObject> list = sg.GetItems(filter);

            if (list != null)
            {
                foreach (RepositoryLocalObject item in list)
                {
                    if (item is Page)
                    {
                        Page childPage = item as Page;
                        // Index pages are prefixed with "000. "
                        if (childPage.Title.StartsWith("000. ")) {
                            return GetPageTitle(childPage);
                        }
                    }
                }
            }
            return null;
        }

        private String ComponentTitle(Page Page){
          string navTitle="";
            if (Page.Title.IndexOf(".") != -1) {
                navTitle = Page.Title.Substring(Page.Title.IndexOf(".") + 1).Trim();
            }
            else{
                navTitle = Page.Title.Trim();
            }
                
            return navTitle;
        }

        public string StripPrefix(string title)
        {
            int length = 4;
            if (title.Length < 4)
                length = title.Length - 1;
            string prefix = title.Substring(0, length);
            int result = 0;
            //Handle number prefix
            if (int.TryParse(prefix, out result))
            {
                title = title.Substring(title.IndexOf(" ") + 1);
            }
            title = title.Trim();
            return title;
        }
    }
}
