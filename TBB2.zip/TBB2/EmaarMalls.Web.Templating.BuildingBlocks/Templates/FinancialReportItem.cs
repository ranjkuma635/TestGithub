﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml;
using System.IO;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.ContentManagement.Fields;
using Tridion.Extensions.ContentManager.Templating;
using Tridion.ContentManager.ContentManagement;
using Emaar.Web.Tridion.System.Extensions;
using Tridion.ContentManager.Publishing;

namespace EmaarMalls.Web.Templating.BuildingBlocks.Templates
{

    [TcmTemplateTitle("FinancialReport DCP")]
    public class FinancialReportItem : TemplateBase
    {
        //<summary>
        //Transforms the current component.
        //</summary>
        //<param name="engine">The engine.</param>
        //<param name="package">The package.</param>
        public override void Transform(Engine engine, Package package)
        {
            base.Transform(engine, package);

            using (StringWriter sw = new StringWriter())
            {

                using (XmlTextWriter xml = new XmlTextWriter(sw))
                {
                    string itemId = Component.Id;

                    if (Component != null)
                    {

                        /* Start of Emaar - Financial Report DCP */
                        if (Component.Schema.Title.Equals("Emaar - Financial Report"))
                        {
                            DateTime startDate = Component.DateMetaValue("publishdate");
                            string strStartDate = "";
                            string year = "";
                            string month = "";

                            if (startDate.ToString("dd/MM/yyyy") != "01/01/0001")
                            {
                                strStartDate = startDate.ToString("dd/MM/yyyy");
                                year = startDate.ToString("yyyy");
                                month = startDate.ToString("MM");
                            }

                            xml.WriteStartElement("item");

                            xml.WriteAttributeString("uri", Component.Id);
                            xml.WriteAttributeString("id", itemId.Split('-')[1]);
                            xml.WriteAttributeString("schema", Component.Schema.Title.Split('-')[1].TrimStart().Replace(" ", ""));
                            xml.WriteAttributeString("title", Component.StringValue("title"));
                            xml.WriteAttributeString("publishDate", strStartDate);
                            xml.WriteAttributeString("sortDate", GetSortDate(strStartDate));
                            xml.WriteAttributeString("year", year);
                            xml.WriteAttributeString("month", month);
                            if (Component.KeywordValue("period") != null)
                            {
                                xml.WriteAttributeString("period", Component.KeywordValue("period").Description);
                            }
                            else
                            {
                                //To handle Disclosures and Governance components
                                xml.WriteAttributeString("period", month);
                            }
                            if (Component.KeywordValue("document") != null)
                            {
                                xml.WriteAttributeString("documentkey", Component.KeywordValue("document").Key);
                                xml.WriteAttributeString("document", Component.KeywordValue("document").Description);
                            }
                            if (Component.KeywordValue("documentdisclosures") != null)
                            {
                                xml.WriteAttributeString("documentdisclosureskey", Component.KeywordValue("documentdisclosures").Key);
                                xml.WriteAttributeString("documentdisclosures", Component.KeywordValue("documentdisclosures").Description);
                            }
                            if (Component.KeywordValue("documentgovernance") != null)
                            {
                                xml.WriteAttributeString("documentgovernancekey", Component.KeywordValue("documentgovernance").Key);
                                xml.WriteAttributeString("documentgovernance", Component.KeywordValue("documentgovernance").Description);
                            }
                            if (Component.KeywordValue("documentotherresources") != null)
                            {
                                xml.WriteAttributeString("documentotherresourceskey", Component.KeywordValue("documentotherresources").Key);
                                xml.WriteAttributeString("documentotherresources", Component.KeywordValue("documentotherresources").Description);
                            }



                            if (Component.ComponentValue("download") != null)
                            {
                                xml.WriteAttributeString("download", PublishBinary(Component.ComponentValue("download")));
                            }

                            xml.WriteEndElement();//item

                        }

                        /* End of Emaar - Financial Report DCP*/

                        Package.AddXml(Package.OutputName, sw.ToString());
                    }
                }
            }
        }





        private static string getHtml(string html)
        {
            return Utility.removeXHTMLtags(html);
        }


        private string GetSortDate(string strDate)
        {

            string strRetval = "";


            string[] datetime = strDate.Split(new char[] { '/' });

            string Year = datetime[2];
            string Month = datetime[1];
            string Day = datetime[0];

            if (Month.Length == 1)
                Month = "0" + Month;

            if (Day.Length == 1)
                Day = "0" + Day;

            strRetval = Year + Month + Day;

            return strRetval;

        }

        public bool checkshouldpublish(string metaval)
        {
            bool shouldadd = true;
            if (Engine.PublishingContext.PublicationTarget.Id.ToString() == "tcm:0-16-65537")
            {
                if (metaval == "Yes")
                    shouldadd = false;
            }
            return shouldadd;
        }


        public string GetYouTubeImage(string videoUrl)
        {
            int mInd = videoUrl.IndexOf("/v/");
            if (mInd < 0) { mInd = videoUrl.IndexOf("?v="); }
            if (mInd != -1)
            {
                string strVideoCode = videoUrl.Substring(videoUrl.IndexOf("?v=") + 3);
                int ind = strVideoCode.IndexOf("?");
                strVideoCode = strVideoCode.Substring(0, ind == -1 ? strVideoCode.Length : ind);
                return "https://img.youtube.com/vi/" + strVideoCode + "/hqdefault.jpg";
            }
            else
                return "not provided";
        }
    }
}
