﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml;
using System.IO;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.ContentManagement.Fields;
using Tridion.Extensions.ContentManager.Templating;
using Tridion.ContentManager.ContentManagement;
using Tridion.ContentManager.CommunicationManagement;
using Emaar.Web.Tridion.System.Extensions;
using Tridion.ContentManager.Publishing;
using Tridion.ContentManager.Publishing.Rendering;
using Tridion.ContentManager;
using System.Web;

namespace EmaarMalls.Web.Templating.BuildingBlocks.Templates
{

    [TcmTemplateTitle("Callouts")]
    public class Callouts : TemplateBase
    {
        //<summary>
        //Transforms the current component.
        //</summary>
        //<param name="engine">The engine.</param>
        //<param name="package">The package.</param>
        public override void Transform(Engine engine, Package package)
        {
            base.Transform(engine, package);
            try
            {
                Page page = this.GetPage(engine, package);

                //Check if this is an index page - if it is the format of the breadcrumb changes
                bool isIndex = false;
                if (page.FileName == "index")
                    isIndex = true;
                if (isIndex)
                {


                    using (StringWriter sw = new StringWriter())
                    {

                        using (XmlTextWriter xml = new XmlTextWriter(sw))
                        {

                            if (Component != null)
                            {
                                xml.WriteStartElement("section");
                                xml.WriteAttributeString("class", "archive");
                                xml.WriteStartElement("div");//start div cmNPageTop
                                xml.WriteAttributeString("class", "cmNPageTop");
                                xml.WriteString("@@Breadcrumb@@");
                                xml.WriteElementString("h2", Component.StringValue("heading"));
                                if (!string.IsNullOrEmpty(Component.StringValue("intro")))
                                    xml.WriteElementString("h5", Utility.decodeString(Component.StringValue("intro")));
                                xml.WriteEndElement();//end div cmNPageTop

                                xml.WriteStartElement("div");//start div block
                                xml.WriteAttributeString("class", "block");


                                StructureGroup sg = page.OrganizationalItem as StructureGroup;

                                Filter filter = new Filter();

                                //filter.Conditions["ItemType"] = ItemType.Page;


                                IList<RepositoryLocalObject> list = sg.GetItems(filter);

                                if (list != null)
                                {
                                    foreach (RepositoryLocalObject item in list)
                                    {
                                        if (item is Page)
                                        {
                                            Page childPage = item as Page;
                                            Logger.Info("childPage title" + childPage.Title);
                                            int n;
                                            if (int.TryParse(childPage.Title.Substring(0, 3), out n))
                                            {

                                                Logger.Info("childSg to be added");

                                                if (!childPage.Equals(page) && childPage.IsPublishedInContext && childPage.ComponentPresentations.Count > 0)
                                                {
                                                    writeCallout(xml, childPage.ComponentPresentations[0].Component);
                                                }
                                            }
                                        }

                                        if (item is StructureGroup)
                                        {

                                            StructureGroup childSg = item as StructureGroup;
                                            Logger.Info("childSg title" + childSg.Title);
                                            int m;
                                            if (int.TryParse(childSg.Title.Substring(0, 3), out m))
                                            {
                                                Filter innerfilter = new Filter();

                                                IList<RepositoryLocalObject> innerlist = childSg.GetItems(innerfilter);

                                                if (innerlist != null)
                                                {
                                                    foreach (RepositoryLocalObject inneritem in innerlist)
                                                    {
                                                        if (inneritem is Page)
                                                        {
                                                            Page innerchildPage = inneritem as Page;
                                                            Logger.Info("childPage title" + innerchildPage.Title);
                                                            int p;
                                                            if ((innerchildPage.IsPublishedInContext && int.TryParse(innerchildPage.Title.Substring(0, 3), out p)))
                                                            {

                                                                if (innerchildPage.FileName.Equals("index") && innerchildPage.ComponentPresentations.Count > 0)
                                                                {
                                                                    writeCallout(xml, innerchildPage.ComponentPresentations[0].Component);
                                                                }
                                                            }
                                                        }
                                                    }
                                                }

                                            }
                                        }
                                    }
                                }

                                xml.WriteEndElement();//end div block

                                xml.WriteEndElement();//end section

                                Package.AddXml(Package.OutputName, sw.ToString());
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Info(ex.Message + ex.StackTrace);
                throw ex;
            }
        }

        protected Page GetPage(Engine engine, Package package)
        {
            CheckInitialized();
            //first try to get from the render context
            RenderContext renderContext = engine.PublishingContext.RenderContext;
            if (renderContext != null)
            {
                Page contextPage = renderContext.ContextItem as Page;
                if (contextPage != null)
                    return contextPage;
            }
            Item pageItem = package.GetByType(ContentType.Page);
            if (pageItem != null)
                return (Page)engine.GetObject(pageItem.GetAsSource().GetValue("ID"));

            return null;
        }

        private void writeCallout(XmlTextWriter xml, Component comp)
        {
            Logger.Info("Insisde writeCallout");
            xml.WriteStartElement("div");
            xml.WriteAttributeString("class", "boxBlock");
            xml.WriteStartElement("div");
            xml.WriteAttributeString("class", "fullBlock");

            xml.WriteStartElement("img");
            xml.WriteAttributeString("src", PublishBinary(comp.EmbeddedMetaValue("callout").ComponentValue("image")));
            xml.WriteAttributeString("alt", comp.EmbeddedMetaValue("callout").StringValue("title"));
            xml.WriteEndElement();//img 
            xml.WriteStartElement("div");
            xml.WriteAttributeString("class", "floatingBlock");
            xml.WriteStartElement("div");
            xml.WriteAttributeString("class", "floatingTable");
            xml.WriteStartElement("a");
            xml.WriteAttributeString("tridion:href", comp.Id);
            xml.WriteAttributeString("class", "cName");
            xml.WriteString(comp.EmbeddedMetaValue("callout").StringValue("title"));
            xml.WriteEndElement();//a
            xml.WriteEndElement();//div floatingBlock
            xml.WriteEndElement();//div floatingBlock
            xml.WriteEndElement();//div fullBlock
            xml.WriteEndElement();//div boxBlock

            Logger.Info("Leaveing writeCallout");
        }
    }
}
