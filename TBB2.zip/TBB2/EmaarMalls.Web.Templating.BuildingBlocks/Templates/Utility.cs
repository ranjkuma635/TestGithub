﻿using System;
using System.Web;

namespace EmaarMalls.Web.Templating.BuildingBlocks.Templates
{
    public static class Utility
    {

        /// <summary>
        /// Log an error message
        /// </summary>
        /// <param name="format">Message format string</param>
        /// <param name="args">Format string parameters</param>
        public static string removeXHTMLtags(string format)
        {
            return format.Replace(" xmlns=" + "\"" + "http://www.w3.org/1999/xhtml" + "\"", "");
        }

        public static string encodeString(string content)
        {
            if (!String.IsNullOrEmpty(content))
                return HttpUtility.HtmlEncode(content);
            return String.Empty;
        }
        public static string decodeString(string content)
        {
            if (!String.IsNullOrEmpty(content))
                return HttpUtility.HtmlDecode(content);
            return String.Empty;
        }

    }
}
