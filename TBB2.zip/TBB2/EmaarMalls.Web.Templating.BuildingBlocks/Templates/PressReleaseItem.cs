﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml;
using System.IO;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.ContentManagement.Fields;
using Tridion.Extensions.ContentManager.Templating;
using Tridion.ContentManager.ContentManagement;
using Emaar.Web.Tridion.System.Extensions;
using Tridion.ContentManager.Publishing;

namespace EmaarMalls.Web.Templating.BuildingBlocks.Templates
{

    [TcmTemplateTitle("Press Release DCP")]
    public class PressReleaseItem : TemplateBase
    {
        //<summary>
        //Transforms the current component.
        //</summary>
        //<param name="engine">The engine.</param>
        //<param name="package">The package.</param>
        public override void Transform(Engine engine, Package package)
        {
            base.Transform(engine, package);



            using (StringWriter sw = new StringWriter())
            {

                using (XmlTextWriter xml = new XmlTextWriter(sw))
                {
                    string itemId = Component.Id;

                    if (Component != null)
                    {

                        /* Start of Emaar - Press Release DCP */

                        if (Component.Schema.Title.Equals("Emaar Malls - Press Release"))
                        {
                            DateTime startDate = Component.DateMetaValue("publishDate");
                            string strStartDate = "";
                            string year = "";
                            string month = "";


                            if (startDate.ToString("dd/MM/yyyy") != "01/01/0001")
                            { strStartDate = startDate.ToString("dd/MM/yyyy"); year = startDate.ToString("yyyy"); month = startDate.ToString("MM"); }

                            xml.WriteStartElement("item");
                            Component image = Component.ComponentValue("image");
                            if (image != null)
                            {
                                xml.WriteAttributeString("src", PublishBinary(image));
                                xml.WriteAttributeString("thumb", GenerateThumbnail(image, "thumb", 188, 125));
                            }
                            xml.WriteAttributeString("uri", Component.Id);
                            xml.WriteAttributeString("id", itemId.Split('-')[1]);
                            xml.WriteAttributeString("schema", Component.Schema.Title.Split('-')[1].TrimStart().Replace(" ", ""));
                            xml.WriteAttributeString("publishDate", strStartDate);
                            xml.WriteAttributeString("sortDate", GetSortDate(strStartDate));
                            xml.WriteAttributeString("year", year);
                            xml.WriteAttributeString("month", month);


                            xml.WriteAttributeString("title", Component.StringValue("title"));
                            xml.WriteAttributeString("description", Component.StringValue("description"));

                            ItemFields fields = new ItemFields(Component.Content, Component.Schema);
                            EmbeddedSchemaField emb = (EmbeddedSchemaField)fields["detail"];
                            // Loop
                            foreach (ItemFields embeddedfields in emb.Values)
                            {
                                xml.WriteStartElement("detail");

                                if (embeddedfields["key"] != null)
                                {

                                    xml.WriteAttributeString("key", embeddedfields.StringValue("key"));
                                }

                                if (embeddedfields["value"] != null)
                                {
                                    xml.WriteAttributeString("value", embeddedfields.StringValue("value"));

                                }
                                xml.WriteEndElement();//detail


                            }

                            xml.WriteEndElement();//item
                        }

                        /* End of Emaar - Press Release DCP*/

                        Package.AddXml(Package.OutputName, sw.ToString());
                    }
                }
            }
        }





        private static string getHtml(string html)
        {
            return Utility.removeXHTMLtags(html);
        }


        private string GetSortDate(string strDate)
        {

            string strRetval = "";


            string[] datetime = strDate.Split(new char[] { '/' });

            string Year = datetime[2];
            string Month = datetime[1];
            string Day = datetime[0];

            if (Month.Length == 1)
                Month = "0" + Month;

            if (Day.Length == 1)
                Day = "0" + Day;

            strRetval = Year + Month + Day;

            return strRetval;

        }

        public bool checkshouldpublish(string metaval)
        {
            bool shouldadd = true;
            if (Engine.PublishingContext.PublicationTarget.Id.ToString() == "tcm:0-16-65537")
            {
                if (metaval == "Yes")
                    shouldadd = false;
            }
            return shouldadd;
        }


        public string GetYouTubeImage(string videoUrl)
        {
            int mInd = videoUrl.IndexOf("/v/");
            if (mInd < 0) { mInd = videoUrl.IndexOf("?v="); }
            if (mInd != -1)
            {
                string strVideoCode = videoUrl.Substring(videoUrl.IndexOf("?v=") + 3);
                int ind = strVideoCode.IndexOf("?");
                strVideoCode = strVideoCode.Substring(0, ind == -1 ? strVideoCode.Length : ind);
                return "https://img.youtube.com/vi/" + strVideoCode + "/hqdefault.jpg";
            }
            else
                return "not provided";
        }
    }
}
