﻿using System;
using System.Linq;
using Tridion.ContentManager.CommunicationManagement;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.ContentManagement.Fields;
using Tridion.Extensions.ContentManager.Templating;
using Tridion.ContentManager.ContentManagement;
using Tridion.ContentManager.Publishing.Rendering;
using Emaar.Web.Tridion.System.Extensions;
using System.Xml;

namespace EmaarMalls.Web.Templating.BuildingBlocks.Templates
{
    [TcmTemplateTitle("Content Page")]
    public class ContentPage : TemplateBase
    {
        public override void Transform(Engine engine, Package package)
        {
            base.Transform(engine, package);
            String seoDescription = String.Empty;
            String seoKeywords = String.Empty;
            String seoImage = String.Empty;
            String spageTitle = String.Empty;


            if (Page.ComponentPresentations.Count > 0)
            {
                Component component = Page.ComponentPresentations[0].Component;

                if (component.EmbeddedMetaValue("seodata") != null)
                {
                    ItemFields seodata = component.EmbeddedMetaValue("seodata");

                    if (!String.IsNullOrEmpty(seodata.StringValue("pageTitle")))
                    {
                        spageTitle = seodata.StringValue("pageTitle");
                    }

                    if (seodata.StringValue("SEODescription") != null)
                    {
                        seoDescription = seodata.StringValue("SEODescription");
                    }
                    if (seodata.StringValue("SEOKeywords") != null)
                    {
                        seoKeywords = seodata.StringValue("SEOKeywords");
                    } 
                }

                if (component.EmbeddedMetaValue("seometadata") != null)
                {
                    ItemFields seometadata = component.EmbeddedMetaValue("seometadata");

                    if (!String.IsNullOrEmpty(seometadata.StringValue("pageTitle")))
                    {
                        spageTitle = seometadata.StringValue("pageTitle");
                    }

                    if (seometadata.StringValue("SEODescription") != null)
                    {
                        seoDescription = seometadata.StringValue("SEODescription");
                    }
                    if (seometadata.StringValue("SEOKeywords") != null)
                    {
                        seoKeywords = seometadata.StringValue("SEOKeywords");
                    }
                }

                seoImage = calloutImage(component);

                if (String.IsNullOrEmpty(spageTitle))
                {
                    if (component.StringValue("title") != null){
                        spageTitle = component.StringValue("title");
                    }
                    else{
                        spageTitle = PageTitle(Page);
                    }
                }
                if (String.IsNullOrEmpty(seoDescription))
                {
                    seoDescription = calloutText(component);
                }

                package.AddString("PageTitle", spageTitle);
                package.AddString("SEODescription", seoDescription);
                package.AddString("SEOKeywords", seoKeywords);
                package.AddString("SEOImage", seoImage);
                package.AddString("PageURL", Page.PublishLocationUrl);

            }

            Callouts(Page);
        }


        private String PageTitle(Page Page)
        {
            string navTitle = "";
            if (Page.Title.IndexOf(".") != -1)
            {
                navTitle = Page.Title.Substring(Page.Title.IndexOf(".") + 1).Trim();
            }
            else
            {
                navTitle = Page.Title.Trim();
            }

            return navTitle;
        }

        public string StripPrefix(string title)
        {
            int length = 4;
            if (title.Length < 4)
                length = title.Length - 1;
            string prefix = title.Substring(0, length);
            int result = 0;
            //Handle number prefix
            if (int.TryParse(prefix, out result))
            {
                title = title.Substring(title.IndexOf(" ") + 1);
            }
            title = title.Split('.')[1];
            title = title.Trim();
            return title;
        }

        private Page GetPage(Engine engine, Package package)
        {
            CheckInitialized();
            //first try to get from the render context
            RenderContext renderContext = engine.PublishingContext.RenderContext;
            if (renderContext != null)
            {
                Page contextPage = renderContext.ContextItem as Page;
                if (contextPage != null)
                    return contextPage;
            }
            Item pageItem = package.GetByType(ContentType.Page);
            if (pageItem != null)
                return (Page)engine.GetObject(pageItem.GetAsSource().GetValue("ID"));

            return null;
        }

        private void Callouts(Page Page)
        {

            StructureGroup sg = Page.OrganizationalItem as StructureGroup;
            bool meta = false;
            XmlNodeList xCalloutList = null;
            if (Page.Metadata != null)
            {
                xCalloutList = Page.Metadata.ChildNodes;
                foreach (XmlNode item in xCalloutList)
                {
                    if (item.Name.Equals("fSideBar"))
                    {
                        Package.AddString(item.InnerText, item.InnerText);
                        meta = true;
                    }

                }
            }

            if (meta == false)
            {
                do
                {
                    if (sg.Metadata != null)
                    {
                        xCalloutList = sg.Metadata.ChildNodes;
                        foreach (XmlNode item in xCalloutList)
                        {
                            if (item.Name.Equals("fSideBar"))
                            {
                                Package.AddString(item.InnerText, item.InnerText);
                                meta = true;
                            }
                        }
                    }
                    if (meta == false)
                    {
                        if (sg.Title.Equals("Root"))
                        {
                            break;
                        }
                        else
                        {
                            sg = sg.OrganizationalItem as StructureGroup;
                        }
                    }
                }
                while (meta == false);
            }
        }

        private string calloutImage(Component component)
        {

            if (component.EmbeddedMetaValue("callout") != null)
            {
                ItemFields callout = component.EmbeddedMetaValue("callout");

                if (callout.ComponentValue("image") != null)
                {
                    Logger.Info("calloutImage " + callout.ComponentValue("image"));
                    return PublishBinary(callout.ComponentValue("image"));
                }
                else if (component.ComponentValue("image") != null)
                {
                    Logger.Info("compImage " + component.ComponentValue("image"));
                    return PublishBinary(component.ComponentValue("image"));
                }
            }
            return string.Empty;
        }

     private string calloutText(Component component)
        {

            if (component.EmbeddedMetaValue("callout") != null)
            {
                ItemFields callout = component.EmbeddedMetaValue("callout");

                if (!String.IsNullOrEmpty(callout.StringValue("value"))){
                    Logger.Info("calloutText " + callout.StringValue("value"));
                    return callout.StringValue("value");
                }
            }
            return string.Empty;
        }


    }
}
