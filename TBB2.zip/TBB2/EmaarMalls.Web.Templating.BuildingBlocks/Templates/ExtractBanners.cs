﻿using System;
using System.Linq;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager;
using Tridion.ContentManager.ContentManagement;
using Emaar.Web.Tridion.System.Extensions;
using Tridion.Extensions.ContentManager.Templating;
using System.Collections.Generic;

namespace EmaarMalls.Web.Templating.BuildingBlocks.Templates
{
    [TcmTemplateTitle("ExtractBanners")]
    public class ExtractBanners : TemplateBase
    {
        public override void Transform(Engine engine, Package package)
        {
            base.Transform(engine, package);
            string bannerPath = string.Empty;
            string bannerAltText = string.Empty;
            string bannerTitle = string.Empty;
            try
            {
                string html = String.Empty;

                if ((Page.ComponentMetaValue("banner") != null) && (!String.IsNullOrEmpty(Page.StringMetaValue("bannertitle"))))
                {
                    bannerPath = PublishBinary(Page.ComponentMetaValue("banner"));
                    bannerAltText = Page.ComponentMetaValue("banner").StringMetaValue("altText");
                    bannerTitle = Page.StringMetaValue("bannertitle");
                }
                else
                {
                    OrganizationalItem structureGroup = Page.OrganizationalItem;
                    do
                    {
                        if ((structureGroup.ComponentMetaValue("banner") != null) && (!String.IsNullOrEmpty(structureGroup.StringMetaValue("bannertitle"))))
                        {
                            bannerPath = PublishBinary(structureGroup.ComponentMetaValue("banner"));
                            bannerAltText = structureGroup.ComponentMetaValue("banner").StringMetaValue("altText");
                            bannerTitle = structureGroup.StringMetaValue("bannertitle");
                            break;
                        }
                        structureGroup = structureGroup.OrganizationalItem;
                    } while (structureGroup != null);
                    //} while ((structureGroup != null) && (!structureGroup.Title.ToLower().Equals("root")));
                }

                html = BannerHTML(bannerPath, bannerAltText, bannerTitle);
                Package.AddHtml("Banner", html);
            }
            catch (Exception ex)
            {
                throw new Exception("Error in Banner processing: " + ex.Message + ex.StackTrace);
            }

        }

        private string BannerHTML(string bannerPath, string bannerAltText, string bannerTitle)
        {
            string html = String.Empty;
            html = String.Format(
                "<section id=\"top\" class=\"top\"><div class=\"banner\"><img class=\"cover\" src=\"{0}\" alt=\"{1}\"><div class=\"bannerInner\"><div class=\"bannerIn\"><h1>{2}</h1></div></div></div></section>",
                bannerPath,
                bannerAltText,
                bannerTitle
                );
            return html;
        }
    }
}
