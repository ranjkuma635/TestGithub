﻿using System;
using System.Text;
using Tridion.ContentManager;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.ContentManagement;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.Extensions.ContentManager.Templating;

namespace DIR.Web.Templating.BuildingBlocks.Templates
{
    [TcmTemplateTitle("Newsticker")]
    public class Newsticker : TemplateBase
    {

        public override void Transform(Engine engine, Package package)
        {
            string strTitle = string.Empty;
            string sCompID = string.Empty;
            string show = "No";

            int i = 0;
            base.Transform(engine, package);

            StringBuilder shtml = new StringBuilder();

            if (Page.ComponentPresentations.Count > 0)
            {
                Item componentsItem = package.GetByName(Package.ComponentsName);
                IComponentPresentationList componentPresentations = ComponentPresentationList.FromXml(componentsItem.GetAsString());

                foreach (ComponentPresentation componentPresentation in componentPresentations)
                {
                    IdentifiableObject componnet = engine.GetSession().GetObject(componentPresentation.ComponentUri.ToString());

                    Component c;
                    c = engine.GetObject(componnet.Id) as Component;
                    if(c.Schema.Id.ToString().Contains("41666"))
                        show = "Yes";
  

                }

                Package.PushItem("Newsticker", Package.CreateStringItem(ContentType.Text, show.ToString()));
            }


        }

    }
}
