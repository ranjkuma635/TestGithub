﻿using System;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.ContentManagement;
using Tridion.Extensions.ContentManager.Templating;
using Emaar.Web.Tridion.System.Extensions;

namespace DIR.Web.Templating.BuildingBlocks.Templates
{
    [TcmTemplateTitle("Header information")]
    public class Headerinformation : TemplateBase 
    {
        public override void Transform(Engine engine, Package package)
        {

            base.Transform(engine, package);

            Component comp = Page.ComponentPresentations[0].Component;
            if (comp.Schema.Id.ToString().Contains("40263"))
            {
                Package.AddString("HeaderTitle", comp.StringValue("Title"));

                Component image = comp.ComponentValue("Image");
                if (image != null)
                {
                    Package.AddString("MainImage", PublishBinary(image));
                }

            }


        }
    }
}
