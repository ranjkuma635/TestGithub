﻿using System;
using System.Collections.Generic;
using System.Xml;
using Tridion.ContentManager.ContentManagement.Fields;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.Extensions.ContentManager.Templating;
using System.IO;
using Emaar.Web.Tridion.System.Extensions;

namespace DIR.Web.Templating.BuildingBlocks.Templates
{
    [TcmTemplateTitle("Dcp timings")]
    public class DcpTimings : TemplateBase
    {
        public override void Transform(Engine engine, Package package)
        {

            base.Transform(engine, package);

            using (StringWriter sw = new StringWriter())
            {

                using (XmlTextWriter xml = new XmlTextWriter(sw))
                {

                    xml.WriteStartElement("Data");


                    if (Component != null)
                    {
                        
                        
                            xml.WriteAttributeString("uri", Component.Id);

                            xml.WriteElementString("Startdate", Component.DateMetaValue("FstartDate").ToString("dd/MM/yyyy"));
                            xml.WriteElementString("Enddate", Component.DateMetaValue("FendDate").ToString("dd/MM/yyyy"));
                            xml.WriteElementString("Type", Component.StringMetaValue("Type")); 

                            xml.WriteStartElement("Headings");
                                xml.WriteElementString("Activity", Component.StringValue("ActivityTitle"));
                                xml.WriteElementString("Specialnoteactivity", Component.StringValue("Specialnoteactivity"));
                                xml.WriteElementString("Timings", Component.StringValue("TimingsTitle"));
                                xml.WriteElementString("Price", Component.StringValue("PriceTitle"));
                            xml.WriteEndElement();


                            IList<ItemFields> componentsshop = Component.EmbeddedValues("Activities");

                            xml.WriteStartElement("Activitylist");
                            if (componentsshop.Count > 0)
                            {

                                for (int i = 0; i < componentsshop.Count; i++)
                                {
                                    xml.WriteStartElement("Activities");
                                    xml.WriteElementString("Highlight", componentsshop[i].StringValue("Highlight")); 
                                    xml.WriteElementString("Activity", componentsshop[i].StringValue("Activity"));
                                    xml.WriteElementString("Timing", componentsshop[i].StringValue("Timings"));
                                    xml.WriteElementString("Price", componentsshop[i].StringValue("Price")); 
                                    xml.WriteEndElement();
                                }
                            }
                            xml.WriteEndElement();
                        
                    }

                    xml.WriteEndElement();
                }

                Package.AddXml(Package.OutputName, sw.ToString());
            }

        }

    }
}
