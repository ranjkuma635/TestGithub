﻿using System;
using System.Text;
using Tridion.ContentManager;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.ContentManagement;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.Extensions.ContentManager.Templating;
using Tridion.ContentManager.ContentManagement.Fields;

namespace DIR.Web.Templating.BuildingBlocks.Templates
{
    [TcmTemplateTitle("Right Content Component")]
    public class RightcontentComponent : TemplateBase 
    {

        public override void Transform(Engine engine, Package package)
        {
            string strTitle = string.Empty;
            string sCompID = string.Empty;

            int i = 0;
            base.Transform(engine, package);

            StringBuilder shtml = new StringBuilder();

            if (Page.ComponentPresentations.Count > 0)
            {


                Item componentsItem = package.GetByName(Package.ComponentsName);
                IComponentPresentationList componentPresentations = ComponentPresentationList.FromXml(componentsItem.GetAsString());

                foreach (ComponentPresentation componentPresentation in componentPresentations)
                {
                    IdentifiableObject componnet = engine.GetSession().GetObject(componentPresentation.ComponentUri.ToString());

                    Component c;
                    c = engine.GetObject(componnet.Id) as Component;
                    ItemFields CompFields = new ItemFields(c.Content,c.Schema);

                    if ((c.Schema.Id.ToString().Contains("41364")) || (c.Schema.Id.ToString().Contains("41356")) || (c.Schema.Id.ToString().Contains("40263")))
                    {
                        strTitle = CompFields["Title"].ToString();
                        if (i == 0)
                        {
                            shtml.Append("<li class=\"list-group-item active\"><a href=\"#\">" + strTitle + "</a></li>");
                            shtml.Append(Environment.NewLine);
                        }
                        else
                        {
                            shtml.Append(Environment.NewLine); 
                            shtml.Append("<li class=\"list-group-item\"><a href=\"#" + c.Id + "\">" + strTitle + "</a></li>");
                        }

                        i++;

                    }

                }

                Package.PushItem("Rightnav", Package.CreateStringItem(ContentType.Html , shtml.ToString()));
            }            


        }


    }
}
