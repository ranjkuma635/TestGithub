﻿using System;
using System.Xml;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.ContentManagement;
using Tridion.Extensions.ContentManager.Templating;
using System.IO;
using Emaar.Web.Tridion.System.Extensions;

namespace DIR.Web.Templating.BuildingBlocks.Templates
{
    [TcmTemplateTitle("DCP press")]
    public class DCPpress : TemplateBase
    {
        public override void Transform(Engine engine, Package package)
        {

            base.Transform(engine, package);

            using (StringWriter sw = new StringWriter())
            {

                using (XmlTextWriter xml = new XmlTextWriter(sw))
                {

                    xml.WriteStartElement("Data");


                    if (Component != null)
                    {
                        if (Component.Schema.Title == "DIR - Press Releases")
                        {
                            xml.WriteAttributeString("uri", Component.Id);

                            xml.WriteElementString("Title", Component.StringValue("Title"));

                            Component Pdf = Component.ComponentValue("Pdf");
                            if (Pdf != null)
                            {
                                xml.WriteElementString("Pdf", PublishBinary(Pdf));
                            }

                            xml.WriteElementString("PublishDate", Component.DateMetaValue("Publishdate").ToString("dd/MM/yyyy"));
                            xml.WriteElementString("Display", Component.StringMetaValue("Display"));
                            
                        }
                    }

                    xml.WriteEndElement();
                }

                Package.AddXml(Package.OutputName, sw.ToString());
            }

        }

    }
}
