﻿using System;
using System.Xml;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.ContentManagement;
using Tridion.Extensions.ContentManager.Templating;
using System.IO;
using Emaar.Web.Tridion.System.Extensions;

namespace DIR.Web.Templating.BuildingBlocks.Templates
{
    [TcmTemplateTitle("DCP")]
    public class DCP : TemplateBase
    {
        public override void Transform(Engine engine, Package package)
        {

            base.Transform(engine, package);

            using (StringWriter sw = new StringWriter())
            {

                using (XmlTextWriter xml = new XmlTextWriter(sw))
                {

                    xml.WriteStartElement("Data");


                    if (Component != null)
                    {
                        if (Component.Schema.Title == "DIR - Events" || Component.Schema.Title == "DIR - Promotion" || Component.Schema.Title == "DIR - No Events Promo")
                        {
                            xml.WriteAttributeString("uri", Component.Id);

                            xml.WriteElementString("Title", Component.StringValue("Title"));
                            xml.WriteElementString("Description", Component.XHTMLValue("Description"));

                            Component EventImage = Component.ComponentValue("Largeimage");
                            if (EventImage != null && EventImage.BinaryContent != null)
                            {

                                Component MetaLarge = EventImage.ComponentMetaValue("flarge");

                                if(MetaLarge!=null)
                                    xml.WriteElementString("LargeImage", PublishBinary(MetaLarge));
                                else
                                    xml.WriteElementString("LargeImage", PublishBinary(EventImage));

                                Component EventThumbImage = Component.ComponentMetaValue("fthumb");
                                if(EventThumbImage!=null)
                                    xml.WriteElementString("ThumbNailImage", PublishBinary(EventThumbImage));
                                else
                                    xml.WriteElementString("ThumbNailImage", GenerateThumbnail(EventImage, "Eventthumb", 300, 200, "#fff"));
                            }

                            //xml.WriteElementString("PublishDate", Component.DateMetaValue("fpublishdate").ToString("dd/MM/yyyy"));
                            xml.WriteElementString("Startdate", Component.DateMetaValue("fstartdate").ToString("dd/MM/yyyy"));
                            xml.WriteElementString("Enddate", Component.DateMetaValue("fenddate").ToString("dd/MM/yyyy"));
                            
                        }
                    }

                    xml.WriteEndElement();
                }

                Package.AddXml(Package.OutputName, sw.ToString());
            }

        }

    }
}
