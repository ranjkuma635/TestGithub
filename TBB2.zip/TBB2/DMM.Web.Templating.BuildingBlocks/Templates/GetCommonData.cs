﻿using System;
using Tridion.ContentManager.CommunicationManagement;
using Tridion.ContentManager.ContentManagement.Fields;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.Extensions.ContentManager.Templating;

namespace DMM.Web.Templating.BuildingBlocks.Templates
{
    [TcmTemplateTitle("Get Common Data")]
    class GetCommonData : TemplateBase
    {

        public override void Transform(Engine engine, Package package)
        {
            this.Initialize(engine, package);
            Page page = GetPage();

            StructureGroup RootSG = (StructureGroup)page.OrganizationalItem as StructureGroup;
            m_Package.PushItem("publicationurl", m_Package.CreateStringItem(ContentType.Text, getPubURL(page)));
            m_Package.PushItem("getHeightStyle", m_Package.CreateStringItem(ContentType.Html , getPagHeightStyle(page)));

        }

        private string getPubURL(Page page)
        {
            string pub = "tcm:0-" + page.Id.PublicationId + "-1";
            Publication publication;
            publication = m_Engine.GetObject(pub) as Publication;
            return publication.PublicationUrl.ToString();
        }

        private string getPagHeightStyle(Page page)
        {

            string strPageStyle = "";

            ItemFields metadataFields = new ItemFields(page.Metadata, page.MetadataSchema);
            if (metadataFields != null)
            {
                if (!String.IsNullOrEmpty(metadataFields["fhight"].ToString()))
                {
                    strPageStyle = "style=\"height:" + metadataFields["fhight"].ToString() + "\"";
                }

                

            }
            return strPageStyle;
        }


    }
}
