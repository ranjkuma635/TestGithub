﻿using System;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.Extensions.ContentManager.Templating;

namespace DMM.Web.Templating.BuildingBlocks.Templates
{
    [TcmTemplateTitle("Home Page HTML")]
    class Homepageflash : TemplateBase
    {
        public override void Transform(Engine engine, Package package)
        {
            this.Initialize(engine, package);

            Item componentsItem = package.GetByName(Package.ComponentName);
            IComponentPresentationList componentPresentationList = ComponentPresentationList.FromXml(componentsItem.GetAsString());

            //m_Package.PushItem("FlashHtml", m_Package.CreateStringItem(ContentType.Text, componentPresentationList[0].ComponentUri.ToString() )); 

        }
    }
}
