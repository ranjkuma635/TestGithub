﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using Tridion.ContentManager;
using Tridion.ContentManager.CommunicationManagement;
using Tridion.ContentManager.ContentManagement;
using Tridion.ContentManager.ContentManagement.Fields;
using Tridion.ContentManager.Templating;
using Tridion.Extensions.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;

namespace DMM.Web.Templating.BuildingBlocks.Templates
{
    [TcmTemplateTitle("Navigation")]
    class Navigations : TemplateBase
    {
        private XmlDocument navDoc = null;

        StringBuilder strNav = new StringBuilder();

        public override void Transform(Engine engine, Package package)
        {

            this.Initialize(engine, package);
            if (this.IsPage())
            {

                Publication publication = this.GetPublication();
                string rootSG = publication.RootStructureGroup.Id;

                strNav.Append("<Root>");

                strNav.Append(GetFirstLevelSG(rootSG));

                strNav.Append("</Root>");

            }
            m_Package.PushItem("Navigation", m_Package.CreateStringItem(ContentType.Html, strNav.ToString()));
        }


        private string GetFirstLevelSG(string strRootSGID)
        {

            StringBuilder strNavLoop = new StringBuilder();


            StructureGroup RootSG = m_Engine.GetObject(strRootSGID) as StructureGroup;

            Filter filter = new Filter();
            filter.Conditions["ItemType"] = ItemType.StructureGroup;

            Filter filterpages = new Filter();
            filterpages.Conditions["ItemType"] = ItemType.Page;


            IList<RepositoryLocalObject> listFistLevelStructureGroup = RootSG.GetItems(filter);
            StructureGroup SG;

            Page page;

            strNavLoop.Append("<node id = \"" + RootSG.Id.ToString() + "\"" + getIndexPage(RootSG.Id.ToString()) + "/>");

            foreach (RepositoryLocalObject RepositoryLocalObject in listFistLevelStructureGroup)
            {
                SG = m_Engine.GetObject(RepositoryLocalObject.Id) as StructureGroup;

                if (SG.Title.Contains("."))
                {
                    strNavLoop.Append("<node title = \"" + ReplaceCdata(SG.Title.ToString()) + "\" id = \"" + SG.Id.ToString() + "\"" + getIndexPage(SG.Id.ToString()) + ">");
                    IList<RepositoryLocalObject> listPages = SG.GetItems(filterpages);

                    foreach (RepositoryLocalObject RepositoryLocalObjectpages in listPages)
                    {
                        if (RepositoryLocalObjectpages.Title.Contains("."))
                        {
                            page = m_Engine.GetObject(RepositoryLocalObjectpages.Id) as Page;
                            strNavLoop.Append("<node pageid = \"" + page.Id.ToString() + "\" url = \"" + ReplaceURL(page.PublishLocationPath) + "\" name = \"" + ReplaceCdata(page.Title.ToString()) + "\"" + getStyles(page) + "/>");
                        }

                    }
                    strNavLoop.Append("</node>");
                }
            }

            return strNavLoop.ToString();

        }

        private string getIndexPage(string strSG)
        {
            Page page;
            Filter filter = new Filter();
            filter.Conditions["ItemType"] = ItemType.Page;

            string strHTML = "";
            StructureGroup SG;
            SG = m_Engine.GetObject(strSG) as StructureGroup;

            IList<RepositoryLocalObject> listPages = SG.GetItems(filter);

            foreach (RepositoryLocalObject RepositoryLocalObjectpages in listPages)
            {
                if (RepositoryLocalObjectpages.Title.StartsWith("000"))
                {
                    page = m_Engine.GetObject(RepositoryLocalObjectpages.Id) as Page;
                    if (SG.Directory != "")
                        strHTML = " name = \"" + ReplaceCdata(page.Title.ToString()) + "\"  pageid = \"" + page.Id.ToString() + "\" url = \"" + ReplaceURL(page.PublishLocationPath) + "\"" + getStyles(page);
                    else
                        strHTML = " name = \"" + ReplaceCdata(page.Title.ToString()) + "\"  pageid = \"" + page.Id.ToString() + "\" url = \"" + ReplaceURL(page.PublishLocationPath) + "\"" + getStyles(page);
                }
            }
            return strHTML;
        }

        private string getStyles(Page page)
        {
            string strHtml;
            string strMenuDisplay = "";
            string strSiteMapDispaly = "";
            string strwidth = "";

            StructureGroup SG;

            ItemFields metadataFields = new ItemFields(page.Metadata, page.MetadataSchema);
            if (metadataFields != null)
            {
                strMenuDisplay = metadataFields["ftypeofnav"].ToString();
                strSiteMapDispaly = metadataFields["fsitemap"].ToString();
            }

            strHtml = " MenuDisplay = \"" + strMenuDisplay + "\"  SiteMapDispaly = \"" + strSiteMapDispaly + "\"";

            return strHtml;

        }


        private string GetDatafromSG(StructureGroup sg, string strType)
        {

            string strVal = "";

            ItemFields metadataFields = new ItemFields(sg.Metadata, sg.MetadataSchema);
            if (metadataFields != null)
            {
                strVal = metadataFields[strType].ToString();
            }

            return strVal;

        }

        private string Getpage(Page page, string strType)
        {

            string strVal = "";

            ItemFields metadataFields = new ItemFields(page.Metadata, page.MetadataSchema);
            if (metadataFields != null)
            {
                strVal = metadataFields[strType].ToString();
            }

            return strVal;

        }

        private string ReplaceCdata(string cdata)
        {

            string decode = cdata;

            decode = decode.Replace("&", "&amp;amp;");

            return decode;

        }

        private string ReplaceURL(string strURL)
        {
            string url = strURL;
            url = url.Replace("\\", "/");
            return url;

        }

    }
}
