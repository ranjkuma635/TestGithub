﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Emaar.Web.Tridion.System.Extensions;
using Tridion.ContentManager.Templating.Expression;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.ContentManagement;
using Tridion.ContentManager;
using System.Globalization;
using Tridion.ContentManager.CommunicationManagement;
using Tridion.ContentManager.ContentManagement.Fields;
using System.Web;
using System.IO;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using Tridion.ContentManager.Publishing.Rendering;
using System.Text.RegularExpressions;
using Tridion.Extensions.ContentManager.Templating;

namespace Emaar.Web.Tridion.System.Dreamweaver_Extension
{
    public class Templating : TemplateBase, IFunctionSource
    {
        private Engine _Engine;
        private Package _Package;
        private TemplatingHandler _ComponentFieldHandler = null;
        private TemplatingHandler _PageFieldHandler = null;
        private TemplatingHandler _PublicationFieldHandler = null;
        private TemplatingHandler _FolderFieldHandler = null;
        private TemplatingHandler _StructureGroupFieldHandler = null;
        private TemplatingLogger _Log;
        private RepositoryLocalObject _Context = null;
        private Boolean _SiteEdit = false;
        private Boolean _SiteEdit2009 = false;
        private ItemType _HandlerContext = ItemType.None;
        private Boolean _EscapeOutputHandlerContent = false;
        private Regex mNavigable = new Regex(@"^[\d]{1,3}\.{0,1}\s", RegexOptions.Compiled);

        public void Initialize(Engine engine, Package package)
        {
            _Engine = engine;
            _Package = package;
            _Log = TemplatingLogger.GetLogger(GetType());
            base.Transform(_Engine, _Package);
        }

        [TemplateCallable]
        public string StripNumberFromTitle(String title)
        {
            Match match = mNavigable.Match(title);
            if (match.Success)
            {
                return title.Substring(match.Length);
            }
            return title;
        }

        [TemplateCallable()]
        public string AddBinary(string itemID, string VariantID)
        {
            CheckInitialized();
            Component mComponent = GetComponent(itemID);
            if (mComponent.BinaryContent != null)
            {
                _Engine.PublishingContext.RenderedItem.AddBinary(mComponent, VariantID);
            }
            return "";
        }


        [TemplateCallable]
        public string KeywordDescription(String itemID,string field)
        {
            CheckInitialized();
            Component mComponent = GetComponent(itemID);
            if (mComponent != null)
            {
                Keyword k = field.StartsWith("Metadata.") ? mComponent.KeywordMetaValue(field.Replace("Metadata.", "")) : mComponent.KeywordValue(field);
                if (k != null)
                    return k.Description;
            }
            return string.Empty;
        }

        [TemplateCallable]
        public string KeywordID(String itemID, string field)
        {
            CheckInitialized();
            Component mComponent = GetComponent(itemID);
            if (mComponent != null)
            {
                Keyword k = field.StartsWith("Metadata.") ? mComponent.KeywordMetaValue(field.Replace("Metadata.", "")) : mComponent.KeywordValue(field);
                if (k != null)
                    return k.Id.ItemId.ToString();
            }
            return string.Empty;
        }

        [TemplateCallable()]
        public string SetVariable(string variableName, object value)
        {
            CheckInitialized();
            _Engine.PublishingContext.RenderContext.ContextVariables.Remove(variableName);
            _Engine.PublishingContext.RenderContext.ContextVariables.Add(variableName, value);

            return "";
        }

        [TemplateCallable()]
        public object GetVariable(string variableName)
        {
            CheckInitialized();
            return _Engine.PublishingContext.RenderContext.ContextVariables[variableName];
        }

        [TemplateCallable]
        public int EmbFieldLength(string itemID, string field)
        {
            int length = 0;
            CheckInitialized();

            Component mComponent = GetComponent(itemID);

            if (mComponent != null)
            {
                IList<ItemFields> values = mComponent.EmbeddedValues(field);
                length = values.Count;
            }

            return length;
        }

        [TemplateCallable]
        public int FieldLength(string itemID, string field)
        {
            int length = 0;
            CheckInitialized();

            Component mComponent = GetComponent(itemID);

            if (mComponent != null)
            {
                IList<Component> values = mComponent.ComponentValues(field); 
                length = values.Count;
            }

            return length;
        }

        [TemplateCallable]
        public string GetSchemaTitle(String itemID)
        {
            string title = String.Empty;
            CheckInitialized();

            Component mComponent = GetComponent(itemID);
            if (mComponent != null)
            {
                title = mComponent.Schema.Title;
            }            
            return title;
        }

        [TemplateCallable]
        public String GetThumbnail(String itemID, String Prefix, int Width, int Height,String ColorCode)
        {
            CheckInitialized();

            ColorCode = (ColorCode == String.Empty) ? "#fff" : ColorCode;

            Component Component = GetComponent(itemID);

            if (Component != null && Component.BinaryContent != null)
            {
                try
                {
                    // Output the existing image to a memory stream
                    using (MemoryStream stream = new MemoryStream())
                    {
                        Component.BinaryContent.WriteToStream(stream);

                        using (Image image = Image.FromStream(stream))
                        {
                            int sourceWidth = image.Width;
                            int sourceHeight = image.Height;
                            int sourceX = 0;
                            int sourceY = 0;
                            int destX = 0;
                            int destY = 0;

                            float nPercent = 0;
                            float nPercentW = 0;
                            float nPercentH = 0;

                            nPercentW = ((float)Width / (float)sourceWidth);
                            nPercentH = ((float)Height / (float)sourceHeight);
                            if (nPercentH < nPercentW)
                            {
                                nPercent = nPercentH;
                                destX = (int)((Width -(sourceWidth * nPercent)) / 2);
                            }
                            else
                            {
                                nPercent = nPercentW;
                                destY = (int)((Height - (sourceHeight * nPercent)) / 2);
                            }

                            int destWidth = (int)(sourceWidth * nPercent);
                            int destHeight = (int)(sourceHeight * nPercent);

                            using (Bitmap bmPhoto = new Bitmap(Width, Height, image.PixelFormat))
                            {
                                //bmPhoto.SetResolution(image.HorizontalResolution, image.VerticalResolution);
                                using (Graphics grPhoto = Graphics.FromImage(bmPhoto))
                                {

                                    grPhoto.Clear(ColorTranslator.FromHtml(ColorCode));
                                    grPhoto.SmoothingMode = SmoothingMode.HighQuality;
                                    grPhoto.CompositingQuality = CompositingQuality.HighQuality;
                                    grPhoto.InterpolationMode = InterpolationMode.High;
                                    grPhoto.PixelOffsetMode = PixelOffsetMode.HighQuality;

                                    grPhoto.DrawImage(image,
                                        new Rectangle(destX, destY, destWidth, destHeight),
                                        new Rectangle(sourceX, sourceY, sourceWidth, sourceHeight),
                                        GraphicsUnit.Pixel);
                                    grPhoto.Dispose();

                                }
                                using (MemoryStream streamOut = new MemoryStream())
                                {
                                    bmPhoto.Save(streamOut, ImageFormat.Jpeg);

                                    Binary binary = Engine.PublishingContext.RenderedItem.AddBinary(streamOut, String.Format("{0}_{1}_tcm{2}_{3}.jpg", Path.GetFileNameWithoutExtension(Component.BinaryContent.Filename), Prefix, Component.Id.PublicationId, Component.Id.ItemId), Prefix, Component, "image/jpeg");
                                    image.Dispose();
                                    bmPhoto.Dispose();
                                    streamOut.Dispose();
                                    return binary.Url;
                                }
                            }

                        }
                    }
                }
                catch (Exception ex)
                {
                    Logger.Debug(ex.Message);

                }
            }
            return String.Empty;
        }

        [TemplateCallable]
        public String GetThumbnail(String itemID, String Prefix, int Width, int Height)
        {
            CheckInitialized();

            Component Component = GetComponent(itemID);

            if (Component != null && Component.BinaryContent != null)
            {
                try
                {
                    // Output the existing image to a memory stream
                    using (MemoryStream stream = new MemoryStream())
                    {
                        Component.BinaryContent.WriteToStream(stream);

                        using (Image image = Image.FromStream(stream))
                        {
                            int newWidth = Width;
                            int newHeight = Height;

                            if (image.Height > image.Width)
                            {
                                newWidth = (int)Math.Round(((double)image.Width / (double)image.Height) * newHeight);
                            }
                            else
                            {
                                newHeight = (int)Math.Round(((double)image.Height / (double)image.Width) * newWidth);
                            }

                            using (Bitmap bitmap = new Bitmap((int)newWidth, (int)newHeight, image.PixelFormat))
                            {
                                using (Graphics graphic = Graphics.FromImage(bitmap))
                                {
                                    graphic.SmoothingMode = SmoothingMode.HighQuality;
                                    graphic.InterpolationMode = InterpolationMode.HighQualityBicubic;
                                    graphic.PixelOffsetMode = PixelOffsetMode.HighQuality;                                    
                                    graphic.DrawImage(image, 0, 0, bitmap.Width, bitmap.Height);
                                    graphic.Dispose();
                                }

                                using (MemoryStream streamOut = new MemoryStream())
                                {
                                    bitmap.Save(streamOut, ImageFormat.Jpeg);

                                    Binary binary = Engine.PublishingContext.RenderedItem.AddBinary(streamOut, String.Format("{0}_{1}_tcm{2}_{3}.jpg", Path.GetFileNameWithoutExtension(Component.BinaryContent.Filename),Prefix, Component.Id.PublicationId, Component.Id.ItemId), Prefix, Component, "image/jpeg");

                                    streamOut.Dispose();
                                    bitmap.Dispose();
                                    image.Dispose();
                                    stream.Dispose();

                                    return binary.Url;
                                }
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    Logger.Error(ex.Message);
                }
            }

            return String.Empty;
        }

        [TemplateCallable]
        public String GetControlTag(String itemID)
        {
            CheckInitialized();

            Component mComponent = GetComponent(itemID);
            return GetControlTag(mComponent);
        }

        [TemplateCallable]
        public String GetControlTag(String itemID, String attributes)
        {
            CheckInitialized();

            Component mComponent = GetComponent(itemID);
            return GetControlTag(mComponent,attributes);
        }

        public String GetControlTag(Component mComponent)
        {
            return GetControlTag(mComponent, String.Empty);
        }
        [TemplateCallable]
        public String ResourceControl(string key)
        {
            return String.Format("<Emaar:GetResources Key=\"{0}\" runat=\"server\"/>", key);
        }

        [TemplateCallable]
        public string PublishBinary(String itemID)
        {
            return PublishBinary(itemID, String.Empty);
        }

        [TemplateCallable]
        public string PublishBinary(String itemID, string variantId)
        {
            return PublishBinary(itemID, variantId, String.Empty);
        }


        [TemplateCallable]
        public string PublishBinary(String itemID, string variantId, string relatedComponentID)
        {
            CheckInitialized();

            Component Component = GetComponent(itemID);

            String publishPath = String.Empty;

            if (Component != null && Component.ComponentType == ComponentType.Multimedia && Component.BinaryContent != null)
            {
                Binary pubBinary = null;

                if (!String.IsNullOrEmpty(variantId))
                {
                    pubBinary = mEngine.PublishingContext.RenderedItem.AddBinary(Component, variantId);
                }
                else
                {
                    pubBinary = mEngine.PublishingContext.RenderedItem.AddBinary(Component);
                }

                if (pubBinary != null)
                    publishPath = pubBinary.Url;
            }
            else
            {
                Logger.Warning("PublishBinary: {0} is not a multimedia component.", Component.Id);
            }

            return publishPath;

        }

        private void ProcessFields(ItemFields fields,StringBuilder attributes)
        {
            String key = fields.StringValue("Key");
            String value = String.Empty;

            if (fields.Contains("Value"))
            {
                ItemField field = fields["Value"];

                if (field is SingleLineTextField)
                {
                    IList<String> values = field.StringValues();
                    value = String.Join(",", values.ToArray<String>());
                }
                else if (field is ExternalLinkField)
                {
                    IList<String> values = field.StringValues();
                    value = String.Join(",", values.ToArray<String>());
                }
                else if (field is DateField)
                {
                    IList<DateTime> values = field.DateValues();
                    List<String> results = new List<String>();

                    foreach (DateTime entry in values)
                    {
                        results.Add(entry.ToString("yyyyMMddHHmmss"));
                    }

                    value = String.Join(",", results.ToArray<String>());
                }
                else if (field is NumberField)
                {
                    IList<Double> values = field.NumberValues();
                    List<String> results = new List<String>();

                    foreach (Double entry in values)
                    {
                        results.Add(entry.ToString());
                    }

                    value = String.Join(",", results.ToArray<String>());
                }
                else if (field is ComponentLinkField)
                {
                    IList<Component> values = field.ComponentValues();

                    List<String> results = new List<String>();

                    foreach (Component entry in values)
                    {
                        results.Add(entry.Id.ToString());
                    }

                    value = String.Join(",", results.ToArray<String>());
                }
                else if (field is XhtmlField)
                {
                    IList<String> values = field.XHTMLValues();
                    List<String> results = new List<String>();

                    foreach (String entry in values)
                    {
                        results.Add(entry.ToString());
                    }

                    value = String.Join(",", results.ToArray<String>());
                }
                else if (field is KeywordField)
                {
                    IList<Keyword> values = field.KeywordValues();
                    List<String> results = new List<String>();

                    foreach (Keyword entry in values)
                    {
                        results.Add(entry.Title);
                    }

                    value = String.Join(",", results.ToArray<String>());
                }
            }

            if (!String.IsNullOrEmpty(key) && !String.IsNullOrEmpty(value))
            {
                // Ignore any additional "runat" attributes
                if (!String.Equals(key, "runat", StringComparison.InvariantCultureIgnoreCase))
                {
                    attributes.AppendFormat(" {0}=\"{1}\"", key, HttpUtility.HtmlEncode(value));
                }
            }
        }

        public String GetControlTag(Component mComponent, String mode)
        {
            if (mComponent != null)
            {
                String prefix = mComponent.StringValue("ftagprefix");
                String tag = mComponent.StringValue("ftagname");

                StringBuilder attributes = new StringBuilder();

                foreach (ItemFields fields in mComponent.EmbeddedValues("Attributes"))
                {
                    ProcessFields(fields, attributes);
                }

                foreach (ItemFields fields in mComponent.EmbeddedValues("AttributeKeywords"))
                {
                    ProcessFields(fields, attributes);
                }

                if (!String.IsNullOrEmpty(mode))
                {
                    attributes.AppendFormat(" {0}=\"{1}\"", "Mode", mode);
                }

                if (!String.IsNullOrEmpty(prefix) && !String.IsNullOrEmpty(tag))
                {   
                    StringBuilder control = new StringBuilder();

                    control.AppendFormat("<{0}:{1} runat=\"server\"{2} ", prefix, tag, attributes.ToString());

                    IList<ItemFields> properties = mComponent.EmbeddedValues("Properties");

                    if (properties.Count > 0)
                    {
                        control.Append(">");

                        foreach (ItemFields fields in properties)
                        {
                            String childControlPrefix = fields.StringValue("TagPrefix");
                            String childControlTagPrefix = fields.StringValue("Tag");

                            StringBuilder childControlAttributes = new StringBuilder();

                            foreach (ItemFields childfields in fields.EmbeddedValues("Attributes"))
                            {
                                ProcessFields(childfields, childControlAttributes);
                            }

                            foreach (ItemFields childfields in fields.EmbeddedValues("AttributeKeywords"))
                            {
                                ProcessFields(childfields, childControlAttributes);
                            }

                            control.AppendFormat("<{0}:{1}{2}/>", childControlPrefix, childControlTagPrefix, childControlAttributes.ToString());
                        }

                        control.AppendFormat("</{0}:{1}>", prefix, tag);
                    }
                    else
                    {
                        control.Append("/>");
                    }

                    return control.ToString();
                }
            }
            return String.Empty;
        }

        [TemplateCallable]
        public String GetFromItem(String ItemID, String FieldPath)
        {
            if (_Package.GetByName("EscapeOutput") != null)
                _EscapeOutputHandlerContent = true;
            // Create context-specific Output Handler
            TcmUri item = null;
            try
            {
                item = new TcmUri(ItemID);
            }
            catch
            {
                return null;
            }
            TemplatingHandler context = new TemplatingHandler(item, _Engine, _Package);
            context.EscapeOutput = _EscapeOutputHandlerContent;

            return context.GetStringValue(FieldPath);
        }

        [TemplateCallable]
        public String Get(String FieldPath)
        {
            Initialize(FieldPath);
            if (_Package.GetByName("EscapeOutput") != null)
                _EscapeOutputHandlerContent = true;
            String result = String.Empty;
            switch (_HandlerContext)
            {
                case ItemType.Publication:
                    _PublicationFieldHandler.EscapeOutput = _EscapeOutputHandlerContent;
                    result = _PublicationFieldHandler.GetStringValue(FieldPath);
                    
                    break;
                case ItemType.Component:
                    _ComponentFieldHandler.EscapeOutput = _EscapeOutputHandlerContent;
                    result = _ComponentFieldHandler.GetStringValue(FieldPath);
                    
                    break;
                case ItemType.Page:
                    _PageFieldHandler.EscapeOutput = _EscapeOutputHandlerContent;
                    result = _PageFieldHandler.GetStringValue(FieldPath);
                    
                    break;
                case ItemType.Folder:
                    _FolderFieldHandler.EscapeOutput = _EscapeOutputHandlerContent;
                    result = _FolderFieldHandler.GetStringValue(FieldPath);
                    
                    break;
                case ItemType.StructureGroup:
                    _StructureGroupFieldHandler.EscapeOutput = _EscapeOutputHandlerContent;
                    result = _StructureGroupFieldHandler.GetStringValue(FieldPath);
                    
                    break;
            }
            return result;

        }

        [TemplateCallable]
        public String GetDate(String FieldPath, String DateFormat, String Culture)
        {
            Initialize(FieldPath);
            String result = String.Empty;
            switch (_HandlerContext)
            {
                case ItemType.Publication:
                    _PublicationFieldHandler.Culture = Culture;
                    _PublicationFieldHandler.DateFormat = DateFormat;
                    result = _PublicationFieldHandler.GetStringValue(FieldPath);
                    break;
                case ItemType.Component:
                    _ComponentFieldHandler.Culture = Culture;
                    _ComponentFieldHandler.DateFormat = DateFormat;
                    result = _ComponentFieldHandler.GetStringValue(FieldPath);
                    break;
                case ItemType.Page:
                    _PageFieldHandler.Culture = Culture;
                    _PageFieldHandler.DateFormat = DateFormat;
                    result = _PageFieldHandler.GetStringValue(FieldPath);
                    break;
                case ItemType.Folder:
                    _FolderFieldHandler.Culture = Culture;
                    _FolderFieldHandler.DateFormat = DateFormat;
                    result = _FolderFieldHandler.GetStringValue(FieldPath);
                    break;
                case ItemType.StructureGroup:
                    _StructureGroupFieldHandler.Culture = Culture;
                    _StructureGroupFieldHandler.DateFormat = DateFormat;
                    result = _StructureGroupFieldHandler.GetStringValue(FieldPath);
                    break;
            }
            return result ;
        }

        /// <summary>
        /// Initializes an instance of the output handler bound to the correct item.
        /// </summary>
        /// <param name="FieldPath">Path to the field you want to read from, which may include "Component", "Page", "StructureGroup", "Folder" or "Publication"</param>
        private void Initialize(String FieldPath)
        {
            
            if (_Context == null)
            {
                if (_Package.GetByName(Package.PageName) != null)
                    _Context = _Engine.GetObject(_Package.GetByName(Package.PageName)) as RepositoryLocalObject;
                else if (_Package.GetByName(Package.ComponentName) != null)
                    _Context = _Engine.GetObject(_Package.GetByName(Package.ComponentName)) as RepositoryLocalObject;
                else
                    _Log.Debug("Could not initialize Tridion Output Handler Extension for Dreamweaver Templates...");

            }
            if (!_SiteEdit && (_Package.GetByName("SiteEdit") != null))
                _SiteEdit = true;
            else if (!_SiteEdit2009 && (_Package.GetByName("SiteEdit2009") != null))
                _SiteEdit2009 = true;
            

            String ItemQualifier = FieldPath.Split(SourceUtilities.QualifiedNameSeparator)[0];
            switch (ItemQualifier)
            {
                case "Publication":
                    if (_PublicationFieldHandler == null)
                    {
                        _PublicationFieldHandler = new TemplatingHandler(_Context.ContextRepository.Id, _Engine, _Package);
                    }
                    _HandlerContext = ItemType.Publication;
                    break;
                case "Component":
                    if (_ComponentFieldHandler == null && _Context is Component)
                    {
                        _ComponentFieldHandler = new TemplatingHandler(_Context.Id, _Engine, _Package);
                        if (_SiteEdit)
                        {
                            _ComponentFieldHandler.SiteEdit = _SiteEdit;
                            _ComponentFieldHandler.SEVersion = TemplatingHandler.SiteEditVersion.SiteEdit13;
                        }
                        else if (_SiteEdit2009)
                        {
                            _ComponentFieldHandler.SiteEdit = _SiteEdit2009;
                            _ComponentFieldHandler.SEVersion = TemplatingHandler.SiteEditVersion.SiteEdit2009;
                        }
                        
                    }
                    else if(!(_Context is Component))
                    {
                        _Log.Error("Cannot use \"Component\" qualifier if context is not Component!");
                        throw new Exception("Cannot use \"Component\" qualifier if context is not Component!");
                    }
                    _HandlerContext = ItemType.Component;
                    break;
                case "Page":
                    if (_PageFieldHandler == null && _Context is Page)
                    {
                        _PageFieldHandler = new TemplatingHandler(_Context.Id, _Engine, _Package);
                    }
                    else if(!(_Context is Page))
                    {
                        _Log.Error("Cannot use \"Page\" qualifier if context is not page!");
                        throw new Exception("Cannot use \"Page\" qualifier if context is not page!");
                    }
                    _HandlerContext = ItemType.Page;
                    break;
                case "Folder":
                    if (_FolderFieldHandler == null && _Context is Component)
                    {
                        _FolderFieldHandler = new TemplatingHandler(_Context.OrganizationalItem.Id, _Engine, _Package);
                    }
                    else if(!(_Context is Component))
                    {
                        _Log.Error("Cannot use \"Folder\" qualifier if context is not Component!");
                        throw new Exception("Cannot use \"Folder\" qualifier if context is not Component!");
                    }
                    _HandlerContext = ItemType.Folder;
                    break;
                case "StructureGroup":
                    if (_StructureGroupFieldHandler == null && _Context is Page)
                    {
                        _StructureGroupFieldHandler = new TemplatingHandler(_Context.OrganizationalItem.Id, _Engine, _Package);
                    }
                    else if(!(_Context is Page))
                    {
                        _Log.Error("Cannot use \"StructureGroup\" qualifier if context is not page!");
                        throw new Exception("Cannot use \"StructureGroup\" qualifier if context is not page!");
                    }
                    _HandlerContext = ItemType.StructureGroup;
                    break;

                default:
                    {
                        if (_Context is Component)
                        {
                            if (_ComponentFieldHandler == null)
                            {
                                _ComponentFieldHandler = new TemplatingHandler(_Context.Id, _Engine, _Package);
                                if (_SiteEdit)
                                {
                                    _ComponentFieldHandler.SiteEdit = _SiteEdit;
                                    _ComponentFieldHandler.SEVersion = TemplatingHandler.SiteEditVersion.SiteEdit13;
                                }
                                else if (_SiteEdit2009)
                                {
                                    _ComponentFieldHandler.SiteEdit = _SiteEdit2009;
                                    _ComponentFieldHandler.SEVersion = TemplatingHandler.SiteEditVersion.SiteEdit2009;
                                }
                            }
                            _HandlerContext = ItemType.Component;
                        }
                        else
                        {
                            if (_PageFieldHandler == null)
                            {
                                _PageFieldHandler = new TemplatingHandler(_Context.Id, _Engine, _Package);
                            }
                            _HandlerContext = ItemType.Page;
                        }
                    }
                    break;
            }

        }

        
    }
}
