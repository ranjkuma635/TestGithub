﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Tridion.ContentManager.Templating;
using System.Xml;
using Tridion.ContentManager;
using Tridion.ContentManager.CommunicationManagement;
using Tridion.ContentManager.ContentManagement;
using Tridion.ContentManager.ContentManagement.Fields;
using System.IO;
using System.Web;
using System.Security;

namespace Emaar.Web.Tridion.System.Extensions
{
    /// <summary>
    /// <see cref="Extensions"/> adds .NET 3.5 extensions for frequent actions
    /// </summary>
    public static class Extensions
    {
        #region Tridion Object extensions
        public static int Level(this Keyword Keyword)
        {
            int level = 1;
            Keyword item = Keyword;

            if (item != null)
            {
                while (!item.IsRoot && item.ParentKeywords != null && item.ParentKeywords.Count > 0)
                {
                    item = item.ParentKeywords[0];
                    level++;
                }
            }

            return level;
        }
        #endregion

        #region Package Item extensions
        public static String Property(this Item Item, String Key)
        {
            String value;

            if (Item.Properties.TryGetValue(Key, out value))
            {
                return value;
            }

            return String.Empty;
        }

        public static TcmUri PropertyAsUri(this Item Item, String Key)
        {
            String value = Item.Property(Key);

            if (!String.IsNullOrEmpty(value) && TcmUri.IsValid(value))
            {
                return new TcmUri(value);
            }

            return null;
        }
        #endregion

        #region Package extensions
        public static void AddValue(this Package Package, ContentType ContentType, String Name, String Value)
        {
            if (Package != null)
            {
                Item packageItem = Package.CreateStringItem(ContentType, Value);
                Package.PushItem(Name, packageItem);
            }
        }

        /// <summary>
        /// Add a new string value to the current <see cref="T:Tridion.Templating.ContentManager.Package" />
        /// </summary>
        /// <param name="Package"><see cref="T:Tridion.Templating.ContentManager.Package" /></param>
        /// <param name="Name">Name.</param>
        /// <param name="Value">Value.</param>
        public static void AddString(this Package Package, String Name, String Value)
        {
            Package.AddValue(ContentType.Text, Name, Value);
        }

        public static void AddNumber(this Package Package, String Name, int Value)
        {
            Package.AddValue(ContentType.Number, Name, Value.ToString());
        }

        public static void AddNumber(this Package Package, String Name, double Value)
        {
            Package.AddValue(ContentType.Number, Name, Value.ToString());
        }

        public static void AddDateTime(this Package Package, String Name, DateTime Value)
        {
            Package.AddValue(ContentType.DateTime, Name, Value.ToString());
        }

        public static void AddXml(this Package Package, String Name, String Value)
        {
            Package.AddValue(ContentType.Xml, Name, Value);
        }

        public static void AddXhtml(this Package Package, String Name, String Value)
        {
            Package.AddValue(ContentType.Xhtml, Name, Value);
        }

        public static void AddExternalLink(this Package Package, String Name, String Value)
        {
            Package.AddValue(ContentType.ExternalLink, Name, Value);
        }

        public static void AddLink(this Package Package, String Name, TcmUri Value)
        {
            Package.AddValue(ContentType.ItemLink, Name, Value.ToString());
        }

        public static void AddLink(this Package Package, String Name, IdentifiableObject Value)
        {
            Package.AddValue(ContentType.ItemLink, Name, Value.Id.ToString());
        }

        public static void AddHtml(this Package Package, String Name, String Value)
        {
            if (Package != null)
            {
                Item packageItem = Package.CreateHtmlItem(Value);
                Package.PushItem(Name, packageItem);
            }
        }

        public static void AddComponent(this Package Package, String Name, TcmUri Value)
        {
            if (Package != null)
            {
                Item packageItem = Package.CreateTridionItem(ContentType.Component, Value);
                Package.PushItem(Name, packageItem);
            }
        }

        public static void AddComponent(this Package Package, String Name, IdentifiableObject Value)
        {
            if (Package != null)
            {
                Item packageItem = Package.CreateTridionItem(ContentType.Component, Value);
                Package.PushItem(Name, packageItem);
            }
        }

        public static void AddMultimedia(this Package Package, String Name, TcmUri Value)
        {
            if (Package != null)
            {
                Item packageItem = Package.CreateMultimediaItem(Value);
                Package.PushItem(Name, packageItem);
            }
        }

        public static void AddComponents(this Package Package, String Name, IList<TcmUri> Value)
        {
            if (Package != null)
            {
                Item packageItem = Package.CreateComponentUriListItem(ContentType.ComponentArray, Value);
                Package.PushItem(Name, packageItem);
            }
        }

        public static void AddComponents(this Package Package, String Name, ComponentPresentationList Value)
        {
            if (Package != null)
            {
                Item packageItem = Package.CreateStringItem(ContentType.ComponentArray, Value.ToXml());
                Package.PushItem(Name, packageItem);
            }
        }

        public static String ItemAsString(this Package Package, String Name)
        {
            if (Package != null)
            {
                Item packageItem = Package.GetByName(Name);

                if (packageItem != null)
                {
                    return packageItem.GetAsString();
                }
            }

            return String.Empty;
        }

        public static TcmUri ItemAsUri(this Package Package, String Name)
        {
            String value = Package.ItemAsString(Name);

            if (!String.IsNullOrEmpty(value) && TcmUri.IsValid(value))
            {
                return new TcmUri(value);
            }

            return null;
        }

        public static IComponentPresentationList ItemAsComponentList(this Package Package, String Name)
        {
            String value = Package.ItemAsString(Name);

            if (!String.IsNullOrEmpty(value))
            {
                return ComponentPresentationList.FromXml(value);
            }

            return new ComponentPresentationList();
        }
        #endregion

        #region ItemField extensions
        public static ItemFields EmbeddedValue(this ItemField f)
        {
            IList<ItemFields> values = f.EmbeddedValues();

            if (values.Count > 0)
                return values[0];

            return null;
        }

        public static Component ComponentValue(this ItemField f)
        {
            IList<Component> values = f.ComponentValues();

            if (values.Count > 0)
                return values[0];

            return null;
        }

        public static String ExternalLinkValue(this ItemField f)
        {
            IList<String> values = f.ExternalLinkValues();

            if (values.Count > 0)
                return values[0];

            return null;
        }

        public static DateTime DateValue(this ItemField f)
        {
            IList<DateTime> values = f.DateValues();

            if (values.Count > 0)
                return values[0];

            return DateTime.MinValue;
        }

        public static Keyword KeywordValue(this ItemField f)
        {
            IList<Keyword> values = f.KeywordValues();

            if (values.Count > 0)
                return values[0];

            return null;
        }

        public static Double NumberValue(this ItemField f)
        {
            IList<Double> values = f.NumberValues();

            if (values.Count > 0)
                return values[0];

            return 0;
        }

        public static String StringValue(this ItemField f)
        {
            IList<String> values = f.StringValues();

            if (values.Count > 0)
                return values[0];

            return null;
        }

        public static String XHTMLValue(this ItemField f)
        {
            IList<String> values = f.XHTMLValues();

            if (values.Count > 0)
                return values[0];

            return null;
        }

        public static String XMLValue(this ItemField f)
        {
            IList<String> values = f.XMLValues();

            if (values.Count > 0)
                return values[0];

            return null;
        }

        public static IList<Component> ComponentValues(this ItemField f)
        {
            ComponentLinkField field = f as ComponentLinkField;

            if (field != null && field.Values.Count > 0)
                return field.Values;

            return new List<Component>();
        }

        public static IList<String> ExternalLinkValues(this ItemField f)
        {
            ExternalLinkField field = f as ExternalLinkField;

            if (field != null && field.Values.Count > 0)
                return field.Values;

            return new List<String>();
        }

        public static IList<ItemFields> EmbeddedValues(this ItemField f)
        {
            EmbeddedSchemaField field = f as EmbeddedSchemaField;

            if (field != null && field.Values.Count > 0)
                return field.Values;

            return new List<ItemFields>();
        }

        public static IList<DateTime> DateValues(this ItemField f)
        {
            DateField field = f as DateField;

            if (field != null && field.Values.Count > 0)
                return field.Values;

            return new List<DateTime>();
        }

        public static IList<Keyword> KeywordValues(this ItemField f)
        {
            KeywordField field = f as KeywordField;

            if (field != null && field.Values.Count > 0)
                return field.Values;

            return new List<Keyword>();
        }

        public static IList<Double> NumberValues(this ItemField f)
        {
            NumberField field = f as NumberField;

            if (field != null && field.Values.Count > 0)
                return field.Values;

            return new List<Double>();
        }

        public static IList<String> StringValues(this ItemField f)
        {
            TextField field = f as TextField;

            if (field != null && field.Values.Count > 0)
                return field.Values;

            return new List<String>();
        }

        public static IList<String> XHTMLValues(this ItemField f)
        {
            XhtmlField field = f as XhtmlField;

            if (field != null && field.Values.Count > 0)
                return field.Values;

            return new List<String>();
        }

        public static IList<String> XMLValues(this ItemField f)
        {
            List<String> results = new List<String>();
            TextField field = f as TextField;

            if (field != null && field.Values.Count > 0)
            {
                XmlDocument xDoc = new XmlDocument();

                foreach (String value in field.Values)
                {
                    xDoc.LoadXml("<x>" + value + "</x>");

                    String xml = xDoc.RemoveNameSpaces();
                    xml = xml.Substring(3, xml.Length - 7);

                    results.Add(xml);
                }
            }

            return results;
        }
        #endregion

        #region ItemFields extensions
        public static Component ComponentValue(this ItemFields f, String FieldName)
        {
            if (f.Contains(FieldName))
            {
                return f[FieldName].ComponentValue();
            }

            return null;
        }

        public static IList<Component> ComponentValues(this ItemFields f, String FieldName)
        {
            if (f.Contains(FieldName))
            {
                return f[FieldName].ComponentValues();
            }

            return new List<Component>();
        }

        public static String ExternalLinkValue(this ItemFields f, String FieldName)
        {
            if (f.Contains(FieldName))
            {
                return f[FieldName].ExternalLinkValue();
            }

            return null;
        }

        public static IList<String> ExternalLinkValues(this ItemFields f, String FieldName)
        {
            if (f.Contains(FieldName))
            {
                return f[FieldName].ExternalLinkValues();
            }

            return new List<String>();
        }

        public static ItemFields EmbeddedValue(this ItemFields f, String FieldName)
        {
            if (f.Contains(FieldName))
            {
                return f[FieldName].EmbeddedValue();
            }

            return null;
        }

        public static IList<ItemFields> EmbeddedValues(this ItemFields f, String FieldName)
        {
            if (f.Contains(FieldName))
            {
                return f[FieldName].EmbeddedValues();
            }

            return new List<ItemFields>();
        }

        public static DateTime DateValue(this ItemFields f, String FieldName)
        {
            if (f.Contains(FieldName))
            {
                return f[FieldName].DateValue();
            }

            return DateTime.MinValue;
        }

        public static IList<DateTime> DateValues(this ItemFields f, String FieldName)
        {
            if (f.Contains(FieldName))
            {
                return f[FieldName].DateValues();
            }

            return new List<DateTime>();
        }

        public static Keyword KeywordValue(this ItemFields f, String FieldName)
        {
            if (f.Contains(FieldName))
            {
                return f[FieldName].KeywordValue();
            }

            return null;
        }

        public static IList<Keyword> KeywordValues(this ItemFields f, String FieldName)
        {
            if (f.Contains(FieldName))
            {
                return f[FieldName].KeywordValues();
            }

            return new List<Keyword>();
        }

        public static Double NumberValue(this ItemFields f, String FieldName)
        {
            if (f.Contains(FieldName))
            {
                return f[FieldName].NumberValue();
            }

            return 0;
        }

        public static IList<Double> NumberValues(this ItemFields f, String FieldName)
        {
            if (f.Contains(FieldName))
            {
                return f[FieldName].NumberValues();
            }

            return new List<Double>();
        }

        public static String StringValue(this ItemFields f, String FieldName)
        {
            if (f.Contains(FieldName))
            {
                return f[FieldName].StringValue();
            }

            return null;
        }

        public static IList<String> StringValues(this ItemFields f, String FieldName)
        {
            if (f.Contains(FieldName))
            {
                return f[FieldName].StringValues();
            }

            return new List<String>();
        }

        public static String XHTMLValue(this ItemFields f, String FieldName)
        {
            if (f.Contains(FieldName))
            {
                return f[FieldName].XHTMLValue();
            }

            return null;
        }

        public static IList<String> XHTMLValues(this ItemFields f, String FieldName)
        {
            if (f.Contains(FieldName))
            {
                return f[FieldName].XHTMLValues();
            }

            return new List<String>();
        }

        public static String XMLValue(this ItemFields f, String FieldName)
        {
            if (f.Contains(FieldName))
            {
                return f[FieldName].XMLValue();
            }

            return null;
        }

        public static IList<String> XMLValues(this ItemFields f, String FieldName)
        {
            if (f.Contains(FieldName))
            {
                return f[FieldName].XMLValues();
            }

            return new List<String>();
        }
        #endregion

        #region Organizational item extensions

        public static IList<Component> Components(this OrganizationalItem f, string Schema, bool Recursive)
        {

            Filter sgFilter = new Filter();
            sgFilter.Conditions["ItemType"] = ItemType.Component;

            if (!String.IsNullOrEmpty(Schema))
                sgFilter.Conditions["Schema"] = Schema;

            if (Recursive)
                sgFilter.Conditions["Recursive"] = true;

            IList<Component> list = new List<Component>();

            foreach (RepositoryLocalObject cmp in f.GetItems(sgFilter))
            {
                if (cmp is Component)
                    list.Add(cmp as Component);
            }

            return list;
        }

        public static IList<Component> Components(this OrganizationalItem f, string Schema)
        {
            return f.Components(Schema, false);
        }

        public static IList<Component> Components(this OrganizationalItem f, bool Recursive)
        {
            return f.Components(String.Empty, Recursive);
        }

        public static IList<Component> Components(this OrganizationalItem f)
        {
            return f.Components(String.Empty, false);
        }
        #endregion

        #region XmlElement Extensions
        public static String GetAttribute(this XmlNode Node, String Name)
        {
            if (Node != null && !String.IsNullOrEmpty(Name))
            {
                XmlAttribute attribute = Node.Attributes[Name];

                if (attribute != null)
                {
                    return attribute.Value;
                }
            }

            return String.Empty;
        }

        public static XmlElement AddTextNode(this XmlNode Node, String Name, String Value)
        {
            if (Node != null && !String.IsNullOrEmpty(Name) && Node.OwnerDocument != null && !String.IsNullOrEmpty(Value))
            {
                XmlElement xElement = Node.OwnerDocument.CreateElement(Name);
                xElement.InnerText = Value;
                Node.AppendChild(xElement);

                return xElement;
            }

            return null;
        }

        public static XmlElement AddXmlNode(this XmlNode Node, String Name, String Value)
        {
            if (Node != null && !String.IsNullOrEmpty(Name) && Node.OwnerDocument != null)
            {
                XmlElement xElement = Node.OwnerDocument.CreateElement(Name);
                xElement.InnerXml = Value;
                Node.AppendChild(xElement);

                return xElement;
            }

            return null;
        }

        public static XmlElement AddKeywordNode(this XmlNode Node, String Name, Keyword Value)
        {
            return Node.AddKeywordNode(Name, Value, false);
        }

        public static XmlElement AddKeywordNode(this XmlNode Node, String Name, Keyword Value, bool IncludeLevel)
        {
            if (Node != null && !String.IsNullOrEmpty(Name) && Node.OwnerDocument != null && Value != null)
            {
                XmlElement xElement = Node.OwnerDocument.CreateElement(Name);
                xElement.SetAttribute("uri", Value.Id);

                if (!String.IsNullOrEmpty(Value.Key))
                    xElement.SetAttribute("key", Value.Key);

                if (!String.IsNullOrEmpty(Value.Description))
                    xElement.SetAttribute("description", Value.Description);

                xElement.SetAttribute("root", Value.IsRoot.ToString().ToLower());

                if (IncludeLevel)
                {
                    xElement.SetAttribute("level", Value.Level().ToString());
                }

                xElement.InnerXml = SecurityElement.Escape(Value.Title);

                Node.AppendChild(xElement);
                return xElement;
            }

            return null;
        }

        public static void AddTextNodes(this XmlNode Node, String Name, IList<String> Values)
        {
            if (Node != null && !String.IsNullOrEmpty(Name) && Node.OwnerDocument != null && Values != null && Values.Count > 0)
            {
                foreach (String value in Values)
                {
                    Node.AddTextNode(Name, value);
                }
            }
        }

        public static void AddXmlNodes(this XmlNode Node, String Name, IList<String> Values)
        {
            if (Node != null && !String.IsNullOrEmpty(Name) && Node.OwnerDocument != null && Values != null && Values.Count > 0)
            {
                foreach (String value in Values)
                {
                    Node.AddXmlNode(Name, value);
                }
            }
        }

        public static void AddKeywordNodes(this XmlNode Node, String Name, IList<Keyword> Values)
        {
            Node.AddKeywordNodes(Name, Values, false);
        }

        public static void AddKeywordNodes(this XmlNode Node, String Name, IList<Keyword> Values, bool IncludeLevel)
        {
            if (Node != null && !String.IsNullOrEmpty(Name) && Node.OwnerDocument != null && Values != null && Values.Count > 0)
            {
                foreach (Keyword value in Values)
                {
                    Node.AddKeywordNode(Name, value, IncludeLevel);
                }
            }
        }
        #endregion

        #region XmlWriter Extensions
        public static void WriteKeywordNode(this XmlWriter Writer, String Name, Keyword Value)
        {
            Writer.WriteKeywordNode(Name, Value, false);
        }

        public static void WriteKeywordNode(this XmlWriter Writer, String Name, Keyword Value, bool IncludeLevel)
        {
            if (Writer != null && !String.IsNullOrEmpty(Name) && Value != null)
            {
                Writer.WriteStartElement(Name);
                Writer.WriteAttributeString("uri", Value.Id);

                if (!String.IsNullOrEmpty(Value.Key))
                    Writer.WriteAttributeString("key", Value.Key);

                if (!String.IsNullOrEmpty(Value.Description))
                    Writer.WriteAttributeString("description", Value.Description);

                Writer.WriteAttributeString("root", Value.IsRoot.ToString().ToLower());

                Writer.WriteEndElement();
            }
        }

        public static void WriteKeywordNodes(this XmlWriter Writer, String Name, IList<Keyword> Values)
        {
            Writer.WriteKeywordNodes(Name, Values, false);
        }

        public static void WriteKeywordNodes(this XmlWriter Writer, String Name, IList<Keyword> Values, bool IncludeLevel)
        {
            if (Writer != null && !String.IsNullOrEmpty(Name) && Values != null && Values.Count > 0)
            {
                foreach (Keyword value in Values)
                {
                    Writer.WriteKeywordNode(Name, value, IncludeLevel);
                }
            }
        }

        public static void WriteTextNodes(this XmlWriter Writer, String Name, IList<String> Values)
        {
            if (Writer != null && Values != null && Values.Count > 0)
            {
                foreach (String value in Values)
                {
                    Writer.WriteElementString(Name, value);
                }
            }
        }

        public static void WriteXmlNode(this XmlWriter Writer, String Name, String Value)
        {
            if (Writer != null && !String.IsNullOrEmpty(Name) && !String.IsNullOrEmpty(Value))
            {
                Writer.WriteStartElement(Name);
                Writer.WriteRaw(Value);
                Writer.WriteEndElement();
            }
        }

        public static void WriteXmlNodes(this XmlWriter Writer, String Name, IList<String> Values)
        {
            if (Writer != null && Values != null && Values.Count > 0)
            {
                foreach (String value in Values)
                {
                    Writer.WriteXmlNode(Name, value);
                }
            }
        }
        #endregion

        #region XmlDocument Extensions
        public static String RemoveNameSpaces(this XmlDocument Document)
        {
            // Prune all duplicate attributes across namespaces
            foreach (XmlNode node in Document.SelectNodes("//node()[@*[local-name() != name()]]"))
            {
                List<XmlAttribute> attrs = new List<XmlAttribute>(node.Attributes.Cast<XmlAttribute>());

                foreach (XmlAttribute attr in attrs)
                {
                    if (node.Attributes[attr.LocalName] != null && attr.LocalName != attr.Name)
                    {
                        node.Attributes.Remove(attr);
                    }
                }
            }

            using (StringWriter sw = new StringWriter())
            {
                using (XmlNoNamespaceWriter xw = new XmlNoNamespaceWriter(sw))
                {
                    xw.Formatting = Formatting.None;
                    Document.Save(xw);
                }

                return sw.ToString();
            }
        }
        #endregion

        #region RepositoryLocalObject Extensions
        public static Component ComponentValue(this RepositoryLocalObject Object, XmlElement Content, Schema Schema, String FieldName)
        {
            IList<Component> values = Object.ComponentValues(Content, Schema, FieldName);

            if (values.Count > 0)
                return values[0];

            return null;
        }

        public static IList<Component> ComponentValues(this RepositoryLocalObject Object, XmlElement Content, Schema Schema, String FieldName)
        {
            if (Object != null && Content != null && Schema != null)
            {
                ItemFields fields = new ItemFields(Content, Schema);

                return fields.ComponentValues(FieldName);
            }

            return new List<Component>();
        }

        public static Component ComponentValue(this RepositoryLocalObject Object, XmlElement Content, Schema Schema, String FieldName, String EmbeddedFieldName)
        {
            IList<Component> values = Object.ComponentValues(Content, Schema, FieldName, EmbeddedFieldName);

            if (values.Count > 0)
                return values[0];

            return null;
        }

        public static IList<Component> ComponentValues(this RepositoryLocalObject Object, XmlElement Content, Schema Schema, String FieldName, String EmbeddedFieldName)
        {
            if (Object != null && Content != null && Schema != null)
            {
                ItemFields fields = new ItemFields(Content, Schema);

                ItemFields embeddedFields = fields.EmbeddedValue(FieldName);

                if (embeddedFields != null)
                {
                    return embeddedFields.ComponentValues(EmbeddedFieldName);
                }
            }

            return new List<Component>();
        }

        public static Component ComponentMetaValue(this RepositoryLocalObject Object, String FieldName)
        {
            return Object.ComponentValue(Object.Metadata, Object.MetadataSchema, FieldName);
        }

        public static IList<Component> ComponentMetaValues(this RepositoryLocalObject Object, String FieldName)
        {
            return Object.ComponentValues(Object.Metadata, Object.MetadataSchema, FieldName);
        }

        public static Component ComponentMetaValue(this RepositoryLocalObject Object, String FieldName, String EmbeddedFieldName)
        {
            return Object.ComponentValue(Object.Metadata, Object.MetadataSchema, FieldName, EmbeddedFieldName);
        }

        public static IList<Component> ComponentMetaValues(this RepositoryLocalObject Object, String FieldName, String EmbeddedFieldName)
        {
            return Object.ComponentValues(Object.Metadata, Object.MetadataSchema, FieldName, EmbeddedFieldName);
        }

        public static String ExternalLinkValue(this RepositoryLocalObject Object, XmlElement Content, Schema Schema, String FieldName)
        {
            IList<String> values = Object.ExternalLinkValues(Content, Schema, FieldName);

            if (values.Count > 0)
                return values[0];

            return null;
        }

        public static IList<String> ExternalLinkValues(this RepositoryLocalObject Object, XmlElement Content, Schema Schema, String FieldName)
        {
            if (Object != null && Content != null && Schema != null)
            {
                ItemFields fields = new ItemFields(Content, Schema);

                return fields.ExternalLinkValues(FieldName);
            }

            return new List<String>();
        }

        public static String ExternalLinkValue(this RepositoryLocalObject Object, XmlElement Content, Schema Schema, String FieldName, String EmbeddedFieldName)
        {
            IList<String> values = Object.ExternalLinkValues(Content, Schema, FieldName, EmbeddedFieldName);

            if (values.Count > 0)
                return values[0];

            return null;
        }

        public static IList<String> ExternalLinkValues(this RepositoryLocalObject Object, XmlElement Content, Schema Schema, String FieldName, String EmbeddedFieldName)
        {
            if (Object != null && Content != null && Schema != null)
            {
                ItemFields fields = new ItemFields(Content, Schema);

                ItemFields embeddedFields = fields.EmbeddedValue(FieldName);

                if (embeddedFields != null)
                {
                    return embeddedFields.ExternalLinkValues(EmbeddedFieldName);
                }
            }

            return new List<String>();
        }

        public static String ExternalLinkMetaValue(this RepositoryLocalObject Object, String FieldName)
        {
            return Object.ExternalLinkValue(Object.Metadata, Object.MetadataSchema, FieldName);
        }

        public static IList<String> ExternalLinkMetaValues(this RepositoryLocalObject Object, String FieldName)
        {
            return Object.ExternalLinkValues(Object.Metadata, Object.MetadataSchema, FieldName);
        }

        public static String ExternalLinkMetaValue(this RepositoryLocalObject Object, String FieldName, String EmbeddedFieldName)
        {
            return Object.ExternalLinkValue(Object.Metadata, Object.MetadataSchema, FieldName, EmbeddedFieldName);
        }

        public static IList<String> ExternalLinkMetaValues(this RepositoryLocalObject Object, String FieldName, String EmbeddedFieldName)
        {
            return Object.ExternalLinkValues(Object.Metadata, Object.MetadataSchema, FieldName, EmbeddedFieldName);
        }

        public static String StringValue(this RepositoryLocalObject Object, XmlElement Content, Schema Schema, String FieldName)
        {
            IList<String> values = Object.StringValues(Content, Schema, FieldName);

            if (values.Count > 0)
                return values[0];

            return String.Empty;
        }

        public static IList<String> StringValues(this RepositoryLocalObject Object, XmlElement Content, Schema Schema, String FieldName)
        {
            if (Object != null && Content != null && Schema != null)
            {
                ItemFields fields = new ItemFields(Content, Schema);

                return fields.StringValues(FieldName);
            }

            return new List<String>();
        }

        public static String StringValue(this RepositoryLocalObject Object, XmlElement Content, Schema Schema, String FieldName, String EmbeddedFieldName)
        {
            IList<String> values = Object.StringValues(Content, Schema, FieldName, EmbeddedFieldName);

            if (values.Count > 0)
                return values[0];

            return String.Empty;
        }

        public static IList<String> StringValues(this RepositoryLocalObject Object, XmlElement Content, Schema Schema, String FieldName, String EmbeddedFieldName)
        {
            if (Object != null && Content != null && Schema != null)
            {
                ItemFields fields = new ItemFields(Content, Schema);

                ItemFields embeddedFields = fields.EmbeddedValue(FieldName);

                if (embeddedFields != null)
                {
                    return embeddedFields.StringValues(EmbeddedFieldName);
                }
            }

            return new List<String>();
        }

        public static String StringMetaValue(this RepositoryLocalObject Object, String FieldName)
        {
            return Object.StringValue(Object.Metadata, Object.MetadataSchema, FieldName);
        }

        public static IList<String> StringMetaValues(this RepositoryLocalObject Object, String FieldName)
        {
            return Object.StringValues(Object.Metadata, Object.MetadataSchema, FieldName);
        }

        public static String StringMetaValue(this RepositoryLocalObject Object, String FieldName, String EmbeddedFieldName)
        {
            return Object.StringValue(Object.Metadata, Object.MetadataSchema, FieldName, EmbeddedFieldName);
        }

        public static IList<String> StringMetaValues(this RepositoryLocalObject Object, String FieldName, String EmbeddedFieldName)
        {
            return Object.StringValues(Object.Metadata, Object.MetadataSchema, FieldName, EmbeddedFieldName);
        }

        public static DateTime DateValue(this RepositoryLocalObject Object, XmlElement Content, Schema Schema, String FieldName)
        {
            IList<DateTime> values = Object.DateValues(Content, Schema, FieldName);

            if (values.Count > 0)
                return values[0];

            return DateTime.MinValue;
        }

        public static IList<DateTime> DateValues(this RepositoryLocalObject Object, XmlElement Content, Schema Schema, String FieldName)
        {
            if (Object != null && Content != null && Schema != null)
            {
                ItemFields fields = new ItemFields(Content, Schema);

                return fields.DateValues(FieldName);
            }

            return new List<DateTime>();
        }

        public static DateTime DateValue(this RepositoryLocalObject Object, XmlElement Content, Schema Schema, String FieldName, String EmbeddedFieldName)
        {
            IList<DateTime> values = Object.DateValues(Content, Schema, FieldName, EmbeddedFieldName);

            if (values.Count > 0)
                return values[0];

            return DateTime.MinValue;
        }

        public static IList<DateTime> DateValues(this RepositoryLocalObject Object, XmlElement Content, Schema Schema, String FieldName, String EmbeddedFieldName)
        {
            if (Object != null && Content != null && Schema != null)
            {
                ItemFields fields = new ItemFields(Content, Schema);

                ItemFields embeddedFields = fields.EmbeddedValue(FieldName);

                if (embeddedFields != null)
                {
                    return embeddedFields.DateValues(EmbeddedFieldName);
                }
            }

            return new List<DateTime>();
        }

        public static DateTime DateMetaValue(this RepositoryLocalObject Object, String FieldName)
        {
            return Object.DateValue(Object.Metadata, Object.MetadataSchema, FieldName);
        }

        public static IList<DateTime> DateMetaValues(this RepositoryLocalObject Object, String FieldName)
        {
            return Object.DateValues(Object.Metadata, Object.MetadataSchema, FieldName);
        }

        public static DateTime DateMetaValue(this RepositoryLocalObject Object, String FieldName, String EmbeddedFieldName)
        {
            return Object.DateValue(Object.Metadata, Object.MetadataSchema, FieldName, EmbeddedFieldName);
        }

        public static IList<DateTime> DateMetaValues(this RepositoryLocalObject Object, String FieldName, String EmbeddedFieldName)
        {
            return Object.DateValues(Object.Metadata, Object.MetadataSchema, FieldName, EmbeddedFieldName);
        }

        public static Keyword KeywordValue(this RepositoryLocalObject Object, XmlElement Content, Schema Schema, String FieldName)
        {
            IList<Keyword> values = Object.KeywordValues(Content, Schema, FieldName);

            if (values.Count > 0)
                return values[0];

            return null;
        }

        public static IList<Keyword> KeywordValues(this RepositoryLocalObject Object, XmlElement Content, Schema Schema, String FieldName)
        {
            if (Object != null && Content != null && Schema != null)
            {
                ItemFields fields = new ItemFields(Content, Schema);

                return fields.KeywordValues(FieldName);
            }

            return new List<Keyword>();
        }

        public static Keyword KeywordValue(this RepositoryLocalObject Object, XmlElement Content, Schema Schema, String FieldName, String EmbeddedFieldName)
        {
            IList<Keyword> values = Object.KeywordValues(Content, Schema, FieldName, EmbeddedFieldName);

            if (values.Count > 0)
                return values[0];

            return null;
        }

        public static IList<Keyword> KeywordValues(this RepositoryLocalObject Object, XmlElement Content, Schema Schema, String FieldName, String EmbeddedFieldName)
        {
            if (Object != null && Content != null && Schema != null)
            {
                ItemFields fields = new ItemFields(Content, Schema);

                ItemFields embeddedFields = fields.EmbeddedValue(FieldName);

                if (embeddedFields != null)
                {
                    return embeddedFields.KeywordValues(EmbeddedFieldName);
                }
            }

            return new List<Keyword>();
        }

        public static Keyword KeywordMetaValue(this RepositoryLocalObject Object, String FieldName)
        {
            return Object.KeywordValue(Object.Metadata, Object.MetadataSchema, FieldName);
        }

        public static IList<Keyword> KeywordMetaValues(this RepositoryLocalObject Object, String FieldName)
        {
            return Object.KeywordValues(Object.Metadata, Object.MetadataSchema, FieldName);
        }

        public static Keyword KeywordMetaValue(this RepositoryLocalObject Object, String FieldName, String EmbeddedFieldName)
        {
            return Object.KeywordValue(Object.Metadata, Object.MetadataSchema, FieldName, EmbeddedFieldName);
        }

        public static IList<Keyword> KeywordMetaValues(this RepositoryLocalObject Object, String FieldName, String EmbeddedFieldName)
        {
            return Object.KeywordValues(Object.Metadata, Object.MetadataSchema, FieldName, EmbeddedFieldName);
        }

        public static Double NumberValue(this RepositoryLocalObject Object, XmlElement Content, Schema Schema, String FieldName)
        {
            IList<Double> values = Object.NumberValues(Content, Schema, FieldName);

            if (values.Count > 0)
                return values[0];

            return 0;
        }

        public static IList<Double> NumberValues(this RepositoryLocalObject Object, XmlElement Content, Schema Schema, String FieldName)
        {
            if (Object != null && Content != null && Schema != null)
            {
                ItemFields fields = new ItemFields(Content, Schema);

                return fields.NumberValues(FieldName);
            }

            return new List<Double>();
        }

        public static Double NumberValue(this RepositoryLocalObject Object, XmlElement Content, Schema Schema, String FieldName, String EmbeddedFieldName)
        {
            IList<Double> values = Object.NumberValues(Content, Schema, FieldName, EmbeddedFieldName);

            if (values.Count > 0)
                return values[0];

            return 0;
        }

        public static IList<Double> NumberValues(this RepositoryLocalObject Object, XmlElement Content, Schema Schema, String FieldName, String EmbeddedFieldName)
        {
            if (Object != null && Content != null && Schema != null)
            {
                ItemFields fields = new ItemFields(Content, Schema);

                ItemFields embeddedFields = fields.EmbeddedValue(FieldName);

                if (embeddedFields != null)
                {
                    return embeddedFields.NumberValues(EmbeddedFieldName);
                }
            }

            return new List<Double>();
        }

        public static Double NumberMetaValue(this RepositoryLocalObject Object, String FieldName)
        {
            return Object.NumberValue(Object.Metadata, Object.MetadataSchema, FieldName);
        }

        public static IList<Double> NumberMetaValues(this RepositoryLocalObject Object, String FieldName)
        {
            return Object.NumberValues(Object.Metadata, Object.MetadataSchema, FieldName);
        }

        public static Double NumberMetaValue(this RepositoryLocalObject Object, String FieldName, String EmbeddedFieldName)
        {
            return Object.NumberValue(Object.Metadata, Object.MetadataSchema, FieldName, EmbeddedFieldName);
        }

        public static IList<Double> NumberMetaValues(this RepositoryLocalObject Object, String FieldName, String EmbeddedFieldName)
        {
            return Object.NumberValues(Object.Metadata, Object.MetadataSchema, FieldName, EmbeddedFieldName);
        }

        public static String XHTMLValue(this RepositoryLocalObject Object, XmlElement Content, Schema Schema, String FieldName)
        {
            IList<String> values = Object.XHTMLValues(Content, Schema, FieldName);

            if (values.Count > 0)
                return values[0];

            return String.Empty;
        }

        public static IList<String> XHTMLValues(this RepositoryLocalObject Object, XmlElement Content, Schema Schema, String FieldName)
        {
            if (Object != null && Content != null && Schema != null)
            {
                ItemFields fields = new ItemFields(Content, Schema);

                return fields.XHTMLValues(FieldName);
            }

            return new List<String>();
        }

        public static String XHTMLValue(this RepositoryLocalObject Object, XmlElement Content, Schema Schema, String FieldName, String EmbeddedFieldName)
        {
            IList<String> values = Object.XHTMLValues(Content, Schema, FieldName, EmbeddedFieldName);

            if (values.Count > 0)
                return values[0];

            return String.Empty;
        }

        public static IList<String> XHTMLValues(this RepositoryLocalObject Object, XmlElement Content, Schema Schema, String FieldName, String EmbeddedFieldName)
        {
            if (Object != null && Content != null && Schema != null)
            {
                ItemFields fields = new ItemFields(Content, Schema);

                ItemFields embeddedFields = fields.EmbeddedValue(FieldName);

                if (embeddedFields != null)
                {
                    return embeddedFields.XHTMLValues(EmbeddedFieldName);
                }
            }

            return new List<String>();
        }

        public static String XHTMLMetaValue(this RepositoryLocalObject Object, String FieldName)
        {
            return Object.XHTMLValue(Object.Metadata, Object.MetadataSchema, FieldName);
        }

        public static IList<String> XHTMLMetaValues(this RepositoryLocalObject Object, String FieldName)
        {
            return Object.XHTMLValues(Object.Metadata, Object.MetadataSchema, FieldName);
        }

        public static String XHTMLMetaValue(this RepositoryLocalObject Object, String FieldName, String EmbeddedFieldName)
        {
            return Object.XHTMLValue(Object.Metadata, Object.MetadataSchema, FieldName, EmbeddedFieldName);
        }

        public static IList<String> XHTMLMetaValues(this RepositoryLocalObject Object, String FieldName, String EmbeddedFieldName)
        {
            return Object.XHTMLValues(Object.Metadata, Object.MetadataSchema, FieldName, EmbeddedFieldName);
        }

        public static String XMLValue(this RepositoryLocalObject Object, XmlElement Content, Schema Schema, String FieldName)
        {
            IList<String> values = Object.XMLValues(Content, Schema, FieldName);

            if (values.Count > 0)
                return values[0];

            return String.Empty;
        }

        public static IList<String> XMLValues(this RepositoryLocalObject Object, XmlElement Content, Schema Schema, String FieldName)
        {
            if (Object != null && Content != null && Schema != null)
            {
                ItemFields fields = new ItemFields(Content, Schema);

                return fields.XMLValues(FieldName);
            }

            return new List<String>();
        }

        public static String XMLValue(this RepositoryLocalObject Object, XmlElement Content, Schema Schema, String FieldName, String EmbeddedFieldName)
        {
            IList<String> values = Object.XMLValues(Content, Schema, FieldName, EmbeddedFieldName);

            if (values.Count > 0)
                return values[0];

            return String.Empty;
        }

        public static IList<String> XMLValues(this RepositoryLocalObject Object, XmlElement Content, Schema Schema, String FieldName, String EmbeddedFieldName)
        {
            if (Object != null && Content != null && Schema != null)
            {
                ItemFields fields = new ItemFields(Content, Schema);

                ItemFields embeddedFields = fields.EmbeddedValue(FieldName);

                if (embeddedFields != null)
                {
                    return embeddedFields.XMLValues(EmbeddedFieldName);
                }
            }

            return new List<String>();
        }

        public static String XMLMetaValue(this RepositoryLocalObject Object, String FieldName)
        {
            return Object.XMLValue(Object.Metadata, Object.MetadataSchema, FieldName);
        }

        public static IList<String> XMLMetaValues(this RepositoryLocalObject Object, String FieldName)
        {
            return Object.XMLValues(Object.Metadata, Object.MetadataSchema, FieldName);
        }

        public static String XMLMetaValue(this RepositoryLocalObject Object, String FieldName, String EmbeddedFieldName)
        {
            return Object.XMLValue(Object.Metadata, Object.MetadataSchema, FieldName, EmbeddedFieldName);
        }

        public static IList<String> XMLMetaValues(this RepositoryLocalObject Object, String FieldName, String EmbeddedFieldName)
        {
            return Object.XMLValues(Object.Metadata, Object.MetadataSchema, FieldName, EmbeddedFieldName);
        }

        public static ItemFields EmbeddedValue(this RepositoryLocalObject Object, XmlElement Content, Schema Schema, String FieldName)
        {
            IList<ItemFields> values = Object.EmbeddedValues(Content, Schema, FieldName);

            if (values.Count > 0)
                return values[0];

            return null;
        }

        public static IList<ItemFields> EmbeddedValues(this RepositoryLocalObject Object, XmlElement Content, Schema Schema, String FieldName)
        {
            if (Object != null && Content != null && Schema != null)
            {
                ItemFields fields = new ItemFields(Content, Schema);

                return fields.EmbeddedValues(FieldName);
            }

            return new List<ItemFields>();
        }

        public static ItemFields EmbeddedValue(this RepositoryLocalObject Object, XmlElement Content, Schema Schema, String FieldName, String EmbeddedFieldName)
        {
            IList<ItemFields> values = Object.EmbeddedValues(Content, Schema, FieldName, EmbeddedFieldName);

            if (values.Count > 0)
                return values[0];

            return null;
        }

        public static IList<ItemFields> EmbeddedValues(this RepositoryLocalObject Object, XmlElement Content, Schema Schema, String FieldName, String EmbeddedFieldName)
        {
            if (Object != null && Content != null && Schema != null)
            {
                ItemFields fields = new ItemFields(Content, Schema);

                ItemFields embeddedFields = fields.EmbeddedValue(FieldName);

                if (embeddedFields != null)
                {
                    return embeddedFields.EmbeddedValues(EmbeddedFieldName);
                }
            }

            return new List<ItemFields>();
        }

        public static ItemFields EmbeddedMetaValue(this RepositoryLocalObject Object, String FieldName)
        {
            return Object.EmbeddedValue(Object.Metadata, Object.MetadataSchema, FieldName);
        }

        public static IList<ItemFields> EmbeddedMetaValues(this RepositoryLocalObject Object, String FieldName)
        {
            return Object.EmbeddedValues(Object.Metadata, Object.MetadataSchema, FieldName);
        }

        public static ItemFields EmbeddedMetaValue(this RepositoryLocalObject Object, String FieldName, String EmbeddedFieldName)
        {
            return Object.EmbeddedValue(Object.Metadata, Object.MetadataSchema, FieldName, EmbeddedFieldName);
        }

        public static IList<ItemFields> EmbeddedMetaValues(this RepositoryLocalObject Object, String FieldName, String EmbeddedFieldName)
        {
            return Object.EmbeddedValues(Object.Metadata, Object.MetadataSchema, FieldName, EmbeddedFieldName);
        }
        #endregion

        #region Component Extensions
        public static Component ComponentValue(this Component Component, String FieldName)
        {
            return Component.ComponentValue(Component.Content, Component.Schema, FieldName);
        }

        public static IList<Component> ComponentValues(this Component Component, String FieldName)
        {
            return Component.ComponentValues(Component.Content, Component.Schema, FieldName);
        }

        public static Component ComponentValue(this Component Component, String FieldName, String EmbeddedFieldName)
        {
            return Component.ComponentValue(Component.Content, Component.Schema, FieldName, EmbeddedFieldName);
        }

        public static IList<Component> ComponentValues(this Component Component, String FieldName, String EmbeddedFieldName)
        {
            return Component.ComponentValues(Component.Content, Component.Schema, FieldName, EmbeddedFieldName);
        }

        public static String ExternalLinkValue(this Component Component, String FieldName)
        {
            return Component.ExternalLinkValue(Component.Content, Component.Schema, FieldName);
        }

        public static IList<String> ExternalLinkValues(this Component Component, String FieldName)
        {
            return Component.ExternalLinkValues(Component.Content, Component.Schema, FieldName);
        }

        public static String ExternalLinkValue(this Component Component, String FieldName, String EmbeddedFieldName)
        {
            return Component.ExternalLinkValue(Component.Content, Component.Schema, FieldName, EmbeddedFieldName);
        }

        public static IList<String> ExternalLinkValues(this Component Component, String FieldName, String EmbeddedFieldName)
        {
            return Component.ExternalLinkValues(Component.Content, Component.Schema, FieldName, EmbeddedFieldName);
        }

        public static String StringValue(this Component Component, String FieldName)
        {
            return Component.StringValue(Component.Content, Component.Schema, FieldName);
        }

        public static IList<String> StringValues(this Component Component, String FieldName)
        {
            return Component.StringValues(Component.Content, Component.Schema, FieldName);
        }

        public static String StringValue(this Component Component, String FieldName, String EmbeddedFieldName)
        {
            return Component.StringValue(Component.Content, Component.Schema, FieldName, EmbeddedFieldName);
        }

        public static IList<String> StringValues(this Component Component, String FieldName, String EmbeddedFieldName)
        {
            return Component.StringValues(Component.Content, Component.Schema, FieldName, EmbeddedFieldName);
        }

        public static DateTime DateValue(this Component Component, String FieldName)
        {
            return Component.DateValue(Component.Content, Component.Schema, FieldName);
        }

        public static IList<DateTime> DateValues(this Component Component, String FieldName)
        {
            return Component.DateValues(Component.Content, Component.Schema, FieldName);
        }

        public static DateTime DateValue(this Component Component, String FieldName, String EmbeddedFieldName)
        {
            return Component.DateValue(Component.Content, Component.Schema, FieldName, EmbeddedFieldName);
        }

        public static IList<DateTime> DateValues(this Component Component, String FieldName, String EmbeddedFieldName)
        {
            return Component.DateValues(Component.Content, Component.Schema, FieldName, EmbeddedFieldName);
        }

        public static Keyword KeywordValue(this Component Component, String FieldName)
        {
            return Component.KeywordValue(Component.Content, Component.Schema, FieldName);
        }

        public static IList<Keyword> KeywordValues(this Component Component, String FieldName)
        {
            return Component.KeywordValues(Component.Content, Component.Schema, FieldName);
        }

        public static Keyword KeywordValue(this Component Component, String FieldName, String EmbeddedFieldName)
        {
            return Component.KeywordValue(Component.Content, Component.Schema, FieldName, EmbeddedFieldName);
        }

        public static IList<Keyword> KeywordValues(this Component Component, String FieldName, String EmbeddedFieldName)
        {
            return Component.KeywordValues(Component.Content, Component.Schema, FieldName, EmbeddedFieldName);
        }

        public static Double NumberValue(this Component Component, String FieldName)
        {
            return Component.NumberValue(Component.Content, Component.Schema, FieldName);
        }

        public static IList<Double> NumberValues(this Component Component, String FieldName)
        {
            return Component.NumberValues(Component.Content, Component.Schema, FieldName);
        }

        public static Double NumberValue(this Component Component, String FieldName, String EmbeddedFieldName)
        {
            return Component.NumberValue(Component.Content, Component.Schema, FieldName, EmbeddedFieldName);
        }

        public static IList<Double> NumberValues(this Component Component, String FieldName, String EmbeddedFieldName)
        {
            return Component.NumberValues(Component.Content, Component.Schema, FieldName, EmbeddedFieldName);
        }

        public static String XHTMLValue(this Component Component, String FieldName)
        {
            return Component.XHTMLValue(Component.Content, Component.Schema, FieldName);
        }

        public static IList<String> XHTMLValues(this Component Component, String FieldName)
        {
            return Component.XHTMLValues(Component.Content, Component.Schema, FieldName);
        }

        public static String XHTMLValue(this Component Component, String FieldName, String EmbeddedFieldName)
        {
            return Component.XHTMLValue(Component.Content, Component.Schema, FieldName, EmbeddedFieldName);
        }

        public static IList<String> XHTMLValues(this Component Component, String FieldName, String EmbeddedFieldName)
        {
            return Component.XHTMLValues(Component.Content, Component.Schema, FieldName, EmbeddedFieldName);
        }

        public static String XMLValue(this Component Component, String FieldName)
        {
            return Component.XMLValue(Component.Content, Component.Schema, FieldName);
        }

        public static IList<String> XMLValues(this Component Component, String FieldName)
        {
            return Component.XMLValues(Component.Content, Component.Schema, FieldName);
        }

        public static String XMLValue(this Component Component, String FieldName, String EmbeddedFieldName)
        {
            return Component.XMLValue(Component.Content, Component.Schema, FieldName, EmbeddedFieldName);
        }

        public static IList<String> XMLValues(this Component Component, String FieldName, String EmbeddedFieldName)
        {
            return Component.XMLValues(Component.Content, Component.Schema, FieldName, EmbeddedFieldName);
        }

        public static ItemFields EmbeddedValue(this Component Component, String FieldName)
        {
            return Component.EmbeddedValue(Component.Content, Component.Schema, FieldName);
        }

        public static IList<ItemFields> EmbeddedValues(this Component Component, String FieldName)
        {
            return Component.EmbeddedValues(Component.Content, Component.Schema, FieldName);
        }

        public static ItemFields EmbeddedValue(this Component Component, String FieldName, String EmbeddedFieldName)
        {
            return Component.EmbeddedValue(Component.Content, Component.Schema, FieldName, EmbeddedFieldName);
        }

        public static IList<ItemFields> EmbeddedValues(this Component Component, String FieldName, String EmbeddedFieldName)
        {
            return Component.EmbeddedValues(Component.Content, Component.Schema, FieldName, EmbeddedFieldName);
        }
        #endregion

        /// <summary>
        /// Return a list of objects of the requested type from the XML.
        /// </summary>
        /// <remarks>
        /// This method goes back to the database to retrieve more information. So it is NOT just a fast and convenient way to get a type safe list from the XML.
        /// </remarks>
        /// <typeparam name="T">The type of object to return, like Publication, User, Group, OrganizationalItem</typeparam>
        /// <param name="listElement">The XML from which to construct the list of objects</param>
        /// <returns>a list of objects of the requested type from the XML</returns>
        public static IList<T> TridionObjects<T>(this XmlElement listElement, Engine Engine) where T : IdentifiableObject
        {
            XmlNodeList itemElements = listElement.SelectNodes("*");
            List<T> result = new List<T>(itemElements.Count);

            foreach (XmlElement itemElement in itemElements)
            {
                result.Add(itemElement.TridionObject<T>(Engine));
            }

            result.Sort(delegate(T item1, T item2)
            {
                return item1.Title.CompareTo(item2.Title);
            });

            return result;
        }

        public static T TridionObject<T>(this XmlElement itemElement, Engine Engine) where T : IdentifiableObject
        {
            return Engine.GetObject(itemElement.GetAttribute("ID")) as T;
        }
    }
}

