﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.IO;
using Tridion.ContentManager;
using Tridion.ContentManager.CommunicationManagement;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Expression;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.Templating.Dreamweaver;
using Tridion;
using Tridion.ContentManager.ContentManagement.Fields;
using Publishing = Tridion.ContentManager.Publishing.Rendering;
using Tridion.ContentManager.ContentManagement;
using Tridion.ContentManager.Publishing.Rendering;
using System.Text.RegularExpressions;
using Emaar.Web.Tridion.System.Extensions;
using Tridion.Extensions.ContentManager.Templating;

namespace Emaar.Web.Tridion.System
{
    [TcmTemplateTitle("Resource List")]
    public class ResourceListTemplate : TemplateBase
    {
        /// <summary>
        /// Transforms the current component.
        /// </summary>
        /// <param name="engine">The engine.</param>
        /// <param name="package">The package.</param>
        public override void Transform(Engine engine, Package package)
        {
            base.Transform(engine, package);

            XmlDocument xDoc = new XmlDocument();
            XmlElement xRoot = xDoc.CreateElement("ResourceLists");
            ItemFields fields = null;

            if (IsComponent)
            {
                IList<Component> components = Component.OrganizationalItem.Components();

                foreach (Component c in components)
                {
                    fields = new ItemFields(c.Content, c.Schema);

                    XmlElement xList = xDoc.CreateElement("list");
                    xList.SetAttribute("tcm", c.Id);
                    xList.SetAttribute("type", fields.StringValue("List"));

                    foreach (ItemField itemField in fields)
                    {
                        if (itemField is EmbeddedSchemaField)
                        {
                            EmbeddedSchemaField field = itemField as EmbeddedSchemaField;

                            foreach (ItemFields embField in field.Values)
                            {
                                XmlElement xItem = xList.AddTextNode("item", embField.StringValue("Value"));
                                xItem.SetAttribute("id", embField.StringValue("Key"));

                                xList.AppendChild(xItem);
                            }
                        }
                    }

                    xRoot.AppendChild(xList);
                }
            }

            xDoc.AppendChild(xRoot);

            package.AddXml(Package.OutputName, xDoc.OuterXml);
        }
    }
}
