﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.ContentManagement.Fields;
using Emaar.Web.Tridion.System.Extensions;
using System.Web;
using Tridion.Extensions.ContentManager.Templating;
using Emaar.Web.Tridion.System.Dreamweaver_Extension;

namespace Emaar.Web.Tridion.System
{
    [TcmTemplateTitle("Control")]
    public class ControlTemplate : TemplateBase
    {
        public override void Transform(Engine engine, Package package)
        {
            base.Transform(engine, package);
            Templating controlTag = new Templating();
            Package.AddString(Package.OutputName, controlTag.GetControlTag(Component));
        }
    }
}
