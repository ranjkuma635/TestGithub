﻿using System;
using System.Collections.Generic;
using Tridion.ContentManager;
using Tridion.ContentManager.CommunicationManagement;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.ContentManagement.Fields;

using Tridion.ContentManager.ContentManagement;
using Tridion.Extensions.ContentManager.Templating;
using Emaar.Web.Tridion.System.Extensions;

namespace Emaar.Web.Tridion.System
{
    [TcmTemplateTitle("Publication Variables")]
    public class PublicationVariablesTemplate : TemplateBase
    {        
        public override void Transform(Engine engine, Package package)
        {
            base.Transform(engine, package);

            Publication pub = Publication;

            package.AddString(Prefix() + ".Url", Publication.PublicationUrl);
            package.AddString(Prefix() + ".Path", Publication.PublicationPath);
            Package.AddNumber(Prefix()+ ".PubID",Publication.Id.ItemId);

            if (Publication.Metadata != null && Publication.MetadataSchema != null)
            {
                ItemFields metaFields = new ItemFields(Publication.Metadata, Publication.MetadataSchema);
                ParseFields(Prefix(), metaFields);
            }
        }

        /// <summary>
        /// Returns the Prefix used for parsed Publication variables
        /// </summary>
        /// <returns></returns>
        protected virtual String Prefix()
        {
            return "PublicationVariable";
        }

        /// <summary>
        /// Indicate whether the specified metadata field should be included in the navigation xml.
        /// Override this method in derived templates in order to supply implementation specific navigation.
        /// </summary>
        /// <param name="fieldName">Metadata Fieldname</param>
        /// <returns>True if the metadata should be included</returns>
        protected virtual bool IncludeMetadata(string FieldName)
        {
            return true;
        }

        private void ParseFields(String Prefix, ItemFields Fields)
        {
            foreach (ItemField field in Fields)
            {
                string fieldName = String.Concat(Prefix, ".", field.Name);

                if (IncludeMetadata(field.Name))
                {
                    if (field is SingleLineTextField)
                    {
                        string value = field.StringValue();

                        if (!String.IsNullOrEmpty(value))
                        {
                            Package.AddString(fieldName, value);
                        }
                    }
                    else if (field is ExternalLinkField)
                    {
                        string value = field.StringValue();

                        if (!String.IsNullOrEmpty(value))
                        {
                            Package.AddString(fieldName, value);
                        }
                    }
                    else if (field is DateField)
                    {
                        string value = field.DateValue().ToString("yyyyMMddHHmmss");

                        if (!String.IsNullOrEmpty(value))
                        {
                            Package.AddString(fieldName, value);
                        }
                    }
                    else if (field is NumberField)
                    {
                        string value = field.NumberValue().ToString();

                        if (!String.IsNullOrEmpty(value))
                        {
                            Package.AddString(fieldName, value);
                        }
                    }
                    else if (field is ComponentLinkField)
                    {
                        IList<Component> components = field.ComponentValues();

                        if (components != null && components.Count > 0)
                        {
                            List<TcmUri> ids = new List<TcmUri>();
                            foreach (Component component in components)
                                ids.Add(component.Id);

                            Package.AddComponents(fieldName, ids);
                        }
                    }
                    else if (field is XhtmlField)
                    {
                        string value = field.XHTMLValue();

                        if (!String.IsNullOrEmpty(value))
                        {
                            Package.AddXhtml(fieldName, value);
                        }
                    }
                    else if (field is KeywordField)
                    {
                        Keyword keyword = field.KeywordValue();

                        if (keyword != null)
                        {
                            Package.AddString(fieldName, keyword.Title);
                        }
                    }
                    else if (field is EmbeddedSchemaField)
                    {
                        ItemFields fields = field.EmbeddedValue();

                        if (fields != null)
                        {
                            ParseFields(fieldName, fields);
                        }
                    }
                }
            }
        }
    }
}
