﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
using System.Web;
using Tridion.ContentManager;
using Tridion.ContentManager.CommunicationManagement;
using Tridion.ContentManager.ContentManagement;
using Tridion.ContentManager.ContentManagement.Fields;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.Publishing;
using Tridion.Extensions.ContentManager.Templating;
using Tridion.ContentManager.Publishing.Rendering;
using Emaar.Web.Tridion.System.Extensions;

namespace Emaar.Web.Tridion.System
{
    [TcmTemplateTitle("Get Common Data")]
    public class GetCommonData : TemplateBase 
    {

        public override void Transform(Engine engine, Package package)
        {
            //this.Initialize(engine, package);
           // Page page = GetPage();
            base.Transform(engine, package);
            StructureGroup RootSG = (StructureGroup)Page.OrganizationalItem as StructureGroup;


            package.AddString("StructureGroup", RootSG.Id.ToString());

            package.PushItem("publicationurl", package.CreateStringItem(ContentType.Text, getPubURL(Page)));
            package.PushItem("publicationid", package.CreateStringItem(ContentType.Text, getPubID(Page)));
            package.PushItem("publicationPath", package.CreateStringItem(ContentType.Text, getPubPath(Page)));
            package.PushItem("publicationURL", package.CreateStringItem(ContentType.Text, getPubURL(Page)));
            package.PushItem("PublicationTargetID", package.CreateStringItem(ContentType.Text, PublicationTargetID(Page)));
            package.PushItem("PublicationPath", package.CreateStringItem(ContentType.Text, Page.PublishLocationUrl));
            package.PushItem("OrganizationalItem", package.CreateStringItem(ContentType.Text, Page.OrganizationalItem.Id));

            package.PushItem("CurrentMonth", package.CreateStringItem(ContentType.Text, GetCurrentMonth()));
            package.PushItem("CurrentYear", package.CreateStringItem(ContentType.Text, GetCurrentYear()));  
        }

        private string getPubURL(Page page)
        {
            string pub = "tcm:0-" + page.Id.PublicationId + "-1";
            Publication publication;
            publication = Engine.GetObject(pub) as Publication;
            return publication.PublicationUrl.ToString();
        }

        private string getPubPath(Page page)
        {
            string pub = "tcm:0-" + page.Id.PublicationId + "-1";
            Publication publication;
            publication = Engine.GetObject(pub) as Publication;
            return publication.PublicationPath.ToString();
        }


       

        private string getPubID(Page page)
        {
            string pub = "tcm:0-" + page.Id.PublicationId + "-1";
            Publication publication;
            publication = Engine.GetObject(pub) as Publication;
            return publication.Id.ToString().Split('-')[1].ToString();
        }

        private string PublicationTargetID(Page page)
        {
            string strPublicationTargetID = "tcm:0-0-0";
            if (Engine.RenderMode == RenderMode.Publish)
            {
                strPublicationTargetID = Engine.PublishingContext.PublicationTarget.Id.ToString();
            }

            return strPublicationTargetID;
           
        }

        private string GetSearchItemsFromSG(OrganizationalItem oRecurSG, string strFieldName)
        {
            OrganizationalItem oParentSG;

            string strMetaDataValue = "";

            ItemFields metadataFields;

            if (oRecurSG != null)
            {
                if (oRecurSG.Metadata != null)
                {
                    metadataFields = new ItemFields(oRecurSG.Metadata, oRecurSG.MetadataSchema);

                    if (metadataFields.Contains(strFieldName))
                    {
                        if (!string.IsNullOrEmpty(metadataFields[strFieldName].ToString()))
                        {
                            strMetaDataValue = metadataFields[strFieldName].ToString();
                        }

                    }
                    else
                    {
                        oParentSG = oRecurSG.OrganizationalItem;
                        return GetSearchItemsFromSG(oParentSG, strFieldName);
                    }
                }
                else
                {
                    oParentSG = oRecurSG.OrganizationalItem;
                    return GetSearchItemsFromSG(oParentSG, strFieldName);
                }
            }
            return strMetaDataValue;
        }

        private string GetSearchItemsFromPage(Page page, string strFieldName)
        {
            string strMetaDataValue = "";
            ItemFields metadataFields;

            if (page.Metadata != null)
            {
                metadataFields = new ItemFields(page.Metadata, page.MetadataSchema);
                if (metadataFields.Contains(strFieldName))
                {
                    if (!string.IsNullOrEmpty(metadataFields[strFieldName].ToString()))
                    {
                        strMetaDataValue = metadataFields[strFieldName].ToString();
                    }
                    else
                    {
                        strMetaDataValue = GetSearchItemsFromSG(page.OrganizationalItem, strFieldName);
                    }
                }
                else
                {
                    strMetaDataValue = GetSearchItemsFromSG(page.OrganizationalItem, strFieldName);
                }

            }
            else
            {
                strMetaDataValue = GetSearchItemsFromSG(page.OrganizationalItem, strFieldName);
            }

            return strMetaDataValue;

        }

        private string GetCurrentMonth()
        {
            return DateTime.Today.Month.ToString();  
    
        }

        private string GetCurrentYear()
        {
            return DateTime.Today.Year.ToString();  
        }

    }
}
