﻿using System;
using System.Collections.Generic;
using System.Xml;
using Tridion.ContentManager;
using Tridion.ContentManager.CommunicationManagement;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.ContentManagement.Fields;
using Tridion.ContentManager.ContentManagement;
using System.Text.RegularExpressions;
using Tridion.Extensions.ContentManager.Templating;
using Emaar.Web.Tridion.System.Extensions;

namespace Emaar.Web.Tridion.System
{
    [TcmTemplateTitle("Page Variables")]
    public class PageVariablesTemplate : TemplateBase
    {
        private Regex mNavigable = new Regex(@"^[\d]{1,3}\.{0,1}\s", RegexOptions.Compiled);
        
        /// <summary>
        /// Executes the template transformation
        /// </summary>
        /// <param name="engine">Tridion Engine.</param>
        /// <param name="package">Tridion Package.</param>
        public override void Transform(Engine engine, Package package)
        {
            base.Transform(engine, package);

            string title = PageTitle(Page);

            string Metatitle = PageTitleMeta(Page);

            if (!String.IsNullOrEmpty(title))
                Package.AddString("PageTitle", title);

            if (!String.IsNullOrEmpty(Metatitle))
                Package.AddString("Metatitle", Metatitle);


            ParseMetadata(Page);
        }

        /// <summary>
        /// Indicate whether the specified metadata field should be included in the page variables.
        /// Override this method in derived templates in order to supply implementation specific page variables.
        /// </summary>
        /// <param name="fieldName">Metadata Fieldname</param>
        /// <returns>True if the metadata should be included</returns>
        protected virtual bool IncludeMetadata(string FieldName)
        {
            return true;
        }

        /// <summary>
        /// Returns wether the specified Schema should be used to generate a page title
        /// </summary>
        /// <returns></returns>
        protected virtual bool TitleTemplate(string Schema)
        {
            return true;
        }

        /// <summary>
        /// Returns the Prefix used for parsed Page variables
        /// </summary>
        /// <returns></returns>
        protected virtual String Prefix()
        {
            return "PageVariable";
        }

        /// <summary>
        /// Returns the Navigation configuration XML fieldname
        /// </summary>
        /// <returns></returns>
        protected virtual String NavConfig()
        {
            return "fnavigationconf";
        }

        /// <summary>
        /// Returns the Navigation configuration Title XML fieldname
        /// </summary>
        /// <returns></returns>
        protected virtual String NavTitle()
        {
            return "fnavigationtext";
        }

        /// <summary>
        /// Indicate whether the specified metadata field value should be inherited from parent items.
        /// Override this method in derived templates in order to supply implementation specific page variables.
        /// </summary>
        /// <param name="fieldName">Metadata Fieldname</param>
        /// <returns>True if the metadata should be inherited</returns>
        protected virtual bool InheritedMetadata(string FieldName)
        {
            return true;
        }

        protected virtual string PageTitle(Page Page)
        {
            Component navConfig = Page.ComponentMetaValue(NavConfig());

            if (navConfig != null && !String.IsNullOrEmpty(navConfig.StringValue(NavTitle())))
            {
                return navConfig.StringValue(NavTitle());
            }

            // Retrieve the Title field of the first Component
            if (Page.ComponentPresentations.Count > 0)
            {
                Component component = Page.ComponentPresentations[0].Component;

                if (component.Content != null && TitleTemplate(component.Schema.Title))
                {
                    XmlNode xTitle = component.Content.SelectSingleNode("//node()[local-name() = 'title' or local-name() = 'ftitle']");

                    if (xTitle != null && !String.IsNullOrEmpty(xTitle.InnerText))
                    {
                        return xTitle.InnerText;
                    }
                }
            }

            // Retrieve the title of a navigable item
            Match match = mNavigable.Match(Page.Title);

            if (match.Success)
            {
                return Page.Title.Substring(match.Length);
            }

            return Page.Title;
        }


        protected virtual string PageTitleMeta(Page Page)
        {
            Component navConfig = Page.ComponentMetaValue(NavConfig());

            // Retrieve the Title field of the first Component
            if (Page.ComponentPresentations.Count > 0)
            {
                Component component = Page.ComponentPresentations[0].Component;

                if (component.Content != null && TitleTemplate(component.Schema.Title))
                {                                                                                     
                    XmlNode xTitleMeta = component.Content.SelectSingleNode("//node()[local-name() = 'CustompageTitle']");

                    if (xTitleMeta != null && !String.IsNullOrEmpty(xTitleMeta.InnerText))
                    {
                        return xTitleMeta.InnerText;
                    }
                    else
                    {
                        XmlNode xTitle = component.Content.SelectSingleNode("//node()[local-name() = 'title' or local-name() = 'ftitle']");

                        if (xTitle != null && !String.IsNullOrEmpty(xTitle.InnerText))
                        {
                            return xTitle.InnerText;
                        }                        
                    
                    }

                }
            }

              return Page.Title;
        }


        private void ParseMetadata(RepositoryLocalObject Item)
        {
            if (Item != null)
            {
                if (Package.GetByName("NavigationParent") == null && mNavigable.IsMatch(Item.Title) && !Item.Title.StartsWith("000"))
                {
                    Package.AddString("NavigationParent", Item.Id);
                }

                if (Item.Metadata != null)
                {
                    ItemFields metadata = new ItemFields(Item.Metadata, Item.MetadataSchema);

                    ParseFields(Prefix(), metadata, Item);
                }

                if (Item.OrganizationalItem.Id != RootStructureGroup.Id)
                    ParseMetadata(Item.OrganizationalItem);
            }
        }

        private void ParseFields(String Prefix, ItemFields Fields, RepositoryLocalObject Item)
        {
            foreach (ItemField field in Fields)
            {
                string fieldName = String.Concat(Prefix, ".", field.Name);
                
                if (Package.GetByName(fieldName) == null && (IncludeMetadata(field.Name) || field.Name == NavConfig()))
                {
                    // Do not include items not marked inherited from parent structure groups
                    if (!(Item is Page) && !InheritedMetadata(field.Name) && field.Name != NavConfig())
                    {
                        Logger.Debug("Not saving inherited metadata: {0}.", field.Name);
                        continue;
                    }

                    if (field is SingleLineTextField || field is MultiLineTextField || field is ExternalLinkField)
                    {
                        string value = field.StringValue();

                        if (!String.IsNullOrEmpty(value))
                        {
                            Package.AddString(fieldName, value);
                        }
                    }                    
                    else if (field is DateField)
                    {
                        string value = field.DateValue().ToString("yyyyMMddHHmmss");

                        if (!String.IsNullOrEmpty(value))
                        {
                            Package.AddString(fieldName, value);
                        }
                    }
                    else if (field is NumberField)
                    {
                        string value = field.NumberValue().ToString();

                        if (!String.IsNullOrEmpty(value))
                        {
                            Package.AddString(fieldName, value);
                        }
                    }
                    else if (field is ComponentLinkField)
                    {
                        IList<Component> components = field.ComponentValues();

                        if (components != null && components.Count > 0)
                        {
                            if (field.Name == NavConfig())
                            {
                                ItemFields componentFields = new ItemFields(components[0].Content, components[0].Schema);
                                ParseFields(Prefix, componentFields, Item);
                            }
                            else
                            {
                                List<TcmUri> ids = new List<TcmUri>();

                                foreach (Component component in components)
                                    ids.Add(component.Id);

                                Package.AddComponents(fieldName, ids);
                            }
                        }
                    }
                    else if (field is XhtmlField)
                    {
                        string value = field.XHTMLValue();

                        if (!String.IsNullOrEmpty(value))
                        {
                            Package.AddXhtml(fieldName, value);
                        }
                    }
                    else if (field is KeywordField)
                    {
                        Keyword keyword = field.KeywordValue();

                        if (keyword != null)
                        {
                            Package.AddLink(fieldName, keyword);                            
                        }
                    }
                    else if (field is EmbeddedSchemaField)
                    {
                        ItemFields fields = field.EmbeddedValue();

                        if (fields != null)
                        {
                            ParseFields(fieldName, fields, Item);
                        }
                    }
                }
            }
        }
    }
}
