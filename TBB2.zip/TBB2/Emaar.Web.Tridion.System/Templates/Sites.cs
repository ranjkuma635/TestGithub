﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.ContentManagement.Fields;
using Tridion.ContentManager;
using Tridion.ContentManager.CommunicationManagement;
using Emaar.Web.Tridion.System.Extensions;
using System.IO;
using System.Xml;
using Tridion.ContentManager.ContentManagement;
using Tridion.Extensions.ContentManager.Templating;

namespace Emaar.Web.Tridion.System
{
    [TcmTemplateTitle("Sites XML")]
    public class SitesTemplate : TemplateBase
    {
        /// <summary>
        /// Executes the template transformation
        /// </summary>
        /// <param name="engine">Tridion Engine.</param>
        /// <param name="package">Tridion Package.</param>
        public override void Transform(Engine engine, Package package)
        {
            base.Transform(engine, package);

            Publication parent = ParentWebPublication(Publication);

            if (parent != null)
            {
                Filter filter = new Filter();
                filter.Conditions.Add("ItemType", ItemType.Publication);
                filter.Conditions.Add("InPublication", false);
                filter.Conditions.Add("InclParentItem", false);

                // Get a full list of all publications in the current publication inheritance tree
                IList<IdentifiableObject> publications = parent.GetUsingItems(filter);

                publications.Insert(0, parent);

                RenderSites(parent, publications);
            }
        }

        private Publication ParentWebPublication(Publication Publication)
        {
            foreach (Repository repository in Publication.Parents)
            {
                if (repository is Publication)
                {
                    Publication parentPublication = repository as Publication;

                    // Only accept publications of PublicationType "Web" which have metadata set
                    if (parentPublication.PublicationType == "Web" && parentPublication.Metadata != null)
                    {   
                        return ParentWebPublication(parentPublication);
                    }
                }
            }

            // No parent publication of PublicationType "Web" with metadata exists
            if (Publication.PublicationType == "Web" && Publication.Metadata != null)
                return Publication;

            // The current publication or its parent is not a valid web publication with metadata
            return null;
        }

        private void RenderSites(Publication Parent, IList<IdentifiableObject> Publications)
        {
            using (StringWriter sw = new StringWriter())
            {
                using (XmlTextWriter xw = new XmlTextWriter(sw))
                {
                    xw.WriteStartElement("sitedata");

                    xw.WriteStartElement("site");

                    ItemFields parentFields = new ItemFields(Parent.Metadata, Parent.MetadataSchema);

                    xw.WriteAttributeString("defaultLanguage", parentFields.StringValue("Language"));
                    xw.WriteAttributeString("id", Parent.Id);
                    xw.WriteAttributeString("url", Parent.PublicationUrl);
                    xw.WriteAttributeString("title", parentFields.StringValue("LocalTitle"));

                    foreach (IdentifiableObject item in Publications)
                    {
                        if (item is Publication)
                        {
                            Publication publication = item as Publication;
                            ItemFields fields = new ItemFields(publication.Metadata, publication.MetadataSchema);

                            xw.WriteStartElement("language");
                            xw.WriteAttributeString("code", fields.StringValue("Language"));
                            xw.WriteAttributeString("pubId", publication.Id);
                            xw.WriteAttributeString("Culture", fields.StringValue("Culture"));
                            xw.WriteAttributeString("localTitle", fields.StringValue("LocalTitle"));
                            xw.WriteAttributeString("url", publication.PublicationUrl);

                            String scope = fields.StringValue("SearchScope");
                            if (!String.IsNullOrEmpty(scope))
                                xw.WriteAttributeString("Scope", scope);
                                                            
                            String path = fields.StringValue("CSSPath");

                            if (!String.IsNullOrEmpty(path))
                                xw.WriteAttributeString("cssBasePath", path);

                            path = fields.StringValue("ScriptPath");

                            if (!String.IsNullOrEmpty(path))
                                xw.WriteAttributeString("jsBasePath", path);

                            // Automatically add all metadata fields pre-fixed with 'site'
                            foreach (ItemField field in fields)
                            {
                                if (field.Name.StartsWith("site"))
                                {
                                    String fieldName = field.Name.Substring(4);

                                    if (field is SingleLineTextField)
                                    {
                                        string value = field.StringValue();

                                        if (!String.IsNullOrEmpty(value))
                                        {
                                            xw.WriteAttributeString(fieldName, value);
                                        }
                                    }
                                    else if (field is DateField)
                                    {
                                        string value = field.DateValue().ToString("yyyyMMddHHmmss");

                                        if (!String.IsNullOrEmpty(value))
                                        {
                                            xw.WriteAttributeString(fieldName, value);
                                        }
                                    }
                                    else if (field is NumberField)
                                    {
                                        string value = field.NumberValue().ToString();

                                        if (!String.IsNullOrEmpty(value))
                                        {
                                            xw.WriteAttributeString(fieldName, value);
                                        }
                                    }
                                    else if (field is ComponentLinkField)
                                    {
                                        IList<Component> components = field.ComponentValues();

                                        if (components != null && components.Count > 0)
                                        {
                                            xw.WriteAttributeString(fieldName, components[0].Id.ToString());
                                        }
                                    }
                                    else if (field is KeywordField)
                                    {
                                        Keyword keyword = field.KeywordValue();

                                        if (keyword != null)
                                        {
                                            xw.WriteAttributeString(fieldName, keyword.Title);
                                        }
                                    }
                                }
                            }
                            
                            xw.WriteValue(fields.StringValue("LocalTitle"));
                            xw.WriteEndElement();
                        }
                    }

                    xw.WriteEndElement();
                    xw.WriteEndElement();
                }

                Package.AddXml(Package.OutputName, sw.ToString());
            }
        }
    }
}
