﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.IO;
using Tridion.ContentManager;
using Tridion.ContentManager.CommunicationManagement;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Expression;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.Templating.Dreamweaver;
using Tridion;
using Tridion.ContentManager.ContentManagement.Fields;
using Publishing = Tridion.ContentManager.Publishing.Rendering;
using Tridion.ContentManager.ContentManagement;
using Tridion.ContentManager.Publishing.Rendering;
using System.Text.RegularExpressions;
using Emaar.Web.Tridion.System.Extensions;
using Tridion.Extensions.ContentManager.Templating;

namespace Emaar.Web.Tridion.System
{
    [TcmTemplateTitle("Resources")]
    public class ResourcesTemplate : TemplateBase
    {
        /// <summary>
        /// Transforms the current component.
        /// </summary>
        /// <param name="engine">The engine.</param>
        /// <param name="package">The package.</param>
        public override void Transform(Engine engine, Package package)
        {
            base.Transform(engine, package);

            XmlDocument xDoc = new XmlDocument();
            XmlElement root = xDoc.CreateElement("root");
            ItemFields fields = null;

            Logger.Info("Start");

            if (IsComponent)
            {
                IList<Component> components = Component.OrganizationalItem.Components();

                Logger.Info("Components count:-{0}", components.Count);

                foreach (Component c in components)
                {
                    fields = new ItemFields(c.Content, c.Schema);

                    foreach (ItemField itemField in fields)
                    {
                        if (itemField is EmbeddedSchemaField)
                        {
                            EmbeddedSchemaField field = itemField as EmbeddedSchemaField;

                            foreach (ItemFields embField in field.Values)
                            {
                                XmlElement xChildNode = xDoc.CreateElement("data");
                                xChildNode.SetAttribute("name", embField.StringValue("Key"));
                                xChildNode.SetAttribute("tcm", c.Id);

                                ItemField valueField = embField["Value"];

                                XmlElement xChildValueNode = xDoc.CreateElement("value");

                                if (valueField is SingleLineTextField)
                                {
                                    xChildNode.SetAttribute("type", "Text");
                                    xChildValueNode.InnerText = valueField.StringValue();
                                }
                                else if (valueField is XhtmlField)
                                {
                                    xChildNode.SetAttribute("type", "FormatText");
                                    xChildValueNode.InnerXml = ExpandXHTML(valueField.XHTMLValue());
                                }
                                else if (valueField is MultimediaLinkField)
                                {
                                    xChildNode.SetAttribute("type", "Image");
                                    Component imageComponent = valueField.ComponentValue();

                                    if (imageComponent != null)
                                    {
                                        xChildValueNode.InnerText = PublishBinary(imageComponent);
                                    }
                                }
                                else if (valueField is ComponentLinkField)
                                {
                                    xChildNode.SetAttribute("type", "ComponentLink");

                                    Component component = valueField.ComponentValue();

                                    if (component != null)
                                        xChildValueNode.InnerText = component.Id;
                                }

                                xChildNode.AppendChild(xChildValueNode);
                                root.AppendChild(xChildNode);
                            }
                        }
                    }
                }
            }

            xDoc.AppendChild(root);

            package.AddXml(Package.OutputName, RemoveNamespace(xDoc));
        }

        private string ExpandXHTML(string xml)
        {
            try
            {
                XmlDocument xDoc = new XmlDocument();

                xDoc.LoadXml("<root>" + xml + "</root>");

                foreach (XmlElement xNode in xDoc.SelectNodes("//node()[local-name() = 'img' and @*[local-name() = 'href']]"))
                {
                    String href = xNode.GetAttribute("href", Constants.XlinkNamespace);

                    if (href != null && href.StartsWith("tcm:"))
                    {
                        xNode.Attributes.RemoveNamedItem("title", Constants.XlinkNamespace);
                        xNode.Attributes.RemoveNamedItem("href", Constants.XlinkNamespace);

                        Component Component = GetComponent(href);

                        if (Component != null)
                        {
                            String src = PublishBinary(Component);
                            xNode.SetAttribute("src", src);
                        }
                    }
                }

                foreach (XmlElement xNode in xDoc.SelectNodes("//node()[local-name() = 'a' and @*[local-name() = 'href']]"))
                {
                    String href = xNode.GetAttribute("href", Constants.XlinkNamespace);

                    if (href != null && href.StartsWith("tcm:"))
                    {
                        xNode.Attributes.RemoveNamedItem("title", Constants.XlinkNamespace);

                        Component Component = GetComponent(href);

                        if (Component != null)
                        {
                            if (Component.BinaryContent != null)
                            {
                                String src = PublishBinary(Component);
                                xNode.Attributes.RemoveNamedItem("href", Constants.XlinkNamespace);
                                xNode.SetAttribute("href", src);
                            }

                            if (Component.Content != null)
                            {
                                XmlNode xTitle = Component.Content.SelectSingleNode("//node()[local-name() = 'Title']");

                                if (xTitle != null && !String.IsNullOrEmpty(xTitle.InnerText))
                                {
                                    xNode.SetAttribute("title", Constants.XlinkNamespace, xTitle.InnerText);
                                }
                            }
                        }
                    }
                }

                return xDoc.DocumentElement.InnerXml;
            }
            catch (Exception ex)
            {
                Logger.Error("Resources: Error expanding XHTML", ex);
            }

            return String.Empty;
        }

        private string RemoveNamespace(XmlDocument doc)
        {
            using (StringWriter sw = new StringWriter())
            {
                using (XmlNoNamespaceWriter xw = new XmlNoNamespaceWriter(sw))
                {
                    xw.Formatting = Formatting.None;
                    doc.Save(xw);
                }

                return sw.ToString();
            }
        }
    }
}
