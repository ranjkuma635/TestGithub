using System;
using System.Collections.Generic;
using System.IO;
using System.Text.RegularExpressions;
using System.Xml;
using Tridion.ContentManager;
using Tridion.ContentManager.CommunicationManagement;
using Tridion.ContentManager.ContentManagement;
using Tridion.ContentManager.ContentManagement.Fields;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.Publishing;
using Tridion.ContentManager.Templating.Expression;
using Tridion.ContentManager.Publishing.Rendering;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using Emaar.Web.Tridion.System.Extensions;

namespace Tridion.Extensions.ContentManager.Templating
{
    /// <summary>
    /// This class contains useful helper functions for typical things you might want to do in a
    /// template. It can be used as the base class for your own Template Building Blocks.
    ///  Use this abstract class to derive your new Template from.
    /// </summary>
    /// <author>
    ///    SDL Tridion Professional Services
    /// </author>
    /// <date>
    ///     created 31-January-2008
    ///		updated: 10-October-2008 
    /// </date>	
    public abstract class TemplateBase : ITemplate, IDisposable
    {
        #region Private Members

        protected Engine mEngine;
        protected Package mPackage;

        // Indicates whether system resources used by this instance have been released
        private bool mDisposed = false;
        private TemplatingLogger mLogger;
        private XmlNamespaceManager mNSM;

        // Cache local Tridion objects if requested
        private Publication mPublication = null;
        private StructureGroup mRootStructureGroup = null;
        private Page mPage = null;
        private PageTemplate mPageTemplate = null;
        private Component mComponent = null;
        private ComponentTemplate mComponentTemplate = null;

        #region Constants
        // Output Format constants
        protected const string OF_ASPJSCRIPT = "ASP JScript";
        protected const string OF_ASPVBSCRIPT = "ASP VBScript";
        protected const string OF_ASCX = "ASCX WebControl";
        protected const string OF_JSP = "JSP Scripting";

        // Target Language constants
        protected const string TL_ASPJSCRIPT = "ASP/JavaScript";
        protected const string TL_ASPVBSCRIPT = "ASP/VBScript";
        protected const string TL_ASPDOTNET = "ASP.NET";
        protected const string TL_JSP = "JSP";

        #endregion

        #endregion

        #region Properties

        /// <summary>
        /// An XmlNameSpaceManager already initialized with several XML namespaces such like: tcm, xlink and xhtml
        /// </summary>
        protected XmlNamespaceManager NSManager
        {
            get
            {
                if (mNSM == null)
                {
                    mNSM = new XmlNamespaceManager(new NameTable());

                    mNSM.AddNamespace("tcm", "http://www.tridion.com/ContentManager/5.0");
                    mNSM.AddNamespace("xlink", "http://www.w3.org/1999/xlink");
                    mNSM.AddNamespace("xhtml", "http://www.w3.org/1999/xhtml");
                }

                return mNSM;
            }
        }

        protected TemplatingLogger Logger
        {
            get
            {
                if (mLogger == null)
                    mLogger = TemplatingLogger.GetLogger(this.GetType());

                return mLogger;
            }
        }

        /// <summary>
        /// Returns true if the current render mode is Publish
        /// </summary>
        protected bool IsPublishing
        {
            get
            {
                CheckInitialized();
                return (mEngine.RenderMode == RenderMode.Publish);
            }
        }

        /// <summary>
        /// Checks whether there is an item in the package of type tridion/page
        /// </summary>
        /// <returns>True if there is a page item in the package</returns>
        protected bool IsPage
        {
            get
            {
                return (Page != null);
            }
        }

        /// <summary>
        /// Checks whether there is an item in the package of type tridion/component
        /// </summary>
        /// <returns>True if there is a component item in the package</returns>
        protected bool IsComponent
        {
            get
            {
                return (Component != null);
            }
        }
        #endregion

        #region Internal Methods
        /// <summary>
        /// Execute the transformation for the specified template
        /// </summary>
        /// <param name="engine"><see cref="T:Tridion.ContentManager.Templating.Engine"/>.</param>
        /// <param name="package"><see cref="T:Tridion.ContentManager.Templating.Package"/></param>
        public virtual void Transform(Engine engine, Package package)
        {
            mEngine = engine;
            mPackage = package;
        }

        /// <summary>
        /// Checks whether the TemplateBase object has been initialized correctly.
        /// This method should be called from any method that requires the <c>m_Engine</c>, 
        /// <c>m_Package</c> or <c>_log</c> member fields.
        /// </summary>
        protected void CheckInitialized()
        {
            if (mEngine == null || mPackage == null)
            {
                throw new InvalidOperationException("This method can not be invoked, unless Initialize has been called");
            }
        }
        #endregion

        #region Base Functionality

        protected Engine Engine
        {
            get
            {
                return mEngine;
            }
        }

        protected Package Package
        {
            get
            {
                return mPackage;
            }
        }


        /// <summary>
        /// Returns the component object that is defined in the package for this template.
        /// </summary>
        /// <remarks>
        /// This method should only be called when there is an actual Component item in the package. 
        /// It does not currently handle the situation where no such item is available.
        /// </remarks>
        /// <returns>the component object that is defined in the package for this template.</returns>
        protected Component Component
        {
            get
            {
                if (mComponent == null)
                {
                    Item component = mPackage.GetByType(ContentType.Component);

                    if (component != null)
                        mComponent = GetComponent(component.GetAsSource().GetValue("ID"));
                }

                return mComponent;
            }
        }

        /// <summary>
        /// Returns the Template from the resolved item if it's a Component Template
        /// </summary>
        /// <returns>A Component Template or null</returns>
        protected ComponentTemplate ComponentTemplate
        {
            get
            {
                if (mComponentTemplate == null)
                {
                    CheckInitialized();

                    Template template = mEngine.PublishingContext.ResolvedItem.Template;

                    if (template is ComponentTemplate)
                    {
                        mComponentTemplate = (ComponentTemplate)template;
                    }
                }

                return mComponentTemplate;
            }
        }

        /// <summary>
        /// Returns the Template from the resolved item if it's a Page Template
        /// </summary>
        /// <returns>A Page Template or null</returns>
        protected PageTemplate PageTemplate
        {
            get
            {
                if (mPageTemplate == null)
                {
                    CheckInitialized();
                    Template template = mEngine.PublishingContext.ResolvedItem.Template;

                    if (template is PageTemplate)
                    {
                        mPageTemplate = (PageTemplate)template;
                    }
                }

                return mPageTemplate;
            }
        }

        /// <summary>
        /// Returns the page object that is defined in the package for this template.
        /// </summary>
        /// <remarks>
        /// This method should only be called when there is an actual Page item in the package. 
        /// It does not currently handle the situation where no such item is available.
        /// </remarks>
        /// <returns>the page object that is defined in the package for this template.</returns>
        protected Page Page
        {
            get
            {
                if (mPage == null)
                {
                    CheckInitialized();
                    Item pageItem = mPackage.GetByType(ContentType.Page);

                    if (pageItem != null)
                        mPage = mEngine.GetObject(pageItem.GetAsSource().GetValue("ID")) as Page;

                    if (Engine.PublishingContext.RenderContext.ContextItem is Page)
                        mPage = Engine.PublishingContext.RenderContext.ContextItem as Page;
                }

                return mPage;
            }
        }

        /// <summary>
        /// Returns the page object that is defined in the package for this template.
        /// </summary>
        /// <remarks>
        /// This method should only be called when there is an actual Page item in the package. 
        /// It does not currently handle the situation where no such item is available.
        /// </remarks>
        /// <returns>the page object that is defined in the package for this template.</returns>
        protected StructureGroup RootStructureGroup
        {
            get
            {
                if (mRootStructureGroup == null)
                {
                    Publication publication = Publication;

                    if (publication != null)
                    {
                        mRootStructureGroup = publication.RootStructureGroup;
                    }
                }

                return mRootStructureGroup;
            }

        }

        /// <summary>
        /// Returns the publication object that can be determined from the package for this template.
        /// </summary>
        /// <remarks>
        /// This method currently depends on a Page item being available in the package, meaning that
        /// it will only work when invoked from a Page Template.
        /// 
        /// Updated by Kah Tan (kah.tang@indivirtual.com)
        /// </remarks>
        /// <returns>the Publication object that can be determined from the package for this template.</returns>
        protected Publication Publication
        {
            get
            {
                if (mPublication == null)
                {
                    CheckInitialized();

                    RepositoryLocalObject pubItem = null;
                    Repository repository = null;

                    pubItem = Page;

                    if (pubItem == null)
                        pubItem = Component;

                    if (pubItem != null)
                    {
                        repository = pubItem.ContextRepository;
                        mPublication = repository as Publication;
                    }
                }

                return mPublication;
            }
        }

        /// <summary>
        /// Gets the <see cref="T:Tridion.ContentManager.ContentManagement.IdentifiableObject"/> object specified by the ID
        /// </summary>
        /// <param name="ID">IdentifiableObject ID</param>
        /// <returns><see cref="T:Tridion.ContentManager.ContentManagement.IdentifiableObject"/></returns>
        protected T GetObject<T>(string ID) where T : IdentifiableObject
        {
            CheckInitialized();
            return mEngine.GetObject(ID) as T;
        }

        /// <summary>
        /// Gets the <see cref="T:Tridion.ContentManager.ContentManagement.IdentifiableObject"/> object specified by the ID
        /// </summary>
        /// <param name="ID">IdentifiableObject ID</param>
        /// <returns><see cref="T:Tridion.ContentManager.ContentManagement.IdentifiableObject"/></returns>
        protected T GetObject<T>(TcmUri ID) where T : IdentifiableObject
        {
            CheckInitialized();
            return mEngine.GetObject(ID) as T;
        }

        /// <summary>
        /// Gets the <see cref="T:Tridion.ContentManager.ContentManagement.Component"/> component specified by the ID
        /// </summary>
        /// <param name="ID">Component ID</param>
        /// <returns><see cref="T:Tridion.ContentManager.ContentManagement.Component"/></returns>
        protected Component GetComponent(TcmUri ID)
        {
            return GetObject<Component>(ID);
        }

        /// <summary>
        /// Gets the <see cref="T:Tridion.ContentManager.ContentManagement.Component"/> component specified by the ID
        /// </summary>
        /// <param name="ID">Component ID</param>
        /// <returns><see cref="T:Tridion.ContentManager.ContentManagement.Component"/></returns>
        protected Component GetComponent(string ID)
        {
            return GetObject<Component>(ID);
        }

        protected StructureGroup GetStructureGroup(string ID)
        {
            return GetObject<StructureGroup>(ID);
        }

        protected StructureGroup GetStructureGroup(TcmUri ID)
        {
            return GetObject<StructureGroup>(ID);
        }

        protected Page GetPage(string ID)
        {
            return GetObject<Page>(ID);
        }

        protected Page GetPage(TcmUri ID)
        {
            return GetObject<Page>(ID);
        }

        /// <summary>
        /// Checks whether a Target Type URI is associated with the current publication target being published to
        /// </summary>
        protected bool IsTTInPublicationContext(string ttURI)
        {
            CheckInitialized();

            if (IsPublishing && mEngine.PublishingContext.PublicationTarget != null) // not null only during publishing
            {
                foreach (TargetType tt in mEngine.PublishingContext.PublicationTarget.TargetTypes)
                {
                    if (tt.Id == ttURI)
                        return true;
                }
            }

            return false;
        }

        /// <summary>
        /// Checks whether at least one of a list of Target Type URIs is associated with the current publication target being published to
        /// </summary>
        protected bool IsTTInPublicationContext(IEnumerable<string> ttURIs)
        {
            CheckInitialized();

            if (mEngine.PublishingContext.PublicationTarget != null)// not null only during publishing
            {
                foreach (string uri in ttURIs)
                {
                    foreach (TargetType tt in mEngine.PublishingContext.PublicationTarget.TargetTypes)
                    {
                        if (tt.Id == uri) return true;
                    }
                }
            }

            return false;
        }
        #endregion

        #region Utilities
        /// <summary>
        /// Publishes the multi-media component binary
        /// </summary>
        /// <param name="Component"><see cref="T:Tridion.ContentManager.ContentManagement.Component"/></param>
        /// <returns>Published binary path</returns>
        protected string PublishBinary(Component Component)
        {
            return PublishBinary(Component, String.Empty);
        }

        /// <summary>
        /// Publishes the multi-media component binary
        /// </summary>
        /// <param name="Component"><see cref="T:Tridion.ContentManager.ContentManagement.Component"/></param>
        /// <param name="variantId">Binary Variant Id.</param>
        /// <returns>Published binary path</returns>
        protected string PublishBinary(Component Component, string variantId)
        {
            String publishPath = String.Empty;

            if (Component != null && Component.ComponentType == ComponentType.Multimedia && Component.BinaryContent != null)
            {
                Binary pubBinary = null;

                if (!String.IsNullOrEmpty(variantId))
                {
                    pubBinary = mEngine.PublishingContext.RenderedItem.AddBinary(Component, variantId);
                }
                else
                {
                    pubBinary = mEngine.PublishingContext.RenderedItem.AddBinary(Component);
                }

                if (pubBinary != null)
                    publishPath = pubBinary.Url;
            }
            else
            {
                Logger.Warning("PublishBinary: {0} is not a multimedia component.", Component.Id);
            }

            return publishPath;

        }

        protected String GenerateThumbnail(Component Component, String Prefix, int Width, int Height, String ColorCode)
        {

            ColorCode = (ColorCode == String.Empty) ? "#fff" : ColorCode;

            if (Component != null && Component.BinaryContent != null)
            {
                try
                {
                    // Output the existing image to a memory stream
                    using (MemoryStream stream = new MemoryStream())
                    {
                        Component.BinaryContent.WriteToStream(stream);

                        using (Image image = Image.FromStream(stream))
                        {
                            int sourceWidth = image.Width;
                            int sourceHeight = image.Height;
                            int sourceX = 0;
                            int sourceY = 0;
                            int destX = 0;
                            int destY = 0;

                            float nPercent = 0;
                            float nPercentW = 0;
                            float nPercentH = 0;

                            nPercentW = ((float)Width / (float)sourceWidth);
                            nPercentH = ((float)Height / (float)sourceHeight);
                            if (nPercentH < nPercentW)
                            {
                                nPercent = nPercentH;
                                destX = (int)((Width - (sourceWidth * nPercent)) / 2);
                            }
                            else
                            {
                                nPercent = nPercentW;
                                destY = (int)((Height - (sourceHeight * nPercent)) / 2);
                            }

                            int destWidth = (int)(sourceWidth * nPercent);
                            int destHeight = (int)(sourceHeight * nPercent);

                            using (Bitmap bmPhoto = new Bitmap(Width, Height, image.PixelFormat))
                            {
                                //bmPhoto.SetResolution(image.HorizontalResolution, image.VerticalResolution);
                                using (Graphics grPhoto = Graphics.FromImage(bmPhoto))
                                {

                                    grPhoto.Clear(ColorTranslator.FromHtml(ColorCode));
                                    grPhoto.SmoothingMode = SmoothingMode.HighQuality;
                                    grPhoto.CompositingQuality = CompositingQuality.HighQuality;
                                    grPhoto.InterpolationMode = InterpolationMode.High;
                                    grPhoto.PixelOffsetMode = PixelOffsetMode.HighQuality;

                                    grPhoto.DrawImage(image,
                                        new Rectangle(destX, destY, destWidth, destHeight),
                                        new Rectangle(sourceX, sourceY, sourceWidth, sourceHeight),
                                        GraphicsUnit.Pixel);
                                    grPhoto.Dispose();

                                }
                                using (MemoryStream streamOut = new MemoryStream())
                                {
                                    bmPhoto.Save(streamOut, ImageFormat.Jpeg);

                                    Binary binary = Engine.PublishingContext.RenderedItem.AddBinary(streamOut, String.Format("{0}_{1}_tcm{2}_{3}.jpg", Path.GetFileNameWithoutExtension(Component.BinaryContent.Filename), Prefix, Component.Id.PublicationId, Component.Id.ItemId), Prefix, Component, "image/jpeg");
                                    image.Dispose();
                                    bmPhoto.Dispose();
                                    streamOut.Dispose();
                                    return binary.Url;
                                }
                            }

                        }
                    }
                }
                catch (Exception ex)
                {
                    Logger.Debug(ex.Message);

                }
            }
            return String.Empty;
        }

        protected String GenerateThumbnail(Component Binary, String FileNamePrefix, int ThumbnailWidth, int ThumbnailHeight)
        {
            if (Binary != null && Binary.BinaryContent != null)
            {
                try
                {
                    // Output the existing image to a memory stream
                    using (MemoryStream stream = new MemoryStream())
                    {
                        Binary.BinaryContent.WriteToStream(stream);

                        using (Image image = Image.FromStream(stream))
                        {
                            int width = ThumbnailWidth;
                            int height = ThumbnailHeight;

                            if (image.Height > image.Width)
                            {
                                width = (int)Math.Round(((double)image.Width / (double)image.Height) * height);
                            }
                            else
                            {
                                height = (int)Math.Round(((double)image.Height / (double)image.Width) * width);
                            }

                            using (Bitmap bitmap = new Bitmap((int)width, (int)height, image.PixelFormat))
                            {
                                Logger.Debug("Pixel format: " + image.PixelFormat.ToString());
                                using (Graphics graphic = Graphics.FromImage(bitmap))
                                {
                                    graphic.SmoothingMode = SmoothingMode.HighQuality;
                                    graphic.InterpolationMode = InterpolationMode.HighQualityBicubic;
                                    graphic.PixelOffsetMode = PixelOffsetMode.HighQuality;

                                    graphic.DrawImage(image, 0, 0, bitmap.Width, bitmap.Height);
                                    graphic.Dispose();
                                }

                                using (MemoryStream streamOut = new MemoryStream())
                                {
                                    bitmap.Save(streamOut, ImageFormat.Jpeg);

                                    Binary binary = Engine.PublishingContext.RenderedItem.AddBinary(streamOut, String.Format("{0}_tcm{1}_{2}.jpg", FileNamePrefix, Binary.Id.PublicationId, Binary.Id.ItemId), "thumbnail", Binary, "image/jpeg");
                                    image.Dispose();
                                    bitmap.Dispose();
                                    streamOut.Dispose();

                                    return binary.Url;
                                }

                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    Logger.Error("GenerateThumbnail", ex);
                }
            }

            return String.Empty;
        }
        #endregion

        #region IDisposable Members
        /// <summary>
        /// Indicates whether system resources used by this instance have been released
        /// </summary>
        protected bool Disposed
        {
            get
            {
                lock (this)
                {
                    return (mDisposed);
                }
            }
        }

        /// <summary>
        /// Releases allocated resources
        /// </summary>
        void IDisposable.Dispose()
        {
            lock (this)
            {
                if (mDisposed == false)
                {
                    mPackage = null;
                    mEngine = null;
                    mLogger = null;
                    mNSM = null;

                    mComponent = null;
                    mComponentTemplate = null;
                    mPage = null;
                    mPageTemplate = null;
                    mPublication = null;

                    mDisposed = true;
                    // take yourself off the finalization queue
                    // to prevent finalization from executing a second time
                    GC.SuppressFinalize(this);
                }
            }
        }
        #endregion
    }
}
