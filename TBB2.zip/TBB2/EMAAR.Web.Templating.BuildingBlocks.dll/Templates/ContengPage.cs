﻿using System;
using System.Linq;
using Tridion.ContentManager.CommunicationManagement;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.ContentManagement.Fields;
using Tridion.Extensions.ContentManager.Templating;
using Tridion.ContentManager.ContentManagement;
using Tridion.ContentManager.Templating.Expression;
using Emaar.Web.Tridion.System.Extensions;
using System.Xml;
using Tridion.ContentManager;
using System.Collections.Generic;


namespace EMR.Web.Templating.BuildingBlocks.Templates
{
    [TcmTemplateTitle("Content Page")]
    public class ContentPage : TemplateBase
    {

        public override void Transform(Engine engine, Package package)
        {
            base.Transform(engine, package);
            String seoImage = String.Empty; ;
            String seoDescription = String.Empty;
            String seoKeywords = String.Empty;
            String spageTitle = String.Empty;
            String strfulldesc = String.Empty;
            String strScript = String.Empty;
            String strPropertyName = String.Empty;
            String strCommunityName = String.Empty;


            if (Page.ComponentPresentations.Count > 0)
            {
                Component component = Page.ComponentPresentations[0].Component;


                //Emaar - Community
                //if (Publication.PublicationUrl == "/ar")
                //{
 
                //    if(component.StringValue("title") != null)
                //        spageTitle = component.StringValue("title");

                //    if (component.StringValue("description") != null)
                //    {
                //        strfulldesc = "<content>" + component.StringValue("description") + "</content>";
                //        XmlDocument doc = new XmlDocument();
                //        doc.LoadXml(strfulldesc);
                //        seoDescription = doc.InnerText;
                //        if(doc.InnerText.Length > 149)
                //        seoDescription = doc.InnerText.Substring(1, 149);
                //    }

                //    if (component.Schema.Title == "Emaar - Corporate Content")
                //    {
                //        strfulldesc = "<content>" + component.StringValue("summary") + "</content>";
                //        XmlDocument doc = new XmlDocument();
                //        doc.LoadXml(strfulldesc);

                //        seoDescription = doc.InnerText;
                //        if (doc.InnerText.Length > 149)
                //            seoDescription = doc.InnerText.Substring(1, 149);
                    
                //    }
                //    if (component.Schema.Title == "Emaar - Intro Content" || component.Schema.Title == "Emaar - Board")
                //    {
                //        if (component.StringValue("heading") != null)
                //            spageTitle = component.StringValue("heading");

                //        if (component.StringValue("content") != null)
                //        {
                //            strfulldesc = "<content>" + component.StringValue("content") + "</content>";
                //            XmlDocument doc = new XmlDocument();
                //            doc.LoadXml(strfulldesc);
                //            seoDescription = doc.InnerText;
                //            if (doc.InnerText.Length > 149)
                //                seoDescription = doc.InnerText.Substring(1, 149);
                //        }

                //    }
                //    if (component.Schema.Title == "Emaar - Content")
                //    {
                //        if (component.StringValue("h1") != null)
                //            spageTitle = component.StringValue("h1");

                //        if (component.StringValue("content") != null)
                //        {
                //            strfulldesc = "<content>" + component.StringValue("content") + "</content>";
                //            XmlDocument doc = new XmlDocument();
                //            doc.LoadXml(strfulldesc);
                //            seoDescription = doc.InnerText;
                //            if (doc.InnerText.Length > 149)
                //                seoDescription = doc.InnerText.Substring(1, 149);
                //        }
                    
                //    }
                //    if (component.Schema.Title == "Emaar - List" || component.Schema.Title == "Emaar - Intro Panel")
                //    {
                //        if (component.StringValue("h1") != null)
                //            spageTitle = component.StringValue("h1");

                //    }
                //    if (component.Schema.Title == "Emaar - Fact Sheets")
                //    {
                //        if (component.StringValue("heading") != null)
                //            spageTitle = component.StringValue("heading");

                //    }


                //}

                if (component.Schema.Title == "Emaar - Community" || component.Schema.Title == "Emaar - Property")
                    package.AddString("strScript", "Yes");

                if (component.Schema.Title == "Emaar - Property")
                {
                    OrganizationalItem parentFolder = component.OrganizationalItem.OrganizationalItem;
                    IList<Component> compList = parentFolder.Components(true);
                    String Communityname = String.Empty;
                    foreach (Component comp in compList)
                    {
                        if (comp.Schema.Title.Equals("Emaar - Community"))
                        {
                            Communityname = comp.Title;
                            if (comp.Title.StartsWith("000."))
                                Communityname = comp.Title.Split('.')[1].Trim();
                            strCommunityName = Communityname;
                            break;
                        }
                    }
                    string tcmid = component.Id.ToString().Split(':')[1];
                    string pubId = tcmid.Split('-')[0];
                    string comid = "";
                    comid = component.Id.ToString();
                    Component proComp = engine.GetObject(comid) as Component;
                    strPropertyName = proComp.Title;

                }   


                if (component.EmbeddedMetaValue("seometadata") != null)
                {
                    ItemFields seoMetadata = component.EmbeddedMetaValue("seometadata");

                    
                    
                        
                        if (seoMetadata.StringValue("fPageTitle") != null)
                        {
                            spageTitle = seoMetadata.StringValue("fPageTitle");
                        }
                        else if (component.StringValue("title") != null)
                        {
                            spageTitle = component.StringValue("title");
                        }

                        if (seoMetadata.StringValue("pageTitle") != null)
                        {
                            spageTitle = seoMetadata.StringValue("pageTitle");
                        }


                        if (seoMetadata.StringValue("fSEOKeywords") != null)
                        {
                            seoKeywords = seoMetadata.StringValue("fSEOKeywords");
                        }
                        if (seoMetadata.StringValue("SEOKeywords") != null)
                        {
                            seoKeywords = seoMetadata.StringValue("SEOKeywords");
                        }


                        if (seoMetadata.ComponentValue("fSEOImage") != null)
                        {
                            seoImage = GenerateThumbnail(seoMetadata.ComponentValue("fSEOImage"), "seo", 600, 600);
                        }

                        if (seoMetadata.StringValue("fSEODescription") != null)
                        {
                            seoDescription = seoMetadata.StringValue("fSEODescription");
                        }
                        if (seoMetadata.StringValue("SEODescription") != null)
                        {
                            seoDescription = seoMetadata.StringValue("SEODescription");
                        }




                }

                if (String.IsNullOrEmpty(seoImage))
                {
                    seoImage = calloutImage(Page);
                }
                if (String.IsNullOrEmpty(seoImage))
                {
                    seoImage = compImage(Page);
                }
                if (String.IsNullOrEmpty(seoImage)) {
                    seoImage = bannerImage(Page);
                }
                if (String.IsNullOrEmpty(seoImage))
                {
                    seoImage = calloutParentImage(Page);
                }
                if (String.IsNullOrEmpty(seoImage))
                {
                    seoImage = bannerParentImage(Page);
                }
                
                package.AddString("PageTitle", spageTitle);
                package.AddString("metaPageTitle", spageTitle);
                package.AddString("SEODescription", seoDescription);
                package.AddString("strCommunity", strCommunityName);
                package.AddString("strProperty", strPropertyName);

                //package.AddString("pub", Publication.PublicationUrl);

                package.AddString("SEOKeywords", seoKeywords);
                package.AddString("SEOImage", seoImage);

                package.AddString("NavPath", Page.PublishLocationUrl.Replace("index.aspx",""));

                if(package.GetByName("PageVariable.subscription")!=null)
                {
                    Keyword k = engine.GetObject(package.GetByName("PageVariable.subscription").GetAsString()) as Keyword;
                    package.AddString("subscription", k.Description);
                    package.AddString("subscriptionKey", k.Key);
                }

                if (Page.Metadata != null)
                {
                    package.AddString("disableremarketingtags", Page.StringMetaValue("disable-re-marketing-tags"));
                }

            }
        }

        private string compImage(Page Page)
        {

            StructureGroup sg = Page.OrganizationalItem as StructureGroup;
            XmlNode xImage = null;
            XmlNode xBanner = null;
            XmlNodeList xBannerList = null;
            string flag = "";
            if (Page.ComponentPresentations.Count > 0)
            {
                Component component = Page.ComponentPresentations[0].Component;
                if (component.Content != null)
                {
                    if (component.Content.SelectSingleNode("//node()[local-name() = 'image']") != null)
                    {
                        xImage = component.Content.SelectSingleNode("//node()[local-name() = 'image']");
                    }
                }
            }
            if (xImage != null)
            {

                String imageID = xImage.GetAttribute("xlink:href");
                if (!String.IsNullOrEmpty(imageID) && imageID.Contains("tcm:"))
                {
                    return GenerateThumbnail(GetComponent(imageID), "seo", 600, 600);

                }
            }
            return string.Empty;
        }

        private string calloutImage(Page Page)
        {

            StructureGroup sg = Page.OrganizationalItem as StructureGroup;
            XmlNode xImage = null;
            XmlNode xBanner = null;
            XmlNodeList xBannerList = null;
            if (xImage == null)
            {
                if (Page.Metadata != null)
                {
                    xBannerList = Page.Metadata.ChildNodes;
                    foreach (XmlNode item in xBannerList)
                    {
                        if (item.Name.Equals("fcalloutImage"))
                        {
                            xBanner = item;
                            break;
                        }

                    }
                }

                if (xBanner != null)
                {
                    if (xBanner.Attributes["xlink:href"] != null)
                    {
                        string heroID = xBanner.Attributes["xlink:href"].Value;


                        if (!String.IsNullOrEmpty(heroID) && heroID.Contains("tcm:"))
                        {
                            return GenerateThumbnail(GetComponent(heroID), "seo", 600, 600);
                        }
                    }
                }
            }
            return "";
        }

        private string calloutParentImage(Page Page)
        {

            StructureGroup sg = Page.OrganizationalItem as StructureGroup;
            XmlNode xImage = null;
            XmlNode xBanner = null;
            XmlNodeList xBannerList = null;

                do
                {
                    if (sg.Metadata != null)
                    {
                        xBannerList = sg.Metadata.ChildNodes;
                        foreach (XmlNode item in xBannerList)
                        {
                            if (item.Name.Equals("fcalloutImage"))
                            {
                                xBanner = item;
                                break;
                            }
                        }
                    }
                    if (sg.Title.Equals("Root"))
                    {
                        break;
                    }
                    else
                    {
                        sg = sg.OrganizationalItem as StructureGroup;
                    }
                }
                while (xBanner == null);

                if (xBanner != null)
                {
                    if (xBanner.Attributes["xlink:href"] != null)
                    {
                        string heroID = xBanner.Attributes["xlink:href"].Value;


                        if (!String.IsNullOrEmpty(heroID) && heroID.Contains("tcm:"))
                        {
                            return GenerateThumbnail(GetComponent(heroID), "seo", 600, 600);
                        }
                    }
                }
            return "";
        }

        private string bannerImage(Page Page)
        {

            StructureGroup sg = Page.OrganizationalItem as StructureGroup;
            XmlNode xImage = null;
            XmlNode xBanner = null;
            XmlNodeList xBannerList = null;

            if (Page.Metadata != null)
            {
                xBannerList = Page.Metadata.ChildNodes;
                foreach (XmlNode item in xBannerList)
                {

                    if (item.Name.Equals("hero"))
                    {
                        xBanner = item;
                        break;
                    }
                }
            }
            if (xBanner != null)
            {
                if (xBanner.Attributes["xlink:href"] != null)
                {
                    string heroID = xBanner.Attributes["xlink:href"].Value;
                    string imageID = string.Empty;


                    if (!String.IsNullOrEmpty(heroID) && heroID.Contains("tcm:"))
                    {
                        Component heroComp = GetComponent(heroID);
                        if (heroComp != null)
                        {
                            imageID = heroComp.EmbeddedValues("carousel").First().XHTMLValue("image");
                            foreach (ItemField field in heroComp.EmbeddedValue("carousel"))
                            {
                                if (field.Name.Equals("image"))
                                {
                                    imageID = field.ComponentValue().Id;
                                    break;
                                }
                            }
                        }
                    }
                    return GenerateThumbnail(GetComponent(imageID), "seo", 600, 600);
                }
            }
            return "";
        }

        private string bannerParentImage(Page Page)
        {

            StructureGroup sg = Page.OrganizationalItem as StructureGroup;
            XmlNode xImage = null;
            XmlNode xBanner = null;
            XmlNodeList xBannerList = null;
            do
            {
                if (sg.Metadata != null)
                {
                    xBannerList = sg.Metadata.ChildNodes;
                    foreach (XmlNode item in xBannerList)
                    {
                        if (item.Name.Equals("hero"))
                        {
                            xBanner = item;
                            break;
                        }
                    }
                }
                if (sg.Title.Equals("Root"))
                {
                    break;
                }
                else
                {
                    sg = sg.OrganizationalItem as StructureGroup;
                }
            }
            while (xBanner == null);

            if (xBanner != null)
            {
                if (xBanner.Attributes["xlink:href"] != null)
                {
                    string heroID = xBanner.Attributes["xlink:href"].Value;
                    string imageID = string.Empty;


                    if (!String.IsNullOrEmpty(heroID) && heroID.Contains("tcm:"))
                    {
                        Component heroComp = GetComponent(heroID);
                        if (heroComp != null)
                        {
                            imageID = heroComp.EmbeddedValues("carousel").First().XHTMLValue("image");
                            foreach (ItemField field in heroComp.EmbeddedValue("carousel"))
                            {
                                if (field.Name.Equals("image"))
                                {
                                    imageID = field.ComponentValue().Id;
                                    break;
                                }
                            }
                        }
                    }
                    return GenerateThumbnail(GetComponent(imageID), "seo", 600, 600);
                }
            }
            return "";
        }

        
    
    
       
    
    }
}
