﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml;
using System.IO;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.ContentManagement.Fields;
using Tridion.Extensions.ContentManager.Templating;
using Tridion.ContentManager.ContentManagement;
using Emaar.Web.Tridion.System.Extensions;
using Tridion.ContentManager.Publishing;

namespace EMAAR.Web.Templating.BuildingBlocks.Templates
{
    public class Imagelist : TemplateBase
    {

        public override void Transform(Engine engine, Package package)
        {
            base.Transform(engine, package);

            string strURL = String.Empty;

            if (engine.PublishingContext.PublicationTarget.Id.ToString() == "tcm:0-9-65537")
            {
                strURL = "http://staging.emaartridion.com";
            }
            else
            {
                strURL = "http://www.emaar.com";
            }

            using (StringWriter sw = new StringWriter())
            {

                using (XmlTextWriter xml = new XmlTextWriter(sw))
                {
                    if (Component != null)
                    {

                        xml.WriteStartElement("images");


                        IList<Component> multimedialist = Component.ComponentValues("images");
                        foreach (Component comp in multimedialist)
                        {
                            xml.WriteElementString("image", strURL + PublishBinary(comp));
                            
                        }

                        xml.WriteEndElement();//item


                    }                
                
                }

                Package.AddXml(Package.OutputName, sw.ToString());

            }

        }


    }
}
