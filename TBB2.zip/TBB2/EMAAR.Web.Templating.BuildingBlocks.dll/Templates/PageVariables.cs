﻿using System;
using System.Collections.Generic;
using Tridion.ContentManager.Templating.Assembly;
using Emaar.Web.Tridion.System;

namespace EMR.Web.Templating.BuildingBlocks.Templates
{
   
    [TcmTemplateTitle("Page Variables")]
    public class PageVariables : PageVariablesTemplate
    {

       private List<String> mIncludeFields;
       private List<String> mInheritedFields;

       public PageVariables(): base()
       {
            mIncludeFields = new List<String>();
            mIncludeFields.Add("hero");
            mIncludeFields.Add("writecallout");
            mIncludeFields.Add("showSideNavigation"); 
            mIncludeFields.Add("subscription");
            mIncludeFields.Add("showSubNavigation");
            mIncludeFields.Add("fhideFromSearch");

            //mInheritedFields.Add("disable-re-marketing-tags");


            mInheritedFields = new List<String>();
            mInheritedFields.Add("hero");
            mInheritedFields.Add("writecallout");
            mInheritedFields.Add("showSideNavigation");
            mInheritedFields.Add("subscription");
           
           
       }

       protected override bool IncludeMetadata(string FieldName)
       {
           return mIncludeFields.Contains(FieldName);
       }

       protected override bool InheritedMetadata(string FieldName)
       {
           return mInheritedFields.Contains(FieldName);
       }
        
        /// <summary>
        /// Returns wether the specified Schema should be used to generate a page title
        /// </summary>
        /// <returns></returns>
       protected override bool TitleTemplate(string Schema)
       {
            return true;
       }

    }
}
