﻿using System;
using System.Linq;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.Extensions.ContentManager.Templating;
using Tridion.ContentManager.ContentManagement;
using Emaar.Web.Tridion.System.Extensions;
using System.Xml;

namespace EMR.Web.Templating.BuildingBlocks.Templates {
    [TcmTemplateTitle("PageCode")]
    public class PageCode : TemplateBase {

        public override void Transform(Engine engine, Package package) {
            base.Transform(engine, package);
            XmlNode xBanner = null;
            XmlNodeList xBannerList = null;

            string codeOutput = "";
            if (Page.Metadata != null){
                xBannerList = Page.Metadata.ChildNodes;
                foreach (XmlNode item in xBannerList){
                    if (item.Name.Equals("fCode"))
                    {
                        xBanner = item;
                        break;
                    }
                }
            }
            if (xBanner != null){
                if (xBanner.Attributes["xlink:href"] != null){
                    string codeID = xBanner.Attributes["xlink:href"].Value;

                    if (!String.IsNullOrEmpty(codeID) && codeID.Contains("tcm:")){
                        Component codeComp = GetComponent(codeID);
                        if (codeComp != null){
                            codeOutput = codeComp.StringValue("content");
                            Logger.Info("code" + codeOutput);
                            package.AddXhtml("codeOutput", codeOutput);
                        }
                    }
                }
            }

        }

    }
}
