﻿using System;
using System.Linq;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager;
using Tridion.ContentManager.ContentManagement;
using Tridion.Extensions.ContentManager.Templating;
using System.Text.RegularExpressions;
using System.IO;

namespace EMR.Web.Templating.BuildingBlocks.Templates
{
[TcmTemplateTitle("ResolvePublishBinariesInCSSstyles")]
public class ResolvePublishBinariesInCSSstyles : TemplateBase{
  private const string CssStyleTcmUriRegex = "tcm:[0-9]*-[0-9]*";  
  public override void Transform(Engine engine, Package package){
       try{
           base.Transform(engine, package);
           string outputName = Package.OutputName;
           Item outputItem = package.GetByName(Package.OutputName);
           string output = outputItem.GetAsString();
           Regex regex = new Regex(ResolvePublishBinariesInCSSstyles.CssStyleTcmUriRegex, RegexOptions.Compiled);
           MatchEvaluator eval = new MatchEvaluator(SubstituteTcmUri);
           output = regex.Replace(output, eval);
           package.Remove(outputItem);
           package.PushItem(outputName, package.CreateStringItem(ContentType.Text, output));  
       }
       catch (Exception ex){
           package.PushItem("ERRORss:", package.CreateStringItem(ContentType.Text, ex.Message +" ;"+ ex.StackTrace)); 
       }     
  }
// The Delegate Method which will take care of Resolving TcmURI references
private string SubstituteTcmUri(Match match) {
   string pattern = match.Value; 
   string replacedOutput = pattern; 
   string multimediaURL = null;   
   Engine m_Engine = base.Engine;
   string multimediaURI = match.Value; 
   if (!string.IsNullOrEmpty(multimediaURI) && TcmUri.IsValid(multimediaURI)){ 
        TcmUri tcmuri = new TcmUri(multimediaURI);
        Component component = m_Engine.GetObject(tcmuri) as Component;
        if (component.Schema.Title == "Emaar - Image"){
            MemoryStream ms = new MemoryStream();
            component.BinaryContent.WriteToStream(ms);
            // Ensure uniqeness of Image published by adding the Image TcmUri as Sufix
            string suffix = String.Format("{0}-{1}", "_tcm" + component.Id.PublicationId, component.Id.ItemId);
            string filename = GetFilename(component.BinaryContent.Filename);
            //int pos = filename.LastIndexOf(".");
            //if (pos > 0)
            //{
            //    filename = filename.Substring(0, pos) + suffix + filename.Substring(pos);
            //}
            //else
            //    filename += suffix;
            // Use AddBinary() to publish the image
            // Note that multimediaURL contains the Path/URL where image is published             
            multimediaURL = m_Engine.AddBinary(tcmuri, TcmUri.UriNull, null, ms.ToArray(), filename);
            if (!string.IsNullOrEmpty(multimediaURL)){
                // Replace the TcmURI with the Published URL 
                replacedOutput = pattern.Replace(multimediaURI, multimediaURL);
            }
        }   
      }
    return replacedOutput;
  }
 protected string GetFilename(string fullpath){ 
      if (fullpath.Contains(@"\")){ 
                int pos = fullpath.LastIndexOf(@"\"); 
                return fullpath.Substring(pos + 1); 
         } 
       return fullpath; 
    }
}
}
