﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml;
using System.IO;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.ContentManagement.Fields;
using Tridion.Extensions.ContentManager.Templating;
using Tridion.ContentManager.ContentManagement;
using Emaar.Web.Tridion.System.Extensions;
using Tridion.ContentManager.Publishing;
using System.Text.RegularExpressions;
using Tridion.ContentManager;

namespace EMR.Web.Templating.BuildingBlocks.Templates
{

    [TcmTemplateTitle("DCPItem")]
    public class DCPItem : TemplateBase
    {
        //<summary>
        //Transforms the current component.
        //</summary>
        //<param name="engine">The engine.</param>
        //<param name="package">The package.</param>
        public override void Transform(Engine engine, Package package)
        {
            base.Transform(engine, package);


            string Communityname = string.Empty;
            string Propertyname = string.Empty;

            using (StringWriter sw = new StringWriter())
            {

                using (XmlTextWriter xml = new XmlTextWriter(sw))
                {
                    string itemId = Component.Id;

                    if (Component != null)
                    {

                        /* Start of Emaar - Financial Report DCP */
                        if (Component.Schema.Title.Equals("Emaar - Financial Report") || Component.Schema.Title.Equals("Emaar - Financial Report Malls"))
                        {
                            DateTime startDate = Component.DateMetaValue("publishdate");
                            string strStartDate = "";
                            string year = "";
                            string month = "";

                            if (startDate.ToString("dd/MM/yyyy") != "01/01/0001")
                            {
                                strStartDate = startDate.ToString("dd/MM/yyyy");
                                year = startDate.ToString("yyyy");
                                month = startDate.ToString("MM");
                            }

                            xml.WriteStartElement("item");

                            xml.WriteAttributeString("uri", Component.Id);
                            xml.WriteAttributeString("id", itemId.Split('-')[1]);
                            xml.WriteAttributeString("schema", Component.Schema.Title.Split('-')[1].TrimStart().Replace(" ", ""));
                            xml.WriteAttributeString("title", Component.StringValue("title"));
                            xml.WriteAttributeString("publishDate", strStartDate);
                            xml.WriteAttributeString("sortDate", GetSortDate(strStartDate));
                            xml.WriteAttributeString("year", year);
                            xml.WriteAttributeString("month", month);
                            if (Component.KeywordValue("period") != null)
                            {
                                xml.WriteAttributeString("period", Component.KeywordValue("period").Description);
                            }
                            else
                            {
                                //To handle Disclosures and Governance components
                                xml.WriteAttributeString("period", month);
                            }
                            if (Component.KeywordValue("document") != null)
                            {
                                xml.WriteAttributeString("documentkey", Component.KeywordValue("document").Key);
                                xml.WriteAttributeString("document", Component.KeywordValue("document").Description);
                            }
                            if (Component.KeywordValue("documentdisclosures") != null)
                            {
                                xml.WriteAttributeString("documentdisclosureskey", Component.KeywordValue("documentdisclosures").Key);
                                xml.WriteAttributeString("documentdisclosures", Component.KeywordValue("documentdisclosures").Description);
                            }
                            if (Component.KeywordValue("documentgovernance") != null)
                            {
                                xml.WriteAttributeString("documentgovernancekey", Component.KeywordValue("documentgovernance").Key);
                                xml.WriteAttributeString("documentgovernance", Component.KeywordValue("documentgovernance").Description);
                            }
                            if (Component.KeywordValue("documentotherresources") != null)
                            {
                                xml.WriteAttributeString("documentotherresourceskey", Component.KeywordValue("documentotherresources").Key);
                                xml.WriteAttributeString("documentotherresources", Component.KeywordValue("documentotherresources").Description);
                            }



                            if (Component.ComponentValue("download") != null)
                            {
                                xml.WriteAttributeString("download", PublishBinary(Component.ComponentValue("download")));
                            }

                            xml.WriteEndElement();//item

                        }

                        /* End of Emaar - Financial Report DCP*/

                        /* Start of Emaar - Malls IPO DCP */
                        if (Component.Schema.Title.Equals("Emaar - Malls IPO"))
                        {

                            xml.WriteStartElement("item");

                            DateTime startDate = Component.DateMetaValue("publishdate");
                            string strStartDate = "";
                            string year = "";
                            string month = "";

                            if (startDate.ToString("dd/MM/yyyy") != "01/01/0001")
                            {
                                strStartDate = startDate.ToString("dd/MM/yyyy");
                                year = startDate.ToString("yyyy");
                                month = startDate.ToString("MM");
                            }

                            xml.WriteAttributeString("uri", Component.Id);
                            xml.WriteAttributeString("id", itemId.Split('-')[1]);
                            xml.WriteAttributeString("schema", Component.Schema.Title.Split('-')[1].TrimStart().Replace(" ", ""));
                            xml.WriteAttributeString("title", Component.StringValue("title"));
                            xml.WriteAttributeString("publishDate", strStartDate);
                            xml.WriteAttributeString("sortDate", GetSortDate(strStartDate));
                            xml.WriteAttributeString("year", year);
                            xml.WriteAttributeString("month", month);

                            if (Component.StringValue("title") != null)
                            {
                                xml.WriteAttributeString("documenttitle", Component.StringValue("title"));
                            }

                            if (Component.KeywordValue("document") != null)
                            {
                                xml.WriteAttributeString("documentTypeKey", Component.KeywordValue("document").Key);
                                xml.WriteAttributeString("document", Component.KeywordValue("document").Description);
                            }

                            if (Component.ComponentValue("download") != null)
                            {
                                xml.WriteAttributeString("download", PublishBinary(Component.ComponentValue("download")));
                            }

                            if (Component.ComponentMetaValue("tccomponent") != null)
                            {
                                xml.WriteAttributeString("tccomponent", Component.ComponentMetaValue("tccomponent").Id);
                            }

                            xml.WriteEndElement();//item
                        }

                        /* End of Emaar - Malls IPO DCP*/

                        /* Start of Emaar - Dividends DCP */
                        if (Component.Schema.Title.Equals("Emaar - Dividends") || Component.Schema.Title.Equals("Emaar - Dividends Malls IR"))
                        {
                            xml.WriteStartElement("item");

                            xml.WriteAttributeString("uri", Component.Id);
                            xml.WriteAttributeString("id", itemId.Split('-')[1]);
                            xml.WriteAttributeString("schema", Component.Schema.Title.Split('-')[1].TrimStart().Replace(" ", ""));
                            xml.WriteAttributeString("title", Component.StringValue("title"));

                            if (!String.IsNullOrEmpty(Component.StringValue("year")))
                            {
                                xml.WriteAttributeString("year", Component.StringValue("year"));
                                xml.WriteAttributeString("sortDate", Component.StringValue("year"));
                            }
                            if (!String.IsNullOrEmpty(Component.StringValue("cashdividend")))
                                xml.WriteAttributeString("cashdividend", Component.StringValue("cashdividend"));
                            if (!String.IsNullOrEmpty(Component.StringValue("dividendpershare")))
                                xml.WriteAttributeString("dividendpershare", Component.StringValue("dividendpershare"));
                            if (!String.IsNullOrEmpty(Component.StringValue("bonusshares")))
                                xml.WriteAttributeString("bonusshares", Component.StringValue("bonusshares"));
                            DateTime date = new DateTime();
                            string strDate = "";
                            if (Component.DateValue("entitlementdate").ToString("dd/MM/yyyy") != "01/01/0001")
                            {
                                date = Component.DateValue("entitlementdate");
                                strDate = date.ToString("MMM dd, yyyy");
                                xml.WriteAttributeString("entitlementdate", strDate);
                                strDate = date.ToString("dd/MM/yyyy");

                            }
                            if (Component.DateValue("exdividenddate").ToString("dd/MM/yyyy") != "01/01/0001")
                            {
                                date = Component.DateValue("exdividenddate");
                                strDate = date.ToString("MMM dd, yyyy");
                                xml.WriteAttributeString("exdividenddate", strDate);
                            }
                            if (Component.DateValue("settlementdate").ToString("dd/MM/yyyy") != "01/01/0001")
                            {
                                date = Component.DateValue("settlementdate");
                                strDate = date.ToString("MMM dd, yyyy");
                                xml.WriteAttributeString("settlementdate", strDate);
                            }
                            if (Component.DateValue("distributiondate").ToString("dd/MM/yyyy") != "01/01/0001")
                            {
                                date = Component.DateValue("distributiondate");
                                strDate = date.ToString("MMM dd, yyyy");
                                xml.WriteAttributeString("distributiondate", strDate);
                            }
                            if (!String.IsNullOrEmpty(Component.StringValue("distributor")))
                                xml.WriteAttributeString("distributor", Component.StringValue("distributor"));

                            if (!String.IsNullOrEmpty(Component.StringValue("contact")))
                            {
                                if (!Component.XHTMLValue("contact").Equals("<br xmlns=\"http://www.w3.org/1999/xhtml\" />"))
                                    xml.WriteElementString("contact", Component.StringValue("contact"));
                            }

                            xml.WriteEndElement();//item
                        }

                        /* End of Emaar - Dividends DCP*/

                        /* Start of Emaar - Credit Ratings DCP */
                        if (Component.Schema.Title.Equals("Emaar - Credit Ratings"))
                        {
                            xml.WriteStartElement("item");

                            xml.WriteAttributeString("uri", Component.Id);
                            xml.WriteAttributeString("id", itemId.Split('-')[1]);
                            xml.WriteAttributeString("schema", Component.Schema.Title.Split('-')[1].TrimStart().Replace(" ", ""));
                            xml.WriteAttributeString("title", Component.StringValue("title"));

                            if (!String.IsNullOrEmpty(Component.StringValue("agency")))
                                xml.WriteAttributeString("agency", Component.StringValue("agency"));
                            if (!String.IsNullOrEmpty(Component.StringValue("rating")))
                                xml.WriteAttributeString("rating", Component.StringValue("rating"));
                            if (!String.IsNullOrEmpty(Component.StringValue("outlook")))
                                xml.WriteAttributeString("outlook", Component.StringValue("outlook"));
                            DateTime date = new DateTime();
                            string strDate = "";
                            if (Component.DateValue("reportdate").ToString("dd/MM/yyyy") != "01/01/0001")
                            {
                                date = Component.DateValue("reportdate");
                                strDate = date.ToString("MMM dd, yyyy");
                                xml.WriteAttributeString("reportdate", strDate);
                                strDate = date.ToString("dd/MM/yyyy");
                                xml.WriteAttributeString("sortDate", GetSortDate(strDate));

                            }
                            if (Component.ComponentValue("download") != null)
                            {
                                xml.WriteAttributeString("download", PublishBinary(Component.ComponentValue("download")));
                            }

                            xml.WriteEndElement();//item
                        }

                        /* End of Emaar - Credit Ratings DCP*/

                        /* Start of Emaar - Press Release DCP */

                        if (Component.Schema.Title.Equals("Emaar - Press Release"))
                        {
                            DateTime startDate = Component.DateMetaValue("publishDate");
                            string strStartDate = "";
                            string year = "";
                            string month = "";


                            if (startDate.ToString("dd/MM/yyyy") != "01/01/0001")
                            { strStartDate = startDate.ToString("dd/MM/yyyy"); year = startDate.ToString("yyyy"); month = startDate.ToString("MM"); }

                            xml.WriteStartElement("item");
                            Component image = Component.ComponentValue("image");
                            if (image != null)
                            {
                                xml.WriteAttributeString("src", PublishBinary(image));
                                xml.WriteAttributeString("thumb", GenerateThumbnail(image, "thumbpress", 260, 156));
                            }
                            xml.WriteAttributeString("uri", Component.Id);
                            xml.WriteAttributeString("id", itemId.Split('-')[1]);
                            xml.WriteAttributeString("schema", Component.Schema.Title.Split('-')[1].TrimStart().Replace(" ", ""));
                            xml.WriteAttributeString("publishDate", strStartDate);
                            xml.WriteAttributeString("sortDate", GetSortDate(strStartDate));
                            xml.WriteAttributeString("year", year);
                            xml.WriteAttributeString("month", month);

                            if (Component.ComponentMetaValue("componentLink") != null)
                            {
                                xml.WriteAttributeString("componentLink", Component.ComponentMetaValue("componentLink").Id);
                            }

                            xml.WriteAttributeString("title", Component.StringValue("title"));
                            xml.WriteAttributeString("description", Component.StringValue("description"));

                            ItemFields fields = new ItemFields(Component.Content, Component.Schema);
                            EmbeddedSchemaField emb = (EmbeddedSchemaField)fields["detail"];
                            // Loop
                            foreach (ItemFields embeddedfields in emb.Values)
                            {
                                xml.WriteStartElement("detail");

                                if (embeddedfields["key"] != null)
                                {

                                    xml.WriteAttributeString("key", embeddedfields.StringValue("key"));
                                }

                                if (embeddedfields["value"] != null)
                                {
                                    xml.WriteAttributeString("value", embeddedfields.StringValue("value"));

                                }
                                xml.WriteEndElement();//detail


                            }

                            if (Component.KeywordMetaValues("segment") != null)
                            {
                                IList<Keyword> keys = Component.KeywordMetaValues("segment");
                                foreach (Keyword key in keys)
                                {
                                    xml.WriteStartElement("segment");
                                    xml.WriteAttributeString("segmentKey", key.Key);
                                    xml.WriteAttributeString("segmentValue", key.Description);
                                    xml.WriteEndElement();//segment
                                }
                            }

                            xml.WriteEndElement();//item
                        }

                        /* End of Emaar - Press Release DCP*/

                        /* Start of Emaar - PhotoAlbum DCP */



                        if (Component.Schema.Title.Equals("Emaar - PhotoAlbum"))
                        {
                            string k = Component.OrganizationalItem.Id;

                            xml.WriteStartElement("item");
                            xml.WriteAttributeString("uri", Component.Id);
                            xml.WriteAttributeString("rank", Component.Title.Split('.')[0]);

                            xml.WriteAttributeString("id", itemId.Split('-')[1]);
                            xml.WriteAttributeString("schema", Component.Schema.Title.Split('-')[1].TrimStart());
                            xml.WriteAttributeString("title", Component.StringValue("title"));
                            xml.WriteAttributeString("description", Component.StringValue("description"));
                            /*if (Component.DateMetaValue("date") != null)
                            {
                                string strStartDate = "";
                                DateTime startDate = Component.DateMetaValue("date");
                                if (startDate.ToString("dd/MM/yyyy") != "01/01/0001")
                                {
                                    strStartDate = startDate.ToString("dd/MM/yyyy"); string year = startDate.ToString("yyyy"); string month = startDate.ToString("MM");
                                    xml.WriteAttributeString("publishDate", strStartDate); xml.WriteAttributeString("year", year);
                                    xml.WriteAttributeString("month", month);
                                }
                            }*/

                            IList<Component> multimedialist = Component.ComponentValues("list");
                            foreach (Component comp in multimedialist)
                            {
                                if (comp.ComponentMetaValue("thumbnil") != null)
                                {
                                    xml.WriteAttributeString("thumbnail", PublishBinary(comp.ComponentMetaValue("thumbnil")));
                                    break;
                                }
                            }

                            xml.WriteEndElement();//item

                        }

                        /* End of Emaar - PhotoAlbum DCP*/

                        /* Start of Emaar - VideoAlbum DCP */




                        if (Component.Schema.Title.Equals("Emaar - VideoAlbum"))
                        {
                            string k = Component.OrganizationalItem.Id;

                            xml.WriteStartElement("item");
                            xml.WriteAttributeString("rank", Component.Title.Split('.')[0]);

                            xml.WriteAttributeString("uri", Component.Id);

                            xml.WriteAttributeString("id", itemId.Split('-')[1]);
                            xml.WriteAttributeString("schema", Component.Schema.Title.Split('-')[1].TrimStart());
                            xml.WriteAttributeString("title", Component.StringValue("title"));
                            xml.WriteAttributeString("description", Component.StringValue("description"));
                            /*if (Component.KeywordMetaValue("country") != null)
                            {
                                xml.WriteAttributeString("countryKey", Component.KeywordMetaValue("country").Key);
                                xml.WriteAttributeString("countryValue", Component.KeywordMetaValue("country").Description);
                            }
                            else
                            {
                                xml.WriteAttributeString("countryKey", "");
                                xml.WriteAttributeString("countryValue", "");
                            }
                            if (Component.KeywordMetaValue("segment") != null)
                            {
                                xml.WriteAttributeString("segmentKey", Component.KeywordMetaValue("segment").Key);
                                xml.WriteAttributeString("segmentValue", Component.KeywordMetaValue("segment").Description);
                            }
                            else
                            {
                                xml.WriteAttributeString("segmentKey", "");
                                xml.WriteAttributeString("segmentValue", "");
                            }*/
                            /*
                            if (Component.DateMetaValue("date") != null)
                            {
                                string strStartDate = "";
                                DateTime startDate = Component.DateMetaValue("date");
                                if (startDate.ToString("dd/MM/yyyy") != "01/01/0001")
                                {
                                    strStartDate = startDate.ToString("dd/MM/yyyy"); string year = startDate.ToString("yyyy"); string month = startDate.ToString("MM");

                                    xml.WriteAttributeString("publishDate", strStartDate);
                                    xml.WriteAttributeString("year", year);
                                    xml.WriteAttributeString("month", month);
                                }
                                else
                                {
                                    xml.WriteAttributeString("publishDate", "");
                                    xml.WriteAttributeString("year", "");
                                    xml.WriteAttributeString("month", "");
                                }
                            }*/

                            IList<Component> multimedialist = Component.ComponentValues("list");
                            foreach (Component li in multimedialist)
                            {
                                xml.WriteStartElement("video");
                                xml.WriteAttributeString("folder", k);
                                xml.WriteAttributeString("uri", li.Id);
                                xml.WriteAttributeString("schema", li.Schema.Title.Split('-')[1].TrimStart());
                                xml.WriteAttributeString("id", li.Id);

                                Component thumbnail = li.ComponentMetaValue("thumbnail");
                                if (thumbnail != null)
                                {
                                    xml.WriteAttributeString("thumbnail", PublishBinary(thumbnail));
                                }
                                else
                                {
                                    string im = GetYouTubeImage(li.StringValue("link"));
                                    xml.WriteAttributeString("thumbnail", im);
                                }


                                xml.WriteAttributeString("altText", Component.StringMetaValue("altText"));
                                xml.WriteAttributeString("video", li.StringValue("link"));
                                xml.WriteEndElement();//video
                            }

                            xml.WriteEndElement();//item

                        }

                        /* End of Emaar - VideoAlbum DCP*/

                        /* Start of Emaar - Media DCP 

                        if (Component.Schema.Title.Equals("Emaar - Media"))
                        {
                            string k = Component.OrganizationalItem.Id;

                            xml.WriteStartElement("item");
                            xml.WriteAttributeString("folder", k);
                            xml.WriteAttributeString("uri", Component.Id);
                            xml.WriteAttributeString("id", itemId.Split('-')[1]);
                            xml.WriteAttributeString("schema", Component.Schema.Title.Split('-')[1].TrimStart());
                            xml.WriteAttributeString("imgsrc", PublishBinary(Component));
                            xml.WriteAttributeString("altText", Component.StringMetaValue("altText"));
                            Component thumbnail = Component.ComponentMetaValue("thumbnil");
                            if (thumbnail != null)
                            {
                                xml.WriteAttributeString("thumbnail", PublishBinary(thumbnail));

                            }
                            else
                            {
                                xml.WriteAttributeString("thumbnail", GenerateThumbnail(Component, "fthumb", 96, 79));
                            }
                            OrganizationalItem folder = engine.GetObject(k) as OrganizationalItem;
                            IList<Component> list = folder.Components(true);
                            foreach (Component comp in list)
                            {
                                if (comp.Schema.Title.Equals("Emaar - PhotoAlbum"))
                                {
                                    if (comp.DateMetaValue("date") != null)
                                    {
                                        string strStartDate = "";
                                        string year = "";
                                        string month = "";
                                        DateTime startDate = comp.DateMetaValue("date");

                                        if (startDate.ToString("dd/MM/yyyy") != "01/01/0001")
                                        { strStartDate = startDate.ToString("dd/MM/yyyy"); year = startDate.ToString("yyyy"); month = startDate.ToString("MM"); }
                                        xml.WriteAttributeString("publishDate", strStartDate); xml.WriteAttributeString("year", year);
                                        xml.WriteAttributeString("month", month);
                                    }


                                    xml.WriteAttributeString("mediaType", comp.StringMetaValue("type"));

                                    if (Component.KeywordMetaValue("country") != null)
                                    {
                                        xml.WriteAttributeString("countryKey", comp.KeywordMetaValue("country").Key);
                                        xml.WriteAttributeString("countryValue", comp.KeywordMetaValue("country").Description);
                                    }
                                    if (Component.KeywordMetaValue("segment") != null)
                                    {
                                        xml.WriteAttributeString("segmentKey", comp.KeywordMetaValue("segment").Key);
                                        xml.WriteAttributeString("segmentValue", comp.KeywordMetaValue("segment").Description);
                                    }
                                }
                            }

                            xml.WriteEndElement();//item
                        }

                         End of Emaar - Media DCP*/

                        /* Start of Emaar - Awards */


                        if (Component.Schema.Title.Equals("Emaar - Awards"))
                        {
                            xml.WriteStartElement("item");
                            string k = Component.OrganizationalItem.Id;

                            //xml.WriteStartElement("item");
                            xml.WriteAttributeString("folder", k);
                            xml.WriteAttributeString("uri", Component.Id);
                            xml.WriteAttributeString("id", itemId.Split('-')[1]);
                            xml.WriteAttributeString("schema", Component.Schema.Title.Split('-')[1].TrimStart());

                            xml.WriteAttributeString("title", Component.StringValue("title"));

                            if (Component.StringMetaValue("altText") != null)
                            {
                                xml.WriteAttributeString("altText", Component.StringMetaValue("altText"));
                            }
                            if (Component.ComponentValue("image") != null)
                            {
                                xml.WriteAttributeString("src", PublishBinary(Component.ComponentValue("image")));
                            }
                            if (Component.DateMetaValue("publishDate") != null)
                            {
                                string yr = "";
                                DateTime startDate = Component.DateMetaValue("publishDate");
                                string strStartDate = "";
                                if (startDate.ToString("dd/MM/yyyy") != "01/01/0001")
                                { strStartDate = startDate.ToString("dd/MM/yyyy"); yr = startDate.ToString("yyyy"); }
                                xml.WriteAttributeString("publishDate", strStartDate);
                                xml.WriteAttributeString("year", yr);
                            }
                            if (Component.KeywordMetaValue("entity") != null)
                            {
                                xml.WriteAttributeString("entityKey", Component.KeywordMetaValue("entity").Key);
                                xml.WriteAttributeString("entityValue", Component.KeywordMetaValue("entity").Description);
                            }
                            xml.WriteAttributeString("description", Component.StringValue("description"));
                            xml.WriteEndElement();//item
                        }


                        /* End of Emaar - Awards DCP*/

                        /* Start of Emaar - Property Building */



                        if (Component.Schema.Title.Equals("Emaar - Property Building"))
                        {

                            xml.WriteStartElement("item");

                            xml.WriteAttributeString("uri", Component.Id);
                            xml.WriteAttributeString("id", itemId.Split('-')[1]);
                            xml.WriteAttributeString("schema", Component.Schema.Title.Split('-')[1].TrimStart());

                            xml.WriteAttributeString("title", Component.StringValue("title"));
                            if (Component.ComponentValue("thumbnail") != null)
                                xml.WriteAttributeString("thumbnail", PublishBinary(Component.ComponentValue("thumbnail")));

                            else
                                xml.WriteAttributeString("thumbnail", "");

                            OrganizationalItem parentFolder = Component.OrganizationalItem;

                            IList<Component> compList = parentFolder.Components(true);
                            foreach (Component comp in compList)
                            {
                                if (comp.Schema.Title.Equals("Emaar - Property"))
                                {
                                    xml.WriteAttributeString("propertyId", comp.Id);
                                    xml.WriteAttributeString("property", comp.StringValue("title"));
                                    break;
                                }
                            }

                            if (Component.ComponentValues("gallery") != null)
                            {
                                IList<Component> list = Component.ComponentValues("gallery");
                                xml.WriteStartElement("gallery");
                                foreach (Component imageComp in list)
                                {
                                    xml.WriteStartElement("image");
                                    xml.WriteAttributeString("src", PublishBinary(imageComp));
                                    xml.WriteEndElement();//image
                                }
                                xml.WriteEndElement();//image
                            }



                            if (Component.EmbeddedValues("floorplans") != null)
                            {
                                IList<ItemFields> floorplans = Component.EmbeddedValues("floorplans");
                                foreach (ItemFields floorplan in floorplans)
                                {
                                    xml.WriteStartElement("floorplan");
                                    xml.WriteAttributeString("type", floorplan.StringValue("type"));
                                    IList<Component> imagelist = floorplan.ComponentValues("image");
                                    foreach (Component imageComp in imagelist)
                                    {
                                        xml.WriteStartElement("image");
                                        xml.WriteAttributeString("src", PublishBinary(imageComp));
                                        xml.WriteEndElement();//image
                                    }

                                    xml.WriteEndElement();//floorplan
                                }
                            }
                            xml.WriteEndElement();//item
                        }



                        /* End of Emaar - Property Building DCP*/

                        /* Start of Emaar - Property DCP */


                        if (Component.Schema.Title.Equals("Emaar - Property"))
                        {

                            xml.WriteStartElement("item");
                            xml.WriteAttributeString("uri", Component.Id);
                            xml.WriteAttributeString("CompTitle", Component.Title);
                            xml.WriteAttributeString("id", itemId.Split('-')[1]);
                            xml.WriteAttributeString("schema", Component.Schema.Title.Split('-')[1].TrimStart());

                            xml.WriteAttributeString("title", Component.StringValue("title"));
                            xml.WriteAttributeString("heading", Component.StringValue("heading"));
                            xml.WriteAttributeString("name", Component.StringValue("name"));
                            xml.WriteAttributeString("description", Component.StringValue("description"));
                            xml.WriteAttributeString("rawdescription", getrawtext(Component.StringValue("description")));
                            

                            xml.WriteAttributeString("display", Component.StringValue("display"));

                            if (!String.IsNullOrEmpty(Component.StringValue("ElauqaURL")))
                                xml.WriteAttributeString("ElauqaURL", Component.StringValue("ElauqaURL"));



                            if (!String.IsNullOrEmpty(Component.StringValue("sqftfrom")))
                                xml.WriteAttributeString("sqftfrom", Component.StringValue("sqftfrom"));
                            if (!String.IsNullOrEmpty(Component.StringValue("sqftto")))
                                xml.WriteAttributeString("sqftto", Component.StringValue("sqftto"));
                            if (Component.ComponentValue("image") != null)
                            {
                                xml.WriteAttributeString("thumb", PublishBinary(Component.ComponentValue("image")));
                                xml.WriteAttributeString("altText", Component.ComponentValue("image").StringMetaValue("altText"));
                            }
                            if (Component.ComponentValue("brochure") != null)
                            {
                                xml.WriteAttributeString("brochure", PublishBinary(Component.ComponentValue("brochure")));
                                xml.WriteAttributeString("brochuretitle", Component.ComponentValue("brochure").StringMetaValue("title"));
                            }

                            if (Component.ComponentValue("floorplans") != null)
                            {
                                xml.WriteAttributeString("floorplans", PublishBinary(Component.ComponentValue("floorplans")));
                            }

                            if (Component.EmbeddedValue("map-parameters") != null)
                            {
                                ItemFields map = Component.EmbeddedValue("map-parameters");
                                xml.WriteAttributeString("data-name", map.StringValue("data-name"));
                                xml.WriteAttributeString("data-lat", map.StringValue("data-lat"));
                                xml.WriteAttributeString("data-lng", map.StringValue("data-lng"));
                            }

                            OrganizationalItem parentFolder = Component.OrganizationalItem.OrganizationalItem;

                            IList<Component> compList = parentFolder.Components(true);
                            foreach (Component comp in compList)
                            {
                                if (comp.Schema.Title.Equals("Emaar - Community"))
                                {
                                    xml.WriteAttributeString("communityId", comp.Id);
                                    xml.WriteAttributeString("community", comp.StringValue("title"));


                                    Communityname = comp.Title;
                                    if (comp.Title.StartsWith("000."))
                                        Communityname = comp.Title.Split('.')[1].Trim();

                                    xml.WriteAttributeString("displaytitle", Communityname + "-" + Component.Title);
                                    break;
                                }
                            }

                            if (Component.ComponentValues("gallery") != null)
                            {
                                IList<Component> list = Component.ComponentValues("gallery");
                                foreach (Component imageComp in list)
                                {
                                    xml.WriteStartElement("image");
                                    xml.WriteAttributeString("src", PublishBinary(imageComp));
                                    xml.WriteAttributeString("altText", imageComp.StringMetaValue("altText"));
                                    xml.WriteEndElement();//image
                                }
                            }


                            OrganizationalItem parentFolderprop = Component.OrganizationalItem;

                            IList<Component> compListprop = parentFolderprop.Components(true);


                            foreach (Component comp in compListprop)
                            {
                                if (comp.Schema.Title.Equals("Emaar - Property Building"))
                                {
                                    if (comp.ComponentValue("PDF") != null)
                                    {
                                        xml.WriteElementString("pdffloor", PublishBinary(comp.ComponentValue("PDF")));
                                        break;
                                    }
                                }
                            }


                            xml.WriteStartElement("floorplan");
                            foreach (Component comp in compListprop)
                            {
                                if (comp.Schema.Title.Equals("Emaar - Property Building"))
                                {



                                    if (comp.EmbeddedValues("floorplans") != null)
                                    {
                                        IList<ItemFields> floorplans = comp.EmbeddedValues("floorplans");
                                        foreach (ItemFields floorplan in floorplans)
                                        {


                                            IList<Component> imagelist = floorplan.ComponentValues("image");
                                            foreach (Component imageComp in imagelist)
                                            {
                                                xml.WriteStartElement("largeimage");
                                                if (comp.Title.Contains("The Address Residence Fountain Views"))
                                                {
                                                    xml.WriteAttributeString("src", PublishBinary(imageComp));
                                                }
                                                else
                                                {
                                                    //xml.WriteAttributeString("src", GenerateThumbnail(imageComp, "floorlarge", 442, 499));
                                                    xml.WriteAttributeString("src", PublishBinary(imageComp));
                                                }

                                                xml.WriteAttributeString("dataimage", PublishBinary(imageComp));

                                                xml.WriteAttributeString("type", floorplan.StringValue("type"));
                                                xml.WriteEndElement();//image


                                            }


                                        }
                                    }


                                }
                            }
                            xml.WriteEndElement();//floorplan


                            xml.WriteEndElement();//item
                        }



                        /* End of Emaar - Property  DCP*/

                        /* Start of Emaar - Construction DCP */


                        if (Component.Schema.Title.Equals("Emaar - Construction"))
                        {


                            xml.WriteStartElement("item");
                            xml.WriteAttributeString("uri", Component.Id);
                            xml.WriteAttributeString("id", itemId.Split('-')[1]);
                            xml.WriteAttributeString("schema", Component.Schema.Title.Split('-')[1].TrimStart());

                            xml.WriteAttributeString("title", Component.StringValue("title"));
                            xml.WriteAttributeString("heading", Component.StringValue("heading"));
                            xml.WriteAttributeString("name", Component.StringValue("name"));
                            xml.WriteAttributeString("description", Component.StringValue("description"));
                            xml.WriteAttributeString("display", Component.StringValue("display"));
                            if (!String.IsNullOrEmpty(Component.StringValue("sqftfrom")))
                                xml.WriteAttributeString("sqftfrom", Component.StringValue("sqftfrom"));
                            if (!String.IsNullOrEmpty(Component.StringValue("sqftto")))
                                xml.WriteAttributeString("sqftto", Component.StringValue("sqftto"));
                            if (Component.ComponentValue("image") != null)
                            {
                                xml.WriteAttributeString("thumb", PublishBinary(Component.ComponentValue("image")));
                                xml.WriteAttributeString("altText", Component.ComponentValue("image").StringMetaValue("altText"));
                            }
                            if (Component.ComponentValue("brochure") != null)
                            {
                                xml.WriteAttributeString("brochure", PublishBinary(Component.ComponentValue("brochure")));
                                xml.WriteAttributeString("brochuretitle", Component.ComponentValue("brochure").StringMetaValue("title"));
                            }
                            if (Component.ComponentValue("Floorplans") != null)
                            {
                                xml.WriteAttributeString("floorplans", PublishBinary(Component.ComponentValue("Floorplans")));
                                xml.WriteAttributeString("floorplanstitle", Component.ComponentValue("Floorplans").StringMetaValue("title"));
                            }

                            if (Component.EmbeddedValue("map-parameters") != null)
                            {
                                ItemFields map = Component.EmbeddedValue("map-parameters");
                                xml.WriteAttributeString("data-name", map.StringValue("data-name"));
                                xml.WriteAttributeString("data-lat", map.StringValue("data-lat"));
                                xml.WriteAttributeString("data-lng", map.StringValue("data-lng"));
                            }


                            if (!String.IsNullOrEmpty(Component.StringValue("pano")))
                                xml.WriteAttributeString("pano", Component.StringValue("pano"));

                            /*OrganizationalItem parentFolder = Component.OrganizationalItem.OrganizationalItem;

                            IList<Component> compList = parentFolder.Components(true);
                            foreach (Component comp in compList)
                            {
                                if (comp.Schema.Title.Equals("Emaar - Community"))
                                {
                                    xml.WriteAttributeString("communityId", comp.Id);
                                    xml.WriteAttributeString("community", comp.StringValue("title"));
                                    break;
                                }
                            }*/

                            if (Component.ComponentValues("gallery") != null)
                            {
                                IList<Component> list = Component.ComponentValues("gallery");
                                foreach (Component imageComp in list)
                                {
                                    xml.WriteStartElement("image");
                                    xml.WriteAttributeString("src", PublishBinary(imageComp));
                                    xml.WriteAttributeString("altText", imageComp.StringMetaValue("altText"));
                                    xml.WriteEndElement();//image
                                }
                            }



                            /*
                            OrganizationalItem parentFolderprop = Component.OrganizationalItem;

                            IList<Component> compListprop = parentFolderprop.Components(true);
                             * 


                            foreach (Component comp in compListprop)
                            {
                                if (comp.Schema.Title.Equals("Emaar - Property Building"))
                                {
                                    if (comp.ComponentValue("PDF") != null)
                                    {
                                        xml.WriteElementString("pdffloor", PublishBinary(comp.ComponentValue("PDF")));
                                        break;
                                    }
                                }
                            }


                            xml.WriteStartElement("floorplan");
                            foreach (Component comp in compListprop)
                            {
                                if (comp.Schema.Title.Equals("Emaar - Property Building"))
                                {



                                    if (comp.EmbeddedValues("floorplans") != null)
                                    {
                                        IList<ItemFields> floorplans = comp.EmbeddedValues("floorplans");
                                        foreach (ItemFields floorplan in floorplans)
                                        {
                                            xml.WriteStartElement("floorplan");
                                            xml.WriteAttributeString("type", floorplan.StringValue("type"));
                                            IList<Component> imagelist = floorplan.ComponentValues("image");
                                            foreach (Component imageComp in imagelist)
                                            {
                                                /*xml.WriteStartElement("thumbimage");
                                                xml.WriteAttributeString("src", GenerateThumbnail(imageComp, "floorthumb", 94, 173));
                                                xml.WriteEndElement();
                                                //image

                                                xml.WriteStartElement("largeimage");
                                                xml.WriteAttributeString("src", GenerateThumbnail(imageComp, "floorlarge", 442, 499));
                                                xml.WriteEndElement();//image

                                            }

                                            xml.WriteEndElement();//floorplan
                                        }
                                    }


                                }
                            }
                            xml.WriteEndElement();//floorplan*/

                            //Construction Facilities
                            if (Component.KeywordValues("facility") != null)
                            {
                                foreach (var facility in Component.KeywordValues("facility"))
                                {
                                    xml.WriteStartElement("facility");
                                    xml.WriteAttributeString("title", facility.Title);
                                    xml.WriteAttributeString("image", facility.Description);
                                    xml.WriteEndElement();
                                }
                            }



                            xml.WriteEndElement();//item
                        }



                        /* End of Emaar - Construction  DCP*/



                        /* Start of Emaar - Lifestyle DCP */


                        if (Component.Schema.Title.Equals("Emaar - Lifestyle"))
                        {


                            xml.WriteStartElement("item");
                            xml.WriteAttributeString("uri", Component.Id);
                            xml.WriteAttributeString("id", itemId.Split('-')[1]);
                            xml.WriteAttributeString("schema", Component.Schema.Title.Split('-')[1].TrimStart());

                            xml.WriteAttributeString("title", Component.StringValue("title"));
                            xml.WriteAttributeString("heading", Component.StringValue("heading"));
                            xml.WriteAttributeString("name", Component.StringValue("name"));
                            xml.WriteAttributeString("descriptionleft", Component.StringValue("descriptionleft"));
                            xml.WriteAttributeString("descriptionright", Component.StringValue("descriptionright"));
                            xml.WriteAttributeString("display", Component.StringValue("display"));

                            if (Component.ComponentValue("image") != null)
                            {
                                xml.WriteAttributeString("thumb", PublishBinary(Component.ComponentValue("image")));
                                xml.WriteAttributeString("altText", Component.ComponentValue("image").StringMetaValue("altText"));
                            }
                            if (Component.ComponentValue("propertylink") != null)
                            {
                                xml.WriteAttributeString("propertylink", Component.ComponentValue("propertylink").Id);

                            }

                            if (Component.ComponentValues("gallery") != null)
                            {
                                IList<Component> list = Component.ComponentValues("gallery");
                                foreach (Component imageComp in list)
                                {
                                    xml.WriteStartElement("image");
                                    xml.WriteAttributeString("src", PublishBinary(imageComp));
                                    xml.WriteAttributeString("altText", imageComp.StringMetaValue("altText"));
                                    xml.WriteEndElement();//image
                                }
                            }






                            xml.WriteEndElement();//item
                        }
                        /* End of Emaar - Lifestyle DCP */



                        /* Start of Emaar - Community DCP */



                        if (Component.Schema.Title.Equals("Emaar - Community"))
                        {

                            xml.WriteStartElement("item");

                            xml.WriteAttributeString("uri", Component.Id);
                            xml.WriteAttributeString("id", itemId.Split('-')[1]);
                            xml.WriteAttributeString("schema", Component.Schema.Title.Split('-')[1].TrimStart());

                            xml.WriteAttributeString("title", Component.StringValue("title"));
                            xml.WriteAttributeString("heading", Component.StringValue("heading"));
                            xml.WriteAttributeString("description", Component.StringValue("description"));

                            /*if (Component.ExternalLinkValue("website") != null)
                            {
                                xml.WriteAttributeString("website", Component.ExternalLinkValue("website"));
                            }
                            if (Component.ComponentValue("brochure") != null)
                            {
                                xml.WriteAttributeString("brochure", PublishBinary(Component.ComponentValue("brochure")));
                            }*/

                            if (Component.StringValue("pod-heading1") != "")
                            {
                                xml.WriteAttributeString("pod-heading1", Component.StringValue("pod-heading1"));
                            }

                            if (Component.StringValue("pod-heading") != "")
                            {
                                xml.WriteAttributeString("pod-heading", Component.StringValue("pod-heading"));
                            }
                            if (Component.EmbeddedValue("map-parameters") != null)
                            {
                                ItemFields map = Component.EmbeddedValue("map-parameters");
                                xml.WriteAttributeString("data-name", map.StringValue("data-name"));
                                xml.WriteAttributeString("data-lat", map.StringValue("data-lat"));
                                xml.WriteAttributeString("data-lng", map.StringValue("data-lng"));
                            }

                            OrganizationalItem parentFolder = Component.OrganizationalItem.OrganizationalItem;

                            xml.WriteAttributeString("countryId", parentFolder.Id);
                            xml.WriteAttributeString("country", parentFolder.StringMetaValue("value"));

                            if (Component.EmbeddedValues("links") != null)
                            {
                                IList<ItemFields> links = Component.EmbeddedValues("links");
                                foreach (ItemFields link in links)
                                {
                                    xml.WriteStartElement("link");
                                    xml.WriteAttributeString("flinkText", link.StringValue("flinkText"));
                                    if (link.ComponentValue("fcomponentLink") != null)
                                    {
                                        xml.WriteAttributeString("fcomponentLink", link.ComponentValue("fcomponentLink").Id);
                                    }
                                    if (link.ExternalLinkValue("fexternalLink") != null)
                                    {
                                        xml.WriteAttributeString("fexternalLink", link.ExternalLinkValue("fexternalLink"));
                                    }
                                    if (link.ComponentValue("pdf") != null)
                                    {
                                        xml.WriteAttributeString("pdf", PublishBinary(link.ComponentValue("pdf")));
                                    }
                                    xml.WriteEndElement();//link
                                }

                            }


                            if (Component.EmbeddedValues("linkscontent") != null)
                            {
                                IList<ItemFields> links = Component.EmbeddedValues("linkscontent");
                                foreach (ItemFields link in links)
                                {
                                    xml.WriteStartElement("linkscontent");
                                    xml.WriteAttributeString("flinkText", link.StringValue("flinkText"));
                                    if (link.ComponentValue("fcomponentLink") != null)
                                    {
                                        xml.WriteAttributeString("fcomponentLink", link.ComponentValue("fcomponentLink").Id);
                                    }
                                    if (link.ExternalLinkValue("fexternalLink") != null)
                                    {
                                        xml.WriteAttributeString("fexternalLink", link.ExternalLinkValue("fexternalLink"));
                                    }
                                    if (link.ComponentValue("pdf") != null)
                                    {
                                        xml.WriteAttributeString("pdf", PublishBinary(link.ComponentValue("pdf")));
                                    }
                                    xml.WriteEndElement();//link
                                }

                            }

                            parentFolder = Component.OrganizationalItem;


                            IList<Component> compList = parentFolder.Components(true);

                            foreach (Component comp in compList)
                            {
                                //if (checkshouldpublish(comp.OrganizationalItem.StringMetaValue("onlystaging")))
                                // {
                                if (comp.Schema.Title.Equals("Emaar - Property"))
                                {



                                    ICollection<PublishInfo> publishInfo = PublishEngine.GetPublishInfo(comp);
                                    bool isPublished = false;

                                    // if component published to the current  target

                                    if (engine.RenderMode == RenderMode.Publish)
                                    {
                                        foreach (PublishInfo info in publishInfo)
                                        {
                                            if (info.Publication.Id.ItemId == comp.Id.PublicationId)
                                            {
                                                if (engine.PublishingContext.PublicationTarget.Title.Equals(info.PublicationTarget.Title))
                                                {
                                                    isPublished = true;
                                                }
                                            }

                                        }
                                    }


                                    if (isPublished)
                                    {
                                        xml.WriteStartElement("property");
                                        xml.WriteAttributeString("number", comp.OrganizationalItem.Title.Substring(0, 3));
                                        xml.WriteAttributeString("propertyId", comp.Id);
                                        xml.WriteAttributeString("name", comp.StringValue("name"));

                                        if (comp.ComponentValue("image") != null)
                                        {
                                            xml.WriteAttributeString("thumb", PublishBinary(comp.ComponentValue("image")));
                                            xml.WriteAttributeString("imagetitle", comp.ComponentValue("image").StringMetaValue("altText"));
                                        }
                                        xml.WriteEndElement();//property

                                    }


                                }
                                // }
                            }

                            if (Component.EmbeddedValues("pod-list1") != null)
                            {
                                IList<ItemFields> amenities = Component.EmbeddedValues("pod-list1");
                                foreach (ItemFields amenity in amenities)
                                {
                                    xml.WriteStartElement("pod1");
                                    xml.WriteAttributeString("text", amenity.StringValue("text"));
                                    xml.WriteAttributeString("image", PublishBinary(amenity.ComponentValue("image")));
                                    xml.WriteAttributeString("imagetitle", amenity.ComponentValue("image").StringMetaValue("altText"));

                                    if (amenity.ComponentValue("fcomponentLink") != null)
                                    {
                                        xml.WriteAttributeString("componentLink", amenity.ComponentValue("fcomponentLink").Id);
                                    }
                                    else if (amenity.ExternalLinkValue("fexternalLink") != null)
                                    {
                                        xml.WriteAttributeString("externalLink", amenity.ExternalLinkValue("fexternalLink"));
                                    }

                                    xml.WriteEndElement();//amenity
                                }
                            }



                            if (Component.EmbeddedValues("pod-list") != null)
                            {
                                IList<ItemFields> amenities = Component.EmbeddedValues("pod-list");
                                foreach (ItemFields amenity in amenities)
                                {
                                    xml.WriteStartElement("pod");
                                    xml.WriteAttributeString("text", amenity.StringValue("text"));
                                    xml.WriteAttributeString("image", PublishBinary(amenity.ComponentValue("image")));
                                    xml.WriteAttributeString("imagetitle", amenity.ComponentValue("image").StringMetaValue("altText"));

                                    if (amenity.ComponentValue("fcomponentLink") != null)
                                    {
                                        xml.WriteAttributeString("componentLink", amenity.ComponentValue("fcomponentLink").Id);
                                    }
                                    else if (amenity.ExternalLinkValue("fexternalLink") != null)
                                    {
                                        xml.WriteAttributeString("externalLink", amenity.ExternalLinkValue("fexternalLink"));
                                    }

                                    xml.WriteEndElement();//amenity
                                }
                            }






                            if (Component.EmbeddedValue("social") != null)
                            {
                                ItemFields social = Component.EmbeddedValue("social");
                                xml.WriteStartElement("social");
                                xml.WriteAttributeString("facebookKey", social.ExternalLinkValue("facebookKey"));
                                xml.WriteAttributeString("youtubeKey", social.StringValue("youtubeKey"));
                                xml.WriteAttributeString("instagramID", social.StringValue("instagramID"));
                                xml.WriteAttributeString("instagramKey", social.NumberValue("instagramKey").ToString());
                                xml.WriteAttributeString("instagramToken", social.StringValue("instagramToken"));
                                xml.WriteAttributeString("twitterKey", social.StringValue("twitterKey"));
                                xml.WriteAttributeString("twitterToken", social.StringValue("twitterToken"));
                                xml.WriteEndElement();//social
                            }


                            xml.WriteEndElement();//item
                        }




                        /* Emaar - Market Entity */

                        if (Component.Schema.Title.Equals("Emaar - Market Community"))
                        {
                            xml.WriteStartElement("item");

                            xml.WriteAttributeString("uri", Component.Id);
                            xml.WriteAttributeString("id", itemId.Split('-')[1]);
                            xml.WriteAttributeString("schema", Component.Schema.Title.Split('-')[1].TrimStart());

                            xml.WriteAttributeString("title", Component.StringValue("title"));
                            xml.WriteAttributeString("heading", Component.StringValue("heading"));
                            xml.WriteAttributeString("description", Component.StringValue("description"));

             
                            if (Component.StringValue("pod-heading") != "")
                            {
                                xml.WriteAttributeString("pod-heading", Component.StringValue("pod-heading"));
                            }
                            if (Component.EmbeddedValue("map-parameters") != null)
                            {
                                ItemFields map = Component.EmbeddedValue("map-parameters");
                                xml.WriteAttributeString("data-name", map.StringValue("data-name"));
                                xml.WriteAttributeString("data-lat", map.StringValue("data-lat"));
                                xml.WriteAttributeString("data-lng", map.StringValue("data-lng"));
                            }

                            OrganizationalItem parentFolder = Component.OrganizationalItem.OrganizationalItem;

                            if (Component.EmbeddedValues("links") != null)
                            {
                                IList<ItemFields> links = Component.EmbeddedValues("links");
                                foreach (ItemFields link in links)
                                {
                                    xml.WriteStartElement("link");
                                    xml.WriteAttributeString("flinkText", link.StringValue("flinkText"));
                                    if (link.ComponentValue("fcomponentLink") != null)
                                    {
                                        xml.WriteAttributeString("fcomponentLink", link.ComponentValue("fcomponentLink").Id);
                                    }
                                    if (link.ExternalLinkValue("fexternalLink") != null)
                                    {
                                        xml.WriteAttributeString("fexternalLink", link.ExternalLinkValue("fexternalLink"));
                                    }
                                    if (link.ComponentValue("pdf") != null)
                                    {
                                        xml.WriteAttributeString("pdf", PublishBinary(link.ComponentValue("pdf")));
                                    }
                                    xml.WriteEndElement();//link
                                }

                            }


                                    parentFolder = Component.OrganizationalItem;


                            IList<Component> compList = parentFolder.Components(true);

                            foreach (Component comp in compList)
                            {
                                //if (checkshouldpublish(comp.OrganizationalItem.StringMetaValue("onlystaging")))
                                // {
                                if (comp.Schema.Title.Equals("Emaar - Property"))
                                {



                                    ICollection<PublishInfo> publishInfo = PublishEngine.GetPublishInfo(comp);
                                    bool isPublished = false;

                                    // if component published to the current  target

                                    if (engine.RenderMode == RenderMode.Publish)
                                    {
                                        foreach (PublishInfo info in publishInfo)
                                        {
                                            if (info.Publication.Id.ItemId == comp.Id.PublicationId)
                                            {
                                                if (engine.PublishingContext.PublicationTarget.Title.Equals(info.PublicationTarget.Title))
                                                {
                                                    isPublished = true;
                                                }
                                            }

                                        }
                                    }


                                    if (isPublished)
                                    {
                                        xml.WriteStartElement("property");
                                        xml.WriteAttributeString("number", comp.OrganizationalItem.Title.Substring(0, 3));
                                        xml.WriteAttributeString("propertyId", comp.Id);
                                        xml.WriteAttributeString("name", comp.StringValue("name"));

                                        if (comp.ComponentValue("image") != null)
                                        {
                                            xml.WriteAttributeString("thumb", PublishBinary(comp.ComponentValue("image")));
                                            xml.WriteAttributeString("imagetitle", comp.ComponentValue("image").StringMetaValue("altText"));
                                        }
                                        xml.WriteEndElement();//property

                                    }


                                }
                                // }
                            }


                            if (Component.EmbeddedValues("pod-list") != null)
                            {
                                IList<ItemFields> amenities = Component.EmbeddedValues("pod-list");
                                foreach (ItemFields amenity in amenities)
                                {
                                    xml.WriteStartElement("pod");
                                    xml.WriteAttributeString("text", amenity.StringValue("text"));
                                    xml.WriteAttributeString("image", PublishBinary(amenity.ComponentValue("image")));
                                    xml.WriteAttributeString("imagetitle", amenity.ComponentValue("image").StringMetaValue("altText"));

                                    if (amenity.ComponentValue("fcomponentLink") != null)
                                    {
                                        xml.WriteAttributeString("componentLink", amenity.ComponentValue("fcomponentLink").Id);
                                    }
                                    else if (amenity.ExternalLinkValue("fexternalLink") != null)
                                    {
                                        xml.WriteAttributeString("externalLink", amenity.ExternalLinkValue("fexternalLink"));
                                    }

                                    xml.WriteEndElement();//amenity
                                }
                            }

                            if (Component.EmbeddedValue("social") != null)
                            {
                                ItemFields social = Component.EmbeddedValue("social");
                                xml.WriteStartElement("social");
                                xml.WriteAttributeString("facebookKey", social.ExternalLinkValue("facebookKey"));
                                xml.WriteAttributeString("youtubeKey", social.StringValue("youtubeKey"));
                                xml.WriteAttributeString("instagramID", social.StringValue("instagramID"));
                                xml.WriteAttributeString("instagramKey", social.NumberValue("instagramKey").ToString());
                                xml.WriteAttributeString("instagramToken", social.StringValue("instagramToken"));
                                xml.WriteAttributeString("twitterKey", social.StringValue("twitterKey"));
                                xml.WriteAttributeString("twitterToken", social.StringValue("twitterToken"));
                                xml.WriteEndElement();//social
                            }


                            xml.WriteEndElement();//item
                        }


                        if (Component.Schema.Title.Equals("Emaar - Market Entity"))
                        {

                            xml.WriteStartElement("item");

                            xml.WriteAttributeString("uri", Component.Id);
                            xml.WriteAttributeString("id", itemId.Split('-')[1]);
                            xml.WriteAttributeString("schema", Component.Schema.Title.Split('-')[1].TrimStart());

                            xml.WriteAttributeString("title", Component.StringValue("title"));
                            xml.WriteAttributeString("heading", Component.StringValue("heading"));
                            xml.WriteAttributeString("description", Component.StringValue("description"));
                            if (Component.ComponentValue("brochure") != null)
                            {
                                xml.WriteAttributeString("brochure", PublishBinary(Component.ComponentValue("brochure")));
                            }

                            if (Component.ComponentValue("mapimage") != null)
                            {
                                xml.WriteAttributeString("mapimage", PublishBinary(Component.ComponentValue("mapimage")));
                            }


                            if (Component.EmbeddedValues("links") != null)
                            {
                                IList<ItemFields> links = Component.EmbeddedValues("links");
                                foreach (ItemFields link in links)
                                {
                                    xml.WriteStartElement("link");
                                    xml.WriteAttributeString("flinkText", link.StringValue("flinkText"));
                                    if (link.ComponentValue("fcomponentLink") != null)
                                    {
                                        xml.WriteAttributeString("fcomponentLink", link.ComponentValue("fcomponentLink").Id);
                                    }
                                    if (link.ExternalLinkValue("fexternalLink") != null)
                                    {
                                        xml.WriteAttributeString("fexternalLink", link.ExternalLinkValue("fexternalLink"));
                                    }
                                    if (link.ComponentValue("pdf") != null)
                                    {
                                        xml.WriteAttributeString("pdf", PublishBinary(link.ComponentValue("pdf")));
                                    }
                                    xml.WriteEndElement();//link
                                }

                            }


                            if (Component.EmbeddedValue("social") != null)
                            {
                                ItemFields social = Component.EmbeddedValue("social");
                                xml.WriteStartElement("social");
                                xml.WriteAttributeString("facebookKey", social.ExternalLinkValue("facebookKey"));
                                xml.WriteAttributeString("youtubeKey", social.StringValue("youtubeKey"));
                                xml.WriteAttributeString("instagramID", social.StringValue("instagramID"));
                                xml.WriteAttributeString("instagramKey", social.NumberValue("instagramKey").ToString());
                                xml.WriteAttributeString("instagramToken", social.StringValue("instagramToken"));
                                xml.WriteAttributeString("twitterKey", social.StringValue("twitterKey"));
                                xml.WriteAttributeString("twitterToken", social.StringValue("twitterToken"));
                                xml.WriteEndElement();//social
                            }


                            xml.WriteEndElement();//item
                        }








                        /* End of Emaar - Community  DCP*/

                        /* Start of Emaar - Entity DCP */


                        if (Component.Schema.Title.Equals("Emaar - Entity"))
                        {

                            xml.WriteStartElement("item");

                            xml.WriteAttributeString("uri", Component.Id);
                            xml.WriteAttributeString("id", itemId.Split('-')[1]);
                            xml.WriteAttributeString("schema", Component.Schema.Title.Split('-')[1].TrimStart());

                            xml.WriteAttributeString("title", Component.StringValue("title"));
                            xml.WriteAttributeString("heading", Component.StringValue("heading"));
                            xml.WriteAttributeString("description", Component.StringValue("description"));
                            if (Component.ExternalLinkValue("video") != null)
                            {
                                xml.WriteAttributeString("video", Component.ExternalLinkValue("video"));
                            }
                            if (Component.ComponentValue("pod-heading") != null)
                            {
                                xml.WriteAttributeString("pod-heading", Component.StringValue("pod-heading"));
                            }


                            if (Component.ExternalLinkValue("website") != null)
                            {
                                xml.WriteAttributeString("website", Component.ExternalLinkValue("website"));
                            }
                            if (Component.ComponentValue("brochure") != null)
                            {
                                xml.WriteAttributeString("brochure", PublishBinary(Component.ComponentValue("brochure")));
                            }
                            if (Component.EmbeddedValue("map-parameters") != null)
                            {
                                ItemFields map = Component.EmbeddedValue("map-parameters");
                                xml.WriteAttributeString("data-name", map.StringValue("data-name"));
                                xml.WriteAttributeString("data-lat", map.StringValue("data-lat"));
                                xml.WriteAttributeString("data-lng", map.StringValue("data-lng"));
                            }

                            OrganizationalItem parentFolder = Component.OrganizationalItem.OrganizationalItem;

                            xml.WriteAttributeString("countryId", parentFolder.Id);
                            xml.WriteAttributeString("country", parentFolder.StringMetaValue("value"));

                            if (Component.EmbeddedValues("links") != null)
                            {
                                IList<ItemFields> links = Component.EmbeddedValues("links");
                                foreach (ItemFields link in links)
                                {
                                    xml.WriteStartElement("link");
                                    xml.WriteAttributeString("flinkText", link.StringValue("flinkText"));
                                    if (link.ComponentValue("fcomponentLink") != null)
                                    {
                                        xml.WriteAttributeString("fcomponentLink", link.ComponentValue("fcomponentLink").Id);
                                    }
                                    if (link.ExternalLinkValue("fexternalLink") != null)
                                    {
                                        xml.WriteAttributeString("fexternalLink", link.ExternalLinkValue("fexternalLink"));
                                    }
                                    if (link.ComponentValue("pdf") != null)
                                    {
                                        xml.WriteAttributeString("pdf", PublishBinary(link.ComponentValue("pdf")));
                                    }
                                    xml.WriteEndElement();//link
                                }

                            }

                            parentFolder = Component.OrganizationalItem;

                            IList<Component> compList = parentFolder.Components(true);
                            foreach (Component comp in compList)
                            {
                                if (comp.Schema.Title.Equals("Emaar - Entity") && comp.Id != Component.Id)
                                {
                                    xml.WriteStartElement("entity");
                                    xml.WriteAttributeString("entityId", comp.Id);
                                    xml.WriteAttributeString("entityTitle", comp.StringValue("title"));
                                    if (comp.ComponentValue("image") != null)
                                    {
                                        xml.WriteAttributeString("thumb", PublishBinary(comp.ComponentValue("image")));
                                    }
                                    xml.WriteEndElement();//property
                                }
                            }

                            if (Component.EmbeddedValues("pod-list") != null)
                            {
                                IList<ItemFields> amenities = Component.EmbeddedValues("pod-list");
                                foreach (ItemFields amenity in amenities)
                                {
                                    xml.WriteStartElement("pod");
                                    xml.WriteAttributeString("text", amenity.StringValue("text"));
                                    xml.WriteAttributeString("image", PublishBinary(amenity.ComponentValue("image")));
                                    xml.WriteEndElement();//amenity
                                }
                            }

                            if (Component.EmbeddedValue("social") != null)
                            {
                                ItemFields social = Component.EmbeddedValue("social");
                                xml.WriteStartElement("social");
                                xml.WriteAttributeString("facebookKey", social.ExternalLinkValue("facebookKey"));
                                xml.WriteAttributeString("youtubeKey", social.StringValue("youtubeKey"));
                                xml.WriteAttributeString("instagramID", social.StringValue("instagramID"));
                                xml.WriteAttributeString("instagramKey", social.NumberValue("instagramKey").ToString());
                                xml.WriteAttributeString("instagramToken", social.StringValue("instagramToken"));
                                xml.WriteAttributeString("twitterKey", social.StringValue("twitterKey"));
                                xml.WriteAttributeString("twitterToken", social.StringValue("twitterToken"));
                                xml.WriteEndElement();//social
                            }


                            xml.WriteEndElement();//item
                        }



                        /* End of Emaar - Entity  DCP*/

                        /* Start of Emaar - Property Launch DCP */


                        if (Component.Schema.Title.Equals("Emaar - Property Launch"))
                        {

                            xml.WriteStartElement("item");
                            xml.WriteAttributeString("uri", Component.Id);
                            xml.WriteAttributeString("id", itemId.Split('-')[1]);
                            xml.WriteAttributeString("schema", Component.Schema.Title.Split('-')[1].TrimStart());

                            xml.WriteAttributeString("downlaodbrochuretext", Component.StringValue("downloadbrochure"));

                            if (Component.StringValue("title") != null)
                            {
                                xml.WriteAttributeString("title ", Component.StringValue("title"));
                            }
                            if (Component.StringValue("heading") != null)
                            {
                                xml.WriteAttributeString("heading ", Component.StringValue("heading"));
                            }
                            if (Component.StringValue("intro") != null)
                            {
                                xml.WriteAttributeString("intro ", Component.XHTMLValue("intro"));
                            }





                            if (Component.ComponentValue("logo") != null)
                            {
                                xml.WriteAttributeString("logo", PublishBinary(Component.ComponentValue("logo")));
                            }
                            //if (Component.ComponentValue("brochure") != null)
                            //{
                            //    xml.WriteAttributeString("brochure", PublishBinary(Component.ComponentValue("brochure")));
                            //}


                            if (!string.IsNullOrEmpty(Component.StringValue("linktopbutton")))
                            {
                                xml.WriteAttributeString("linktopbutton", Component.StringValue("linktopbutton"));
                            }

                            if (Component.EmbeddedValues("brochurelinks") != null)
                            {

                                IList<ItemFields> brochurelinkslist = Component.EmbeddedValues("brochurelinks");
                                foreach (ItemFields brochurelinks in brochurelinkslist)
                                {

                                    xml.WriteStartElement("brochurelinks");
                                    if (brochurelinks != null)
                                    {
                                        if (brochurelinks.StringValue("flinkText") != "")
                                        {
                                            xml.WriteAttributeString("flinkText", brochurelinks.StringValue("flinkText"));
                                        }

                                        if (brochurelinks.ComponentValue("fcomponentLink") != null)
                                        {
                                            xml.WriteAttributeString("fcomponentLink", brochurelinks.ComponentValue("fcomponentLink").Id);
                                        }
                                        if (brochurelinks.ExternalLinkValue("fexternalLink") != null)
                                        {
                                            xml.WriteAttributeString("fexternalLink", brochurelinks.ExternalLinkValue("fexternalLink"));
                                        }
                                        if (brochurelinks.ComponentValue("pdf") != null)
                                        {
                                            xml.WriteAttributeString("pdf", PublishBinary(brochurelinks.ComponentValue("pdf")));
                                        }
                                    }
                                    xml.WriteEndElement();



                                }

                            }




                            if (Component.EmbeddedValues("register") != null)
                            {
                                //ItemFields reglink = Component.EmbeddedValue("register");

                                IList<ItemFields> registerlist = Component.EmbeddedValues("register");
                                foreach (ItemFields register in registerlist)
                                {
                                    xml.WriteStartElement("register");
                                    if (register != null)
                                    {
                                        if (register.StringValue("flinkText") != "")
                                        {
                                            xml.WriteAttributeString("flinkText", register.StringValue("flinkText"));
                                        }

                                        if (register.ComponentValue("fcomponentLink") != null)
                                        {
                                            xml.WriteAttributeString("fcomponentLink", register.ComponentValue("fcomponentLink").Id);
                                        }
                                        if (register.ExternalLinkValue("fexternalLink") != null)
                                        {
                                            xml.WriteAttributeString("fexternalLink", register.ExternalLinkValue("fexternalLink"));
                                        }
                                        if (register.ComponentValue("pdf") != null)
                                        {
                                            xml.WriteAttributeString("pdf", PublishBinary(register.ComponentValue("pdf")));
                                        }
                                    }
                                    xml.WriteEndElement();
                                }

                            }

                            IList<ItemFields> features = Component.EmbeddedValues("feature");
                            foreach (ItemFields feature in features)
                            {
                                xml.WriteStartElement("feature");
                                xml.WriteAttributeString("type ", feature.KeywordValue("type").Key);
                                //if (feature.ComponentValue("youtubelink") != null)
                                xml.WriteAttributeString("youtubelink ", feature.StringValue("youtubelink"));
                                xml.WriteAttributeString("Youtubefullview ", feature.StringValue("Youtubefullview"));

                                if (feature.ComponentValue("mapimage") != null)
                                    xml.WriteAttributeString("mapimage ", PublishBinary(feature.ComponentValue("mapimage")));
                                
                                if (feature.ComponentValue("mappdf") != null)
                                    xml.WriteAttributeString("mappdf ", PublishBinary(feature.ComponentValue("mappdf")));


                                if (feature.StringValue("title") != null)
                                {
                                    xml.WriteAttributeString("title ", feature.StringValue("title"));
                                }
                                if (feature.StringValue("description") != null)
                                {
                                    xml.WriteAttributeString("description ", feature.StringValue("description"));
                                }

                                if (feature.ComponentValues("gallery") != null)
                                {
                                    IList<Component> list = feature.ComponentValues("gallery");
                                    foreach (Component imageComp in list)
                                    {
                                        xml.WriteStartElement("image");
                                        if (imageComp != null)
                                        {
                                            xml.WriteAttributeString("src", PublishBinary(imageComp));
                                            xml.WriteAttributeString("altText", imageComp.StringMetaValue("altText"));
                                        }
                                        xml.WriteEndElement();//image
                                    }
                                }


                                
                                


                                xml.WriteEndElement();//feature

                            }


                            xml.WriteStartElement("floorplan");
                            
                            
                                    if (Component.EmbeddedValues("floorplans") != null)
                                    {
                                        IList<ItemFields> floorplans = Component.EmbeddedValues("floorplans");
                                        foreach (ItemFields floorplan in floorplans)
                                        {
                                            IList<Component> imagelist = floorplan.ComponentValues("image");
                                            foreach (Component imageComp in imagelist)
                                            {
                                                xml.WriteStartElement("largeimage");
                                                    xml.WriteAttributeString("src", GenerateThumbnail(imageComp, "floorlarge", 442, 499));

                                                    xml.WriteAttributeString("dataimage", PublishBinary(imageComp));

                                                    xml.WriteAttributeString("type", floorplan.StringValue("type"));
                                                xml.WriteEndElement();//image

                                            }

                                        }
                                    }

                            xml.WriteEndElement();//floorplan




                            xml.WriteEndElement();//item
                        }


                        /* End of Emaar - Property Launch  DCP*/

                        /* Start of Emaar - News DCP */



                        if (Component.Schema.Title.Equals("Emaar - News"))
                        {

                            xml.WriteStartElement("item");
                            xml.WriteAttributeString("uri", Component.Id);
                            xml.WriteAttributeString("id", itemId.Split('-')[1]);
                            xml.WriteAttributeString("schema", Component.Schema.Title.Split('-')[1].TrimStart());

                            xml.WriteAttributeString("title", Component.StringValue("title"));
                            xml.WriteAttributeString("detail", Component.StringValue("detail"));
                            xml.WriteAttributeString("description", Component.StringValue("description"));
                            xml.WriteAttributeString("image", PublishBinary(Component.ComponentValue("image")));
                            if (Component.ComponentValue("popup") != null)
                                xml.WriteAttributeString("popup", PublishBinary(Component.ComponentValue("popup")));
                            else
                                xml.WriteAttributeString("popup", PublishBinary(Component.ComponentValue("image")));
                            xml.WriteAttributeString("style", Component.StringMetaValue("style"));
                            if (Component.EmbeddedValue("link") != null)
                            {
                                ItemFields link = Component.EmbeddedValue("link");
                                if (link.ComponentValue("componentLink") != null)
                                {
                                    xml.WriteAttributeString("linkText", link.StringValue("flinkText"));
                                    xml.WriteAttributeString("componentLink", link.ComponentValue("fcomponentLink").Id);
                                }
                                else if (link.ExternalLinkValue("fexternalLink") != null)
                                {
                                    xml.WriteAttributeString("linkText", link.StringValue("flinkText"));
                                    xml.WriteAttributeString("externalLink", link.ExternalLinkValue("fexternalLink"));
                                }
                            }
                            string strpublishDate = DateTime.Now.ToString("dd/MM/yyyy");
                            DateTime publishDate = Component.DateMetaValue("publishDate");
                            if (publishDate.ToString("dd/MM/yyyy") != "01/01/0001")
                            {
                                strpublishDate = publishDate.ToString("dd/MM/yyyy");
                            }
                            xml.WriteAttributeString("publishDate", strpublishDate);
                            xml.WriteAttributeString("sortDate", GetSortDate(strpublishDate));
                            xml.WriteAttributeString("year", GetSortDate(strpublishDate).Substring(0, 4));

                            xml.WriteEndElement();//item
                        }



                        /* End of Emaar - News  DCP*/

                        /* Start of Emaar - Quote DCP */


                        if (Component.Schema.Title.Equals("Emaar - Quote"))
                        {

                            xml.WriteStartElement("item");
                            xml.WriteAttributeString("uri", Component.Id);
                            xml.WriteAttributeString("id", itemId.Split('-')[1]);
                            xml.WriteAttributeString("schema", Component.Schema.Title.Split('-')[1].TrimStart());

                            xml.WriteAttributeString("title", Component.StringValue("title"));
                            xml.WriteAttributeString("name", Component.StringValue("name"));
                            xml.WriteAttributeString("info", Component.StringValue("info"));
                            xml.WriteAttributeString("style", Component.StringMetaValue("style"));

                            string strpublishDate = DateTime.Now.ToString("dd/MM/yyyy");
                            DateTime publishDate = Component.DateMetaValue("publishDate");
                            if (publishDate.ToString("dd/MM/yyyy") != "01/01/0001")
                            {
                                strpublishDate = publishDate.ToString("dd/MM/yyyy");
                            }
                            xml.WriteAttributeString("publishDate", strpublishDate);
                            xml.WriteAttributeString("sortDate", GetSortDate(strpublishDate));
                            xml.WriteAttributeString("year", GetSortDate(strpublishDate).Substring(0, 4));

                            xml.WriteEndElement();//item
                        }

                        /* End of Emaar - Quote DCP */

                        /* Start of Emaar - LifestyleNews DCP */
                        if (Component.Schema.Title.Equals("Emaar - LifestyleNews"))
                        {

                            xml.WriteStartElement("item");
                            xml.WriteAttributeString("uri", Component.Id);
                            xml.WriteAttributeString("id", itemId.Split('-')[1]);
                            xml.WriteAttributeString("schema", Component.Schema.Title.Split('-')[1].TrimStart());

                            xml.WriteAttributeString("title", Component.StringValue("title"));
                            xml.WriteAttributeString("detail", Component.StringValue("detail"));
                            xml.WriteAttributeString("description", Component.StringValue("description"));
                            xml.WriteAttributeString("image", PublishBinary(Component.ComponentValue("image")));
                            //if (Component.ComponentValue("popup") != null)
                            //    xml.WriteAttributeString("popup", PublishBinary(Component.ComponentValue("popup")));
                            //else
                            //    xml.WriteAttributeString("popup", PublishBinary(Component.ComponentValue("image")));
                            xml.WriteAttributeString("style", Component.StringMetaValue("style"));
                            if (Component.EmbeddedValue("link") != null)
                            {
                                ItemFields link = Component.EmbeddedValue("link");
                                if (link.ComponentValue("fcomponentLink") != null)
                                {
                                    xml.WriteAttributeString("linkText", link.StringValue("flinkText"));
                                    xml.WriteAttributeString("componentLink", link.ComponentValue("fcomponentLink").Id);
                                }
                                else if (link.ExternalLinkValue("fexternalLink") != null)
                                {
                                    xml.WriteAttributeString("linkText", link.StringValue("flinkText"));
                                    xml.WriteAttributeString("externalLink", link.ExternalLinkValue("fexternalLink"));
                                }
                            }
                            string strpublishDate = DateTime.Now.ToString("dd/MM/yyyy");
                            DateTime publishDate = Component.DateMetaValue("publishDate");
                            if (publishDate.ToString("dd/MM/yyyy") != "01/01/0001")
                            {
                                strpublishDate = publishDate.ToString("dd/MM/yyyy");
                            }
                            xml.WriteAttributeString("publishDate", strpublishDate);
                            xml.WriteAttributeString("sortDate", GetSortDate(strpublishDate));
                            xml.WriteAttributeString("year", GetSortDate(strpublishDate).Substring(0, 4));

                            xml.WriteEndElement();//item
                        }
                        /* End of Emaar - LifestyleNews DCP */


                        /* Start of Emaar - LifestyleQuote DCP */
                        if (Component.Schema.Title.Equals("Emaar - LifestyleQuote"))
                        {

                            xml.WriteStartElement("item");
                            xml.WriteAttributeString("uri", Component.Id);
                            xml.WriteAttributeString("id", itemId.Split('-')[1]);
                            xml.WriteAttributeString("schema", Component.Schema.Title.Split('-')[1].TrimStart());

                            xml.WriteAttributeString("title", Component.StringValue("title"));
                            xml.WriteAttributeString("name", Component.StringValue("name"));
                            xml.WriteAttributeString("info", Component.StringValue("info"));
                            xml.WriteAttributeString("style", Component.StringMetaValue("style"));

                            if (Component.EmbeddedValue("link") != null)
                            {
                                ItemFields link = Component.EmbeddedValue("link");
                                if (link.ComponentValue("fcomponentLink") != null)
                                {
                                    xml.WriteAttributeString("linkText", link.StringValue("flinkText"));
                                    xml.WriteAttributeString("componentLink", link.ComponentValue("fcomponentLink").Id);
                                }
                                else if (link.ExternalLinkValue("fexternalLink") != null)
                                {
                                    xml.WriteAttributeString("linkText", link.StringValue("flinkText"));
                                    xml.WriteAttributeString("externalLink", link.ExternalLinkValue("fexternalLink"));
                                }
                            }
                            string strpublishDate = DateTime.Now.ToString("dd/MM/yyyy");
                            DateTime publishDate = Component.DateMetaValue("publishDate");
                            if (publishDate.ToString("dd/MM/yyyy") != "01/01/0001")
                            {
                                strpublishDate = publishDate.ToString("dd/MM/yyyy");
                            }
                            xml.WriteAttributeString("publishDate", strpublishDate);
                            xml.WriteAttributeString("sortDate", GetSortDate(strpublishDate));
                            xml.WriteAttributeString("year", GetSortDate(strpublishDate).Substring(0, 4));

                            xml.WriteEndElement();//item
                        }
                        /* End of Emaar - LifestyleQuote DCP */
                        Package.AddXml(Package.OutputName, sw.ToString());
                    }
                }
            }
        }





        private static string getHtml(string html)
        {
            return Utility.removeXHTMLtags(html);
        }


        private string GetSortDate(string strDate)
        {

            string strRetval = "";


            string[] datetime = strDate.Split(new char[] { '/' });

            string Year = datetime[2];
            string Month = datetime[1];
            string Day = datetime[0];

            if (Month.Length == 1)
                Month = "0" + Month;

            if (Day.Length == 1)
                Day = "0" + Day;

            strRetval = Year + Month + Day;

            return strRetval;

        }

        public bool checkshouldpublish(string metaval)
        {
            bool shouldadd = true;
            if (Engine.PublishingContext.PublicationTarget.Id.ToString() == "tcm:0-16-65537")
            {
                if (metaval == "Yes")
                    shouldadd = false;
            }
            return shouldadd;
        }


        public string GetYouTubeImage(string videoUrl)
        {
            int mInd = videoUrl.IndexOf("/v/");
            if (mInd < 0) { mInd = videoUrl.IndexOf("?v="); }
            if (mInd != -1)
            {
                string strVideoCode = videoUrl.Substring(videoUrl.IndexOf("?v=") + 3);
                int ind = strVideoCode.IndexOf("?");
                strVideoCode = strVideoCode.Substring(0, ind == -1 ? strVideoCode.Length : ind);
                return "https://img.youtube.com/vi/" + strVideoCode + "/hqdefault.jpg";
            }
            else
                return "not provided";
        }

        private string getrawtext(string val)
        {

            string strfulldesc = string.Empty;

            strfulldesc = val.Replace("<br/>", "");
            strfulldesc = strfulldesc.Replace("<br xmlns=\"http://www.w3.org/1999/xhtml\" />", "");


            strfulldesc = "<content>" + strfulldesc + "</content>";
            XmlDocument doc = new XmlDocument();
            doc.LoadXml(strfulldesc);

            strfulldesc = doc.InnerText;
            strfulldesc = Regex.Replace(strfulldesc, @"\t|\n|\r", "");
            strfulldesc = Regex.Replace(strfulldesc, "\"[^\"]*\"", string.Empty);


            return strfulldesc;

        }


    }
}
