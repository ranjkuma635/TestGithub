﻿using System;
using System.Linq;
using System.Xml;
using System.IO;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.Extensions.ContentManager.Templating;
using Emaar.Web.Tridion.System.Extensions;
using Tridion.ContentManager.Publishing.Rendering;
using Tridion.ContentManager;
using Tridion.ContentManager.ContentManagement;
using Tridion.ContentManager.CommunicationManagement;
using System.Text.RegularExpressions;
using System.Collections.Generic;
using Tridion.ContentManager.ContentManagement.Fields;

namespace EMR.Web.Templating.BuildingBlocks.Templates
{
    [TcmTemplateTitle("Onlinesales")]
    public class  Onlinesales : TemplateBase 
    {
        public override void Transform(Engine engine, Package package)
        {
            base.Transform(engine, package);

            string pubURL = "";
            string pubURLThumb = "";

            if (engine.PublishingContext.PublicationTarget.Title.ToString().ToUpper().Contains("STAGING"))
            {
                pubURL = "http://staging.emaartridion.com";
            }
            else
            {
                pubURL = "http://www.emaar.com";
            }
            using (StringWriter sw = new StringWriter())
            {
                using (XmlTextWriter xml = new XmlTextWriter(sw))
                {

                    base.Transform(engine, package);
                    string itemId = Component.Id;

                    if (Component != null)
                    {

                        xml.WriteStartElement("OnlineSales");

                        xml.WriteElementString("Launchname", Component.StringValue("Launchname"));

                        xml.WriteElementString("Registrationstartdate", Component.DateValue("Registrationstartdate").ToString());
                        xml.WriteElementString("Registrationenddate", Component.DateValue("Registrationenddate").ToString());

                        xml.WriteElementString("Communityname", Component.StringValue("communityname"));


                        xml.WriteElementString("Launchstratdatetime", Component.DateValue("Launchstratdatetime").ToString() );
                        xml.WriteElementString("Launchenddatetime", Component.DateValue("Launchenddatetime").ToString());

                        if (Component.ComponentValue("Bannerimage") != null)
                        {
                            xml.WriteElementString("Bannerimage", pubURL + PublishBinary(Component.ComponentValue("Bannerimage")));
                        }

                        if (Component.ComponentValue("MasterPlanImage") != null)
                        {
                            xml.WriteElementString("MasterPlanImage", pubURL + PublishBinary(Component.ComponentValue("MasterPlanImage")));
                        }

                        xml.WriteElementString("EventDescription", Component.StringValue("EventDescription"));

                        xml.WriteElementString("CounterVisibleText", Component.StringValue("CounterVisibleText"));

                        xml.WriteElementString("EventClosedText", Component.XHTMLValue("EventClosedText"));

                        xml.WriteElementString("PropertyLockedText", Component.XHTMLValue("PropertyLockedText"));

                        xml.WriteElementString("MultiplePurchaseMessage", Component.XHTMLValue("MultiplePurchaseMessage"));

                        xml.WriteElementString("PropertyAlreadySoldMessage", Component.XHTMLValue("PropertyAlreadySoldMessage"));

                            xml.WriteStartElement("FloorPlans");

                            ItemFields fields = new ItemFields(Component.Content, Component.Schema);
                            EmbeddedSchemaField emb = (EmbeddedSchemaField)fields["Floorplans"];
                            
                            foreach (ItemFields embeddedfields in emb.Values)
                            {

                                xml.WriteStartElement("FloorPlan");

                                xml.WriteElementString("UnitType", embeddedfields.StringValue("UnitType"));
                                xml.WriteElementString("Bedrooms", embeddedfields.StringValue("Bedrooms"));


                                if (embeddedfields.ComponentValue("Image") != null)
                                {
                                    xml.WriteElementString("Image", pubURL + this.PublishBinary1(engine, package, embeddedfields.ComponentValue("Image"), 10103).Replace("\\","/"));
                                }
                                if (embeddedfields.ComponentValue("Pdf") != null)
                                {
                                    xml.WriteElementString("Pdf", pubURL + this.PublishBinary1(engine, package, embeddedfields.ComponentValue("Pdf"), 10103).Replace("\\", "/"));
                                }

                                xml.WriteEndElement();//FloorPlan
                            }


                        

                            xml.WriteEndElement();//FloorPlans

                            xml.WriteElementString("Termsandconditions", Component.XHTMLValue("Termsandconditions"));

                            xml.WriteElementString("Campaignname", Component.StringValue("Campaignname"));
                            xml.WriteElementString("Quotereferencedesc", Component.StringValue("Quotereferencedesc"));

                            xml.WriteElementString("Enableiphone", Component.StringValue("Enableiphone"));

                        


                        xml.WriteEndElement();//OnlineSales

                    }
                
                }

                Package.AddXml(Package.OutputName, sw.ToString());

            }
        }

        public string PublishBinary1(Engine engine, Package package, Component multimediaComponent, int sgID)
        {

            BinaryContent binaryContent = multimediaComponent.BinaryContent;
            Session session = engine.GetSession();
            TcmUri structureGroupUri = new TcmUri(sgID, ItemType.StructureGroup, 130);
            StructureGroup structureGroup = new StructureGroup(structureGroupUri, session);

            Binary binary = engine.PublishingContext.RenderedItem.AddBinary(multimediaComponent, structureGroup, Regex.Replace(binaryContent.Filename, "\\W", string.Empty));
            return binary.Path;
        }


    }
}
