﻿using System;
using System.Linq;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager;
using Tridion.ContentManager.ContentManagement;
using Tridion.Extensions.ContentManager.Templating;

namespace EMR.Web.Templating.BuildingBlocks.Templates
{
    [TcmTemplateTitle("Publish Attached DCP")]
    public class PublishDCP : TemplateBase
    {
        public override void Transform(Engine engine, Package package)
        {
            base.Transform(engine, package);
            //IComponentPresentationList componentPresentations = package.ItemAsComponentList(Package.ComponentsName);
            if (Page.ComponentPresentations.Count > 0)
            {
                Component component = Page.ComponentPresentations[0].Component;
                String schemaTitle = component.Schema.Title;
                if (component != null)
                {
                    switch (schemaTitle)
                    {
                        case "Emaar - Property":
                        case "Emaar - Community":
                        case "Emaar - Entity":
                        case "Emaar - Property Launch":
                        case "Emaar - PhotoAlbum":
                        case "Emaar - VideoAlbum":
                            engine.RenderComponentPresentation(component.Id, new TcmUri(45369, ItemType.ComponentTemplate, Publication.Id.ItemId));
                            break;
                        default:
                            break;
                    }

                }
            }
            
        }
    }
}
