﻿using System;
using System.Collections.Generic;
using System.Xml;
using Tridion.ContentManager.CommunicationManagement;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.ContentManagement;
using Emaar.Web.Tridion.System.Extensions;
using Emaar.Web.Tridion.System;


namespace DPEC.Web.Templating.BuildingBlocks.Templates {
   
    [TcmTemplateTitle("Page Variables")]
    public class PageVariables : PageVariablesTemplate  {

       private List<String> mIncludeFields;
       private List<String> mInheritedFields;

       public PageVariables(): base() {
            mIncludeFields = new List<String>();
            mIncludeFields.Add("fhideNavigation");
            mIncludeFields.Add("fhideFooter");
            mIncludeFields.Add("fSideBar");
            mIncludeFields.Add("fhideFromSearch");
            mIncludeFields.Add("fCarousels");
            mIncludeFields.Add("fAreaId");

            mInheritedFields = new List<String>();
            mInheritedFields.Add("fhideNavigation");
            mInheritedFields.Add("fhideFooter");
            mInheritedFields.Add("fSideBar");
            mInheritedFields.Add("fCarousels");
       }

       public override void Transform(Engine engine, Package package)
       {
           base.Transform(engine, package);

           /*string subtitle = PageSubTitle(Page);

           if (!String.IsNullOrEmpty(subtitle))
               Package.AddString("PageSubTitle", subtitle);
            * */
       }

        protected override string NavConfig() {
            return "fnavigationconf";
        }

        protected override bool IncludeMetadata(string FieldName) {
            return mIncludeFields.Contains(FieldName);
        }

        protected override bool InheritedMetadata(string FieldName) {
            return mInheritedFields.Contains(FieldName);
        }

        /// <summary>
        /// Returns wether the specified Schema should be used to generate a page title
        /// </summary>
        /// <returns></returns>
        protected override bool TitleTemplate(string Schema) {
            return true;
        }

        public string PageSubTitle(Page Page) {
            String subTitle = String.Empty;
            // Retrieve the Title field of the first Component
            if (Page.ComponentPresentations.Count > 0) {
                Component component = Page.ComponentPresentations[0].Component;

                if (component.Content != null && TitleTemplate(component.Schema.Title)) {
                    XmlNode xTitle = component.Content.SelectSingleNode("//node()[local-name() = 'title']");

                    if (xTitle != null && !String.IsNullOrEmpty(xTitle.InnerText)){
                        subTitle =  xTitle.InnerText;
                    }
                }
            }
            return subTitle;
        }
    }
}
