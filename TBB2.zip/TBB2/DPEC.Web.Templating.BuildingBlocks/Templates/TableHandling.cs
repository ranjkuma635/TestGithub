﻿using System;
using System.Linq;
using System.Xml;
using System.IO;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.Extensions.ContentManager.Templating;
using Emaar.Web.Tridion.System.Extensions;
using System.Collections.Generic;

namespace DPEC.Web.Templating.BuildingBlocks.Templates
{

    [TcmTemplateTitle("TableHandling")]
    public class TableHandling : TemplateBase
    {
        /// <summary>
        /// Transforms the current component.
        /// </summary>
        /// <param name="engine">The engine.</param>
        /// <param name="package">The package.</param>
        public override void Transform(Engine engine, Package package)
        {
            base.Transform(engine, package);

            using (StringWriter sw = new StringWriter())
            {

                using (XmlTextWriter xml = new XmlTextWriter(sw))
                {

                    if (Component != null && Component.StringValues("table") != null)
                    {

                        IList<String> tables = Component.StringValues("table");
                        XmlDocument doc = new XmlDocument();

                        foreach (String table in tables){

                            Logger.Info("table :" + table);

                            doc.LoadXml(table);
                            xml.WriteStartElement("table");
                            xml.WriteStartElement("tbody");
                            XmlNode tbody = doc.FirstChild.FirstChild;

                            xml.WriteStartElement("tr");

                            foreach (XmlNode th in tbody.FirstChild.ChildNodes)
                            {
                                xml.WriteElementString("th", th.InnerText);
                            }
                            xml.WriteEndElement();//thead
                            for (int i = 1; i < tbody.ChildNodes.Count; i++)
                            {
                                XmlNode tr = tbody.ChildNodes[i];
                                xml.WriteStartElement("tr");

                                for (int j = 0; j < tr.ChildNodes.Count; j++)
                                {
                                    XmlNode td = tr.ChildNodes[j];
                                    xml.WriteStartElement("td");
                                    xml.WriteAttributeString("data-title", tbody.FirstChild.ChildNodes[j].InnerText);
                                    if (td.Attributes["colspan"] != null)
                                    {
                                        xml.WriteAttributeString("colspan", td.Attributes["colspan"].Value);
                                    }
                                    if (!String.IsNullOrEmpty(td.OuterXml))
                                    {
                                        xml.WriteRaw(td.InnerXml);
                                    }
                                    xml.WriteEndElement();//td
                                }

                                xml.WriteEndElement();//tr
                            }
                            xml.WriteEndElement();//tbody
                            xml.WriteEndElement();//table
                        }
                    }
                    Package.AddXml("table", sw.ToString().Replace("&lt;br xmlns=\"http://www.w3.org/1999/xhtml\" /&gt;", "<br/>"));
                }
            }
        }

        private static string getHtml(string html)
        {
            return Utility.removeXHTMLtags(html);
        }


        private string GetSortDate(string strDate)
        {

            string strRetval = "";


            string[] datetime = strDate.Split(new char[] { '/' });

            string Year = datetime[2];
            string Month = datetime[1];
            string Day = datetime[0];

            if (Month.Length == 1)
                Month = "0" + Month;

            if (Day.Length == 1)
                Day = "0" + Day;

            strRetval = Year + Month + Day;

            return strRetval;

        }
    }
}