﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml;
using System.IO;
using Tridion.ContentManager;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.Extensions.ContentManager.Templating;
using Tridion.ContentManager.ContentManagement;
using Emaar.Web.Tridion.System.Extensions;

namespace DPEC.Web.Templating.BuildingBlocks.Templates
{
    [TcmTemplateTitle("Gallery")]
    public class Gallery : TemplateBase
    {
        /// <summary>
        /// Transforms the current component.
        /// </summary>
        /// <param name="engine">The engine.</param>
        /// <param name="package">The package.</param>
        public override void Transform(Engine engine, Package package)
        {
            int i = 1;
            int j = 1;

            base.Transform(engine, package);

            Engine m_Engine;
            m_Engine = engine;


            OrganizationalItem HotelsFolder = m_Engine.GetObject(Component.OrganizationalItem.Id) as OrganizationalItem;

            using (StringWriter sw = new StringWriter())
            {
                using (XmlTextWriter xml = new XmlTextWriter(sw))
                {
                    xml.WriteStartElement("list");

                    i = 1;
                    IList<Component> hotelsList = HotelsFolder.Components(true);
                    foreach (Component comp in hotelsList) {

                        if (comp.Schema.Title.Equals("DPEC - Image")){
                            Filter f = new Filter();
                            f.Conditions["ItemType"] = ItemType.Component;
                            string itemId = comp.Id;
                            xml.WriteStartElement("item");
                            xml.WriteAttributeString("index", i.ToString());
                            xml.WriteAttributeString("uri", comp.Id.ToString());
                            xml.WriteAttributeString("id", itemId.Split('-')[1]);
                            xml.WriteAttributeString("src", PublishBinary(comp));
                            xml.WriteAttributeString("altText", comp.StringMetaValue("altText"));
                            xml.WriteEndElement();//item
                            i++;
                        }
                    }
                    xml.WriteEndElement();
                }
                Package.AddXml(Package.OutputName, sw.ToString());
            }
        }
    }
}
