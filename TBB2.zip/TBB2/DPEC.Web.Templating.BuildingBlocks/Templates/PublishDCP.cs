﻿using System;
using System.Linq;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager;
using Tridion.ContentManager.ContentManagement;
using Emaar.Web.Tridion.System.Extensions;
using Tridion.Extensions.ContentManager.Templating;
using System.Collections.Generic;

namespace DPEC.Web.Templating.BuildingBlocks.Templates
{
    [TcmTemplateTitle("PublishBannerDCP")]
    public class PublishBannerDCP : TemplateBase
    {
        public override void Transform(Engine engine, Package package)
        {
            base.Transform(engine, package);
            Logger.Info("start :" + package.GetByName("PageVariable.fCarousels").ToString());
            IComponentPresentationList banner = engine.GetObject(package.GetByName("PageVariable.fCarousels")) as IComponentPresentationList;
            Logger.Info("Count :" + banner.Count);

           // Component component = banner[0].ComponentUri;
            Logger.Info("Component Title :" + banner[0].ComponentUri);
           // Logger.Info("Component Schema:" + component.Schema.Title);

            //ngine.RenderComponentPresentation(component.Id, new TcmUri(68437, ItemType.ComponentTemplate, component.Id.PublicationId));
           // package.AddString("BannerURI", component.Id.ToString());
                         
        }
    }
}
