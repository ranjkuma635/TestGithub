﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
using System.Web;
using Tridion.ContentManager;
using Tridion.ContentManager.CommunicationManagement;
using Tridion.ContentManager.ContentManagement;
using Tridion.ContentManager.ContentManagement.Fields;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.Publishing;
using Tridion.Extensions.ContentManager.Templating;
using Tridion.ContentManager.Publishing.Rendering;

namespace EGC.Web.Templating.BuildingBlocks
{
    class Getbackgroundimages : TemplateBase 
    {


        public override void Transform(Engine engine, Package package)
        {
            this.Initialize(engine, package);
            Page page = GetPage();
            m_Package.PushItem("LeftImage", m_Package.CreateStringItem(ContentType.Html, GetBackgroundImage("fLeftimage", page)));
            m_Package.PushItem("RightImage", m_Package.CreateStringItem(ContentType.Html, GetBackgroundImage("fRightimage", page)));
        }

        private string GetBackgroundImage(string strTrype, Page page)
        {
            string strHtml = string.Empty;
            string publishPath = "";
            ComponentLinkField BackgroundImage = null;

            if (page.Metadata != null)
            {
                ItemFields metadataFields = new ItemFields(page.Metadata, page.MetadataSchema);
                if (metadataFields.Count > 0)
                {
                    if (metadataFields[strTrype] != null)
                    {
                        try
                        {
                            BackgroundImage = (ComponentLinkField)metadataFields[strTrype];
                            Component comp = m_Engine.GetObject(BackgroundImage.Value.Id.ToString()) as Component;
                            Binary pubBinary = m_Engine.PublishingContext.RenderedItem.AddBinary(comp);
                            publishPath = pubBinary.Url;
                            strHtml = "background-image: url(" + publishPath + ");";
                        }
                        catch
                        {                       
                        }
                    }
                }
            }

            return strHtml;
        }
    }
}
