﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
using System.Web;
using Tridion.ContentManager;
using Tridion.ContentManager.CommunicationManagement;
using Tridion.ContentManager.ContentManagement;
using Tridion.ContentManager.ContentManagement.Fields;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.Publishing;
using Tridion.Extensions.ContentManager.Templating;
using Tridion.ContentManager.Publishing.Rendering;

namespace EGC.Web.Templating.BuildingBlocks
{
    class Navigations : TemplateBase
    {
        private XmlDocument navDoc = null;

        StringBuilder strNav = new StringBuilder();

        public override void Transform(Engine engine, Package package)
        {

            this.Initialize(engine, package);
            if (this.IsPage())
            {

                Publication publication = this.GetPublication();
                string rootSG = publication.RootStructureGroup.Id;

                strNav.Append("<Root>");

                strNav.Append(GetFirstLevelSG(rootSG));

                strNav.Append("</Root>");

            }
            m_Package.PushItem("Navigation", m_Package.CreateStringItem(ContentType.Html, strNav.ToString()));
        }


        private string GetFirstLevelSG(string strRootSGID)
        {

            StringBuilder strNavLoop = new StringBuilder();


            StructureGroup RootSG = m_Engine.GetObject(strRootSGID) as StructureGroup;

            Filter filter = new Filter();
            filter.Conditions["ItemType"] = ItemType.StructureGroup;

            Filter filterpages = new Filter();
            filterpages.Conditions["ItemType"] = ItemType.Page;


            IList<RepositoryLocalObject> listFistLevelStructureGroup = RootSG.GetItems(filter);
            StructureGroup SG;

            Page page;

            strNavLoop.Append("<node id = \"" + RootSG.Id.ToString() + "\"" + getIndexPage(RootSG.Id.ToString()) + "/>");

            foreach (RepositoryLocalObject RepositoryLocalObject in listFistLevelStructureGroup)
            {
                SG = m_Engine.GetObject(RepositoryLocalObject.Id) as StructureGroup;

                if (SG.Title.Contains("."))
                {
                    strNavLoop.Append("<node title = \"" + ReplaceCdata(SG.Title.ToString()) + "\" id = \"" + SG.Id.ToString() + "\"" + getIndexPage(SG.Id.ToString()) + ">");
                    IList<RepositoryLocalObject> listPages = SG.GetItems(filterpages);

                    foreach (RepositoryLocalObject RepositoryLocalObjectpages in listPages)
                    {
                        if (RepositoryLocalObjectpages.Title.Contains("."))
                        {
                            page = m_Engine.GetObject(RepositoryLocalObjectpages.Id) as Page;
                            strNavLoop.Append("<node pageid = \"" + page.Id.ToString() + "\"" +  getMetaDataValues(page)  + " name = \"" + ReplaceCdata(page.Title.ToString()) + "\"" + "/>");
                        }

                    }
                    strNavLoop.Append("</node>");
                }
            }

            return strNavLoop.ToString();

        }

        private string getIndexPage(string strSG)
        {
            Page page;
            bool FindIndx = false; 
            Filter filter = new Filter();
            filter.Conditions["ItemType"] = ItemType.Page;

            string strHTML = "";
            StructureGroup SG;
            SG = m_Engine.GetObject(strSG) as StructureGroup;

            IList<RepositoryLocalObject> listPages = SG.GetItems(filter);

            foreach (RepositoryLocalObject RepositoryLocalObjectpages in listPages)
            {
                if (RepositoryLocalObjectpages.Title.StartsWith("000"))
                {
                    page = m_Engine.GetObject(RepositoryLocalObjectpages.Id) as Page;
                    strHTML = " name = \"" + ReplaceCdata(page.Title.ToString()) + "\"  pageid = \"" + page.Id.ToString() + "\"" + getMetaDataValues(page) ;
                    FindIndx = true;
                }
            }

            if (FindIndx == false)
            {
                strHTML = getMetaDataValuesSG(strSG);
            }

            return strHTML;
        }

        private string getMetaDataValuesSG(string strSG)
        {
            string strFriendlyTitle;
            string strHtml = "";

            StructureGroup SG;
            SG = m_Engine.GetObject(strSG) as StructureGroup;
            strFriendlyTitle = SG.Title.Split('.')[1].ToString().Trim();
            
            if (SG.Metadata != null)
            {
                ItemFields metadataFields = new ItemFields(SG.Metadata, SG.MetadataSchema);

                if (!string.IsNullOrEmpty(metadataFields["ffriendlytitle"].ToString() ))
                {
                    strFriendlyTitle = ReplaceCdata(metadataFields["ffriendlytitle"].ToString()); 
                }
            }

            strHtml = " displaytitle = \"" + ReplaceCdata(strFriendlyTitle) + "\"";
            return  strHtml;
        }

        private string getMetaDataValues(Page page)
        {
            string strHtml = "";
            string strClass = "";
            string sURL = "#";
            string strFriendlyTitle = ReplaceCdata(page.Title.Split('.')[1].ToString().Trim()); 

            StructureGroup SG;

            if (page.Metadata != null)
            {
                ItemFields metadataFields = new ItemFields(page.Metadata, page.MetadataSchema);
                if (metadataFields.Count > 0)
                {
                    sURL = metadataFields["furl"].ToString();
                    strClass = metadataFields["fClass"].ToString();
                    if (!string.IsNullOrEmpty(metadataFields["ffriendlytitle"].ToString()))
                    {
                        strFriendlyTitle = ReplaceCdata(metadataFields["ffriendlytitle"].ToString());
                    }
                }

                if (string.IsNullOrEmpty(sURL))
                {
                    sURL = ReplaceURL(page.PublishLocationPath);
                }

            }
            else
            {
                sURL = ReplaceURL(page.PublishLocationPath);
            }

            strHtml = " url = \"" + sURL + "\" class = \"" + strClass + "\" displaytitle = \"" + strFriendlyTitle + "\"";

            return strHtml;

        }


        private string GetDatafromSG(StructureGroup sg, string strType)
        {

            string strVal = "";

            ItemFields metadataFields = new ItemFields(sg.Metadata, sg.MetadataSchema);
            if (metadataFields != null)
            {
                strVal = metadataFields[strType].ToString();
            }

            return strVal;

        }

        private string Getpage(Page page, string strType)
        {
            string strVal = "";
            ItemFields metadataFields = new ItemFields(page.Metadata, page.MetadataSchema);
            if (metadataFields != null)
            {
                strVal = metadataFields[strType].ToString();
            }
            return strVal;
        }

        private string ReplaceCdata(string cdata)
        {
            string decode = cdata;
            decode = decode.Replace("&", "&amp;amp;");
            return decode;
        }

        private string ReplaceURL(string strURL)
        {
            string url = strURL;
            url = url.Replace("\\", "/");
            return url;
        }

    }
}
