﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Tridion.Extensions.ContentManager.Templating
{
	/// <summary>
	/// This attribute is used in conjunction with the XSLTMediator, when this attribute decorates a class
	/// which is used as an XSLT transformation extension this attribute's namespace value will be used when 
	/// the extension is added to the transformation argument collection
	/// </summary>
	[System.AttributeUsage(System.AttributeTargets.Class, AllowMultiple = false)] // multiuse attribute
	public class TridionXSLTHelperNSAttribute : Attribute
	{
		private string m_NS;

		public TridionXSLTHelperNSAttribute() { }

		public TridionXSLTHelperNSAttribute(string helperNamespace)
		{
			m_NS = helperNamespace;
		}

		public string HelperNamespace
		{
			get { return m_NS; }
			set { m_NS = value; }
		}

		/// <summary>
		/// Will return the namespace assigned to this attribute
		/// </summary>		
		public override string ToString()
		{
			return m_NS;
		}
	}
}
