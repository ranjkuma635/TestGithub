﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml.Linq;
using Tridion.ContentManager.CoreService.Client;


namespace EmaarCoreServices
{
    public partial class PublishComponents : System.Web.UI.Page
    {
        CoreServiceClient client = new CoreServiceClient();
        DateTime publishDate;
        protected void Page_Load(object sender, EventArgs e)
        {

            if (!Page.IsPostBack)
            {
                client.ClientCredentials.Windows.ClientCredential.UserName = ConfigurationManager.AppSettings["UserId"];
                client.ClientCredentials.Windows.ClientCredential.Password = ConfigurationManager.AppSettings["Password"];
                client.Open();
                
                var filter = new PublicationTargetsFilterData();
                XElement pubTargetsXml = client.GetSystemWideListXml(filter);

                foreach (XElement pubTarget in pubTargetsXml.Elements())
                {
                    ListItem listItem = new ListItem();
                    listItem.Text = pubTarget.Attribute("Title").Value;
                    listItem.Value = pubTarget.Attribute("ID").Value;
                    chkPublishingTarget.Items.Add(listItem);
                }
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtFolder.Text == "")
                {
                    lblMessage.Visible = true;
                    lblMessage.Text = "Please enter the folder ID";
                }
                else if (chkPublishingTarget.SelectedIndex == -1)
                {
                    lblMessage.Visible = true;
                    lblMessage.Text = "Please select Target Type";
                }
                else if (txtDate.Text == "")
                {
                    lblMessage.Visible = true;
                    lblMessage.Text = "Please select Publish date";
                }
                else
                {
                    lblMessage.Visible = false;
                    publishDate = DateTime.Parse(txtDate.Text);
                    var pubData = new PublishInstructionData
                    {
                        ResolveInstruction = new ResolveInstructionData() { IncludeChildPublications = chkChild.Checked },
                        RenderInstruction = new RenderInstructionData(),
                        StartAt = publishDate
                    };
                    string[] pubTargetIdsArray = GetTarget();
                    string[] componentList = GetComponentList();
                    if (componentList.Length != 0)
                        client.Publish(componentList, pubData, pubTargetIdsArray, PublishPriority.Normal, null);
                    }
            }
            catch (Exception ex)
            {

            }
        }

        private string[] GetTarget()
        {
            List<string> pubTargetIds = new List<string>();
            foreach (ListItem li in chkPublishingTarget.Items)
            {
                if (li.Selected == true)
                {
                    pubTargetIds.Add(li.Value);
                }
            }
            return pubTargetIds.ToArray();
        }

        private string[] GetComponentList()
        {
            string folderId = txtFolder.Text;

            OrganizationalItemItemsFilterData filter = new OrganizationalItemItemsFilterData();
            filter.ItemTypes = new ItemType[] { ItemType.Component };
            filter.ComponentTypes = new ComponentType[] { ComponentType.Normal };
            filter.Recursive = chkRecursive.Checked;
            filter.BaseColumns = ListBaseColumns.Extended;
            XElement items = client.GetListXml(folderId, filter);

            string[] compList = items.Elements().Where(a => a.Attribute("IsPublished").Value.Equals("true", StringComparison.OrdinalIgnoreCase)).Select(a => a.Attribute("ID").Value).ToArray();
            return compList;
        }

        protected void calDate_SelectionChanged(object sender, EventArgs e)
        {
            txtDate.Text = calDate.SelectedDate.ToString();
        }
    }
}