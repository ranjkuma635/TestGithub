﻿using System;
using System.Linq;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.ContentManagement.Fields;
using Tridion.Extensions.ContentManager.Templating;
using Tridion.ContentManager.ContentManagement;
using Emaar.Web.Tridion.System.Extensions;

namespace DAUZ.Web.Templating.BuildingBlocks.Templates
{
    [TcmTemplateTitle("Content Page")]
    public class ContentPage : TemplateBase
    {

        public override void Transform(Engine engine, Package package)
        {
            base.Transform(engine, package);
            String seoImage = String.Empty; ;
            String seoDescription = String.Empty;
            String seoKeywords = String.Empty;
            String spageTitle = String.Empty;

            if (Page.ComponentPresentations.Count > 0)
            {
                Component component = Page.ComponentPresentations[0].Component;

                if (component.EmbeddedMetaValue("seometadata") != null)
                {
                    ItemFields seoMetadata = component.EmbeddedMetaValue("seometadata");
                    spageTitle = seoMetadata.StringValue("pageTitle");
                    if (seoMetadata.StringValue("pageTitle") != null)
                    {
                        spageTitle = seoMetadata.StringValue("pageTitle");
                    }
                    else if (component.StringValue("title") != null)
                    {
                        spageTitle = component.StringValue("title");
                    }
                    if (seoMetadata.StringValue("SEODescription") != null)
                    {
                        seoDescription = seoMetadata.StringValue("SEODescription");
                    }

                    if (seoMetadata.StringValue("SEOKeywords") != null)
                    {
                        seoKeywords = seoMetadata.StringValue("SEOKeywords");
                    }

                }

                package.AddString("PageTitle", spageTitle);
                package.AddString("metaPageTitle", spageTitle);
                package.AddString("SEODescription", seoDescription);
                package.AddString("SEOKeywords", seoKeywords);
            }
        }
    }

}
