﻿using System;
using System.Collections.Generic;
using System.Xml;
using Tridion.ContentManager.ContentManagement.Fields;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager;
using System.Collections;
using Tridion.ContentManager.ContentManagement;
using Tridion.ContentManager.CommunicationManagement;
using System.Xml.XPath;
using System.Web;
using Tridion.Extensions.ContentManager.Templating;
using System.IO;
using Emaar.Web.Tridion.System.Extensions;

namespace DAUZ.Web.Templating.BuildingBlocks.Templates
{
    [TcmTemplateTitle("DCP")]
    public class DCP : TemplateBase
    {
        public override void Transform(Engine engine, Package package)
        {

            base.Transform(engine, package);

            using (StringWriter sw = new StringWriter())
            {

                using (XmlTextWriter xml = new XmlTextWriter(sw))
                {

                    xml.WriteStartElement("Data");


                    if (Component != null)
                    {
                        if (Component.Schema.Title == "DAUZ - Events" || Component.Schema.Title == "DAUZ - No Events Promo" || Component.Schema.Title == "DAUZ - Promotion")
                        {
                            xml.WriteAttributeString("uri", Component.Id);

                            xml.WriteElementString("Title", Component.StringValue("Title"));
                            xml.WriteElementString("Description", Component.XHTMLValue("Description"));

                            Component EventImage = Component.ComponentValue("Largeimage");
                            if (EventImage != null && EventImage.BinaryContent != null)
                            {

                                Component MetaLarge = EventImage.ComponentMetaValue("flarge");

                                if(MetaLarge!=null)
                                    xml.WriteElementString("LargeImage", PublishBinary(MetaLarge));
                                else
                                    xml.WriteElementString("LargeImage", PublishBinary(EventImage));

                                Component EventThumbImage = Component.ComponentMetaValue("fthumb");
                                if(EventThumbImage!=null)
                                    xml.WriteElementString("ThumbNailImage", PublishBinary(EventThumbImage));
                                else
                                    xml.WriteElementString("ThumbNailImage", GenerateThumbnail(EventImage, "Eventthumb", 300, 200, "#fff"));
                            }

                            xml.WriteElementString("Startdate", Component.DateMetaValue("fstartdate").ToString("dd/MM/yyyy"));
                            xml.WriteElementString("Enddate", Component.DateMetaValue("fenddate").ToString("dd/MM/yyyy"));
                            
                        }
                    }

                    xml.WriteEndElement();
                }

                Package.AddXml(Package.OutputName, sw.ToString());
            }

        }

    }
}
