﻿using System;
using System.Collections.Generic;
using Tridion.ContentManager;
using Tridion.ContentManager.CommunicationManagement;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.ContentManagement.Fields;

using Tridion.ContentManager.ContentManagement;
using Tridion.Extensions.ContentManager.Templating;
using Emaar.Web.Tridion.System.Extensions;
using Emaar.Web.Tridion.System;


namespace DAUZ.Web.Templating.BuildingBlocks.Templates
{
    [TcmTemplateTitle("Leftcallout")]
    public class Leftcallout : TemplateBase
    {

        string strText = string.Empty;

        public override void Transform(Engine engine, Package package)
        {
            base.Transform(engine, package);

            if (Page.Metadata != null)
            {
                ItemFields metadataField = new ItemFields(Page.Metadata, Page.MetadataSchema);
                ComponentLinkField mainimage = null;

                mainimage = (ComponentLinkField)metadataField["leftsidecallout"];
                Component Image = (Component)mainimage.Value;


                if (Image != null)
                {
                    Package.AddString("Leftcallout", Image.Id.ToString());
                }
                else
                {
                    Package.AddString("Leftcallout", PublishCalloutsSG(Page.OrganizationalItem));
                }

            }
            else 
            {
                Package.AddString("Leftcallout", PublishCalloutsSG(Page.OrganizationalItem));
            }

        }

        private string PublishCalloutsSG(OrganizationalItem oRecurSG )
        {
            OrganizationalItem oParentSG;

            string strImageValue = string.Empty;

            if (oRecurSG != null)
            {
                if (oRecurSG.Metadata != null)
                {
                    ItemFields metadataFields = new ItemFields(oRecurSG.Metadata, oRecurSG.MetadataSchema);
                    ComponentLinkField featureField = null;

                    featureField = (ComponentLinkField)metadataFields["leftsidecallout"];
                    Component Image = (Component)featureField.Value;

                    if (Image != null)
                    {
                        strImageValue = Image.Id.ToString();  

                    }
                    else
                    {
                        oParentSG = oRecurSG.OrganizationalItem;
                        PublishCalloutsSG(oParentSG);
                    }
                }
                else
                {
                    oParentSG = oRecurSG.OrganizationalItem;
                    PublishCalloutsSG(oParentSG);
                }
            }

            return strImageValue;

        }


    }
}
