﻿using System;
using System.Collections.Generic;
using Tridion.ContentManager;
using Tridion.ContentManager.CommunicationManagement;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.ContentManagement.Fields;

using Tridion.ContentManager.ContentManagement;
using Tridion.Extensions.ContentManager.Templating;
using Emaar.Web.Tridion.System.Extensions;
using Emaar.Web.Tridion.System;

namespace AR.Web.Templating.BuildingBlocks.Templates
{
    [TcmTemplateTitle("Template Specific")]
    public class TemplateSpecific : TemplateBase
    {
         string DisplayLeftNav = "Yes";
         string TitleXML = "Yes";

         public override void Transform(Engine engine, Package package)
         {
            base.Transform(engine, package);

            if (Page.ComponentPresentations.Count > 0)
            {
                string Schema = Page.ComponentPresentations[0].Component.Schema.Title;

                if ((Schema == "AR - News") || (Schema == "AR - Campaigns") || (Schema == "AR - Events"))
                {
                    DisplayLeftNav = "No";
                    Package.AddString("DisplayLeftNav", DisplayLeftNav);
                    TitleXML = "No";
                }

                if(Schema=="AR - Photo Gallery")
                    Package.AddString("DisplayType", "Photo");

                if(Schema == "AR - Video Gallery")
                    Package.AddString("DisplayType", "Video");

            }

            Package.AddString("GetSectionTitle", GetSectionTitle(Page,engine));
            Package.AddString("TitleXML", TitleXML);
            Package.AddString("CustompageTitle", Page.ComponentPresentations[0].Component.StringValue("title"));

         }

         private string GetSectionTitle(Page page, Engine m_Engine)
         {

             string strtitle = "";

             StructureGroup SG;

             SG = (StructureGroup)page.OrganizationalItem as StructureGroup;

             if (SG != null)
             {
                 if (SG.Metadata != null)
                 {
                     ItemFields metadataFields = new ItemFields(SG.Metadata, SG.MetadataSchema);

                     ComponentLinkField HeaderTitle = null;
                     HeaderTitle = (ComponentLinkField)metadataFields["fnavigationconf"];

                     if (HeaderTitle.Value  != null)
                     {
                         {
                             Component comp = m_Engine.GetObject(HeaderTitle.Value.Id.ToString()) as Component;
                             if (comp != null)
                             {
                             ItemFields fields = new ItemFields(comp.Content, comp.Schema);
                             strtitle = fields["fnavigationtext"].ToString();
                             }
                         }
                     }
                 }
             }

             return strtitle;

         }

    }
}
