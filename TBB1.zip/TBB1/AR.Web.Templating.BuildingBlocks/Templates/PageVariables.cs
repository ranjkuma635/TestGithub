﻿using System;
using System.Collections.Generic;
using System.Xml;
using Tridion.ContentManager;
using Tridion.ContentManager.CommunicationManagement;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.ContentManagement.Fields;
using Tridion.ContentManager.ContentManagement;
using System.Text.RegularExpressions;
using Tridion.Extensions.ContentManager.Templating;
using Emaar.Web.Tridion.System.Extensions;
using Emaar.Web.Tridion.System;

namespace Sega.Web.Templating.BuildingBlocks.Templates
{

    [TcmTemplateTitle("Page Variables")]
    public class PageVariables : PageVariablesTemplate
    {

        private List<String> mIncludeFields;
        private List<String> mInheritedFields;

        public PageVariables()
            : base()
        {


        }
    }
}
