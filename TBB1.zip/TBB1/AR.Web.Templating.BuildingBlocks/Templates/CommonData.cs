﻿using System;
using System.Collections.Generic;
using Tridion.ContentManager;
using Tridion.ContentManager.CommunicationManagement;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.ContentManagement.Fields;

using Tridion.ContentManager.ContentManagement;
using Tridion.Extensions.ContentManager.Templating;
using Emaar.Web.Tridion.System.Extensions;
using Emaar.Web.Tridion.System;

namespace AR.Web.Templating.BuildingBlocks
{
    [TcmTemplateTitle("Get Common Data")]
    public class CommonData : GetCommonData
    {

        public CommonData()
            : base()
        {

        }
    }
}
