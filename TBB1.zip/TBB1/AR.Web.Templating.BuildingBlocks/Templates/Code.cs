﻿using System;
using System.Linq;
using Tridion.ContentManager.CommunicationManagement;
using Tridion.ContentManager.Templating;
using Tridion.Extensions.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Emaar.Web.Tridion.System.Extensions;
using Tridion.ContentManager.ContentManagement;
using Tridion.ContentManager.ContentManagement.Fields;

namespace AR.Web.Templating.BuildingBlocks.Templates
{
    /// <summary>
    /// Class to Create the BreadCrumb
    /// </summary>
    [TcmTemplateTitle("Code")]
    public class Code : TemplateBase
    {
        /// <summary>
        /// Creates Code Output
        /// </summary>
        /// <param name="engine">Provides access to the Tridion System</param>
        /// <param name="package">Stack containing all output variables</param>
        public override void Transform(Engine engine, Package package)
        {
            base.Transform(engine, package);

            Component component = engine.GetObject(package.GetByType(ContentType.Component).GetAsSource().GetValue("ID")) as Component;
            string code = string.Empty;

            if (Component != null)
            {
                switch (Component.Schema.Title.Split('-')[1].Trim())
                {
                    case "Code": ItemFields fields = new ItemFields(component.Content, component.Schema);
                        foreach (ItemField field in fields)
                        {
                            if (field.Name.Equals("code"))
                            {
                                code = field.StringValue();
                            }
                        }
                        break;
                    default: code = string.Empty;
                        break;
                }
                Package.AddXhtml("codexhtml",code); 
            }
        }
    }
}
