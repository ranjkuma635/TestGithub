﻿using System;
using System.Collections.Generic;
using System.Xml;
using Tridion.ContentManager;
using Tridion.ContentManager.CommunicationManagement;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.ContentManagement.Fields;
using Tridion.ContentManager.ContentManagement;
using System.Text.RegularExpressions;

using Tridion.Extensions.ContentManager.Templating;

using Emaar.Web.Tridion.System.Extensions;
using Emaar.Web.Tridion.System;
using System.Text;

namespace AR.Web.Templating.BuildingBlocks.Templates
{
    [TcmTemplateTitle("Gallery Menu")]
    public class GalleryMenu : TemplateBase 
    {
        public override void Transform(Engine engine, Package package)
        {

            base.Transform(engine, package);
            
            Item outputItem = package.GetByName(Package.OutputName);
            string outputValue = outputItem.GetAsString();

            outputValue = outputValue.Replace("[*NAVIGATIONMENU*]", GetNavidatio(engine,package));

            package.Remove(outputItem);
            outputItem.SetAsString(outputValue);
            package.PushItem(Package.OutputName, outputItem);

        }

        private string GetNavidatio(Engine engine, Package package)
        {

            string strHTML = "";

            Page page;
            StructureGroup SG;


            StringBuilder strNavLoop = new StringBuilder();

            string[] arrID = this.Publication.Id.ToString().Split(new char[] { '-' });


            string strSGID = "";
            if (GetPageType(Page) == "PG")
                strSGID= "tcm:" + arrID[1] + "-4296-4";
            else
                strSGID = "tcm:" + arrID[1] + "-4294-4";

            StructureGroup RootSG = engine.GetObject(strSGID) as StructureGroup;

            Filter filterSG = new Filter();
            filterSG.Conditions["ItemType"] = ItemType.StructureGroup;
            IList<RepositoryLocalObject> listFistLevelStructureGroup = RootSG.GetItems(filterSG);

            Filter filterPage = new Filter();
            filterPage.Conditions["ItemType"] = ItemType.Page;



            if (listFistLevelStructureGroup.Count > 0)
            {
                foreach (RepositoryLocalObject RepositoryLocalObject in listFistLevelStructureGroup)
                {

                    SG = engine.GetObject(RepositoryLocalObject.Id) as StructureGroup;

                    if (SG.Title.Contains("."))
                    {
                        strNavLoop.Append("<ul class=\"accordion fact-sheets1\" id=\"acd_" + SG.Title.Split('.')[1].ToString().Trim() + "\">");
                        strNavLoop.AppendLine(); 
                        strNavLoop.Append("<li class=\"head\">" + SG.Title.Split('.')[1].ToString().Trim() + "</li>");
                        strNavLoop.AppendLine(); 
                        strNavLoop.Append("<ul>");
                        strNavLoop.AppendLine(); 

                        IList<RepositoryLocalObject> listPages = SG.GetItems(filterPage);

                        foreach (RepositoryLocalObject RepositoryLocalObjectpages in listPages)
                        {
                            page = engine.GetObject(RepositoryLocalObjectpages.Id) as Page;
                            strNavLoop.Append("<li><a href=\"" + page.PublishLocationUrl.ToString() + "?year=" + SG.Title.Split('.')[1].ToString().Trim() + "\">" + GetTitle(page)+ "</a></li>");
                            strNavLoop.AppendLine(); 
                        }

                        strNavLoop.AppendLine(); 
                        strNavLoop.Append("</ul>");
                        strNavLoop.AppendLine(); 
                        strNavLoop.Append("</ul>");

                        strNavLoop.AppendLine(); 
                    }
                }
            
            }

            strHTML = strNavLoop.ToString();

            return strHTML;

        }

        private string GetTitle(Page page)
        {

            string strTitle = "";

            strTitle = page.Title.Split('.')[1].ToString().Trim();

            if (page.ComponentPresentations.Count > 0)
            {
                string Schema = page.ComponentPresentations[0].Component.Schema.Title;
                if ((Schema == "AR - Photo Gallery") || (Schema == "AR - Video Gallery"))
                {
                    ItemFields Comp = new ItemFields(page.ComponentPresentations[0].Component.Content, Page.ComponentPresentations[0].Component.Schema);
                    strTitle = Comp["Menuname"].ToString();
                    if (string.IsNullOrEmpty(strTitle))
                        strTitle = page.Title.Split('.')[1].ToString().Trim();
                }
            }

            return strTitle;

        }

        private string GetPageType(Page page)
        {

            string strRetval = "";

            if (page.ComponentPresentations.Count > 0)
            {
                string Schema = page.ComponentPresentations[0].Component.Schema.Title;
                if (Schema == "AR - Photo Gallery")
                    strRetval = "PG";
                else
                    strRetval = "VG";
            }

                return strRetval;
        }

    }
}
