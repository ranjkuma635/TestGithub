﻿using System;
using System.Collections.Generic;
using Tridion.ContentManager.Templating.Assembly;
using Emaar.Web.Tridion.System;


namespace BurjKhalifa.Web.Templating.BuildingBlocks.Templates {
   
    [TcmTemplateTitle("Page Variables")]
    public class PageVariables : PageVariablesTemplate  {

       private List<String> mIncludeFields;
       private List<String> mInheritedFields;

       public PageVariables(): base() {
            mIncludeFields = new List<String>();
            mIncludeFields.Add("fBgImage");
            mIncludeFields.Add("fWrapperClass");
            mIncludeFields.Add("fType");
            mIncludeFields.Add("fhideFromSearch");

            mInheritedFields = new List<String>();
            mInheritedFields.Add("fBgImage");
            mInheritedFields.Add("fWrapperClass");
            mInheritedFields.Add("fType");
            mInheritedFields.Add("fhideFromSearch");
       }

        protected override bool IncludeMetadata(string FieldName) {
            return mIncludeFields.Contains(FieldName);
        }

        protected override bool InheritedMetadata(string FieldName) {
            return mInheritedFields.Contains(FieldName);
        }


        /// <summary>
        /// Returns wether the specified Schema should be used to generate a page title
        /// </summary>
        /// <returns></returns>
        protected override bool TitleTemplate(string Schema) {
            return true;
        }

    }
}
