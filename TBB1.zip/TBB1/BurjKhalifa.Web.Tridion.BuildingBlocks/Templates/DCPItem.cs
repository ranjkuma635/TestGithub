﻿using System;
using System.Linq;
using System.Xml;
using System.IO;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.Extensions.ContentManager.Templating;
using Emaar.Web.Tridion.System.Extensions;
using System.Collections.Generic;
using Tridion.ContentManager.ContentManagement.Fields;

namespace BurjKhalifa.Web.Templating.BuildingBlocks.Templates
{

    [TcmTemplateTitle("DCPItem")]
    public class DCPItem : TemplateBase
    {
        /// <summary>
        /// Transforms the current component.
        /// </summary>
        /// <param name="engine">The engine.</param>
        /// <param name="package">The package.</param>
        public override void Transform(Engine engine, Package package)
        {
            base.Transform(engine, package);

            using (StringWriter sw = new StringWriter())
            {

                using (XmlTextWriter xml = new XmlTextWriter(sw))
                {

                    if (Component != null)
                    {
                        if (Component.Schema.Title.Equals("BK - Press Release"))
                        {

                            xml.WriteStartElement("item");

                            xml.WriteElementString("uri", Component.Id.ToString());
                            xml.WriteElementString("id", Component.Id.ItemId.ToString());
                            xml.WriteElementString("title", Component.StringValue("ftitle"));
                            xml.WriteElementString("summary", Component.StringValue("fsummary"));
                            xml.WriteElementString("description", Component.StringValue("fdescription"));


                            DateTime fpublishdate = Component.DateMetaValue("fpublishdate");
                            if (fpublishdate.ToString("dd/MM/yyyy") != "01/01/0001")
                            {
                                xml.WriteElementString("date", fpublishdate.ToString("dd/MM/yyyy"));
                                xml.WriteElementString("sortdate", GetSortDate(fpublishdate.ToString("dd/MM/yyyy")));
                                xml.WriteElementString("year", GetYear(fpublishdate.ToString("dd/MM/yyyy")));
                            }
                            else
                            {
                                xml.WriteElementString("date", DateTime.Now.ToString("dd/MM/yyyy"));
                                xml.WriteElementString("sortDate", GetSortDate(DateTime.Now.ToString("dd/MM/yyyy")));
                                xml.WriteElementString("year", GetYear(DateTime.Now.ToString("dd/MM/yyyy")));
                            }

                            xml.WriteEndElement();//item    
 
                        }


                        if (Component.Schema.Title.Equals("BK - Video Album"))
                        {

                            IList<String> items = Component.ExternalLinkValues("item");
                            foreach (String item in items)
                            {
                                xml.WriteStartElement("a");

                                xml.WriteAttributeString("data-type", "youtube");
                                xml.WriteAttributeString("href", item);
                                xml.WriteStartElement("img");
                                xml.WriteAttributeString("src", "https://img.youtube.com/vi/" + item.Substring(32) + "/hqdefault.jpg");
                                xml.WriteAttributeString("style", "width:200px");
                                xml.WriteEndElement();//img
                                xml.WriteEndElement();//a  
                            }

                        }

                        if (Component.Schema.Title.Equals("BK - Offer"))
                        {

                            xml.WriteStartElement("item");

                            xml.WriteElementString("uri", Component.Id.ToString());
                            xml.WriteElementString("id", Component.Id.ItemId.ToString());
                            xml.WriteElementString("title", Component.StringValue("title"));
                            xml.WriteElementString("text", Component.StringValue("text"));
                            xml.WriteElementString("price", Component.StringValue("price"));

                            IList<String> timings = Component.StringValues("timings");
                            foreach (String timing in timings)
                            {
                                xml.WriteElementString("timing", timing);
                            }

                            xml.WriteElementString("category", Component.StringValue("category"));

                            xml.WriteElementString("image", PublishBinary(Component.ComponentValue("image")));

                            DateTime startdate = Component.DateMetaValue("startdate");
                            if (startdate.ToString("dd/MM/yyyy") != "01/01/0001")
                            {
                                xml.WriteElementString("startdate", startdate.ToString("dd/MM/yyyy"));
                                xml.WriteElementString("sortdate", GetSortDate(startdate.ToString("dd/MM/yyyy")));
                            }
                            else
                            {
                                xml.WriteElementString("startdate", DateTime.Now.ToString("dd/MM/yyyy"));
                                xml.WriteElementString("sortDate", GetSortDate(DateTime.Now.ToString("dd/MM/yyyy")));
                            }

                            DateTime enddate = Component.DateMetaValue("enddate");
                            if (enddate.ToString("dd/MM/yyyy") != "01/01/0001")
                            {
                                xml.WriteElementString("enddate", enddate.ToString("dd/MM/yyyy"));
                            }
                            else
                            {
                                xml.WriteElementString("enddate", DateTime.Now.ToString("dd/MM/yyyy"));
                            }

                            xml.WriteEndElement();//item    

                        }

                    }

                    Package.AddXml(Package.OutputName, sw.ToString());
                }
            }
        }

        private static string getHtml(string html)
        {
            return Utility.removeXHTMLtags(html);
        }


        private string GetSortDate(string strDate)
        {

            string strRetval = "";


            string[] datetime = strDate.Split(new char[] { '/' });

            string Year = datetime[2];
            string Month = datetime[1];
            string Day = datetime[0];

            if (Month.Length == 1)
                Month = "0" + Month;

            if (Day.Length == 1)
                Day = "0" + Day;

            strRetval = Year + Month + Day;

            return strRetval;

        }

        private string GetYear(string strDate){

            string[] datetime = strDate.Split(new char[] { '/' });

            return datetime[2];
     
        }
    }
}