﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Net;
using System.IO;
using System.Xml;
using System.Text.RegularExpressions;
using System.Configuration;

namespace PropertyDetails
{
    public partial class DataSyncronization : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                //To sync Data uncomment the GetData Method.
                //GetData();
            }           
           
        }      


        private void GetData()
        {
            try
            {
                DataSet ds = null;
                using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConSourceForDataSync"].ConnectionString.ToString()))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter("select DISTINCT  COMMUNITY,PROPERTY_NAME,BUILDING, [FLOOR],UNIT,EventId,LOCATION_ID,ORG_ID,SELLING_PRICE,PropertyStatus  FROM [SalesLaunch].[dbo].[SL_Property_Inventory] where EventId in(select EventId from SalesEvent where LaunchTypeSe like '%temp%') and PropertyStatus='Available' ", con))
                    {
                        using (ds = new DataSet())
                        {
                            da.Fill(ds);
                        }
                    }
                }
                foreach (DataRow dr in ds.Tables[0].Rows)
                {
                    using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConTargetForDataSync"].ConnectionString.ToString()))
                    {
                        using (SqlCommand cmd = new SqlCommand("usp_GetDataFromPropertyInventoryTable", con))
                        {
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.Parameters.AddWithValue("@CommunityName", dr["COMMUNITY"].ToString());
                            cmd.Parameters.AddWithValue("@PropertyName", dr["PROPERTY_NAME"].ToString());
                            cmd.Parameters.AddWithValue("@BuildingName", dr["BUILDING"].ToString());
                            cmd.Parameters.AddWithValue("@FloorName", dr["FLOOR"].ToString());
                            cmd.Parameters.AddWithValue("@UnitName", dr["UNIT"].ToString());
                            cmd.Parameters.AddWithValue("@EventId", Convert.ToInt32(dr["EventId"].ToString() == "" ? "0" : dr["EventId"].ToString()));
                            cmd.Parameters.AddWithValue("@LOCATION_ID", Convert.ToInt32(dr["LOCATION_ID"].ToString() == "" ? "0" : dr["LOCATION_ID"].ToString()));
                            cmd.Parameters.AddWithValue("@ORG_ID", Convert.ToInt32(dr["ORG_ID"].ToString() == "" ? "0" : dr["ORG_ID"].ToString()));
                            cmd.Parameters.AddWithValue("@SellingPrice", Convert.ToSingle(dr["SELLING_PRICE"].ToString() == "" ? "0" : dr["SELLING_PRICE"].ToString()));
                            cmd.Parameters.AddWithValue("@UnitStatus", dr["PropertyStatus"].ToString());
                            con.Open();
                            int intResult = cmd.ExecuteNonQuery();
                            con.Close();
                        }
                    }
                }
            }
            catch (Exception)
            {
                
            }
        }

    }
}