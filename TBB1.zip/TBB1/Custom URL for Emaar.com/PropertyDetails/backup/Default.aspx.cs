﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using PropertyDetailsBal;

namespace PropertyDetails
{
    public partial class _Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //if (Session["UserName"] == null)
            //{
            //    Response.Redirect("~/Login.aspx");
            //}
            if (!IsPostBack)
            {
                FillCommunityType();
            }

        }

        public void FillCommunityType()
        {
            ddlCommunityType.DataSource = (new ClsPropertyDetailsBal()).GetCommunityTypes();
            ddlCommunityType.DataTextField = "Type";
            ddlCommunityType.DataValueField = "Id";
            ddlCommunityType.DataBind();

            ddlCommunityType.Items.Insert(0, new ListItem("--Select--", "-1"));
        }

        protected void ddlCommunityType_SelectedIndexChanged(object sender, EventArgs e)
        {

            //ddlCommunityType
            ddlCommunity.Items.Clear();
            ddlProperty.Items.Clear();
            ddlBuilding.Items.Clear();
            ddlFloor.Items.Clear();
            ddlUnit.Items.Clear();

            if (ddlCommunityType.SelectedValue != "-1")
            {
                ddlCommunity.DataSource = (new ClsPropertyDetailsBal()).GetCommunities(
                    Convert.ToInt32(ddlCommunityType.SelectedValue));
                ddlCommunity.DataTextField = "CommunityName";
                ddlCommunity.DataValueField = "CommunityId";
                ddlCommunity.DataBind();
                ddlCommunity.Items.Insert(0, new ListItem("--Select--", "-1"));              
            }
            lblCommunityID.Text = "";
            lblPropertyID.Text = "";
            lblBuildingID.Text = "";
            lblFloorID.Text = "";
            lblUnitID.Text = "";


        }

        protected void ddlCommunity_SelectedIndexChanged(object sender, EventArgs e)
        {
            // ddlCommunity.Items.Clear();
            ddlProperty.Items.Clear();
            ddlBuilding.Items.Clear();
            ddlFloor.Items.Clear();
            ddlUnit.Items.Clear();
            if (ddlCommunity.SelectedValue != "-1")
            {
                ddlProperty.DataSource = (new ClsPropertyDetailsBal()).GetProperties(
                    Convert.ToInt32(ddlCommunity.SelectedValue));
                ddlProperty.DataTextField = "PropertyName";
                ddlProperty.DataValueField = "PropertyId";
                ddlProperty.DataBind();
                ddlProperty.Items.Insert(0, new ListItem("--Select--", "-1"));
                lblCommunityID.Text = ddlCommunity.SelectedValue;
                lblPropertyID.Text = "";
                lblBuildingID.Text = "";
                lblFloorID.Text = "";
                lblUnitID.Text = "";
            }
            else
            {
                lblCommunityID.Text = "";
                lblPropertyID.Text = "";
                lblBuildingID.Text = "";
                lblFloorID.Text = "";
                lblUnitID.Text = "";
            }

        }

        protected void ddlProperty_SelectedIndexChanged(object sender, EventArgs e)
        {
            // ddlCommunity.Items.Clear();
            // ddlProperty.Items.Clear();
            ddlBuilding.Items.Clear();
            ddlFloor.Items.Clear();
            ddlUnit.Items.Clear();

            if (ddlCommunity.SelectedValue != "-1")
            {
                ddlBuilding.DataSource = (new ClsPropertyDetailsBal()).GetBuildings(
                     Convert.ToInt32(ddlCommunity.SelectedValue),
                      Convert.ToInt32(ddlProperty.SelectedValue));
                ddlBuilding.DataTextField = "BuildingName";
                ddlBuilding.DataValueField = "BuildingId";
                ddlBuilding.DataBind();
                ddlBuilding.Items.Insert(0, new ListItem("--Select--", "-1"));
                lblPropertyID.Text = ddlProperty.SelectedValue;
                lblBuildingID.Text = "";
                lblFloorID.Text = "";
                lblUnitID.Text = "";
            }
            else
            {
                lblPropertyID.Text = "";
                lblPropertyID.Text = "";
                lblBuildingID.Text = "";
                lblFloorID.Text = "";
                lblUnitID.Text = "";
            }


        }

        protected void ddlBuilding_SelectedIndexChanged(object sender, EventArgs e)
        {
            // ddlCommunity.Items.Clear();
            // ddlProperty.Items.Clear();
            //  ddlBuilding.Items.Clear();
            ddlFloor.Items.Clear();
            ddlUnit.Items.Clear();
            if (ddlBuilding.SelectedValue != "-1")
            {
                ddlFloor.DataSource = (new ClsPropertyDetailsBal()).GetFloors(
                    Convert.ToInt32(ddlCommunity.SelectedValue),
                      Convert.ToInt32(ddlProperty.SelectedValue),
                        Convert.ToInt32(ddlBuilding.SelectedValue));
                ddlFloor.DataTextField = "FloorName";
                ddlFloor.DataValueField = "FloorId";
                ddlFloor.DataBind();
                ddlFloor.Items.Insert(0, new ListItem("--Select--", "-1"));
                lblBuildingID.Text = ddlBuilding.SelectedValue;
                lblFloorID.Text = "";
                lblUnitID.Text = "";
            }
            else
            {
                lblBuildingID.Text = "";
                lblFloorID.Text = "";
                lblUnitID.Text = "";
            }
        }

        protected void ddlFloor_SelectedIndexChanged(object sender, EventArgs e)
        {
            //  ddlCommunity.Items.Clear();
            //  ddlProperty.Items.Clear();
            //   ddlBuilding.Items.Clear();
            //   ddlFloor.Items.Clear();
            ddlUnit.Items.Clear();
            if (ddlFloor.SelectedValue != "-1")
            {

                ddlUnit.DataSource = (new ClsPropertyDetailsBal()).GetUnits(
                      Convert.ToInt32(ddlCommunity.SelectedValue),
                      Convert.ToInt32(ddlProperty.SelectedValue),
                        Convert.ToInt32(ddlBuilding.SelectedValue),
                        Convert.ToInt32(ddlFloor.SelectedValue));
                ddlUnit.DataTextField = "UnitName";
                ddlUnit.DataValueField = "UnitId";
                ddlUnit.DataBind();
                ddlUnit.Items.Insert(0, new ListItem("--Select--", "-1"));

                lblFloorID.Text = ddlFloor.SelectedValue;
                lblUnitID.Text = "";
            }
            else
            {
                lblFloorID.Text = "";
                lblUnitID.Text = "";
            }
        }

        protected void ddlUnit_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlUnit.SelectedValue != "-1")
            {
                lblUnitID.Text = ddlUnit.SelectedValue;
            }
        }
    }
}