﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace PropertyDetails
{
    public class GetData
    {
        private string StrConnectionString { get; set; }
        public GetData()
        {
            try
            {
                StrConnectionString = ConfigurationManager.ConnectionStrings["ConProretyDetails"].ConnectionString;
            }
            catch (Exception)
            {

            }
        }
        //ConProretyDetails
        public DataTable GetCommunityTypes()
        {
            try
            {
                using (SqlConnection con = new SqlConnection(StrConnectionString))
                {
                    using (SqlCommand cmd = new SqlCommand("usp_Details", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@Flag", 1);
                        using (SqlDataAdapter da=new SqlDataAdapter(cmd))
                        {
                            using (DataSet ds = new DataSet())
                            {
                                da.Fill(ds);
                                return ds.Tables[0];
                            } 
                        }
                        
                    }
                }
            }
            catch (Exception)
            {

                return null;
            }
        }

        public DataTable GetCommunities(int CommunityTypeID)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(StrConnectionString))
                {
                    using (SqlCommand cmd = new SqlCommand("usp_Details", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@Flag", 2);
                        cmd.Parameters.AddWithValue("@CommunityTypeID", CommunityTypeID);
                        using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                        {
                            using (DataSet ds = new DataSet())
                            {
                                da.Fill(ds);
                                return ds.Tables[0];
                            }
                        }

                    }
                }
            }
            catch (Exception)
            {

                return null;
            }
           
        }
        public DataTable GetProperties(int CommunityId)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(StrConnectionString))
                {
                    using (SqlCommand cmd = new SqlCommand("usp_Details", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@Flag", 3);
                        cmd.Parameters.AddWithValue("@CommunityID", CommunityId);
                        using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                        {
                            using (DataSet ds = new DataSet())
                            {
                                da.Fill(ds);
                                return ds.Tables[0];
                            }
                        }

                    }
                }
            }
            catch (Exception)
            {

                return null;
            }
        }
        public DataTable GetBuildings(int CommunityId,int PropertyID)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(StrConnectionString))
                {
                    using (SqlCommand cmd = new SqlCommand("usp_Details", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@Flag", 4);
                        cmd.Parameters.AddWithValue("@CommunityID", CommunityId);
                        cmd.Parameters.AddWithValue("@PropertyID", PropertyID);
                        using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                        {
                            using (DataSet ds = new DataSet())
                            {
                                da.Fill(ds);
                                return ds.Tables[0];
                            }
                        }

                    }
                }
            }
            catch (Exception)
            {

                return null;
            }
        }

        public DataTable GetFloors(int CommunityId, int PropertyID,int BuildingID)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(StrConnectionString))
                {
                    using (SqlCommand cmd = new SqlCommand("usp_Details", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@Flag", 5);
                        cmd.Parameters.AddWithValue("@CommunityID", CommunityId);
                        cmd.Parameters.AddWithValue("@PropertyID", PropertyID);
                        cmd.Parameters.AddWithValue("@BuildingID", BuildingID);
                        using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                        {
                            using (DataSet ds = new DataSet())
                            {
                                da.Fill(ds);
                                return ds.Tables[0];
                            }
                        }

                    }
                }
            }
            catch (Exception)
            {

                return null;
            }
        }
        public DataTable GetUnits(int CommunityId, int PropertyID, int BuildingID,int FloorID)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(StrConnectionString))
                {
                    using (SqlCommand cmd = new SqlCommand("usp_Details", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@Flag", 6);
                        cmd.Parameters.AddWithValue("@CommunityID", CommunityId);
                        cmd.Parameters.AddWithValue("@PropertyID", PropertyID);
                        cmd.Parameters.AddWithValue("@BuildingID", BuildingID);
                        cmd.Parameters.AddWithValue("@FloorID", FloorID);
                        using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                        {
                            using (DataSet ds = new DataSet())
                            {
                                da.Fill(ds);
                                return ds.Tables[0];
                            }
                        }

                    }
                }
            }
            catch (Exception)
            {

                return null;
            }
        }

        public DataTable GetAllCommunities()
        {
            try
            {
                using (SqlConnection con = new SqlConnection(StrConnectionString))
                {
                    using (SqlCommand cmd = new SqlCommand("usp_Details", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@Flag", 8);
                        using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                        {
                            using (DataSet ds = new DataSet())
                            {
                                da.Fill(ds);
                                return ds.Tables[0];
                            }
                        }

                    }
                }
            }
            catch (Exception)
            {

                return null;
            }
        }
        public DataTable GetAllUnits(int CommunityId, int PropertyID, int BuildingID)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(StrConnectionString))
                {
                    using (SqlCommand cmd = new SqlCommand("usp_Details", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@Flag", 9);
                        cmd.Parameters.AddWithValue("@CommunityID", CommunityId);
                        cmd.Parameters.AddWithValue("@PropertyID", PropertyID);
                        cmd.Parameters.AddWithValue("@BuildingID", BuildingID);                       
                        using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                        {
                            using (DataSet ds = new DataSet())
                            {
                                da.Fill(ds);
                                return ds.Tables[0];
                            }
                        }

                    }
                }
            }
            catch (Exception)
            {

                return null;
            }
        }

        public string UpdateTcmId(int Flag, int CommunityId, int PropertyID, int BuildingID, int UnitId, string strTcmId)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(StrConnectionString))
                {
                    using (SqlCommand cmd = new SqlCommand("usp_UpdateTcmId", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@Flag", Flag);
                        cmd.Parameters.AddWithValue("@CommunityID", CommunityId);
                        cmd.Parameters.AddWithValue("@PropertyID", PropertyID);
                        cmd.Parameters.AddWithValue("@BuildingID", BuildingID);
                        cmd.Parameters.AddWithValue("@UnitId", UnitId);
                        cmd.Parameters.AddWithValue("@TcmId", strTcmId);
                        con.Open();
                        int intResult = cmd.ExecuteNonQuery();
                        if (intResult > 0)
                        {
                            return "success";
                        }
                        else
                        {
                            return "fail";
                        }
                    }
                }
            }
            catch (Exception)
            {

                return "fail";
            }
            finally
            { 
            
            }
           
        }
    }
}