﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PropertyDetails
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            if (txtUserName.Text != "" && txtPassword.Text != "")
            {
                if (txtUserName.Text.ToLower() == "admin" && txtPassword.Text == "admin@123")
                {
                    Session["UserName"] = txtUserName.Text;
                    Response.Redirect("~/Default.aspx");
                }
                else
                {
                    trResult.Visible = true;
                    lblResult.Text = "Invalid UserName/Password";
                    lblResult.ForeColor = System.Drawing.Color.Red;
                }
            }
            else
            {
                trResult.Visible = true;
                lblResult.Text = "Invalid UserName/Password";
                lblResult.ForeColor = System.Drawing.Color.Red;
            }
        }
    }
}