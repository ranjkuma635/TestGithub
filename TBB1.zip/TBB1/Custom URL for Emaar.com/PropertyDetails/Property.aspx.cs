﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using PropertyDetailsBal;
using System.Configuration;

namespace PropertyDetails
{
    public partial class Property : System.Web.UI.Page
    {
        private string strConnectionString { get; set; }
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
		lblResult.Text = "";
                if (dbConStrList.SelectedItem.Value.ToLower().Equals("staging"))
                {
                    strConnectionString = "ConProretyDetailsStaging";
                }
                else if (dbConStrList.SelectedItem.Value.ToLower().Equals("live"))
                {
                    strConnectionString = "ConProretyDetailsLive";
                }
                else
                {
                    strConnectionString = "ConProretyDetails";
                }
                if (!IsPostBack)
                {
                    GetAllCommunities();
                }
            }
            catch (Exception)
            {
            }
            finally
            {
            }
        }
        private void GetAllCommunities()
        {
            try
            {
                ddlCommunity.DataSource = Session["CommunityDetails"] = (new ClsPropertyDetailsBal()).GetAllCommunities(strConnectionString);
                ddlCommunity.DataTextField = "CommunityName";
                ddlCommunity.DataValueField = "CommunityId";
                ddlCommunity.DataBind();
                ddlCommunity.Items.Insert(0, new ListItem("--Select Community--", "-1"));

                lblCommunityID.Text = "";
                lblPropertyID.Text = "";
                lblBuildingId.Text = "";

                txtCommunityTcmId.Text = "";
                txtPropertyTcmId.Text = "";
                txtBuildingTcmId.Text = "";

                ddlBuilding.Items.Clear();
                gvUnits.DataSource = null;
                gvUnits.DataBind();
            }
            catch (Exception ex)
            {
                lblError.Text = ex.Message + ex.StackTrace;
            }
            finally
            {
            }
        }
        protected void DdlCommunity_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                lblResult.Visible = false;
                if (ddlCommunity.SelectedValue != "-1")
                {
                    if (Session["CommunityDetails"] != null)
                    {
                        //for tcmid
                        DataTable dt = (DataTable)Session["CommunityDetails"];
                        dt.DefaultView.RowFilter = "CommunityId=" + ddlCommunity.SelectedValue;
                        txtCommunityTcmId.Text = dt.DefaultView.ToTable().Rows[0]["TcmId"].ToString();
                        lblCommunityID.Text = ddlCommunity.SelectedValue;

                        ddlProperty.DataSource = Session["PropertyDetails"] = (new ClsPropertyDetailsBal()).GetProperties(strConnectionString,
                            Convert.ToInt32(ddlCommunity.SelectedValue));
                        ddlProperty.DataTextField = "PropertyName";
                        ddlProperty.DataValueField = "PropertyId";
                        ddlProperty.DataBind();
                        ddlProperty.Items.Insert(0, new ListItem("--Select Property--", "-1"));

                        lblPropertyID.Text = "";
                        lblBuildingId.Text = "";

                        txtPropertyTcmId.Text = "";
                        txtBuildingTcmId.Text = "";

                        ddlBuilding.Items.Clear();
                        gvUnits.DataSource = null;
                        gvUnits.DataBind();
                    }
                }
                else
                {
                    lblCommunityID.Text = "";
                    lblPropertyID.Text = "";
                    lblBuildingId.Text = "";

                    txtCommunityTcmId.Text = "";
                    txtPropertyTcmId.Text = "";
                    txtBuildingTcmId.Text = "";

                    ddlProperty.Items.Clear();
                    ddlBuilding.Items.Clear();
                    gvUnits.DataSource = null;
                }


            }
            catch (Exception)
            {
            }
            finally
            {
            }
        }
        protected void DdlProperty_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                lblResult.Visible = false;
                if (ddlProperty.SelectedValue != "-1")
                {
                    if (Session["PropertyDetails"] != null)
                    {
                        //for tcmid
                        DataTable dt = (DataTable)Session["PropertyDetails"];
                        dt.DefaultView.RowFilter = "PropertyId=" + ddlProperty.SelectedValue;
                        txtPropertyTcmId.Text = dt.DefaultView.ToTable().Rows[0]["TcmId"].ToString();
                        lblPropertyID.Text = ddlProperty.SelectedValue;


                        ddlBuilding.DataSource = Session["BuildingDetails"] = (new ClsPropertyDetailsBal()).GetBuildings(strConnectionString,
                               Convert.ToInt32(ddlCommunity.SelectedValue),
                                Convert.ToInt32(ddlProperty.SelectedValue));
                        ddlBuilding.DataTextField = "BuildingName";
                        ddlBuilding.DataValueField = "BuildingId";
                        ddlBuilding.DataBind();
                        ddlBuilding.Items.Insert(0, new ListItem("--Select Building--", "-1"));


                        lblBuildingId.Text = "";
                        txtBuildingTcmId.Text = "";

                        gvUnits.DataSource = null;
                        gvUnits.DataBind();
                    }
                }
                else
                {
                    lblPropertyID.Text = "";
                    lblBuildingId.Text = "";
                    txtPropertyTcmId.Text = "";
                    txtBuildingTcmId.Text = "";
                    ddlBuilding.Items.Clear();
                    gvUnits.DataSource = null;
                    gvUnits.DataBind();
                }
            }
            catch (Exception)
            {
            }
            finally
            {
            }
        }
        protected void DdlBuilding_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                lblResult.Visible = false;
                if (ddlBuilding.SelectedValue != "-1")
                {
                    if (Session["BuildingDetails"] != null)
                    {
                        //for tcmid
                        DataTable dt = (DataTable)Session["BuildingDetails"];
                        dt.DefaultView.RowFilter = "BuildingId=" + ddlBuilding.SelectedValue;
                        txtBuildingTcmId.Text = dt.DefaultView.ToTable().Rows[0]["TcmId"].ToString();
                        lblBuildingId.Text = ddlBuilding.SelectedValue;

                        gvUnits.DataSource = (new ClsPropertyDetailsBal()).GetAllUnits(strConnectionString,
                             Convert.ToInt32(ddlCommunity.SelectedValue),
                               Convert.ToInt32(ddlProperty.SelectedValue),
                                 Convert.ToInt32(ddlBuilding.SelectedValue));
                        gvUnits.DataBind();
                    }
                }
                else
                {

                    lblBuildingId.Text = "";
                    txtBuildingTcmId.Text = "";

                    gvUnits.DataSource = null;
                    gvUnits.DataBind();

                }
            }
            catch (Exception)
            {
            }
            finally
            {
            }
        }
        protected void BtnCommunity_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtCommunityTcmId.Text.Trim() != "" && lblCommunityID.Text != "")
                {
                    //Hard coding eng website
                    txtCommunityTcmId.Text = txtCommunityTcmId.Text.Trim().Replace("tcm:128", "tcm:130");
                    string strResult = (new ClsPropertyDetailsBal()).UpdateTcmId(strConnectionString, 1, Convert.ToInt32(lblCommunityID.Text), 0, 0, 0, txtCommunityTcmId.Text.Trim());
                    if (strResult == "success")
                    {
                        lblResult.Text = "TCMID " + txtCommunityTcmId.Text.Trim() + "  is saved successfully for the community " + ddlCommunity.SelectedItem.Text + " in the Database: " + dbConStrList.SelectedItem.Value;
                        lblResult.ForeColor = System.Drawing.Color.Green;
                        lblResult.Visible = true;

                        Session["CommunityDetails"] = (new ClsPropertyDetailsBal()).GetAllCommunities(strConnectionString);
                    }
                    else
                    {
                        lblResult.Text = "TCMID is not saved.";
                        lblResult.ForeColor = System.Drawing.Color.Red;
                        lblResult.Visible = true;
                    }
                }
                else
                {
                    lblResult.Text = "Select Community/Enter TcmId";
                    lblResult.ForeColor = System.Drawing.Color.Red;
                    lblResult.Visible = true;
                }
            }
            catch (Exception)
            {
            }
            finally
            {
            }
        }
        protected void BtnProperty_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtPropertyTcmId.Text.Trim() != "" && lblPropertyID.Text != "")
                {
                    //Hard coding eng website
                    txtPropertyTcmId.Text = txtPropertyTcmId.Text.Trim().Replace("tcm:128", "tcm:130");
                    string strResult = (new ClsPropertyDetailsBal()).UpdateTcmId(strConnectionString, 2, 0, Convert.ToInt32(lblPropertyID.Text), 0, 0, txtPropertyTcmId.Text.Trim());
                    if (strResult == "success")
                    {
                        lblResult.Text = "TCMID " + txtPropertyTcmId.Text.Trim() + " is saved successfully for the property " + ddlProperty.SelectedItem.Text + " in the Database: " + dbConStrList.SelectedItem.Value;
                        lblResult.ForeColor = System.Drawing.Color.Green;
                        lblResult.Visible = true;

                        Session["PropertyDetails"] = (new ClsPropertyDetailsBal()).GetProperties(strConnectionString,
                              Convert.ToInt32(ddlCommunity.SelectedValue));
                    }
                    else
                    {
                        lblResult.Text = "TCMID is not saved.";
                        lblResult.ForeColor = System.Drawing.Color.Red;
                        lblResult.Visible = true;
                    }
                }
                else
                {
                    lblResult.Text = "Select Property/Enter TcmId";
                    lblResult.ForeColor = System.Drawing.Color.Red;
                    lblResult.Visible = true;
                }
            }
            catch (Exception)
            {
            }
            finally
            {
            }
        }
        protected void BtnBuilding_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtBuildingTcmId.Text.Trim() != "" && lblBuildingId.Text != "")
                {
                    //Hard coding eng website
                    txtBuildingTcmId.Text = txtBuildingTcmId.Text.Trim().Replace("tcm:128", "tcm:130");
                    string strResult = (new ClsPropertyDetailsBal()).UpdateTcmId(strConnectionString, 3, 0, 0, Convert.ToInt32(lblBuildingId.Text), 0, txtBuildingTcmId.Text.Trim().Replace("tcm:128", "tcm:130"));
                    if (strResult == "success")
                    {
                        lblResult.Text = "TCMID " + txtBuildingTcmId.Text.Trim().Replace("tcm:128", "tcm:130") + " is saved successfully for the building " + ddlBuilding.SelectedItem.Text + " in the Database: " + dbConStrList.SelectedItem.Value;
                        lblResult.ForeColor = System.Drawing.Color.Green;
                        lblResult.Visible = true;

                        Session["BuildingDetails"] = (new ClsPropertyDetailsBal()).GetBuildings(strConnectionString,
                            Convert.ToInt32(ddlCommunity.SelectedValue),
                             Convert.ToInt32(ddlProperty.SelectedValue));
                    }
                    else
                    {
                        lblResult.Text = "Select Property/Enter TcmId";
                        lblResult.ForeColor = System.Drawing.Color.Red;
                        lblResult.Visible = true;
                    }
                }
                else
                {
                    lblResult.Text = "Select Building/Enter TcmId";
                    lblResult.ForeColor = System.Drawing.Color.Red;
                    lblResult.Visible = true;
                }
            }
            catch (Exception)
            {
            }
            finally
            {
            }
        }
        protected void GvUnits_RowCommand(object sender, GridViewCommandEventArgs e)
        {

            GridViewRow row = (GridViewRow)(((Control)e.CommandSource).NamingContainer);
            TextBox txtTcmId = row.FindControl("txtTcmId") as TextBox;
            Label lblUnitName = row.FindControl("lblUnitName") as Label;
            string id = gvUnits.DataKeys[row.RowIndex].Value.ToString();

            if (txtTcmId.Text.Trim() != "")
            {
                string strResult = (new ClsPropertyDetailsBal()).UpdateTcmId(strConnectionString, 4, 0, 0, 0, Convert.ToInt32(id), txtTcmId.Text.Trim());

                if (strResult == "success")
                {
                    lblResult.Text = "TCMID " + txtTcmId.Text.Trim() + " is saved successfully for the Unit " + lblUnitName.Text + " in the Database: " + dbConStrList.SelectedItem.Value;
                    lblResult.ForeColor = System.Drawing.Color.Green;
                    lblResult.Visible = true;
                }
                else
                {
                    lblResult.Text = "TCMID is not saved.";
                    lblResult.ForeColor = System.Drawing.Color.Red;
                    lblResult.Visible = true;
                }
            }
            else
            {
                lblResult.Text = "TCMID is not saved.";
                lblResult.ForeColor = System.Drawing.Color.Red;
                lblResult.Visible = true;
            }
        }
        protected void dbConStrList_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (dbConStrList.SelectedItem.Value.ToLower().Equals("staging"))
            {
                strConnectionString = "ConProretyDetailsStaging";
            }
            else if (dbConStrList.SelectedItem.Value.ToLower().Equals("live"))
            {
                strConnectionString = "ConProretyDetailsLive";
            }
            else
            {
                strConnectionString = "ConProretyDetails";
            }
        }
    }
}