﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
using System.Web;
using Tridion.ContentManager;
using Tridion.ContentManager.CommunicationManagement;
using Tridion.ContentManager.ContentManagement;
using Tridion.ContentManager.ContentManagement.Fields;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.Publishing;
using Tridion.Extensions.ContentManager.Templating;
using Tridion.ContentManager.Publishing.Rendering;

namespace BK.Web.Tridion.BuildingBlocks.Templates
{
    [TcmTemplateTitle("Control Tag Data")]
    class ControlTagData : TemplateBase
    {
        public override void Transform(Engine engine, Package package)
        {
            this.Initialize(engine, package);
            Page page = GetPage();

            Item outputItem = m_Package.GetByName(Package.OutputName);
            string outputValue = outputItem.GetAsString();

            string strYear = GetYear(page);

            outputValue = outputValue.Replace("[*YEAR*]",strYear); 
            m_Package.Remove(outputItem);
            outputItem.SetAsString(outputValue);
            package.PushItem(Package.OutputName, outputItem);

            outputValue = outputValue.Replace("[*LeftClass*]", (getMetaDataPage(page, "frightimage") == "Yes") ? "left-short" : "left");
            m_Package.Remove(outputItem);
            outputItem.SetAsString(outputValue);
            package.PushItem(Package.OutputName, outputItem);  


        }

        private string GetYear(Page page)
        {
            string strVal = "Null";
            ItemFields metadataFields = new ItemFields(page.Metadata, page.MetadataSchema);
            if (metadataFields != null)
            {
                if (!string.IsNullOrEmpty(metadataFields["fyear"].ToString()))
                {
                    strVal = metadataFields["fyear"].ToString().Split(' ')[1];

                    Keyword  keyword  = m_Engine.GetObject(strVal) as Keyword ;

                    strVal = keyword.Description.ToString();   

                }
            }
            return strVal;
        }

        private string getMetaDataPage(Page page, string strFieldname)
        {

            string strRetVal = "";
            strRetVal = page.PublishLocationPath;

            if (page.Metadata != null)
            {
                ItemFields metadataFields = new ItemFields(page.Metadata, page.MetadataSchema);
                if (metadataFields != null)
                {
                    if (!string.IsNullOrEmpty(metadataFields[strFieldname].ToString()))
                    {
                        strRetVal = metadataFields[strFieldname].ToString();
                    }
                }

            }
            return strRetVal;

        }

    }
}
