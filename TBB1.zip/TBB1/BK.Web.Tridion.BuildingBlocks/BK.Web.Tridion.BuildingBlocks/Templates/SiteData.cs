﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
using System.Web;
using Tridion.ContentManager;
using Tridion.ContentManager.CommunicationManagement;
using Tridion.ContentManager.ContentManagement;
using Tridion.ContentManager.ContentManagement.Fields;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.Publishing;
using Tridion.Extensions.ContentManager.Templating;
using Tridion.ContentManager.Publishing.Rendering;

namespace BK.Web.Tridion.BuildingBlocks.Templates
{
    [TcmTemplateTitle("SiteData")] 
    public class SiteData : TemplateBase
    {
        int i = 0;
        public override void Transform(Engine engine, Package package)
        {
            this.Initialize(engine, package);
            Page page = GetPage();
            StructureGroup RootSG = (StructureGroup)page.OrganizationalItem as StructureGroup;

            m_Package.PushItem("StructureGroupForMenu", m_Package.CreateStringItem(ContentType.Text, RenderParentSGRoot(page,page.OrganizationalItem)));
            m_Package.PushItem("containerClass", m_Package.CreateStringItem(ContentType.Text, (getMetaDataPage(page, "frightimage") == "Yes") ? "sub_page" : ""));

        }

        private string getPubURL(Page page)
        {
            string pub = "tcm:0-" + page.Id.PublicationId + "-1";
            Publication publication;
            publication = m_Engine.GetObject(pub) as Publication;
            return publication.PublicationUrl.ToString();
        }

        private string getPubPath(Page page)
        {
            string pub = "tcm:0-" + page.Id.PublicationId + "-1";
            Publication publication;
            publication = m_Engine.GetObject(pub) as Publication;
            return publication.PublicationPath.ToString();
        }




        private string getPubID(Page page)
        {
            string pub = "tcm:0-" + page.Id.PublicationId + "-1";
            Publication publication;
            publication = m_Engine.GetObject(pub) as Publication;
            return publication.Id.ToString().Split('-')[1].ToString();
        }

        private string PublicationTargetID(Page page)
        {
            string strPublicationTargetID = "tcm:0-0-0";
            if (m_Engine.RenderMode == RenderMode.Publish)
            {
                strPublicationTargetID = m_Engine.PublishingContext.PublicationTarget.Id.ToString();
            }

            return strPublicationTargetID;

        }

        private string RenderParentSGRoot(Page page,OrganizationalItem oRecurSG)
        {
            string strORGID = "";
            

            OrganizationalItem oParentSG;

            OrganizationalItem oParentSGVal = oRecurSG;
            
            if (oRecurSG.OrganizationalItem  != null)
            {
                oParentSG = oRecurSG.OrganizationalItem;
                RenderParentSGRoot(page,oParentSG);
                i = i + 1;
            }

            if (i == 1)
            {
               strORGID =  page.OrganizationalItem.Id;
 
            }
            if (i == 2)
            {
               strORGID =  page.OrganizationalItem.OrganizationalItem.Id; 

            }

            return strORGID; 
        }

        private string getMetaDataPage(Page page, string strFieldname)
        {

            string strRetVal = "";
            strRetVal = page.PublishLocationPath;

            if (page.Metadata != null)
            {
                ItemFields metadataFields = new ItemFields(page.Metadata, page.MetadataSchema);
                    if (metadataFields != null)
                    {
                        if (!string.IsNullOrEmpty(metadataFields[strFieldname].ToString()))
                        {
                            strRetVal = metadataFields[strFieldname].ToString();
                        }
                    }

            }
            return strRetVal;

        }

    }
}
