﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
using System.Web;
using Tridion.ContentManager;
using Tridion.ContentManager.CommunicationManagement;
using Tridion.ContentManager.ContentManagement;
using Tridion.ContentManager.ContentManagement.Fields;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.Publishing;
using Tridion.Extensions.ContentManager.Templating;
using Tridion.ContentManager.Publishing.Rendering;

namespace BK.Web.Tridion.BuildingBlocks.Templates
{

    [TcmTemplateTitle("Get WallPaper Menu")] 
   class LoopSG : TemplateBase  
    {
        public override void Transform(Engine engine, Package package)
        {
            this.Initialize(engine, package);
            Page page = GetPage();
            StructureGroup RootSG = (StructureGroup)page.OrganizationalItem as StructureGroup;

            m_Package.PushItem("GalleryMenu", m_Package.CreateStringItem(ContentType.Html, GetLinks(RootSG, page.Title)));
        }

        private string GetLinks(StructureGroup SG, string strTitle)
        {

            StringBuilder sb = new StringBuilder();
            Page page;

            Filter filterpages = new Filter();
            filterpages.Conditions["ItemType"] = ItemType.Page;

            if (!strTitle.Contains("999"))
            {
                sb.Append("<table style=\"width:100%\">");
                sb.Append("<tr>");
                sb.Append("<td align=\"left\" width=\"100%\">");
                IList<RepositoryLocalObject> listPages = SG.GetItems(filterpages);
                foreach (RepositoryLocalObject RepositoryLocalObjectpages in listPages)
                {
                    page = m_Engine.GetObject(RepositoryLocalObjectpages.Id) as Page;

                    if (page.Title.Contains(".") && !page.Title.Contains("999"))
                        sb.Append("<a style=\"margin: 0px 2px 0px 2px\" class = \"media_controls\" href= \"" + page.PublishLocationUrl + "\" >" + page.Title.Split('.')[1].ToString().Trim() + "</a>");

                }
                sb.Append("</td>");
                sb.Append("</tr>");
                sb.Append("</table>");
            }

            return sb.ToString(); 
        
        }

    }
}
