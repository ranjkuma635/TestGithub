﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Tridion.Extensions.ContentManager.Templating
{
	/// <summary>
	/// This interface is used by the XSLT Mediator, any class implementing this interface will be used
	/// as an extension to the XSLT transformation if the Mediator is configured to load extension objects from Tridion.
	/// This configuration is done in the tridion.ContentManager.config file.
	/// </summary>
	public interface IXSLTHelper
	{
	}
}
