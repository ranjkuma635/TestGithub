﻿using System;
using System.Collections.Generic;
using System.Linq;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager;
using Tridion.Extensions.ContentManager.Templating;
using Tridion.ContentManager.CommunicationManagement;
using Tridion.ContentManager.Publishing;
using Tridion.ContentManager.ContentManagement;

namespace URBANE.Web.Templating.BuildingBlocks.Templates
{
    [TcmTemplateTitle("PublishNavigation")]
    public class PublishNavigation : TemplateBase
    {
        public override void Transform(Engine engine, Package package)
        {
            base.Transform(engine, package);
            if (Page.ComponentPresentations.Count > 0)
            {
                Tridion.ContentManager.ContentManagement.Component comp = Page.ComponentPresentations[0].Component;
                {
                    try
                    {
                        Logger.Info("Publishing Navigation");
                        string strPubid = Page.Id.PublicationId.ToString();

                        TcmUri pagUri = new TcmUri("tcm:" + strPubid + "-111876-64");

                        Page xmlPage = engine.GetObject(pagUri) as Page;

                        IList<IdentifiableObject> items = new List<IdentifiableObject>();
                        items.Add(xmlPage);
                        IList<PublicationTarget> targets = new List<PublicationTarget>();
                        if (engine.PublishingContext.PublicationTarget != null)
                        {
                            targets.Add(engine.PublishingContext.PublicationTarget);
                            PublishEngine.Publish(items, engine.PublishingContext.PublishInstruction, targets);
                        }
                    }
                    catch (Exception ex)
                    {
                        Logger.Info("Exception Message: " + ex.Message);
                        Logger.Info("Exception StackTrace: " + ex.StackTrace);
                    }
                }
            }
        }

        public bool IsCompMetaRevised(Component latest)
        {
            DateTime checkdate = latest.RevisionDate;

            Logger.Info("Date " + checkdate);
            Logger.Info("version " + latest.Version);

            Filter f = new Filter();
            f.Conditions["ItemType"] = ItemType.Component;
            IList<VersionedItem> comps = latest.GetVersions(f);
            Component oldcomp = (Component)comps[comps.Count - 2];
            DateTime lastDate = comps[comps.Count - 2].RevisionDate;
            Logger.Info("lastDate " + lastDate);
            Logger.Info("lastversion " + oldcomp.Version);

            try
            {
                if (latest.Metadata != null && oldcomp.Metadata != null)
                {
                    if (!latest.Metadata.SelectSingleNode("//node()[local-name() = 'title']").InnerText.Equals(oldcomp.Metadata.SelectSingleNode("//node()[local-name() = 'title']").InnerText))
                        return true;
                    if (!latest.Metadata.SelectSingleNode("//node()[local-name() = 'value']").InnerText.Equals(oldcomp.Metadata.SelectSingleNode("//node()[local-name() = 'value']").InnerText))
                        return true;
                    if (!latest.Metadata.SelectSingleNode("//node()[local-name() = 'image']").Attributes["xlink:href"].Value.Equals(oldcomp.Metadata.SelectSingleNode("//node()[local-name() = 'image']").Attributes["xlink:href"].Value))
                        return true;
                }
                Logger.Info("returning false");
                return false;
            }
            catch (Exception ex)
            {
                return true;
            }
        }

    }

}
