﻿using System;
using System.Collections.Generic;
using System.Linq;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.Extensions.ContentManager.Templating;
using Tridion.ContentManager.ContentManagement;
using Emaar.Web.Tridion.System.Extensions;
using Tridion.ContentManager.ContentManagement.Fields;

namespace URBANE.Web.Templating.BuildingBlocks.Templates
{
    [TcmTemplateTitle("Constants")]
    public class Constants : TemplateBase
    {
        /// <summary>
        /// Transforms the current component.
        /// </summary>
        /// <param name="engine">The engine.</param>
        /// <param name="package">The package.</param>
        public override void Transform(Engine engine, Package package)
        {
            string strPubid = string.Empty;
            base.Transform(engine, package);
            if(Component!=null)
             strPubid = Component.Id.PublicationId.ToString();
            else if(Page!=null)
                 strPubid = Page.Id.PublicationId.ToString();

            string itemId = "111670";
            string strCompId = "tcm:" + strPubid + "-"+itemId +"-16";
            Component component=GetComponent(strCompId);
            if (component != null){
                IList<ItemFields> pairs = component.EmbeddedValues("Text");
                foreach (ItemFields pair in pairs){
                    Package.AddString(pair.StringValue("Key"), pair.StringValue("Value"));
                }
            }        
        }

    }
}