﻿using System;
using System.Collections.Generic;
using System.Xml;
using Tridion.ContentManager.ContentManagement.Fields;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager;
using System.Collections;
using Tridion.ContentManager.ContentManagement;
using Tridion.ContentManager.CommunicationManagement;
using System.Xml.XPath;
using System.Web;
using Tridion.Extensions.ContentManager.Templating;
using Emaar.Web.Tridion.System.Extensions;
using Tridion.ContentManager.Publishing;

namespace URBANE.Web.Templating.BuildingBlocks.Templates
{

    [TcmTemplateTitle("Navigation XML")]
    public class Navigation : TemplateBase
    {

        private List<String> mLinks;
        private Engine engine;

        /// <summary>
        /// Executes the template transformation
        /// </summary>
        /// <param name="engine">Tridion Engine.</param>
        /// <param name="package">Tridion Package.</param>
        public override void Transform(Engine engine, Package package)
        {
            base.Transform(engine, package);

            mLinks = new List<String>();
            this.engine = engine;
            mLinks.Add("redirect");
            mLinks.Add("component");
            mLinks.Add("external");

            // Build the output navigation xml structure
            XmlDocument xDoc = new XmlDocument();
            xDoc.LoadXml("<root/>");

            // Start rendering with the root structure group children
            XmlElement xRoot = xDoc.DocumentElement;
            RenderNavigation(ref xRoot, BuildItemCache(engine, package), Publication.RootStructureGroup.Id);

            package.AddXml(Package.OutputName, xDoc.OuterXml);
        }

        /// <summary>
        /// Indicate whether the specified metadata field should be included in the navigation xml.
        /// Override this method in derived templates in order to supply implementation specific navigation.
        /// </summary>
        /// <param name="fieldName">Metadata Fieldname</param>
        /// <returns>True if the metadata should be included</returns>
        protected bool IncludeMetadata(string FieldName)
        {
            return mLinks.Contains(FieldName);
        }

        /// <summary>
        /// Indicate whether the specified metadata field should be rendered as a component tcm uri only.
        /// Override this method in derived templates in order to supply implementation specific navigation.
        /// </summary>
        /// <param name="fieldName">Metadata Fieldname</param>
        /// <returns>True if the metadata should be included</returns>
        protected bool AsComponentLink(string FieldName)
        {
            return true;
        }

        /// <summary>
        /// Parses final navigable item URL
        /// </summary>
        /// <param name="Url">URL</param>
        /// <returns>Parsed URL to include in the generated navigation XML</returns>
        protected virtual String ParseUrl(String Url)
        {
            if (!String.IsNullOrEmpty(Url))
            {
                String pages = "default.aspx;index.aspx";
                String filename = VirtualPathUtility.GetFileName(Url).ToLower();

                if (pages.Contains(filename))
                    return VirtualPathUtility.GetDirectory(Url);
            }

            return Url;
        }

        private Hashtable BuildItemCache(Engine engine, Package package)
        {
            Filter filter = new Filter();

            filter.Conditions["ItemType"] = ItemType.StructureGroup | ItemType.Page;
            filter.Conditions["Recursive"] = true;

            filter.BaseColumns = ListBaseColumns.Extended;

            // Retrieve only items from the root structure group (Do not loop content folders for performance reasons)
            XmlElement list = Publication.RootStructureGroup.GetListItems(filter);

            Hashtable itemCache = new Hashtable(list.ChildNodes.Count);

            XPathNavigator xNav = list.CreateNavigator();
            XPathExpression xExpr = xNav.Compile("/tcm:ListItems/tcm:Item[(@IsPublished = 'true' or @Type = '4') and string(number(substring-before(@Title, '. '))) != 'NaN']");
            xExpr.SetContext(NSManager);
            xExpr.AddSort("number(substring-before(@Title, '. '))", XmlSortOrder.Ascending, XmlCaseOrder.None, String.Empty, XmlDataType.Number);

            // Find out which publication target we are publishing to
            bool isProduction = false;

            if (engine.PublishingContext.PublicationTarget != null)
            {
                string title = engine.PublishingContext.PublicationTarget.Title.ToLower();

                // For publication targets which are named 'Live' or 'Production' we should filter navigation items
                if (title.Contains("live") || title.Contains("production"))
                    isProduction = true;
            }

            // Populate all navigation items from the Tridion database
            foreach (XPathNavigator node in xNav.Select(xExpr))
            {
                string id = node.GetAttribute("ID", String.Empty);

                if (!String.IsNullOrEmpty(id))
                {
                    RepositoryLocalObject item = GetObject<RepositoryLocalObject>(id);

                    if (item != null)
                    {
                        // If the item is marked "Not Live" and we are publishing to a "Live/Production" publication target, skip it.
                        if (String.Compare(item.StringMetaValue("NotLive"), "Yes", StringComparison.InvariantCultureIgnoreCase) == 0 && isProduction)
                            continue;

                        string parentId = item.OrganizationalItem.Id;
                        List<RepositoryLocalObject> items = itemCache[parentId] as List<RepositoryLocalObject>;

                        if (items == null)
                        {
                            items = new List<RepositoryLocalObject>();
                            itemCache.Add(parentId, items);
                        }

                        items.Add(item);
                    }
                }
            }

            return itemCache;
        }

        private void RenderNavigation(ref XmlElement Root, Hashtable itemCache, String ParentId)
        {
            List<RepositoryLocalObject> items = itemCache[ParentId] as List<RepositoryLocalObject>;

            if (items != null)
            {
                foreach (RepositoryLocalObject item in items)
                {
                    if (item is StructureGroup)
                        RenderStructureGroup(ref Root, itemCache, item as StructureGroup);

                    if (item is Page)
                        RenderPage(ref Root, item as Page);
                }
            }
        }

        private void RenderStructureGroup(ref XmlElement Root, Hashtable itemCache, StructureGroup StructureGroup)
        {
            string parentId = StructureGroup.Id;

            XmlElement xNode = Root.OwnerDocument.CreateElement("node");

            xNode.SetAttribute("id", StructureGroup.Id.ToString());
            xNode.SetAttribute("title", StructureGroup.Title);
            //xElement.SetAttribute("url", StructureGroup.PublishLocationUrl);

            // Loop through all child items to find a possible index page            
            List<RepositoryLocalObject> items = itemCache[parentId] as List<RepositoryLocalObject>;

            if (items != null)
            {
                foreach (RepositoryLocalObject item in items)
                {
                    if (item is Page)
                    {
                        Page childPage = item as Page;

                        // Index pages are prefixed with "000. "
                        if (childPage.Title.StartsWith("000. "))
                        {
                            xNode.SetAttribute("url", ParseUrl(childPage.PublishLocationUrl));
                            xNode.SetAttribute("indexpage", childPage.Id);
                            ComponentTitle(ref xNode, childPage);
                            break;
                        }
                    }
                }
            }

            // Parse metadata if available
            if (StructureGroup.Metadata != null)
            {
                ItemFields metadata = new ItemFields(StructureGroup.Metadata, StructureGroup.MetadataSchema);
                ParseFields(ref xNode, metadata);
            }

            // Recurse into the structure group            
            RenderNavigation(ref xNode, itemCache, parentId);
            Root.AppendChild(xNode);
        }

        private void RenderPage(ref XmlElement Root, Page Page)
        {
            // Add only non-index pages
            if (!Page.Title.StartsWith("000. ") && ShowInOutput(Page))
            {
                XmlElement xNode = Root.OwnerDocument.CreateElement("node");

                xNode.SetAttribute("id", Page.Id.ToString());
                xNode.SetAttribute("title", Page.Title);
                xNode.SetAttribute("url", ParseUrl(Page.PublishLocationUrl));

                ComponentTitle(ref xNode, Page);

                if (Page.Metadata != null)
                {
                    ItemFields metadata = new ItemFields(Page.Metadata, Page.MetadataSchema);
                    ParseFields(ref xNode, metadata);
                }

                Root.AppendChild(xNode);
            }
        }

        private bool ShowInOutput(RepositoryLocalObject pageOrSg)
        {
            if (engine.RenderMode == Tridion.ContentManager.Publishing.RenderMode.Publish)
            {
                if (PublishEngine.IsPublished(pageOrSg, engine.PublishingContext.PublicationTarget))
                    return true;
            }
            return false;
        }

        private void ComponentTitle(ref XmlElement Node, Page Page)
        {
            if (Page.ComponentPresentations.Count > 0)
            {
                Component component = Page.ComponentPresentations[0].Component;

                if (component.EmbeddedMetaValue("seodata") != null)
                {
                    ItemFields seodata = component.EmbeddedMetaValue("seodata");
                    if (!String.IsNullOrEmpty(seodata.StringValue("navigationTitle")))
                        Node.SetAttribute("navigationTitle", seodata.StringValue("navigationTitle"));
                    else if (!String.IsNullOrEmpty(component.Content.SelectSingleNode("//node()[local-name() = 'title']").InnerText))
                        Node.SetAttribute("navigationTitle", component.Content.SelectSingleNode("//node()[local-name() = 'title']").InnerText);
                }


                if (component.EmbeddedMetaValue("callout") != null)
                {
                    ItemFields callout = component.EmbeddedMetaValue("callout");
                    if (!String.IsNullOrEmpty(callout.StringValue("title")))
                        Node.SetAttribute("calloutTitle", callout.StringValue("title"));
                    else
                        Node.SetAttribute("calloutTitle", component.Content.SelectSingleNode("//node()[local-name() = 'title']").InnerText);

                    if (!String.IsNullOrEmpty(callout.StringValue("value")))
                        Node.SetAttribute("calloutText", callout.StringValue("value"));

                    if (callout.ComponentValue("image") != null)
                    {
                        Node.SetAttribute("calloutImage", PublishBinary(callout.ComponentValue("image")));
                        Component compCalloutImage = callout.ComponentValue("image");
                        ItemFields calloutImageMeta = new ItemFields(compCalloutImage.Metadata, compCalloutImage.MetadataSchema);
                        Node.SetAttribute("calloutImageAlt", calloutImageMeta.StringValue("altText"));
                    }
                    else if (component.ComponentValue("image") != null)
                        Node.SetAttribute("calloutImage", PublishBinary(component.ComponentValue("image")));
                }
            }
        }

        private void ParseFields(ref XmlElement Node, ItemFields Fields)
        {
            foreach (ItemField field in Fields)
            {

                if (IncludeMetadata(field.Name))
                {
                    if (field is SingleLineTextField)
                    {
                        IList<String> values = field.StringValues();

                        if (values != null && values.Count > 0)
                        {
                            foreach (String value in values)
                                Node.AddTextNode(field.Name, value);
                        }
                    }
                    else if (field is ExternalLinkField)
                    {
                        IList<String> values = field.StringValues();

                        if (values != null && values.Count > 0)
                        {
                            foreach (String value in values)
                                Node.AddTextNode(field.Name, value);
                        }
                    }
                    else if (field is DateField)
                    {
                        IList<DateTime> values = field.DateValues();

                        if (values != null && values.Count > 0)
                        {
                            foreach (DateTime value in values)
                                Node.AddTextNode(field.Name, value.ToString("yyyyMMddHHmmss"));
                        }
                    }
                    else if (field is NumberField)
                    {
                        IList<Double> values = field.NumberValues();

                        if (values != null && values.Count > 0)
                        {
                            foreach (Double value in values)
                                Node.AddTextNode(field.Name, value.ToString());
                        }
                    }
                    else if (field is MultimediaLinkField)
                    {
                        ComponentLinkField test = field as ComponentLinkField;

                        IList<Component> values = field.ComponentValues();

                        if (values != null && values.Count > 0)
                        {
                            foreach (Component value in values)
                            {
                                string url = PublishBinary(value);

                                if (!String.IsNullOrEmpty(url))
                                    Node.AddTextNode(field.Name, url);
                            }
                        }
                    }
                    else if (field is ComponentLinkField)
                    {
                        ComponentLinkField test = field as ComponentLinkField;

                        IList<Component> values = field.ComponentValues();

                        if (values != null && values.Count > 0)
                        {
                            foreach (Component value in values)
                            {
                                if (AsComponentLink(field.Name))
                                    Node.AddTextNode(field.Name, value.Id);
                                else
                                {
                                    try
                                    {
                                        ItemFields fields = new ItemFields(value.Content, value.Schema);

                                        XmlElement xField = Node.OwnerDocument.CreateElement(field.Name);

                                        ParseFields(ref xField, fields);

                                        if (xField.ChildNodes.Count > 0)
                                            Node.AppendChild(xField);
                                    }
                                    catch (Exception ex)
                                    {
                                        IList<Component> mvalues = field.ComponentValues();

                                        if (mvalues != null && mvalues.Count > 0)
                                        {
                                            foreach (Component valuev in mvalues)
                                            {
                                                string url = PublishBinary(valuev);
                                                if (!String.IsNullOrEmpty(url))
                                                    Node.AddTextNode(field.Name, url);
                                            }
                                        }

                                    }
                                }
                            }
                        }
                    }
                    else if (field is XhtmlField)
                    {
                        IList<String> values = field.XHTMLValues();

                        if (values != null && values.Count > 0)
                        {
                            foreach (String value in values)
                                Node.AddXmlNode(field.Name, value);
                        }
                    }
                    else if (field is KeywordField)
                    {
                        IList<Keyword> values = field.KeywordValues();

                        if (values != null && values.Count > 0)
                        {
                            foreach (Keyword value in values)
                            {
                                XmlElement xField = Node.AddTextNode(field.Name, value.Title);
                                xField.SetAttribute("id", value.Id);
                                xField.SetAttribute("key", value.Key);
                            }
                        }
                    }
                    else if (field is EmbeddedSchemaField)
                    {
                        IList<ItemFields> values = field.EmbeddedValues();

                        if (values != null && values.Count > 0)
                        {
                            foreach (ItemFields value in values)
                            {
                                XmlElement xField = Node.OwnerDocument.CreateElement(field.Name);
                                ParseFields(ref xField, value);

                                if (xField.ChildNodes.Count > 0)
                                    Node.AppendChild(xField);
                            }
                        }
                    }
                    else
                    {
                        Logger.Error("Navigation: Unknown field {0} found.", field.GetType().FullName);
                    }
                }
            }
        }
    }
}
