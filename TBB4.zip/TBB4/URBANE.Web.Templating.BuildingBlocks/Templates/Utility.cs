﻿using System;
using Emaar.Web.Tridion.System.Extensions;
using Tridion.ContentManager.CommunicationManagement;
using Tridion.ContentManager.ContentManagement;
using Tridion.ContentManager.ContentManagement.Fields;

namespace URBANE.Web.Templating.BuildingBlocks.Templates
{
    public static class Utility
    {
        /// <summary>
        /// Log an error message
        /// </summary>
        /// <param name="format">Message format string</param>
        /// <param name="args">Format string parameters</param>
        public static string removeXHTMLtags(string format)
        {
            return format.Replace(" xmlns=" + "\"" + "http://www.w3.org/1999/xhtml" + "\"", "");
        }

        public static String ComponentTitle(Page Page)
        {
            string navTitle = "";

            if (Page.ComponentPresentations.Count > 0)
            {
                Component component = Page.ComponentPresentations[0].Component;

                if (component.EmbeddedMetaValue("seodata") != null)
                {
                    ItemFields seoMetadata = component.EmbeddedMetaValue("seodata");
                    navTitle = seoMetadata.StringValue("navigationTitle");
                }
            }

            if (String.IsNullOrEmpty(navTitle))
            {
                if (Page.Title.IndexOf(".") != -1)
                    navTitle = Page.Title.Substring(Page.Title.IndexOf(".") + 1).Trim();
                else
                    navTitle = Page.Title.Trim();
            }

            return navTitle;
        }

    }
}
