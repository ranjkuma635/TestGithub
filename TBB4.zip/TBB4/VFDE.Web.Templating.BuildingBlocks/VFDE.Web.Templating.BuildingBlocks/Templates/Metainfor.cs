﻿using System;
using System.Collections.Generic;
using System.Xml;
using Tridion.ContentManager.ContentManagement.Fields;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager;
using System.Collections;
using Tridion.ContentManager.ContentManagement;
using Tridion.ContentManager.CommunicationManagement;
using System.Xml.XPath;
using System.Web;
using Tridion.Extensions.ContentManager.Templating;
using Emaar.Web.Tridion.System.Extensions;
using System.Text.RegularExpressions;
using System.IO;

namespace VFDE.Web.Templating.BuildingBlocks.Templates
{
    [TcmTemplateTitle("Metainfor")]
    public class Metainfor:TemplateBase 
    {
        public override void Transform(Engine engine, Package package)
        {
            string ShowPress = "No";
            string hidevfde = "No";
            String seoImage = String.Empty; ;
            String seoDescription = String.Empty;
            String seoKeywords = String.Empty;
            String spageTitle = String.Empty;

            base.Transform(engine, package);

            if (Page.Metadata != null && !string.IsNullOrEmpty(Page.StringMetaValue("hidepress")))
            {
                ShowPress = Page.StringMetaValue("hidepress"); 
            }
            else
            {
                ShowPress = getdata(Page.OrganizationalItem, "hidepress");
            }

            if (Page.Metadata != null && !string.IsNullOrEmpty(Page.StringMetaValue("hidevfde")))
            {
                hidevfde = Page.StringMetaValue("hidevfde"); 
            }
            else
            {
                hidevfde = getdata(Page.OrganizationalItem, "hidevfde");
            }

            if (Page.ComponentPresentations.Count > 0)
            {
                Component component = Page.ComponentPresentations[0].Component;

                if (component.EmbeddedMetaValue("seometadata") != null)
                {
                    ItemFields seoMetadata = component.EmbeddedMetaValue("seometadata");
                    spageTitle = seoMetadata.StringValue("fPageTitle");
                    if (seoMetadata.StringValue("fPageTitle") != null)
                    {
                        spageTitle = seoMetadata.StringValue("fPageTitle");
                    }
                    else if (component.StringValue("title") != null)
                    {
                        spageTitle = component.StringValue("title");
                    }
                    if (seoMetadata.StringValue("fSEODescription") != null)
                    {
                        seoDescription = seoMetadata.StringValue("fSEODescription");
                    }

                    if (seoMetadata.StringValue("fSEOKeywords") != null)
                    {
                        seoKeywords = seoMetadata.StringValue("fSEOKeywords");
                    }

                }

            }


            package.AddString("metaPageTitle", spageTitle);
            package.AddString("SEODescription", seoDescription);
            package.AddString("SEOKeywords", seoKeywords);

            Package.AddString("Hidevfde", hidevfde);
            Package.AddString("HidePress", ShowPress);
            Package.AddString("ShowRandom", checkrandom(Page));
            Package.AddString("DesignersXML", GettehDesignersXML(Page));

        }

        private string checkrandom(Page  page)
        {
            Component Component;
            string strcheckrandom = "No";

            if (page.ComponentPresentations.Count != 0)
            {
                Component = Page.ComponentPresentations[0].Component;

                if (Component.Schema.Title == "VFDE - Fashion Walk")
                {
                        strcheckrandom = "Yes";
                }
            }

            return strcheckrandom;
        }


        private string GettehDesignersXML(Page page)
        {

            string strGettehDesignersXML = "";

            if (page.Title.Split(".".ToCharArray(), StringSplitOptions.RemoveEmptyEntries)[0]!="000") 
            {
                if (page.OrganizationalItem.Metadata != null)
                {
                    if (page.OrganizationalItem.Metadata["designerstype"] != null)
                    {
                        if (page.OrganizationalItem.Metadata["designerstype"].InnerText == "International")
                        {
                            strGettehDesignersXML = "InternationalTalentShowcase.xml";
                        }
                        if (page.OrganizationalItem.Metadata["designerstype"].InnerText == "Local")
                        {
                            strGettehDesignersXML = "TheFashionCatwalk.xml";
                        }
                    }
                }
            }

            return strGettehDesignersXML;
        }

        private string getdata(OrganizationalItem oRecurSG,string field)
        {
            string fieldvalue = string.Empty;

            OrganizationalItem oParentSG;

            

            if (oRecurSG != null)
            {
                if (oRecurSG.Metadata != null)
                {

                    fieldvalue = oRecurSG.StringMetaValue(field);

                    if (string.IsNullOrEmpty(fieldvalue))
                    {
                        fieldvalue = oRecurSG.StringMetaValue(field);

                    }
                    else
                    {
                        oParentSG = oRecurSG.OrganizationalItem;
                        
                    }
                }
                else
                {
                    oParentSG = oRecurSG.OrganizationalItem;
                    
                }
            }

            return fieldvalue;

        }

    }
}
