﻿using System;
using System.Collections.Generic;
using System.Xml;
using Tridion.ContentManager.ContentManagement.Fields;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager;
using System.Collections;
using Tridion.ContentManager.ContentManagement;
using Tridion.ContentManager.CommunicationManagement;
using System.Xml.XPath;
using System.Web;
using Tridion.Extensions.ContentManager.Templating;
using Emaar.Web.Tridion.System.Extensions;
using System.Text.RegularExpressions;
using System.IO;

namespace VFDE.Web.Templating.BuildingBlocks.Templates
{
    [TcmTemplateTitle("Lectures XML")]
    public class Lectures : TemplateBase
    {
        public override void Transform(Engine engine, Package package)
        {

            base.Transform(engine, package);

            using (StringWriter sw = new StringWriter())
            {

                using (XmlTextWriter xml = new XmlTextWriter(sw))
                {

                    string itemId = Component.Id;

                    if (Component != null)
                    {

                        if (Component.Schema.Title.Equals("VFDE - Lectures Data"))
                        {

                            xml.WriteStartElement("Data");


                            xml.WriteElementString("uri", Component.Id);
                            xml.WriteElementString("title", Component.StringValue("title"));
                            xml.WriteElementString("name", Component.StringValue("name"));
                            xml.WriteElementString("designation", Component.StringValue("designation"));
                            xml.WriteElementString("time", Component.StringValue("time"));
                            xml.WriteElementString("venue", Component.StringValue("venue"));
                            xml.WriteElementString("description", Component.XHTMLValue("description"));
                            Component image = Component.ComponentValue("image");
                            if (image != null)
                            {
                                xml.WriteElementString("src", PublishBinary(image));

                              
                            }
                                                        
                            xml.WriteEndElement();

                        }
                    }

                }

                Package.AddXml(Package.OutputName, sw.ToString());

            }

            
        }

    }
}
