﻿using System;
using System.Collections.Generic;
using System.Xml;
using Tridion.ContentManager.ContentManagement.Fields;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager;
using System.Collections;
using Tridion.ContentManager.ContentManagement;
using Tridion.ContentManager.CommunicationManagement;
using System.Xml.XPath;
using System.Web;
using Tridion.Extensions.ContentManager.Templating;
using Emaar.Web.Tridion.System.Extensions;
using System.Text.RegularExpressions;
using System.IO;

namespace VFDE.Web.Templating.BuildingBlocks.Templates
{
    [TcmTemplateTitle("Gallery")]
    public class Gallery:TemplateBase 
    {
        public override void Transform(Engine engine, Package package)
        {
            base.Transform(engine, package);
            Component Component;
            if (Page.ComponentPresentations != null)
            {
                if (Page.ComponentPresentations.Count != 0)
                {
                    Component = Page.ComponentPresentations[0].Component;
                        
                    using (StringWriter sw = new StringWriter())
                    {
                        using (XmlTextWriter xml = new XmlTextWriter(sw))
                        {
                            xml.WriteStartElement("data");

                            if (Component != null)
                            {
                                IList<ItemFields> iFields = Component.EmbeddedValues("imagelist");
                                
                                foreach (ItemFields fields in iFields)
                                {

                                    xml.WriteStartElement("node");
                                        xml.WriteElementString("setiontitle", fields.StringValue("title"));
                                        xml.WriteStartElement("images");

                                            IList<Component> complist = fields.ComponentValues("componentlist");

                                            foreach (Component comp in complist)
                                            {
                                                xml.WriteStartElement("image");
                                                    xml.WriteElementString("largeimage", PublishBinary(comp));
                                                    Component thumb = comp.ComponentMetaValue("thumbnil");
                                                    if (thumb != null)
                                                    {
                                                        xml.WriteElementString("smallimage", PublishBinary(thumb));
                                                    }
                                                    else
                                                    {
                                                        xml.WriteElementString("smallimage", GenerateThumbnail(comp, "thumb", 208, 204));
                                                    }
                                                    xml.WriteElementString("imagetitle", comp.StringMetaValue("altText"));
                                                    xml.WriteElementString("displayhomepage", comp.StringMetaValue("sholddisplayonhomepage"));
                                                xml.WriteEndElement(); 
                                            }

                                        xml.WriteEndElement(); 
                                    xml.WriteEndElement(); 
                                }

                                xml.WriteStartElement("Youtube");
                                IList<String> Youtube = Component.StringValues("videoslist");
                                foreach (String sYoutube in Youtube)
                                {
                                    xml.WriteStartElement("node");
                                    xml.WriteElementString("link", sYoutube);
                                    xml.WriteEndElement(); 
                                
                                }
                                xml.WriteEndElement(); 

                            }


                            xml.WriteEndElement(); 
                        }

                        Package.AddXml(Package.OutputName, sw.ToString());
                    }

                    
                }
            }
        }
    }
}
