﻿using System;
using System.Collections.Generic;
using System.Xml;
using Tridion.ContentManager.ContentManagement.Fields;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager;
using System.Collections;
using Tridion.ContentManager.ContentManagement;
using Tridion.ContentManager.CommunicationManagement;
using System.Xml.XPath;
using System.Web;
using Tridion.Extensions.ContentManager.Templating;
using Emaar.Web.Tridion.System.Extensions;
using System.Text.RegularExpressions;
using System.IO;

namespace VFDE.Web.Templating.BuildingBlocks.Templates
{
    [TcmTemplateTitle("Press XML")]
    public class Press:TemplateBase
    {
        public override void Transform(Engine engine, Package package)
        {

            base.Transform(engine, package);

            using (StringWriter sw = new StringWriter())
            {

                using (XmlTextWriter xml = new XmlTextWriter(sw))
                {

                    string itemId = Component.Id;

                    if (Component != null)
                    {

                        if (Component.Schema.Title.Equals("VFDE - Press Releases") || Component.Schema.Title.Equals("VFDE - Events"))
                        {

                            xml.WriteStartElement("Data");


                            xml.WriteElementString("uri", Component.Id);
                            xml.WriteElementString("title", Component.StringValue("title"));
                            xml.WriteElementString("summary", Component.StringValue("summary"));
                            xml.WriteElementString("description", Component.XHTMLValue("description"));
                            Component image = Component.ComponentValue("image");
                            if (image != null)
                            {
                                xml.WriteElementString("src", PublishBinary(image));

                                Component ThumbImage = Component.ComponentValue("thumbnil");
                                Component calloutimage = Component.ComponentValue("smallimage");

                                if (ThumbImage != null)
                                    xml.WriteElementString("ThumbImage", PublishBinary(ThumbImage));
                                else if (calloutimage!=null)
                                    xml.WriteElementString("ThumbImage", PublishBinary(calloutimage));
                                else 
                                    xml.WriteElementString("ThumbImage", GenerateThumbnail(image, "thumb", 307, 188));


                                Component Presssummaryimage = Component.ComponentValue("presssummaryimage");
                                if (Presssummaryimage != null)
                                    xml.WriteElementString("Presssummaryimage", PublishBinary(Presssummaryimage));
                                else
                                    xml.WriteElementString("Presssummaryimage", GenerateThumbnail(image, "Presssummaryimage", 134, 134,"#fff"));

                            }

                            xml.WriteElementString("date", Component.DateMetaValue("publishdate").ToString("dd/MM/yyyy"));

                            xml.WriteEndElement();

                        }
                    }

                }

                Package.AddXml(Package.OutputName, sw.ToString());

            }

            
        }

    }
}
