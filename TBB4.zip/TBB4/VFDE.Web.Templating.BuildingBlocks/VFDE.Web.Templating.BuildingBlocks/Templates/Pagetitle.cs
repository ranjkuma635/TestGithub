﻿using System;
using System.Collections.Generic;
using System.Xml;
using Tridion.ContentManager.ContentManagement.Fields;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager;
using System.Collections;
using Tridion.ContentManager.ContentManagement;
using Tridion.ContentManager.CommunicationManagement;
using System.Xml.XPath;
using System.Web;
using Tridion.Extensions.ContentManager.Templating;
using Emaar.Web.Tridion.System.Extensions;
using System.Text.RegularExpressions;


namespace VFDE.Web.Templating.BuildingBlocks.Templates
{
    [TcmTemplateTitle("Page Title")]
    public class Pagetitle : TemplateBase
    {

        public override void Transform(Engine engine, Package package)
        {

            base.Transform(engine, package);
            Component comp;
            if (Page.ComponentPresentations != null)
            {
                if (Page.ComponentPresentations.Count != 0)
                {
                    comp = Page.ComponentPresentations[0].Component;
                    Package.AddString("PageTitle", comp.StringValue("title").ToString());
                }
                

            }

        }


    }
}
