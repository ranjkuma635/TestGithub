﻿using System;
using System.Collections.Generic;
using System.Xml;
using Tridion.ContentManager.ContentManagement.Fields;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager;
using System.Collections;
using Tridion.ContentManager.ContentManagement;
using Tridion.ContentManager.CommunicationManagement;
using System.Xml.XPath;
using System.Web;
using Tridion.Extensions.ContentManager.Templating;
using Emaar.Web.Tridion.System.Extensions;
using System.Text.RegularExpressions;
using System.IO;

namespace VFDE.Web.Templating.BuildingBlocks.Templates
{
    [TcmTemplateTitle("talent xml")]
    public  class talent : TemplateBase
    {
        public override void Transform(Engine engine, Package package)
        {
            base.Transform(engine, package);
            Component Component;
            int i = 1;
            if (Page.ComponentPresentations != null)
            {

                if (Page.ComponentPresentations.Count != 0)
                {
                    Component = Page.ComponentPresentations[0].Component;
                    using (StringWriter sw = new StringWriter())
                    {

                        using (XmlTextWriter xml = new XmlTextWriter(sw))
                        {
                            xml.WriteStartElement("data");

                            if (Component != null)
                            {


                                IList<Component> complist = Component.ComponentValues("list");
                                foreach (Component comp in complist)
                                {
                                    xml.WriteStartElement("node");


                                   Component image = comp.ComponentValue("image");

                                   Component thumb = null;
                                   if (image != null)
                                   {
                                       thumb = image.ComponentMetaValue("thumbnil");
                                   }

                                    xml.WriteAttributeString("componnetId", comp.Id.ToString());
                                    xml.WriteAttributeString("id", i.ToString());

                                    if (thumb != null)
                                    {
                                        xml.WriteElementString("image", PublishBinary(thumb));
                                    }
                                    else
                                    {
                                        if (image != null)
                                            xml.WriteElementString("image", PublishBinary(image));
                                    }

                                    xml.WriteElementString("name", comp.StringValue("title"));
                                    xml.WriteElementString("location", comp.StringValue("location"));


                                    xml.WriteEndElement();
                                    i++;
                                }


                            }

                            xml.WriteEndElement(); 
                        }

                        Package.AddXml(Package.OutputName, sw.ToString());

                    }

                }
            }
        }

    }
}
