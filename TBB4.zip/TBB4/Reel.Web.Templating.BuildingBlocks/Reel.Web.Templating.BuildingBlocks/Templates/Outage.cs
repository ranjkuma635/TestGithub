﻿using System;
using System.Web;
using System.Linq;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.ContentManagement.Fields;
using Tridion.Extensions.ContentManager.Templating;
using Tridion.ContentManager.ContentManagement;
using Emaar.Web.Tridion.System.Extensions;
using System.IO;
using System.Xml;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using Tridion.ContentManager;

namespace Reel.Web.Templating.BuildingBlocks.Templates.Templates
{
    [TcmTemplateTitle("Outage")]
    public class Outage : TemplateBase 
    {

        public override void Transform(Engine engine, Package package)
        {
            base.Transform(engine, package);
            Component component = Page.ComponentPresentations[0].Component;

            using (StringWriter sw = new StringWriter())
            {
                using (XmlTextWriter xml = new XmlTextWriter(sw))
                {

                    xml.WriteStartElement("Data");

                    xml.WriteElementString("From", component.DateValue("From").ToString("dd/MM/yyyy HH:mm:ss"));
                    xml.WriteElementString("To", component.DateValue("To").ToString("dd/MM/yyyy HH:mm:ss"));

                    xml.WriteEndElement(); 

                }

                Package.AddXml(Package.OutputName, sw.ToString());
            }

        }

    }
}
