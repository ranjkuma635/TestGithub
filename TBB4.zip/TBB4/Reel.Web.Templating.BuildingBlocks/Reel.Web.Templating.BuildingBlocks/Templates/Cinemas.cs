﻿using System;
using System.Web;
using System.Linq;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.ContentManagement.Fields;
using Tridion.Extensions.ContentManager.Templating;
using Tridion.ContentManager.ContentManagement;
using Emaar.Web.Tridion.System.Extensions;
using System.IO;
using System.Xml;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using Tridion.ContentManager;


namespace Reel.Web.Templating.BuildingBlocks.Templates
{
    [TcmTemplateTitle("Cinemas")]
    public class Cinemas:TemplateBase 
    {
        public override void Transform(Engine engine, Package package)
        {
            string desc = string.Empty; 
            base.Transform(engine, package);
            if (Page.ComponentPresentations.Count > 0)
            {
                Component component = Page.ComponentPresentations[0].Component;


                using (StringWriter sw = new StringWriter())
                {
                    using (XmlTextWriter xml = new XmlTextWriter(sw))
                    {
                        xml.WriteStartElement("Root");

                        IList<Component> componentlist = component.ComponentValues("list");

                        foreach (Component c in componentlist)
                        {

                            xml.WriteStartElement("cinema");
                                xml.WriteElementString("title", c.StringValue("title"));
                                xml.WriteElementString("cinemaid", c.StringValue("cinemaid"));

                                //desc = HttpUtility.HtmlEncode(replaceHref(c.XHTMLValue("descriptionforapp")).Replace("xmlns=\"http://www.w3.org/1999/xhtml\"", ""));
                                desc = (replaceHref(c.XHTMLValue("descriptionforapp")).Replace("xmlns=\"http://www.w3.org/1999/xhtml\"", ""));
                                xml.WriteElementString("Description", desc);

                                xml.WriteStartElement("images");
                                IList<Component> imgcomplist = c.ComponentValues("images");
                                foreach (Component cimage in imgcomplist)
                                {
                                    xml.WriteElementString("image", PublishBinary(cimage));
                                }
                                xml.WriteEndElement();

                                xml.WriteElementString("cords", c.StringValue("cordsmobile"));
                            xml.WriteEndElement();

                        }

                        xml.WriteStartElement("overview");
                        xml.WriteElementString("overviewtitle", component.StringValue("title"));
                        xml.WriteElementString("overviewDescription", component.XHTMLValue("summaryfroapp").Replace("xmlns=\"http://www.w3.org/1999/xhtml\"", ""));
                        
                        xml.WriteStartElement("overviewImages");
                            IList<Component> imgcomplistsum = component.ComponentValues("images");
                            foreach (Component cimage in imgcomplistsum)
                            {
                                xml.WriteElementString("overviewImage", PublishBinary(cimage));
                            }
                            xml.WriteEndElement();


                            IList<Component> componentlistsummary = component.ComponentValues("list");
                            xml.WriteStartElement("overviewCinemas");
                            foreach (Component csummary in componentlistsummary)
                            {
                                xml.WriteStartElement("overviewCinema");
                                if (csummary.ComponentValue("summaryimage") != null)
                                {
                                    xml.WriteElementString("overviewCinemaImage", PublishBinary(csummary.ComponentValue("summaryimage")));
                                }
                                xml.WriteElementString("overviewCinemaTitle", csummary.StringValue("title"));
                                xml.WriteElementString("summary", csummary.StringValue("summaryfroapp"));
                                xml.WriteElementString("overviewCinemaID", csummary.StringValue("cinemaid"));
                                xml.WriteEndElement();

                            }
                            xml.WriteEndElement();


                        xml.WriteEndElement();




                        xml.WriteEndElement(); 
                    }

                    Package.AddXml(Package.OutputName, sw.ToString());
                }

            }

        }


        private string replaceHref(string fieldText)
        {
            string pattern = "href=\"(tcm:.*?)\"";
            MatchCollection collection = Regex.Matches(fieldText, pattern);
            foreach (Match match in collection)
            {
                string matchedString = match.Groups[1].Value;
                //string matchedStringwithAttr = match.Groups[0].Value;
                TcmUri tcmId = new TcmUri(matchedString + "-16");
                Component component = GetComponent(tcmId);
                if (component.Schema.Purpose.Equals(SchemaPurpose.Multimedia))
                {
                    string publishedPath = PublishBinary(component);
                    string fileName = component.BinaryContent.Filename;
                    string fileType = fileName.Substring(fileName.LastIndexOf('.') + 1, fileName.Length - fileName.LastIndexOf('.') - 1);
                    switch (fileType.ToLower())
                    {
                        case "jpeg":
                        case "gif":
                        case "jpg":
                        case "png":
                            fieldText = fieldText.Replace(matchedString, publishedPath);
                            fieldText = fieldText.Replace("xlink:href", "src");
                            break;
                        case "doc":
                        case "docx":
                        case "pdf":
                            fieldText = fieldText.Replace(matchedString, publishedPath);
                            fieldText = fieldText.Replace("xlink:href", "href");
                            break;
                        default: fieldText = fieldText.Replace(matchedString, publishedPath);
                            fieldText = fieldText.Replace("xlink:href", "href"); break;
                    }
                }
            }
            return fieldText;
        }



    }
}
