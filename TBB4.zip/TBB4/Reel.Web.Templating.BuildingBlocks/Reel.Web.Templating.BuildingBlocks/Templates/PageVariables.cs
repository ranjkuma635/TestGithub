﻿using System;
using System.Collections.Generic;
using System.Xml;
using Tridion.ContentManager;
using Tridion.ContentManager.CommunicationManagement;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.ContentManagement.Fields;
using Tridion.ContentManager.ContentManagement;
using System.Text.RegularExpressions;
using Tridion.Extensions.ContentManager.Templating;
using Emaar.Web.Tridion.System.Extensions;
using Emaar.Web.Tridion.System;


namespace Reel.Web.Templating.BuildingBlocks.Templates
{
   
    [TcmTemplateTitle("Page Variables")]
    public class PageVariables : PageVariablesTemplate
    {

       private List<String> mIncludeFields;
       private List<String> mInheritedFields;

       public PageVariables(): base()
        {
            mIncludeFields = new List<String>();
            mIncludeFields.Add("leftsidecallout");
            mIncludeFields.Add("callout");
            mIncludeFields.Add("morestores");
            mIncludeFields.Add("calloutgallery");
            mIncludeFields.Add("hidecallouts");
            mIncludeFields.Add("sponsorfooter");
            mIncludeFields.Add("heroimage");

            mIncludeFields.Add("app");
            mIncludeFields.Add("competitioncallout");
            mIncludeFields.Add("Promotions");

            mInheritedFields = new List<String>();
            mInheritedFields.Add("leftsidecallout");
            mInheritedFields.Add("callout");
            mInheritedFields.Add("morestores");
            mInheritedFields.Add("sponsorfooter");
            mInheritedFields.Add("calloutgallery");
            mInheritedFields.Add("hidecallouts");
            mInheritedFields.Add("heroimage");

            mInheritedFields.Add("app");
            mInheritedFields.Add("competitioncallout");
            mInheritedFields.Add("Promotions");

        }

       protected override bool IncludeMetadata(string FieldName)
       {
           return mIncludeFields.Contains(FieldName);
       }

       protected override bool InheritedMetadata(string FieldName)
       {
           return mInheritedFields.Contains(FieldName);
       }

    }
}
