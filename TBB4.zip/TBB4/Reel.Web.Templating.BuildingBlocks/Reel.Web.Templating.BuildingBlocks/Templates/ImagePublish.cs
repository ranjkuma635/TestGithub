﻿using System;
using System.Linq;
using System.Xml;
using System.IO;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.Extensions.ContentManager.Templating;
using Emaar.Web.Tridion.System.Extensions;
using Tridion.ContentManager.Publishing.Rendering;
using Tridion.ContentManager;
using Tridion.ContentManager.ContentManagement;
using Tridion.ContentManager.CommunicationManagement;
using System.Text.RegularExpressions;
using System.Collections.Generic;

namespace Reel.Web.Templating.BuildingBlocks.Templates
{

    [TcmTemplateTitle("UploadBinary")]
    public class UploadBinary : TemplateBase
    {
        /// <summary>
        /// Transforms the current component.
        /// </summary>
        /// <param name="engine">The engine.</param>
        /// <param name="package">The package.</param>
        public override void Transform(Engine engine, Package package)
        {
            base.Transform(engine, package);

            if (Component != null)
            {

                if (Component.Schema.Title.Equals("Reel - Vertical Images"))
                {
                    this.PublishBinary(engine, package, Component, 8591);
                }
                if (Component.Schema.Title.Equals("Reel - Horizontal"))
                {
                    this.PublishBinary(engine, package, Component, 8807);
                }
                if (Component.Schema.Title.Equals("Reel - Tarilers"))
                {
                    this.PublishBinary(engine, package, Component, 8645);
                }
                if (Component.Schema.Title.Equals("Reel - Horizontal 1120x630"))
                {
                    this.PublishBinary(engine, package, Component, 9098);
                }
            }
        }
        public Binary PublishBinary(Engine engine, Package package, Component multimediaComponent,int sgID)
        {

            BinaryContent binaryContent = multimediaComponent.BinaryContent;
            Session session = engine.GetSession();
            TcmUri structureGroupUri = new TcmUri(sgID, ItemType.StructureGroup, 168);
            StructureGroup structureGroup = new StructureGroup(structureGroupUri, session);


            Binary binary = engine.PublishingContext.RenderedItem.AddBinary(multimediaComponent, structureGroup, Regex.Replace(binaryContent.Filename, "\\W", string.Empty));

            return binary;
        }

    }

}


