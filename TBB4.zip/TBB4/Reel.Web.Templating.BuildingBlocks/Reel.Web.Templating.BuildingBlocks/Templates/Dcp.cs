﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml;
using System.IO;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.ContentManagement.Fields;
using Tridion.Extensions.ContentManager.Templating;
using Tridion.ContentManager.ContentManagement;
using Emaar.Web.Tridion.System.Extensions;

namespace Reel.Web.Templating.BuildingBlocks.Templates
{
    [TcmTemplateTitle("Dcp")]
    public class Dcp : TemplateBase
    {
        public override void Transform(Engine engine, Package package)
        {

            base.Transform(engine, package);
            string strfulldesc = "";
            using (StringWriter sw = new StringWriter())
            {

                using (XmlTextWriter xml = new XmlTextWriter(sw))
                {

                    string itemId = Component.Id;
                    if (Component != null)
                    {

                        if (Component.Schema.Title.Equals("Reel - Box Office Promotions") || Component.Schema.Title.Equals("Reel - Food & Beverage"))
                        {
                            xml.WriteStartElement("item");

                                xml.WriteElementString("uri", Component.Id);
                                xml.WriteElementString("title", Component.StringValue("title"));
                                xml.WriteElementString("sunnary", Component.StringValue("sunnary"));
                                xml.WriteElementString("description", Component.XHTMLValue("description"));

                                strfulldesc = "<content>" + Component.StringValue("description") + "</content>";
                                XmlDocument doc = new XmlDocument();
                                doc.LoadXml(strfulldesc);
                                strfulldesc = doc.InnerText;


                                xml.WriteElementString("descriptionsummary", strfulldesc);


                                if (Component.ComponentValue("smallimage") != null)
                                {
                                    xml.WriteElementString("smallimage", PublishBinary(Component.ComponentValue("smallimage")));
                                }
                                if (Component.ComponentValue("largeimage") != null)
                                {
                                    xml.WriteElementString("largeimage", PublishBinary(Component.ComponentValue("largeimage")));
                                }
                                xml.WriteElementString("startdate", Component.DateMetaValue("startdate").ToString("dd/MM/yyyy"));
                                xml.WriteElementString("enddate", Component.DateMetaValue("enddate").ToString("dd/MM/yyyy"));

                                xml.WriteElementString("shouldnotdisplaymobile", Component.StringValue("shouldnotdisplaymobile"));

                            xml.WriteEndElement();//item
                        }




                        if (Component.Schema.Title.Equals("REEL - Competition"))
                        {
                            xml.WriteStartElement("item");

                            xml.WriteElementString("uri", Component.Id);
                            xml.WriteElementString("title", Component.StringValue("title"));
                            xml.WriteElementString("description", Component.XHTMLValue("description"));
                            xml.WriteElementString("question", Component.XHTMLValue("question"));
                            xml.WriteElementString("description2", Component.XHTMLValue("description2"));

                            if (Component.ComponentValue("image") != null)
                                xml.WriteElementString("image", PublishBinary(Component.ComponentValue("image")));

                            xml.WriteElementString("startdate", Component.DateMetaValue("startdate").ToString("dd/MM/yyyy"));
                            xml.WriteElementString("enddate", Component.DateMetaValue("enddate").ToString("dd/MM/yyyy"));

                            xml.WriteElementString("Termscompetition", Component.XHTMLValue("Termscompetition"));
                            

                            xml.WriteEndElement();//item
                        }

                    }
                    Package.AddXml(Package.OutputName, sw.ToString());
                }

                
            }
        }
    }
}
