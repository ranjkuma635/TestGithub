﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.IO;
using Tridion.ContentManager;
using Tridion.ContentManager.CommunicationManagement;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Expression;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.Templating.Dreamweaver;
using Tridion;
using Tridion.ContentManager.ContentManagement.Fields;
using Tridion.Extensions.ContentManager.Templating;
using Publishing = Tridion.ContentManager.Publishing.Rendering;
using Tridion.ContentManager.ContentManagement;
using Tridion.ContentManager.Publishing.Rendering;
using System.Text.RegularExpressions;
using Emaar.Web.Tridion.System.Extensions;

namespace Reel.Web.Templating.BuildingBlocks.Templates
{
    [TcmTemplateTitle("Partners XML")]
    public class Partners : TemplateBase
    {
        public override void Transform(Engine engine, Package package)
        {
            base.Transform(engine, package);

            Engine m_Engine;
            m_Engine = engine;

            string strPubid = Page.ComponentPresentations[0].Component.Id.PublicationId.ToString();


            Component cPartner = Page.ComponentPresentations[0].Component;

            using (StringWriter sw = new StringWriter())
            {
                using (XmlTextWriter xml = new XmlTextWriter(sw))
                {

                    xml.WriteStartElement("partners");

                    if (cPartner.EmbeddedValues("List") != null)
                    {
                        IList<ItemFields> partnerlist = cPartner.EmbeddedValues("List");

                        foreach (ItemFields partner in partnerlist)
                        {

                            xml.WriteStartElement("partner");

                               Component Image = partner.ComponentValue("image");
                               if(Image!=null)
                               xml.WriteElementString("image" ,PublishBinary(Image));

                               Component clink = partner.ComponentValue("clink");
                                if(clink!=null)
                                    xml.WriteElementString("clink", clink.Id.ToString());   

                               xml.WriteElementString("link", partner.ExternalLinkValue("link"));
                            xml.WriteElementString("text", partner.StringValue("text"));

                            xml.WriteEndElement(); 
                        }

                    }

                    xml.WriteEndElement(); 

                }

                Package.AddXml(Package.OutputName, sw.ToString());
            }

        }
    }

}
