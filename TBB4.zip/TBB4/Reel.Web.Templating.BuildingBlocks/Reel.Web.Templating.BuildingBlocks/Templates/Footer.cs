﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.IO;
using Tridion.ContentManager;
using Tridion.ContentManager.CommunicationManagement;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Expression;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.Templating.Dreamweaver;
using Tridion;
using Tridion.ContentManager.ContentManagement.Fields;
using Tridion.Extensions.ContentManager.Templating;
using Publishing = Tridion.ContentManager.Publishing.Rendering;
using Tridion.ContentManager.ContentManagement;
using Tridion.ContentManager.Publishing.Rendering;
using System.Text.RegularExpressions;
using Emaar.Web.Tridion.System.Extensions;

namespace Reel.Web.Templating.BuildingBlocks.Templates
{
    [TcmTemplateTitle("Footer XML")]
    public class Footer : TemplateBase
    {
        public override void Transform(Engine engine, Package package)
        {
            base.Transform(engine, package);

            Engine m_Engine;
            m_Engine = engine;

            string strPubid = Page.ComponentPresentations[0].Component.Id.PublicationId.ToString();

            Component cFooter = Page.ComponentPresentations[0].Component;


            using (StringWriter sw = new StringWriter())
            {

                using (XmlTextWriter xml = new XmlTextWriter(sw))
                {

                    xml.WriteStartElement("footer");

                        xml.WriteStartElement("links");

                            xml.WriteElementString("title", cFooter.StringValue("titleleft"));

                            IList<ItemFields> Footerleft = cFooter.EmbeddedValues("left");

                            foreach (ItemFields footerleft in Footerleft)
                            {
                                xml.WriteStartElement("list");

                                xml.WriteElementString("title", footerleft.StringValue("flinkText"));

                                Component c = footerleft.ComponentValue("fcomponentLink");
                                if (c != null)
                                    xml.WriteElementString("clink", c.Id.ToString());

                                if (!string.IsNullOrEmpty(footerleft.ExternalLinkValue("fexternalLink")))
                                    xml.WriteElementString("exlink", footerleft.ExternalLinkValue("fexternalLink"));

                                xml.WriteEndElement(); 
                            }

                        xml.WriteEndElement();

                        xml.WriteStartElement("links");

                            xml.WriteElementString("title", cFooter.StringValue("titleright"));

                            IList<ItemFields> FooterRight = cFooter.EmbeddedValues("right");

                            foreach (ItemFields footerright in FooterRight)
                            {
                                xml.WriteStartElement("list");

                                xml.WriteElementString("title", footerright.StringValue("flinkText"));

                                Component c = footerright.ComponentValue("fcomponentLink");
                                if (c != null)
                                    xml.WriteElementString("clink", c.Id.ToString());

                                if (!string.IsNullOrEmpty(footerright.ExternalLinkValue("fexternalLink")))
                                    xml.WriteElementString("exlink", footerright.ExternalLinkValue("fexternalLink"));

                                xml.WriteEndElement(); 
                            }

                        xml.WriteEndElement();


                        xml.WriteStartElement("adds");

                        IList<ItemFields> Aaddblocks = cFooter.EmbeddedValues("addblocks");

                        foreach (ItemFields addblocks in Aaddblocks)
                        {
                            xml.WriteStartElement("list");

                            Component Image = addblocks.ComponentValue("fimage");
                            if (Image != null)
                                xml.WriteElementString("image", PublishBinary(Image));


                            Component c = addblocks.ComponentValue("fcomponentLink");
                            if (c != null)
                                xml.WriteElementString("clink", c.Id.ToString());

                            if (!string.IsNullOrEmpty(addblocks.ExternalLinkValue("fexternalLink")))
                                xml.WriteElementString("exlink", addblocks.ExternalLinkValue("fexternalLink"));

                            xml.WriteEndElement();
                        }

                        xml.WriteEndElement();


                    xml.WriteEndElement(); 
                
                }

                Package.AddXml(Package.OutputName, sw.ToString());

            }

       
        }
    }

}
