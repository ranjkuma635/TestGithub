﻿using System;
using System.Linq;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.ContentManagement.Fields;
using Tridion.Extensions.ContentManager.Templating;
using Tridion.ContentManager.ContentManagement;
using Emaar.Web.Tridion.System.Extensions;
using System.IO;
using System.Xml;


namespace Reel.Web.Templating.BuildingBlocks.Templates
{
    [TcmTemplateTitle("Competition Callout")]
    public class competitioncallout : TemplateBase 
    {
        public override void Transform(Engine engine, Package package)
        {

            base.Transform(engine, package);

            
            if (Page.ComponentPresentations.Count > 0)
            {
              
                Component component = Page.ComponentPresentations[0].Component;


                    using (StringWriter sw = new StringWriter())
                    {
                        using (XmlTextWriter xml = new XmlTextWriter(sw))
                        {

                            xml.WriteStartElement("Data");

                            if (component.EmbeddedValue("competition") != null)
                            {
                                

                                ItemFields competition = component.EmbeddedValue("competition");
                                xml.WriteStartElement("competition");

                                    xml.WriteElementString("title", competition.StringValue("title"));
                                    xml.WriteElementString("description", competition.XHTMLValue("description"));

                                    if (competition.EmbeddedValue("list") != null)
                                    {
                                        ItemFields competitionlist = competition.EmbeddedValue("list");

                                        xml.WriteElementString("linktext", competitionlist.StringValue("flinkText"));

                                        if (competitionlist.ComponentValue("fimage") != null)
                                            xml.WriteElementString("image", PublishBinary(competitionlist.ComponentValue("fimage")));

                                        if (competitionlist.ComponentValue("fcomponentLink") != null)
                                            xml.WriteElementString("componnetlink", competitionlist.ComponentValue("fcomponentLink").Id);

                                    }


                                xml.WriteEndElement(); 
                            }


                            if (component.EmbeddedValue("nocompetition") != null)
                            {

                                ItemFields nocompetition = component.EmbeddedValue("nocompetition");
                                xml.WriteStartElement("nocompetition");

                                xml.WriteElementString("title", nocompetition.StringValue("title"));
                                xml.WriteElementString("description", nocompetition.XHTMLValue("description"));

                                if (nocompetition.EmbeddedValue("list") != null)
                                {
                                    ItemFields nocompetitionlist = nocompetition.EmbeddedValue("list");

                                    xml.WriteElementString("linktext", nocompetitionlist.StringValue("flinkText"));

                                    if (nocompetitionlist.ComponentValue("fimage") != null)
                                        xml.WriteElementString("image", PublishBinary(nocompetitionlist.ComponentValue("fimage")));

                                    if (nocompetitionlist.ComponentValue("fcomponentLink") != null)
                                        xml.WriteElementString("componnetlink", nocompetitionlist.ComponentValue("fcomponentLink").Id);

                                    if (nocompetitionlist.ExternalLinkValue("fexternalLink") != null)
                                        xml.WriteElementString("ExternalLink", nocompetitionlist.ExternalLinkValue("fexternalLink"));


                                }


                                xml.WriteEndElement();
                            }



                            xml.WriteEndElement(); 

                        }

                        Package.AddXml(Package.OutputName, sw.ToString());
                    }
              
            }
                
        }
    }
}
