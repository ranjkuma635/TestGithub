﻿using System;
using System.Collections.Generic;
using System.Xml;
using Tridion.ContentManager.ContentManagement.Fields;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager;
using System.Collections;
using Tridion.ContentManager.ContentManagement;
using Tridion.ContentManager.CommunicationManagement;
using System.Xml.XPath;
using System.Web;
using Tridion.Extensions.ContentManager.Templating;
using System.IO;
using Emaar.Web.Tridion.System.Extensions;

namespace TDM.Web.Templating.BuildingBlocks.Templates
{
    [TcmTemplateTitle("Jobs")]
    public class Jobs : TemplateBase
    {

        public override void Transform(Engine engine, Package package)
        {
            base.Transform(engine, package);

            using (StringWriter sw = new StringWriter())
            {

                using (XmlTextWriter xml = new XmlTextWriter(sw))
                {

                    xml.WriteStartElement("Data");

                    if (Component != null)
                    {
                        xml.WriteAttributeString("uri", Component.Id);
                        xml.WriteElementString("Title", Component.StringValue("title"));
                        xml.WriteElementString("Code", Component.StringValue("code"));
                        xml.WriteElementString("Department", Component.StringValue("department"));
                        xml.WriteElementString("Zone", Component.StringValue("zone"));
                        xml.WriteElementString("Salary", Component.StringValue("salary"));
                        xml.WriteElementString("Description", Component.XHTMLValue("description"));
                        xml.WriteElementString("Requirements", Component.XHTMLValue("requirements"));
                        xml.WriteElementString("StatrtDate", Component.DateMetaValue("publishdate").ToString("dd/MM/yyyy"));
                        xml.WriteElementString("EndDate", Component.DateMetaValue("enddate").ToString("dd/MM/yyyy"));

                    }

                    xml.WriteEndElement(); // Data

                }

                Package.AddXml(Package.OutputName, sw.ToString());

            }

        }

    }
}
