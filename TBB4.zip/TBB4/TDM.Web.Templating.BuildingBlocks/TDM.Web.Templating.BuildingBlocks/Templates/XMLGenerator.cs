﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml;
using System.IO;
using Tridion.ContentManager;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.Extensions.ContentManager.Templating;
using Tridion.ContentManager.ContentManagement;
using System.Text.RegularExpressions;
using Emaar.Web.Tridion.System.Extensions;
using System.Web;
using Tridion.ContentManager.ContentManagement.Fields;

namespace TDM.Web.Templating.BuildingBlocks.Templates
{
    [TcmTemplateTitle("XMLGenerator")]
    public class XMLGenerator : TemplateBase
    {
        /// <summary>
        /// Transforms the current component.
        /// </summary>
        /// <param name="engine">The engine.</param>
        /// <param name="package">The package.</param>
        public override void Transform(Engine engine, Package package)
        {


            string strfulldesc = string.Empty;

            base.Transform(engine, package);


            using (StringWriter sw = new StringWriter())
            {
                using (XmlTextWriter xml = new XmlTextWriter(sw))
                {

                    if (Component.Schema.Title.Equals("TDM-Shop"))
                    {


                        xml.WriteStartElement("store");

                        xml.WriteAttributeString("type", "shop");
                        xml.WriteAttributeString("typejason", "Shop");
                        xml.WriteAttributeString("floor", string.Empty);

                        xml.WriteAttributeString("uri", Component.Id);
                        xml.WriteAttributeString("id", Component.Id.ToString().Replace("tcm:", "").Replace("-", "") + Component.KeywordMetaValue("category").Id.ToString().Replace("tcm:", "").Replace("-", ""));
                        xml.WriteAttributeString("ShopID", Component.StringValue("shopid"));

                        xml.WriteAttributeString("category", Component.KeywordMetaValue("category").Description);
                        xml.WriteAttributeString("categoryID", Component.KeywordMetaValue("category").Id.ToString());

                        xml.WriteAttributeString("updateddate", Component.RevisionDate.ToString());

                        if (Component.OrganizationalItem.Metadata != null)
                        {
                            ItemFields metadataFields = new ItemFields(Component.OrganizationalItem.Metadata, Component.OrganizationalItem.MetadataSchema);
                            xml.WriteAttributeString("categoryimage", PublishBinary(Component.OrganizationalItem.ComponentMetaValue("image")));
                        }


                        string strname = "<content>" + Component.StringValue("title") + "</content>";
                        XmlDocument doc = new XmlDocument();
                        doc.LoadXml(strname);

                        xml.WriteAttributeString("name", doc.InnerText.Replace("''", ""));


                        Component Imag;
                        Imag = Component.ComponentValue("logo");
                        if (Imag != null)
                        {
                            xml.WriteAttributeString("image", GenerateThumbnail(Imag, "thumblogo", 132, 92, "#fff").Replace("%20", " "));
                            xml.WriteAttributeString("Logoimage", PublishBinary(Imag));
                        }

                        Component galleryimage;
                        IList<Component> listimages = Component.ComponentValues("galleryimage");
                        if (listimages != null)
                        {
                            if (listimages.Count > 0)
                            {
                                galleryimage = listimages[0];
                                if (galleryimage != null)
                                {
                                    xml.WriteAttributeString("galleryimage", GenerateThumbnail(galleryimage, "stl", 165, 110, "#fff"));
                                }
                            }
                        }


                        strfulldesc = "<content>" + Component.StringValue("description") + "</content>";
                        XmlDocument doc1 = new XmlDocument();
                        doc1.LoadXml(strfulldesc);

                        strfulldesc = doc1.InnerText;

                        xml.WriteAttributeString("description", HttpUtility.UrlEncode(replaceHref(Component.XHTMLValue("description"))));


                        ItemFields itemfield;
                        itemfield = new ItemFields(Component.Content, Component.Schema);
                        xml.WriteAttributeString("shortdescription", getrawtext(itemfield["description"].StringValue(),false));
                        xml.WriteAttributeString("shortdescriptionapp", getrawtext(itemfield["description"].StringValue(), true));

                        xml.WriteAttributeString("emaargift", Component.StringValue("emaargift"));

                        xml.WriteAttributeString("telephone", Component.XHTMLValue("telephone"));
                        xml.WriteAttributeString("email", Component.StringValue("email"));
                        xml.WriteAttributeString("fax", Component.StringValue("fax"));
                        xml.WriteAttributeString("website", Component.StringValue("website"));
                        xml.WriteAttributeString("StoreFrontCode", Component.StringValue("StoreFrontCode"));

                        if (Component.ComponentValues("imagegallery") != null)
                        {
                            xml.WriteStartElement("Imagegallery");
                            IList<Component> imagegallery = Component.ComponentValues("galleryimage");
                            foreach (Component image in imagegallery)
                            {
                                xml.WriteElementString("image", PublishBinary(image));
                            }
                            xml.WriteEndElement(); //Imagegallery
                        }

                        xml.WriteEndElement();//store
                    }


                    if (Component.Schema.Title.Equals("TDM-Dine"))
                    {

                        Filter f = new Filter();
                        f.Conditions["ItemType"] = ItemType.Component;

                        string strModifiedDate = Component.GetListVersions(f).LastChild.GetAttribute("Modified").ToString();


                        //if (CheckShouldAdd(strModifiedDate))
                        //{

                        xml.WriteStartElement("store");

                        xml.WriteAttributeString("type", "dine");
                        xml.WriteAttributeString("typejason", "Dine");
                        xml.WriteAttributeString("uri", Component.Id);
                        xml.WriteAttributeString("id", Component.Id.ToString().Replace("tcm:", "").Replace("-", "") + Component.KeywordMetaValue("category").Id.ToString().Replace("tcm:", "").Replace("-", ""));
                        xml.WriteAttributeString("ShopID", Component.StringValue("shopid"));
                        xml.WriteAttributeString("floor", string.Empty);

                        xml.WriteAttributeString("category", Component.KeywordMetaValue("category").Description);
                        xml.WriteAttributeString("categoryID", Component.KeywordMetaValue("category").Id.ToString());

                        xml.WriteAttributeString("name", Component.StringValue("title").Replace("''", ""));

                        Component dImage;
                        dImage = Component.ComponentValue("logo");
                        if (dImage != null)
                        {
                            xml.WriteAttributeString("image", GenerateThumbnail(dImage, "thumblogo", 132, 92, "#fff").Replace("%20", " "));
                            xml.WriteAttributeString("Logoimage", PublishBinary(dImage));
                        }


                        Component galleryimage;
                        IList<Component> listimages = Component.ComponentValues("galleryimage");
                        if (listimages != null)
                        {
                            if (listimages.Count > 0)
                            {
                                galleryimage = listimages[0];
                                if (galleryimage != null)
                                {
                                    xml.WriteAttributeString("galleryimage", GenerateThumbnail(galleryimage, "stl", 165, 110, "#fff"));
                                }
                            }
                        }


                        strfulldesc = "<content>" + Component.StringValue("description") + "</content>";
                        XmlDocument doc2 = new XmlDocument();
                        doc2.LoadXml(strfulldesc);
                        strfulldesc = doc2.InnerText;


                        xml.WriteAttributeString("description", HttpUtility.UrlEncode(replaceHref(Component.XHTMLValue("description"))));

                        ItemFields itemfield;
                        itemfield = new ItemFields(Component.Content, Component.Schema);
                        xml.WriteAttributeString("shortdescription", getrawtext(itemfield["description"].StringValue(),false));
                        xml.WriteAttributeString("shortdescriptionapp", getrawtext(itemfield["description"].StringValue(), true));

                        xml.WriteAttributeString("emaargift", Component.StringValue("emaargift"));

                        xml.WriteAttributeString("telephone", Component.StringValue("telephone"));
                        xml.WriteAttributeString("email", Component.StringValue("email"));
                        xml.WriteAttributeString("fax", Component.StringValue("fax"));
                        xml.WriteAttributeString("website", Component.StringValue("website"));
                        xml.WriteAttributeString("StoreFrontCode", Component.StringValue("StoreFrontCode"));

                        if (Component.ComponentValues("imagegallery") != null)
                        {
                            xml.WriteStartElement("Imagegallery");
                            IList<Component> imagegallery = Component.ComponentValues("galleryimage");
                            foreach (Component image in imagegallery)
                            {
                                xml.WriteElementString("image", PublishBinary(image));
                            }
                            xml.WriteEndElement();//Imagegallery
                        }

                        xml.WriteEndElement();//store
                    }



                    if (Component.Schema.Title.Equals("TDM-Entertain"))
                    {

                        xml.WriteStartElement("store");


                        xml.WriteAttributeString("type", "entertain");
                        xml.WriteAttributeString("test", "test4");
                        xml.WriteAttributeString("uri", Component.Id);
                        xml.WriteAttributeString("id", Component.Id.ToString().Replace("tcm:", "").Replace("-", "") + "00000000000");
                        xml.WriteAttributeString("ShopID", Component.StringValue("shopid"));
                        xml.WriteAttributeString("category", "");
                        xml.WriteAttributeString("categoryID", "");
                        xml.WriteAttributeString("name", Component.StringValue("title").Replace("''", ""));

                        Component eImag;
                        eImag = Component.ComponentValue("logo");
                        if (eImag != null)
                        {
                            //xml.WriteAttributeString("image", GenerateThumbnail(eImag, "thumblogo", 132, 92, "#fff").Replace("%20", " "));
                            xml.WriteAttributeString("image", PublishBinary(eImag));
                        }


                        strfulldesc = "<content>" + Component.StringValue("description") + "</content>";
                        XmlDocument doc3 = new XmlDocument();
                        doc3.LoadXml(strfulldesc);

                        strfulldesc = doc3.InnerText;


                        xml.WriteAttributeString("description", HttpUtility.UrlEncode(replaceHref(Component.XHTMLValue("description"))));

                        xml.WriteAttributeString("telephone", Component.StringValue("telephone"));
                        xml.WriteAttributeString("email", Component.StringValue("email"));
                        xml.WriteAttributeString("fax", "");
                        xml.WriteAttributeString("website", Component.StringValue("website"));
                        xml.WriteAttributeString("StoreFrontCode", Component.StringValue("StoreFrontCode"));

                        xml.WriteEndElement(); //store
                    }
                }

                Package.AddXml(Package.OutputName, sw.ToString());
            }

        }


        private string replaceHref(string fieldText)
        {
            string pattern = "href=\"(tcm:.*?)\"";
            MatchCollection collection = Regex.Matches(fieldText, pattern);
            foreach (Match match in collection)
            {
                string matchedString = match.Groups[1].Value;
                //string matchedStringwithAttr = match.Groups[0].Value;
                TcmUri tcmId = new TcmUri(matchedString + "-16");
                Component component = GetComponent(tcmId);
                if (component.Schema.Purpose.Equals(SchemaPurpose.Multimedia))
                {
                    string publishedPath = PublishBinary(component);
                    //string publishedPath = Engine.AddBinary(component.Id, null, null, component.BinaryContent.GetByteArray(), Path.GetFileNameWithoutExtension(component.BinaryContent.Filename));
                    string fileName = component.BinaryContent.Filename;
                    string fileType = fileName.Substring(fileName.LastIndexOf('.') + 1, fileName.Length - fileName.LastIndexOf('.') - 1);
                    switch (fileType.ToLower())
                    {
                        case "jpeg":
                        case "gif":
                        case "jpg":
                        case "png":
                            fieldText = fieldText.Replace(matchedString, publishedPath);
                            fieldText = fieldText.Replace("xlink:href", "src");
                            break;
                        case "doc":
                        case "docx":
                        case "pdf":
                            fieldText = fieldText.Replace(matchedString, publishedPath);
                            fieldText = fieldText.Replace("xlink:href", "href");
                            break;
                        default: fieldText = fieldText.Replace(matchedString, publishedPath);
                            fieldText = fieldText.Replace("xlink:href", "href"); break;
                    }
                }
            }
            return fieldText;
        }

        private string getrawtext(string val, bool hundred)
        {

            int len = 150;
            if(hundred)
                len = 100;


            string strfulldesc = string.Empty;

            strfulldesc = val.Replace("<br/>", "");
            strfulldesc = strfulldesc.Replace("<br xmlns=\"http://www.w3.org/1999/xhtml\" />", "");


            strfulldesc = "<content>" + strfulldesc + "</content>";
            XmlDocument doc = new XmlDocument();
            doc.LoadXml(strfulldesc);

            strfulldesc = doc.InnerText;
            strfulldesc = Regex.Replace(strfulldesc, @"\t|\n|\r", "");
            strfulldesc = Regex.Replace(strfulldesc, "\"[^\"]*\"", string.Empty);


            if (strfulldesc.Length > len)
                strfulldesc = strfulldesc.Substring(0, len);

            return strfulldesc;

        }

    }
}
