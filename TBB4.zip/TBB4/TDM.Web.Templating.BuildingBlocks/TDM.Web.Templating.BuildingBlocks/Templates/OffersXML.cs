﻿using System;
using System.Collections.Generic;
using System.Xml;
using Tridion.ContentManager.ContentManagement.Fields;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager;
using System.Collections;
using Tridion.ContentManager.ContentManagement;
using Tridion.ContentManager.CommunicationManagement;
using System.Xml.XPath;
using System.Web;
using Tridion.Extensions.ContentManager.Templating;
using System.IO;
using Emaar.Web.Tridion.System.Extensions;

namespace TDM.Web.Templating.BuildingBlocks.Templates
{
    [TcmTemplateTitle("Offers XML")]
    public class OffersXML:TemplateBase 
    {

        public override void Transform(Engine engine, Package package)
        {

            string startDate = string.Empty;
            string endDate = string.Empty;

            string sFullDate = string.Empty;

            string s = string.Empty;

            string strfulldesc = string.Empty;

            base.Transform(engine, package);

            Engine m_Engine;
            m_Engine = engine;

            string strPubid = Page.ComponentPresentations[0].Component.Id.PublicationId.ToString();

            string strEvent = "tcm:" + strPubid + "-2155-2";

            OrganizationalItem EventFolder = m_Engine.GetObject(strEvent) as OrganizationalItem;

            DateTime CurrentDate = new DateTime(DateTime.Today.Year, DateTime.Today.Month, DateTime.Today.Day);

            using (StringWriter sw = new StringWriter())
            {
                using (XmlTextWriter xml = new XmlTextWriter(sw))
                {
                    xml.WriteStartElement("Offers");
                    

                    IList<Component> componentsshop = EventFolder.Components(true);
                    foreach (Component c in componentsshop)
                    {
                        if (c.Schema.Title.Equals("TDM-Offers"))
                        {

                            String strdate =  c.DateMetaValue("enddate").ToString("dd/MM/yyyy");
                            string[] EndDate = strdate.Split(new char[] { '/' });
                            DateTime eventexpdate = new DateTime(int.Parse(EndDate[2]), int.Parse(EndDate[1]), int.Parse(EndDate[0]));


                            if (eventexpdate > CurrentDate)
                            {

                                xml.WriteStartElement("Offers");

                                xml.WriteAttributeString("Entity", "TDM");
                                xml.WriteAttributeString("Name", c.StringValue("ftitle"));

                                xml.WriteAttributeString("description", c.StringValue("fbody"));


                                Component shop = c.ComponentMetaValue("fshop");
                                if (shop != null)
                                {
                                    if (shop.Schema.Title == "TDM-Shop" || shop.Schema.Title == "TDM-Dine")
                                    {

                                        xml.WriteAttributeString("Shopid", shop.StringValue("shopid"));
                                        xml.WriteAttributeString("StoreFrontCode", shop.StringValue("StoreFrontCode")); 
                                    }
                                }



                                startDate = c.DateMetaValue("startdate").ToString("dd/MM/yyyy")  ;
                                string[] sDate = startDate.Split(new char[] { '/' });

                                endDate = c.DateMetaValue("enddate").ToString("dd/MM/yyyy");
                                string[] eDate = endDate.Split(new char[] { '/' });

                                sFullDate = sDate[0] + " " + GetMonth(sDate[1]) + "," + " " + sDate[2] + " - " + eDate[0] + " " + GetMonth(eDate[1]) + "," + " " + eDate[2];

                                xml.WriteAttributeString("Dates", sFullDate);

                                xml.WriteStartElement("Offerimages");

                                Component Imag;
                                IList<Component> listimages = c.ComponentValues("fimage");
                                if (listimages != null)
                                {
                                    if (listimages.Count > 0)
                                    {
                                        Imag = listimages[0];
                                        if (Imag != null)
                                        {
                                            //GenerateThumbnail(Imag, "thumblogo", 132, 92, "").Replace("%20"," ").Replace(" ","_")
                                            xml.WriteAttributeString("Location", PublishBinary(Imag).Replace("%20"," "));
                                        }
                                    }
                                }
                                xml.WriteEndElement();

                                xml.WriteEndElement();

                            }
                        }
                    }


                    xml.WriteEndElement();
                }
                Package.AddXml(Package.OutputName, sw.ToString());
            }


        }

        private string GetMonth(string month)
        {
            string sMonth = string.Empty;

            switch (month)
            {
                case "01":
                    sMonth = "January";
                    break;
                case "02":
                    sMonth = "February";
                    break;
                case "03":
                    sMonth = "March";
                    break;
                case "04":
                    sMonth = "April";
                    break;
                case "05":
                    sMonth = "May";
                    break;
                case "06":
                    sMonth = "June";
                    break;
                case "07":
                    sMonth = "July";
                    break;
                case "08":
                    sMonth = "August";
                    break;
                case "09":
                    sMonth = "September";
                    break;
                case "10":
                    sMonth = "October";
                    break;
                case "11":
                    sMonth = "November";
                    break;
                case "12":
                    sMonth = "December";
                    break;
            }

            return sMonth;
        
        }


    }
}
