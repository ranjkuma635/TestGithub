﻿using System;
using System.Collections.Generic;
using System.Xml;
using Tridion.ContentManager.ContentManagement.Fields;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager;
using System.Collections;
using Tridion.ContentManager.ContentManagement;
using Tridion.ContentManager.CommunicationManagement;
using System.Xml.XPath;
using System.Web;
using Tridion.Extensions.ContentManager.Templating;
using Emaar.Web.Tridion.System.Extensions;

namespace TDM.Web.Templating.BuildingBlocks.Templates
{
    [TcmTemplateTitle("Home")]
    public class Home : TemplateBase
    {
        String IsFlashBanner = "false";
        private String FeaturedVideoID = String.Empty;
        List<TcmUri> mBannerList = new List<TcmUri>();

        public override void Transform(Engine engine, Package package)
        {
            base.Transform(engine, package);
            if (Page.ComponentPresentations.Count > 0)
            {
                Component component = Page.ComponentPresentations[0].Component;
                if (component != null && component.Schema.Title.ToLower() == "tdm-home")
                {
                   Component mBanner =  component.ComponentValue("banner");
                    if(mBanner!=null)
                    {
                        if(mBanner.Schema.Title.ToLower()=="flash")
                        {
                            IsFlashBanner = "true";
                            package.AddString("BannerSrc", PublishBinary(mBanner));
                        }
                        
                        mBannerList.Add(mBanner.Id);
                        package.AddComponents("Banner", mBannerList);
                    }
                    FeaturedVideoID = component.StringValue("fyoutubelink");
                }
            }
            package.AddString("IsFlashBanner", IsFlashBanner);
            package.AddString("FeaturedVideoID", FeaturedVideoID);
        }
    }
}
