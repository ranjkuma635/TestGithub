﻿using System;
using System.Collections.Generic;
using System.Xml;
using Tridion.ContentManager.ContentManagement.Fields;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.ContentManagement;
using Tridion.Extensions.ContentManager.Templating;
using System.IO;
using Emaar.Web.Tridion.System.Extensions;

namespace TDM.Web.Templating.BuildingBlocks.Templates
{
    [TcmTemplateTitle("FlashBannerXml DCP")]
    public class FlashBannerXml : TemplateBase 
    {

        public override void Transform(Engine engine, Package package)
        {
            base.Transform(engine, package);

            using (StringWriter sw = new StringWriter())
            {

                using (XmlTextWriter xml = new XmlTextWriter(sw))
                {

                    xml.WriteStartElement("data");

                    if (Component != null)
                    {

                        IList<ItemFields> iFields = Component.EmbeddedValues("data");

                        foreach (ItemFields fields in iFields)
                        {
                            xml.WriteStartElement("section");

                            Component IconImage = fields.ComponentValue("icon");
                            if (IconImage != null)
                                xml.WriteElementString("thumb", PublishBinary(IconImage));

                            xml.WriteElementString("heading", fields.StringValue("title"));
                            xml.WriteElementString("discription", fields.StringValue("summary"));
                            xml.WriteElementString("readMoreTxt", fields.StringValue("internallinktext"));

                            Component ReadMore = fields.ComponentValue("internallink");
                            if (ReadMore != null)
                            {
                                xml.WriteElementString("readMore", String.Format("/system/aspx/link.aspx?id={0}", ReadMore.Id.ItemId.ToString()));
                            }
                            else
                            {
                                xml.WriteElementString("readMore", "#");
                            }

                            xml.WriteElementString("externalLink", fields.ExternalLinkValue("externallink"));
                            xml.WriteElementString("externalLinkTitle", fields.StringValue("externallinktext"));
                            xml.WriteStartElement("media");
                            Component BannerImage = fields.ComponentValue("banner");
                                if (BannerImage != null)
                                    xml.WriteElementString("item", PublishBinary(BannerImage));

                            xml.WriteEndElement(); //media                            
                            xml.WriteEndElement(); //section
                        }                        

                    }

                    xml.WriteEndElement(); // Data
                    

                }

                Package.AddXml(Package.OutputName, sw.ToString());

            }

        }

    }
}
