﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.IO;
using Tridion.ContentManager;
using Tridion.ContentManager.CommunicationManagement;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Expression;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.Templating.Dreamweaver;
using Tridion;
using Tridion.ContentManager.ContentManagement.Fields;
using Tridion.Extensions.ContentManager.Templating;
using Publishing = Tridion.ContentManager.Publishing.Rendering;
using Tridion.ContentManager.ContentManagement;
using Tridion.ContentManager.Publishing.Rendering;
using System.Text.RegularExpressions;
using Emaar.Web.Tridion.System.Extensions;

namespace TDM.Web.Templating.BuildingBlocks.Templates
{
      [TcmTemplateTitle("Categorylist XML")]
    public class Categorylist : TemplateBase
    {
        public override void Transform(Engine engine, Package package)
        {
            base.Transform(engine, package);

            Engine m_Engine;
            m_Engine = engine;

            string strPubid = Page.ComponentPresentations[0].Component.Id.PublicationId.ToString();

            string strShop = "tcm:" + strPubid + "-2169-512";
            string strDine = "tcm:" + strPubid + "-2131-512";

            Filter f = new Filter();

            Category categoryshop = m_Engine.GetObject(strShop) as Category;
            Category categorydine = m_Engine.GetObject(strDine) as Category;

            using (StringWriter sw = new StringWriter())
            {
                using (XmlTextWriter xml = new XmlTextWriter(sw))
                {
                    xml.WriteStartElement("Categories");
                    
                    IList<Keyword> catshop = categoryshop.GetKeywords(f);
                    foreach (Keyword c in catshop)
                    {
                        xml.WriteElementString("Category", c.Description);
                        
                    }

                    IList<Keyword> catdine = categorydine.GetKeywords(f);
                    foreach (Keyword c1 in catdine)
                    {
                        xml.WriteElementString("Category", c1.Description);

                    }


                    xml.WriteEndElement();
                }

                Package.AddXml(Package.OutputName, sw.ToString());
            }

           
        }

    }
}
