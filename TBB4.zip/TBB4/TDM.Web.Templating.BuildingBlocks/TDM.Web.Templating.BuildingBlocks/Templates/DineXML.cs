﻿using System.Collections.Generic;
using System.Xml;
using System.IO;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.Extensions.ContentManager.Templating;
using Publishing = Tridion.ContentManager.Publishing.Rendering;
using Tridion.ContentManager.ContentManagement;
using Emaar.Web.Tridion.System.Extensions;

namespace TDM.Web.Templating.BuildingBlocks.Templates
{
    [TcmTemplateTitle("Dine XML")]
    public class DineXML : TemplateBase
    {
        /// <summary>
        /// Transforms the current component.
        /// </summary>
        /// <param name="engine">The engine.</param>
        /// <param name="package">The package.</param>
        public override void Transform(Engine engine, Package package)
        {
            string strActive = string.Empty;
            base.Transform(engine, package);
            using (StringWriter sw = new StringWriter())
            {
                using (XmlTextWriter xml = new XmlTextWriter(sw))
                {
                    xml.WriteStartElement("venues");
                    if (IsComponent)
                    {
                        IList<Component> components = Component.OrganizationalItem.Components(true);
                        foreach (Component c in components)
                        {
                            if (c.Schema.Title.Equals("TDM-Dine"))
                            {
                                strActive = "Yes";
                                if (c.StringValue("active") == "No")
                                    strActive = "No";

                                if (strActive == "Yes")
                                {
                                    xml.WriteStartElement("venue");
                                    xml.WriteAttributeString("type", "dine");
                                    xml.WriteAttributeString("uri", c.Id);
                                    xml.WriteAttributeString("id", c.StringValue("shopid"));
                                    xml.WriteElementString("name", c.StringValue("title"));
                                    xml.WriteElementString("category", c.KeywordMetaValue("category").Title);
                                    xml.WriteElementString("categorydesc", c.KeywordMetaValue("category").Description);
                                    xml.WriteElementString("emaargift", c.StringValue("emaargift"));
                                    xml.WriteElementString("telephone", c.StringValue("telephone"));
                                    xml.WriteElementString("email", c.StringValue("email"));
                                    xml.WriteElementString("website", c.StringValue("website"));

                                    Component iconImage = Component.ComponentValue("listviewicon");
                                    if (iconImage != null && iconImage.BinaryContent != null)
                                    {
                                        xml.WriteElementString("icon", PublishBinary(iconImage));
                                    }
                                    Component LogoImage = c.ComponentValue("logo");
                                    if (LogoImage != null)
                                        xml.WriteElementString("Logoimage", PublishBinary(LogoImage));


                                    xml.WriteEndElement();
                                }
                            }
                           
                        }
                    }
                    xml.WriteEndElement();
                }
                Package.AddXml(Package.OutputName, sw.ToString());
            }
        }
    }
}
