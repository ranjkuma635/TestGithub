﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Xml;
using System.IO;
using Tridion.ContentManager;
using Tridion.ContentManager.CommunicationManagement;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Expression;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.Templating.Dreamweaver;
using Tridion;
using Tridion.ContentManager.ContentManagement.Fields;
using Tridion.Extensions.ContentManager.Templating;
using Publishing = Tridion.ContentManager.Publishing.Rendering;
using Tridion.ContentManager.ContentManagement;
using Tridion.ContentManager.Publishing.Rendering;
using System.Text.RegularExpressions;
using Emaar.Web.Tridion.System.Extensions;

namespace TDM.Web.Templating.BuildingBlocks.Templates
{
    [TcmTemplateTitle("Shoplocator XML")]
    public class Shoplocator : TemplateBase
    {
        /// <summary>
        /// Transforms the current component.
        /// </summary>
        /// <param name="engine">The engine.</param>
        /// <param name="package">The package.</param>
        public override void Transform(Engine engine, Package package)
        {

            string s = string.Empty;

            string strfulldesc = string.Empty;

            base.Transform(engine, package);
            
            Engine  m_Engine;
            m_Engine = engine;

            string strPubid = Page.ComponentPresentations[0].Component.Id.PublicationId.ToString();   

            string strShop = "tcm:"+strPubid+"-2149-2";
            string strDine= "tcm:"+strPubid+"-2150-2";
            string strEnt= "tcm:"+strPubid+"-2151-2";
            string strStay = "tcm:" + strPubid + "-2152-2";

            OrganizationalItem ShopFolder = m_Engine.GetObject(strShop) as OrganizationalItem;
            OrganizationalItem DineFolder = m_Engine.GetObject(strDine) as OrganizationalItem;
            OrganizationalItem EntertatmentFolder = m_Engine.GetObject(strEnt) as OrganizationalItem;
            OrganizationalItem StayFolder = m_Engine.GetObject(strStay) as OrganizationalItem;

            using (StringWriter sw = new StringWriter())
            {
            using (XmlTextWriter xml = new XmlTextWriter(sw))
            {
                xml.WriteStartElement("stores");


                    IList<Component> componentsshop = ShopFolder.Components(true);
                    foreach (Component c in componentsshop)
                    {
                        if (c.Schema.Title.Equals("TDM-Shop"))
                        {
                            xml.WriteStartElement("store");
                            xml.WriteAttributeString("type", "shop");
                            xml.WriteAttributeString("uri", c.Id);
                            xml.WriteAttributeString("id", c.StringValue("shopid"));
                            xml.WriteAttributeString("storefrontcode", splitspaces(c.StringValue("StoreFrontCode")));
                            xml.WriteAttributeString("category", c.KeywordMetaValue("category").Description);

                            xml.WriteElementString("floor", c.StringValue("floor"));
                            xml.WriteElementString("name", c.StringValue("title"));

                            xml.WriteElementString("telephone", c.XHTMLValue("telephone"));
                            xml.WriteElementString("website", c.StringValue("website"));

                            Component LogoImage = c.ComponentValue("logo");
                            if (LogoImage != null)
                                xml.WriteElementString("Logoimage", PublishBinary(LogoImage));

                            ItemFields itemfield;
                            itemfield = new ItemFields(c.Content,c.Schema);
                            strfulldesc = itemfield["description"].StringValue();
                            strfulldesc = "<content>" + strfulldesc + "</content>";
                            XmlDocument doc = new XmlDocument(); 
                            doc.LoadXml(strfulldesc);

                            strfulldesc = doc.InnerText;

                            if (strfulldesc.Length > 150)
                                xml.WriteElementString("description", strfulldesc.Substring(0, 150));
                            else
                                xml.WriteElementString("description", strfulldesc);



                            xml.WriteElementString("emaargift", c.StringValue("emaargift"));

                            Component Imag;
                            IList<Component> listimages = c.ComponentValues("galleryimage");
                            if (listimages != null)
                            {
                                if (listimages.Count > 0)
                                {
                                    Imag = listimages[0];
                                    if (Imag != null)
                                    {
                                        xml.WriteElementString("image", GenerateThumbnail(Imag, "stl", 165, 110, "#fff"));
                                    }
                                }
                            }
                            xml.WriteEndElement();
                        }
                    }



                    IList<Component> componentsdine = DineFolder.Components(true);
                    foreach (Component c in componentsdine)
                    {
                        if (c.Schema.Title.Equals("TDM-Dine"))
                        {
                            xml.WriteStartElement("store");
                            xml.WriteAttributeString("type", "dine");
                            xml.WriteAttributeString("uri", c.Id);

                            xml.WriteAttributeString("id", c.StringValue("shopid"));
                            xml.WriteAttributeString("storefrontcode", splitspaces(c.StringValue("StoreFrontCode")));

                            xml.WriteAttributeString("category", c.KeywordMetaValue("category").Description);

                            xml.WriteElementString("floor", c.StringValue("floor"));
                            xml.WriteElementString("name", c.StringValue("title"));

                            Component LogoImage = c.ComponentValue("logo");
                            if (LogoImage != null)
                                xml.WriteElementString("Logoimage", PublishBinary(LogoImage));

                            xml.WriteElementString("telephone", c.StringValue("telephone"));
                            xml.WriteElementString("website", c.StringValue("website"));

                            ItemFields itemfield;
                            itemfield = new ItemFields(c.Content, c.Schema);
                            strfulldesc = itemfield["description"].StringValue();
                            strfulldesc = "<content>" + strfulldesc + "</content>";
                            XmlDocument doc = new XmlDocument();
                            doc.LoadXml(strfulldesc);

                            strfulldesc = doc.InnerText;                            

                            if (strfulldesc.Length > 150)
                                xml.WriteElementString("description", strfulldesc.Substring(0, 150));
                            else
                                xml.WriteElementString("description", strfulldesc);                            

                            

                            Component Imag;
                            IList<Component> listimages = c.ComponentValues("galleryimage");
                            if (listimages != null)
                            {
                                if (listimages.Count > 0)
                                {
                                    Imag = listimages[0];
                                    if (Imag != null)
                                        xml.WriteElementString("image", GenerateThumbnail(Imag, "storelocator", 165, 110, "#fff"));
                                }
                            }
                            xml.WriteEndElement();
                        }

                    }



                    IList<Component> componententertatin = EntertatmentFolder.Components(true);
                    foreach (Component c in componententertatin)
                    {
                        if (c.Schema.Title.Equals("TDM-Entertain"))
                        {
                            xml.WriteStartElement("store");
                            xml.WriteAttributeString("test", "test1");
                            xml.WriteAttributeString("type", "Entertain");
                            xml.WriteAttributeString("uri", c.Id);
                            xml.WriteAttributeString("storefrontcode", splitspaces(c.StringValue("StoreFrontCode")));

                            xml.WriteElementString("floor", c.StringValue("floor"));
                            xml.WriteElementString("name", c.StringValue("title"));

                            ItemFields itemfield;
                            itemfield = new ItemFields(c.Content, c.Schema);
                            strfulldesc = itemfield["description"].StringValue();
                            strfulldesc = "<content>" + strfulldesc + "</content>";
                            XmlDocument doc = new XmlDocument();
                            doc.LoadXml(strfulldesc);

                            strfulldesc = doc.InnerText;


                            if (strfulldesc.Length > 150)
                                xml.WriteElementString("description", strfulldesc.Substring(0, 150));
                            else
                                xml.WriteElementString("description", strfulldesc);


                            Component Imag;
                            IList<Component> listimages = c.ComponentValues("galleryimage");
                            if (listimages != null)
                            {
                                if (listimages.Count > 0)
                                {
                                    Imag = listimages[0];
                                    if (Imag != null)
                                        xml.WriteElementString("image", GenerateThumbnail(Imag, "storelocator", 165, 110, "#fff"));
                                }
                            }
                            xml.WriteEndElement();
                        }

                    }




                    xml.WriteEndElement();
                }
                Package.AddXml(Package.OutputName, sw.ToString());
            }



        }

        private string splitspaces(string val)
        {
            if (val.Contains(' '))
            {
                string _returnVal = "";
                val.Split(new string[] { " " }, StringSplitOptions.None).ToList().ForEach(_d =>
                    {
                        _returnVal += _d;
                    });
                return _returnVal;
            }
            else
                return val;
            
        }
    }
}
