﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Tridion.ContentManager.ContentManagement;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.Extensions.ContentManager.Templating;
using Emaar.Web.Tridion.System.Extensions;
using Tridion.ContentManager;
using System.Xml;

namespace TDM.Web.Templating.BuildingBlocks.Templates
{
    [TcmTemplateTitle("Component template spesific")]
    public class componenttemplatespesific : TemplateBase
    {

        public override void Transform(Engine engine, Package package)
        {
            base.Transform(engine, package);

            Engine m_Engine;
            m_Engine = engine;

            Package m_Package;
            m_Package = package; 

            string pubID = Component.Id.PublicationId.ToString();

            string compID = "tcm:"+pubID+"-27156";
            Component comp = m_Engine.GetObject(compID) as Component;

            string compIDLearnMore = "tcm:" + pubID + "-27993";
            Component compLEarnmore = m_Engine.GetObject(compIDLearnMore) as Component;


            string strViewStore = comp.StringValue("text");
            string LearnMore = compLEarnmore.StringValue("text");

            m_Package.PushItem("Viewstoreinfor", m_Package.CreateStringItem(ContentType.Text, strViewStore));
            m_Package.PushItem("Learnmoretext", m_Package.CreateStringItem(ContentType.Text, LearnMore)); 

        }
    }
}
