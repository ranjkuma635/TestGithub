﻿using System.Collections.Generic;
using System.Xml;
using System.IO;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.Extensions.ContentManager.Templating;
using Publishing = Tridion.ContentManager.Publishing.Rendering;
using Tridion.ContentManager.ContentManagement;
using Emaar.Web.Tridion.System.Extensions;
using Tridion.ContentManager;
using System;


namespace TDM.Web.Templating.BuildingBlocks.Templates
{
    [TcmTemplateTitle("Retailpromotions XML")]
    public class Retailpromotions : TemplateBase
    {

        public override void Transform(Engine engine, Package package)
        {

            base.Transform(engine, package);

            using (StringWriter sw = new StringWriter())
            {
                using (XmlTextWriter xml = new XmlTextWriter(sw))
                {

                    xml.WriteStartElement("Data");

                    if (Page.ComponentPresentations.Count > 0)
                    {


                        Component Comp = Page.ComponentPresentations[0].Component; 

                        IList<Component> components = Comp.ComponentValues("Components");
                        xml.WriteElementString("category", Comp.StringValue("Title"));
                        foreach (Component c in components)
                        {

                                xml.WriteStartElement("Retail");

                                xml.WriteAttributeString("uri", c.Id);
                                xml.WriteElementString("name", c.StringValue("title"));

                               
                                Component LogoImage = c.ComponentValue("logo");
                                if (LogoImage != null)
                                   
                                    xml.WriteElementString("Logoimage", GenerateThumbnail(LogoImage, "retaildine", 132, 92, "#fff"));
                                if (c.StringValue("promotions") != null)
                                {
                                    
                                    xml.WriteElementString("promotions", c.StringValue("promotions").Replace("xmlns=\"http://www.w3.org/1999/xhtml\"", ""));
                                  //  xml.WriteElementString("promotions", StripHTML(c.StringValue("promotions"), c.StringValue("promotions").Length));
                                }

                                xml.WriteEndElement();
                        }


                    
                    }

                    xml.WriteEndElement(); 

                }

                Package.AddXml(Package.OutputName, sw.ToString());
            }

            
        }

    }
}
