﻿using System;
using System.Collections.Generic;
using System.Xml;
using Tridion.ContentManager.ContentManagement.Fields;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager;
using System.Collections;
using Tridion.ContentManager.ContentManagement;
using Tridion.ContentManager.CommunicationManagement;
using System.Xml.XPath;
using System.Web;
using Tridion.Extensions.ContentManager.Templating;
using System.IO;
using Emaar.Web.Tridion.System.Extensions;

namespace TDM.Web.Templating.BuildingBlocks.Templates
{


    //This the DCP for the Image Gallery

    [TcmTemplateTitle("Media Gallery")]
    public class MediaGallery: TemplateBase 
    {
        public override void Transform(Engine engine, Package package)
        { 
        
            base.Transform(engine, package);

            string strDate = string.Empty;
            DateTime dtm = new DateTime(); 
            
            using (StringWriter sw = new StringWriter())
            {
                using (XmlTextWriter xml = new XmlTextWriter(sw))
                {

                    xml.WriteStartElement("Data");

                    if (Component != null)
                    {
                        xml.WriteAttributeString("uri", Component.Id);
                        xml.WriteElementString("LargeImage", PublishBinary(Component));
                        xml.WriteElementString("ThumbNailImage", GenerateThumbnail(Component, "thumb", 101, 76, "#fff"));
                        xml.WriteElementString("Title", Component.StringMetaValue("title"));
                        xml.WriteElementString("Description", Component.StringMetaValue("Description"));

                        if (Component.DateMetaValue("Date").ToString("dd/MM/yyyy") != "01/01/0001")
                            strDate = Component.DateMetaValue("Date").ToString("dd/MM/yyyy");
                        else
                            strDate = Component.CreationDate.ToString("dd/MM/yyyy");



                        xml.WriteElementString("Date", strDate);

                        xml.WriteElementString("SortDate", GetSortDate(strDate));

                    }

                    xml.WriteEndElement(); // Data

                }

                Package.AddXml(Package.OutputName, sw.ToString());

            }
        }

        private string GetSortDate(string strDate)
        {

            string strRetval = "";


            string[] datetime = strDate.Split(new char[] { '/' });

            string Year = datetime[2];
            string Month = datetime[1];
            string Day = datetime[0];

            if (Month.Length == 1)
                Month = "0" + Month;

            if (Day.Length == 1)
                Day = "0" + Day;

            strRetval = Year + Month + Day;

            return strRetval;

        }

    }
}
