﻿using System.Collections.Generic;
using System.Xml;
using System.IO;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.Extensions.ContentManager.Templating;
using Publishing = Tridion.ContentManager.Publishing.Rendering;
using Tridion.ContentManager.ContentManagement;
using Emaar.Web.Tridion.System.Extensions;
using Tridion.ContentManager;
namespace TDM.Web.Templating.BuildingBlocks.Templates
{

    [TcmTemplateTitle("prizeartwork XML")]
    public class prizeartwork : TemplateBase
    {

        public override void Transform(Engine engine, Package package)
        {

            base.Transform(engine, package);

            using (StringWriter sw = new StringWriter())
            {
                using (XmlTextWriter xml = new XmlTextWriter(sw))
                {

                    xml.WriteStartElement("Data");

                    if (Page.ComponentPresentations.Count > 0)
                    {


                        Component Comp = Page.ComponentPresentations[0].Component;

                        IList<Component> components = Comp.ComponentValues("Components");

                        foreach (Component c in components)
                        {
                            xml.WriteStartElement("Hotel");
                            xml.WriteAttributeString("uri", c.Id);
                            xml.WriteElementString("name", c.StringValue("title"));
                            Component LogoImage = c.ComponentValue("logo");
                            if (LogoImage != null)
                                //xml.WriteElementString("Logoimage", PublishBinary(LogoImage));
                                xml.WriteElementString("Logoimage", GenerateThumbnail(LogoImage, "hoteldine", 96, 56, "#fff"));

                            IList<Component> resturantcomponent = c.ComponentValues("Restaurants");
                            foreach (Component rescomponent in resturantcomponent)
                            {
                                xml.WriteStartElement("Restaurants");
                                xml.WriteAttributeString("uri", rescomponent.Id);
                                xml.WriteElementString("location", rescomponent.StringValue("location"));
                                xml.WriteElementString("title", rescomponent.Title);
                                Component resturantLogoImage = rescomponent.ComponentValue("logo");
                                if (LogoImage != null)
                                  // xml.WriteElementString("restutantLogoimage", PublishBinary(LogoImage));
                                //    xml.WriteElementString("restutantLogoimage", GenerateThumbnail(resturantLogoImage, "resturantsdine", 211, 174, "#fff"));
                                xml.WriteElementString("restutantLogoimage", GenerateThumbnail(resturantLogoImage, "resturantsdine", 100, 100, "#fff"));

                                xml.WriteEndElement();

                            }



                            xml.WriteEndElement();
                        }

                    }
                        xml.WriteEndElement();
                  

                }
                Package.AddXml(Package.OutputName, sw.ToString());


            }
        }

    }
}
