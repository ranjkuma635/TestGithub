﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager;
using Tridion.ContentManager.ContentManagement;
using Emaar.Web.Tridion.System.Extensions;
using Tridion.Extensions.ContentManager.Templating;

namespace TDM.Web.Templating.BuildingBlocks.Templates
{
    [TcmTemplateTitle("Publish Attached DCP")]
    public class PublishDCP : TemplateBase
    {
        public override void Transform(Engine engine, Package package)
        {
            base.Transform(engine, package);
            IComponentPresentationList componentPresentations = package.ItemAsComponentList(Package.ComponentsName);

            foreach (ComponentPresentation componentPresentation in componentPresentations)
            {
                Component component = GetComponent(componentPresentation.ComponentUri);
                if (component != null && (component.Schema.Title == "TDM-Events" || component.Schema.Title == "TDM-Offers"))
                {
                    engine.RenderComponentPresentation(component.Id, new TcmUri(17553, ItemType.ComponentTemplate, Publication.Id.ItemId));
                }
            }

            IComponentPresentationList BannerList = package.ItemAsComponentList("PageVariable.BannerImage");
            foreach (ComponentPresentation BannerItem in BannerList)
            {
                Component banner= GetComponent(BannerItem.ComponentUri);
                if (banner != null && banner.Schema.Title == "TDM-FlashBannerXML")
                {
                    engine.RenderComponentPresentation(banner.Id, new TcmUri(22389, ItemType.ComponentTemplate, Publication.Id.ItemId));
                }
            }
            
        }
    }
}
