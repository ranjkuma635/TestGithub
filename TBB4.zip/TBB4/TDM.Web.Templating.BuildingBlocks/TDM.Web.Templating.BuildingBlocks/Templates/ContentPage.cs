﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Tridion.ContentManager.ContentManagement;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.Extensions.ContentManager.Templating;
using Emaar.Web.Tridion.System.Extensions;
using Tridion.ContentManager;
using System.Xml;

namespace TDM.Web.Templating.BuildingBlocks.Templates
{
    [TcmTemplateTitle("Content Page")]
    public class ContentPage : TemplateBase
    {
        private String _resource = "<Emaar:GetResources Key=\"{0}\" runat=\"server\"/>";

        public override void Transform(Engine engine, Package package)
        {
            base.Transform(engine, package);
            String title = package.ItemAsString("PageTitle");
            String PageImage = String.Empty;
            String seoDescription = String.Empty;
            String seoKeywords = String.Empty;
            string sCustompageTitle = string.Empty;

            if (Page.ComponentPresentations.Count > 0)
            {
                Component component = Page.ComponentPresentations[0].Component;


                if (component.Content != null)
                {

                    if (component.StringValue("CustompageTitle") != null)
                    {
                        sCustompageTitle = component.StringValue("CustompageTitle");
                    }

                    switch(component.Schema.Title)
                    {
                        case "TDM-Shop":
                            title = String.Format(_resource, "Shop.ShopDetailTitle");
                            break;
                        case "TDM-Dine":
                            title = String.Format(_resource, "Dine.DineDetailTitle");
                            break;
                        case "TDM-Offers":
                            title = String.Format(_resource, "Offers.OffersDetailTitle");
                            break;
                        case "TDM-Events":
                            title = component.StringValue("ftitle"); 
                            break;
                        case "TDM-General":
                            title = component.StringValue("title");
                            break;
                    }

                    String SubTitle = component.StringValue("subtitle");
                    package.AddString("SubTitle", SubTitle);

                    String Info = component.XHTMLValue("info");
                    package.AddHtml("Info", Info);

                    Component imageComponent = component.ComponentValue("banner");
                    if (imageComponent != null)
                    {
                        List<TcmUri> imageURI = new List<TcmUri>();
                        imageURI.Add(imageComponent.Id);
                        Item bannerImage = package.CreateComponentUriListItem(ContentType.ComponentArray, imageURI);
                        package.Remove(package.GetByName("PageVariable.BannerImage"));
                        package.PushItem("PageVariable.BannerImage", bannerImage);
                    }

                    Component pageImage = component.ComponentValue("logo");
                    if (pageImage != null)
                    {
                        PageImage = GenerateThumbnail(pageImage, "s_thumb", 61, 46, "#fff");
                    }
                    else
                    {
                        switch (component.Schema.Title)
                        {
                            case "TDM-Events":
                                PageImage = ExtractImage(component, "fbody");
                                break;
                            case "TDM-General":
                                PageImage = ExtractImage(component, "body");
                                break;
                            default:
                                PageImage = ExtractImage(component, "description");
                                break;
                        }                                                                       
                    }
                    package.AddString("PageImage", PageImage);

                    seoDescription = component.StringMetaValue("seodescription");
                    seoKeywords = component.StringMetaValue("seokeywords");
                    package.AddString("SEODescription", seoDescription);
                    package.AddString("SEOKeywords", seoKeywords);

                    package.AddString("CustompageTitle", sCustompageTitle);

                    
                }
            }
            package.AddXhtml("DisplayTitle",title);
        }

        public string ExtractImage(Component component, string field)
        {
            String sHtml = component.XHTMLValue(field);
            String WithoutNameSpace;
            if (!String.IsNullOrEmpty(sHtml))
            {
                XmlDocument xHtml = new XmlDocument();
                xHtml.LoadXml("<root>"+sHtml+"</root>");
                WithoutNameSpace = xHtml.RemoveNameSpaces();
                xHtml = new XmlDocument();
                xHtml.LoadXml(WithoutNameSpace);
                XmlNode image = xHtml.SelectSingleNode("/root//img");
                if(image != null)
                {
                    String imageID = image.GetAttribute("href");
                    if(!String.IsNullOrEmpty(imageID) && imageID.Contains("tcm:"))
                    {
                        return GenerateThumbnail(GetComponent(imageID),"s_thumb",61,46,"#fff");
                    }
                }
            }
            return String.Empty;
        }
    }
}
