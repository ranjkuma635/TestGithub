﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Xml;
using System.IO;
using Tridion.ContentManager;
using Tridion.ContentManager.CommunicationManagement;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Expression;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.Templating.Dreamweaver;
using Tridion;
using Tridion.ContentManager.ContentManagement.Fields;
using Tridion.Extensions.ContentManager.Templating;
using Publishing = Tridion.ContentManager.Publishing.Rendering;
using Tridion.ContentManager.ContentManagement;
using Tridion.ContentManager.Publishing.Rendering;
using System.Text.RegularExpressions;
using Emaar.Web.Tridion.System.Extensions;

namespace TDM.Web.Templating.BuildingBlocks.Templates
{
    [TcmTemplateTitle("Updatedstores XML")]
    public class Updatedstores: TemplateBase
    {
        /// <summary>
        /// Transforms the current component.
        /// </summary>
        /// <param name="engine">The engine.</param>
        /// <param name="package">The package.</param>
        public override void Transform(Engine engine, Package package)
        {

            int i = 1;

            string s = string.Empty;

            string strfulldesc = string.Empty;

            base.Transform(engine, package);
            
            Engine  m_Engine;
            m_Engine = engine;

            string strPubid = Page.ComponentPresentations[0].Component.Id.PublicationId.ToString();   

            string strShop = "tcm:"+strPubid+"-2149-2";
            string strDine= "tcm:"+strPubid+"-2150-2";
            string strEnt= "tcm:"+strPubid+"-2151-2";
            string strStay = "tcm:" + strPubid + "-2152-2";

            OrganizationalItem ShopFolder = m_Engine.GetObject(strShop) as OrganizationalItem;
            OrganizationalItem DineFolder = m_Engine.GetObject(strDine) as OrganizationalItem;
            OrganizationalItem EntertatmentFolder = m_Engine.GetObject(strEnt) as OrganizationalItem;
            OrganizationalItem StayFolder = m_Engine.GetObject(strStay) as OrganizationalItem;

            using (StringWriter sw = new StringWriter())
            {
            using (XmlTextWriter xml = new XmlTextWriter(sw))
            {
                xml.WriteStartElement("stores");

                    i = 1;
                    IList<Component> componentsshop = ShopFolder.Components(true);
                    foreach (Component c in componentsshop)
                    {
                        if (c.Schema.Title.Equals("TDM-Shop"))
                        {


                            Filter f = new Filter();
                            f.Conditions["ItemType"] = ItemType.Component;

                            string strModifiedDate = c.GetListVersions(f).LastChild.GetAttribute("Modified").ToString();


                            if (CheckShouldAdd(strModifiedDate))
                            {
                                xml.WriteStartElement("store");

                                xml.WriteAttributeString("type", "shop");
                                xml.WriteAttributeString("uri", c.Id);
                                xml.WriteAttributeString("ShopID", c.StringValue("shopid"));
                                xml.WriteAttributeString("LastUpdatedDate", strModifiedDate);

                                xml.WriteAttributeString("No", i.ToString());

                                xml.WriteElementString("categorydesc", c.KeywordMetaValue("category").Description);
                                xml.WriteElementString("name", c.StringValue("title"));

                                Component Imag;
                                Imag = c.ComponentValue("logo");
                                if (Imag != null)
                                {
                                    xml.WriteElementString("image", "http://www.thedubaimall.com" + GenerateThumbnail(Imag, "thumblogo", 132, 92, "#fff"));
                                }

                                xml.WriteElementString("description", c.StringValue("description").Replace("xmlns=\"http://www.w3.org/1999/xhtml\"", ""));

                                xml.WriteElementString("telephone", c.XHTMLValue("telephone"));
                                xml.WriteElementString("email", c.StringValue("email"));
                                xml.WriteElementString("fax", c.StringValue("fax"));
                                xml.WriteElementString("website", c.StringValue("website"));
                                xml.WriteElementString("StoreFrontCode", c.StringValue("StoreFrontCode"));

                                xml.WriteEndElement();

                                i++;
                            }
                        }
                    }



                    i = 1;
                    IList<Component> componentsdine = DineFolder.Components(true);
                    foreach (Component c in componentsdine)
                    {
                        if (c.Schema.Title.Equals("TDM-Dine"))
                        {

                            Filter f = new Filter();
                            f.Conditions["ItemType"] = ItemType.Component;

                            string strModifiedDate = c.GetListVersions(f).LastChild.GetAttribute("Modified").ToString();


                            if (CheckShouldAdd(strModifiedDate))
                            {

                                xml.WriteStartElement("store");

                                xml.WriteAttributeString("type", "dine");
                                xml.WriteAttributeString("uri", c.Id);
                                xml.WriteAttributeString("ShopID", c.StringValue("shopid"));
                                xml.WriteAttributeString("LastUpdatedDate", strModifiedDate);

                                xml.WriteAttributeString("No", i.ToString());

                                xml.WriteElementString("categorydesc", c.KeywordMetaValue("category").Description);
                                xml.WriteElementString("name", c.StringValue("title"));

                                Component Imag;
                                Imag = c.ComponentValue("logo");
                                if (Imag != null)
                                {
                                    xml.WriteElementString("image", "http://www.thedubaimall.com" + GenerateThumbnail(Imag, "thumblogo", 132, 92, "#fff"));
                                }

                                xml.WriteElementString("description", c.StringValue("description").Replace("xmlns=\"http://www.w3.org/1999/xhtml\"", ""));

                                xml.WriteElementString("telephone", c.StringValue("telephone"));
                                xml.WriteElementString("email", c.StringValue("email"));
                                xml.WriteElementString("fax", c.StringValue("fax"));
                                xml.WriteElementString("website", c.StringValue("website"));
                                xml.WriteElementString("StoreFrontCode", c.StringValue("StoreFrontCode"));

                                xml.WriteEndElement();

                                i++;

                            }
                        }

                    }



                    //IList<Component> componententertatin = EntertatmentFolder.Components(true);
                    //foreach (Component c in componententertatin)
                    //{
                    //    if (c.Schema.Title.Equals("TDM-Entertain"))
                    //    {
                    //        xml.WriteStartElement("store");
                    //        xml.WriteAttributeString("type", "Entertain");
                    //        xml.WriteAttributeString("uri", c.Id);
                    //        xml.WriteAttributeString("storefrontcode", splitspaces(c.StringValue("StoreFrontCode")));

                    //        xml.WriteElementString("floor", c.StringValue("floor"));
                    //        xml.WriteElementString("name", c.StringValue("title"));

                    //        //strfulldesc = c.StringValue("description").ToString().Replace("<p xmlns=\"http://www.w3.org/1999/xhtml\">", "");
                    //        //strfulldesc = strfulldesc.Replace("<p>", "");
                    //        //strfulldesc = strfulldesc.Replace("</p>", "");
                    //        //strfulldesc = strfulldesc.Replace("<strong>", "");
                    //        //strfulldesc = strfulldesc.Replace("<strong xmlns=\"http://www.w3.org/1999/xhtml\">", "");
                    //        //strfulldesc = strfulldesc.Replace("<span xmlns=\"http://www.w3.org/1999/xhtml\">", "");
                    //        //strfulldesc = strfulldesc.Replace("</strong>", "");
                    //        //strfulldesc = strfulldesc.Replace("</span>", "");
                    //        //strfulldesc = strfulldesc.Replace("xmlns=\"http://www.w3.org/1999/xhtml\"", "");
                    //        //strfulldesc = strfulldesc.Replace("xmlns=\"http://www.w3.org/1999/xhtml\"", "");
                    //        //strfulldesc = strfulldesc.Replace("xmlns=\"http://www.w3.org\"", "");
                    //        //strfulldesc = strfulldesc.Replace("xmlns=\"http://www.w3.org/1999/", "");
                    //        //strfulldesc = strfulldesc.Replace("xmlns=\"http://www.w3.org/", "");
                    //        //strfulldesc = strfulldesc.Replace("xmlns=\"http://www.w3.org/1999/xhtml\"", "");

                    //        ItemFields itemfield;
                    //        itemfield = new ItemFields(c.Content, c.Schema);
                    //        strfulldesc = itemfield["description"].StringValue();
                    //        strfulldesc = "<content>" + strfulldesc + "</content>";
                    //        XmlDocument doc = new XmlDocument();
                    //        doc.LoadXml(strfulldesc);

                    //        strfulldesc = doc.InnerText;


                    //        if (strfulldesc.Length > 150)
                    //            xml.WriteElementString("description", strfulldesc.Substring(0, 150));
                    //        else
                    //            xml.WriteElementString("description", strfulldesc);


                    //        Component Imag;
                    //        IList<Component> listimages = c.ComponentValues("galleryimage");
                    //        if (listimages != null)
                    //        {
                    //            if (listimages.Count > 0)
                    //            {
                    //                Imag = listimages[0];
                    //                if (Imag != null)
                    //                    xml.WriteElementString("image", GenerateThumbnail(Imag, "storelocator", 165, 110, "#fff"));
                    //            }
                    //        }
                    //        xml.WriteEndElement();
                    //    }

                    //}


                    i = 1;
                    IList<Component> staytertatin = StayFolder.Components(true);
                    foreach (Component c in staytertatin)
                    {
                        if (c.Schema.Title.Equals("TDM-Stay"))
                        {

                            Filter f = new Filter();
                            f.Conditions["ItemType"] = ItemType.Component;

                            string strModifiedDate = c.GetListVersions(f).LastChild.GetAttribute("Modified").ToString();

                            if (CheckShouldAdd(strModifiedDate))
                            {
                                xml.WriteStartElement("store");


                                xml.WriteAttributeString("type", "stay");
                                xml.WriteAttributeString("uri", c.Id);
                                xml.WriteAttributeString("ShopID", c.StringValue("shopid"));
                                xml.WriteAttributeString("LastUpdatedDate", strModifiedDate);

                                xml.WriteAttributeString("No", i.ToString());


                                xml.WriteElementString("name", c.StringValue("title"));

                                Component Imag;
                                Imag = c.ComponentValue("logo");
                                if (Imag != null)
                                {
                                    xml.WriteElementString("image", "http://www.thedubaimall.com" + GenerateThumbnail(Imag, "thumblogo", 132, 92, "#fff"));
                                }

                                xml.WriteElementString("description", c.StringValue("description").Replace("xmlns=\"http://www.w3.org/1999/xhtml\"", ""));

                                xml.WriteElementString("telephone", c.StringValue("telephone"));
                                xml.WriteElementString("email", c.StringValue("email"));
                                xml.WriteElementString("fax", c.StringValue("fax"));
                                xml.WriteElementString("website", c.StringValue("website"));
                                xml.WriteElementString("StoreFrontCode", c.StringValue("StoreFrontCode"));

                                xml.WriteEndElement();

                                i++;
                            }
                        }

                    }



                    xml.WriteEndElement();
                }
                Package.AddXml(Package.OutputName, sw.ToString());
            }



        }

        private bool CheckShouldAdd(string strDate)
        {

            bool retval = false;

            DateTime date = new DateTime(2013, 3, 17);

            if (TridionDateToDateTime(strDate) >= date)
                return true;

            return retval;

        }

        private static DateTime TridionDateToDateTime(string TridionDate)
        {
            try
            {
                string[] datetime = TridionDate.Split(new char[] { 'T' });
                string[] ymd = datetime[0].Split(new char[] { '-' });
                string[] hms = datetime[1].Split(new char[] { ':' });
                return new DateTime(int.Parse(ymd[0]), int.Parse(ymd[1]), int.Parse(ymd[2]));
            }
            catch
            {
                return DateTime.Now;
            }

        }

    }
}
