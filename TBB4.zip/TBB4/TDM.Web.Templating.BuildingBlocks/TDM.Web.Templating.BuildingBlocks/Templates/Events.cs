﻿using System;
using System.Collections.Generic;
using System.Xml;
using Tridion.ContentManager.ContentManagement.Fields;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager;
using System.Collections;
using Tridion.ContentManager.ContentManagement;
using Tridion.ContentManager.CommunicationManagement;
using System.Xml.XPath;
using System.Web;
using Tridion.Extensions.ContentManager.Templating;
using System.IO;
using Emaar.Web.Tridion.System.Extensions;

namespace TDM.Web.Templating.BuildingBlocks.Templates
{
    [TcmTemplateTitle("Events")]
    public class Events : TemplateBase 
    {

        public override void Transform(Engine engine, Package package)
        {
            base.Transform(engine, package);

            using (StringWriter sw = new StringWriter())
            {

                using (XmlTextWriter xml = new XmlTextWriter(sw))
                {

                    
                    xml.WriteStartElement("Data");

                    if (Component != null)
                    {
                        xml.WriteAttributeString("uri", Component.Id);

                        xml.WriteElementString("uri", Component.Id);

                        if (Component.Schema.Title == "TDM-Offers")
                        xml.WriteElementString("Title", Component.XHTMLValue("ftitle"));
                        else
                            xml.WriteElementString("Title", Component.StringValue("ftitle"));

                        xml.WriteElementString("Summary", Component.StringValue("fsummary"));
                        xml.WriteElementString("Body", Component.XHTMLValue("fbody"));
                        xml.WriteElementString("Location", Component.StringValue("flocation"));

                        xml.WriteElementString("PublishDate", Component.DateMetaValue("publishdate").ToString("dd/MM/yyyy"));
                        xml.WriteElementString("StatrtDate", Component.DateMetaValue("startdate").ToString("dd/MM/yyyy"));
                        xml.WriteElementString("EndDate", Component.DateMetaValue("enddate").ToString("dd/MM/yyyy"));

                        Component EventFeatureImage = Component.ComponentValue("ffeatureimage");
                        if(EventFeatureImage!=null)
                            xml.WriteElementString("FeatureImage", PublishBinary(EventFeatureImage));


                        Component EventImage = Component.ComponentValue("fimage");
                        if(EventImage != null && EventImage.BinaryContent!=null)
                        {
                            xml.WriteElementString("LargeImage", PublishBinary(EventImage));
                            xml.WriteElementString("ThumbNailImage", GenerateThumbnail(EventImage, "thumb", 125, 88, "#fff"));
                        }
                        
                        xml.WriteStartElement("Shop");
                        Component shop = Component.ComponentMetaValue("fshop");
                        if (shop != null)
                        {
                            if (shop.Schema.Title == "TDM-Shop" || shop.Schema.Title == "TDM-Dine")
                            {
                                Component ImageComponent = shop.ComponentValue("logo");
                                if (ImageComponent != null)
                                    xml.WriteElementString("Offerthumb", GenerateThumbnail(ImageComponent, "Offerthumb", 70, 50, "#fff"));


                                xml.WriteElementString("shopuri", shop.Id);
                                xml.WriteElementString("Schema", shop.Schema.Id);

                                if (shop.Schema.Title == "TDM-Shop")
                                {
                                    xml.WriteElementString("Type", "Shop");
                                    xml.WriteElementString("title", shop.XHTMLValue("title"));
                                }
                                else
                                {
                                    xml.WriteElementString("Type", "Dine");
                                    xml.WriteElementString("title", shop.StringValue("title"));
                                }



                                xml.WriteElementString("category", shop.KeywordMetaValue("category").Title);
                            }
                            else
                            {
                                xml.WriteElementString("Offerthumb", "");
                                xml.WriteElementString("shopuri", "");
                                xml.WriteElementString("Schema", "");
                                xml.WriteElementString("title", "");
                                xml.WriteElementString("category", "");
                            }

                        }
                        xml.WriteEndElement(); //shop

                    }

                    xml.WriteEndElement(); // Data
                    

                }

                Package.AddXml(Package.OutputName, sw.ToString());

            }

        }

    }
}
