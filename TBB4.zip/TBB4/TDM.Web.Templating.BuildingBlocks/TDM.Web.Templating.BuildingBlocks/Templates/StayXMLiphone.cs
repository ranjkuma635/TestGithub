﻿using System;
using System.Collections.Generic;
using System.Xml;
using System.IO;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.Extensions.ContentManager.Templating;
using Tridion.ContentManager.ContentManagement;

using Emaar.Web.Tridion.System.Extensions;

namespace TDM.Web.Templating.BuildingBlocks.Templates
{
    [TcmTemplateTitle("Stay XML Iphone")]
    public class StayXMLIPHONE : TemplateBase
    {
        /// <summary>
        /// Transforms the current component.
        /// </summary>
        /// <param name="engine">The engine.</param>
        /// <param name="package">The package.</param>
        public override void Transform(Engine engine, Package package)
        {
            //string strActive = string.Empty;
            string strActive = string.Empty;
            string strfulldesc = string.Empty;
            base.Transform(engine, package);
            int i = 29035;

            using (StringWriter sw = new StringWriter())
            {
                using (XmlTextWriter xml = new XmlTextWriter(sw))
                {
                    xml.WriteStartElement("venues");
                    if (IsComponent)
                    {
                        IList<Component> components = Component.OrganizationalItem.Components(true);
                        foreach (Component c in components)
                        {
                            if (c.Schema.Title.Equals("TDM-Stay"))
                            {

                                    //xml.WriteStartElement("venue");
                                     //   xml.WriteAttributeString("type", "shop");
                                      //  xml.WriteAttributeString("Date", c.CreationDate.ToString("yyyy/MM/dd"));
                                    //xml.WriteEndElement();


                                    //Filter f = new Filter();
                                    //f.Conditions["ItemType"] = ItemType.Component;

                                    //string strModifiedDate = c.GetListVersions(f).LastChild.GetAttribute("Modified").ToString();

                                    if (CheckShouldAdd(c.CreationDate.ToString("yyyy/MM/dd")))
                                    {

                                        xml.WriteStartElement("venue");

                                        xml.WriteAttributeString("type", "stay");
                                        xml.WriteAttributeString("uri", c.Id);
                                        xml.WriteAttributeString("ShopID", c.StringValue("shopid"));
                                        xml.WriteAttributeString("LastUpdatedDate", c.CreationDate.ToString("yyyy/MM/dd"));

                                        xml.WriteAttributeString("No", i.ToString());

                                        
                                        xml.WriteElementString("name", c.StringValue("title"));

                                        Component Imag;
                                        Imag = c.ComponentValue("logo");
                                        if (Imag != null)
                                        {
                                            xml.WriteElementString("image", "http://www.thedubaimall.com" + GenerateThumbnail(Imag, "thumblogo", 132, 92, "#fff"));
                                        }

                                        xml.WriteElementString("description", c.StringValue("description").Replace("xmlns=\"http://www.w3.org/1999/xhtml\"", ""));

                                        xml.WriteElementString("telephone", c.StringValue("telephone"));
                                        xml.WriteElementString("email", c.StringValue("email"));
                                        xml.WriteElementString("fax", c.StringValue("fax"));
                                        xml.WriteElementString("website", c.StringValue("website"));
                                        xml.WriteElementString("StoreFrontCode", c.StringValue("StoreFrontCode"));



                                        xml.WriteEndElement();

                                        i++;

                                    }
                           
                            } 
                        }
                    }
                    xml.WriteEndElement();
                }
                Package.AddXml(Package.OutputName, sw.ToString());
            }
        }

        private bool CheckShouldAdd(string strDate)
        {

            

            bool retval = false;

            DateTime date = new DateTime(2013, 3, 17);

            if (TridionDateToDateTime(strDate) >= date)
                return true;

            return retval;
        
        }

        private static DateTime TridionDateToDateTime(string TridionDate)
        {
            try
            {
                string[] datetime = TridionDate.Split(new char[] { '/' });
                return new DateTime(int.Parse(datetime[0]), int.Parse(datetime[1]), int.Parse(datetime[2]));
            }
            catch
            {
                return DateTime.Now;
            }



        }



    }
}
