﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Xml;
using System.IO;
using Tridion.ContentManager;
using Tridion.ContentManager.CommunicationManagement;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Expression;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.Templating.Dreamweaver;
using Tridion;
using Tridion.ContentManager.ContentManagement.Fields;
using Tridion.Extensions.ContentManager.Templating;
using Publishing = Tridion.ContentManager.Publishing.Rendering;
using Tridion.ContentManager.ContentManagement;
using Tridion.ContentManager.Publishing.Rendering;
using System.Text.RegularExpressions;
using Emaar.Web.Tridion.System.Extensions;


namespace TDM.Web.Templating.BuildingBlocks.Templates
{
    public class StorelocatorJSON : TemplateBase
    {

        public override void Transform(Engine engine, Package package)
        {

            string Shop = "Shop";
            string Dine = "dine";
            string Entertain = "Entertain";

            int loopcount = 0;
            int CompCount;

            string s = string.Empty;

            string strfulldesc = string.Empty;

            base.Transform(engine, package);

            Engine m_Engine;
            m_Engine = engine;

            string strPubid = Page.ComponentPresentations[0].Component.Id.PublicationId.ToString();

            string strShop = "tcm:" + strPubid + "-2149-2";
            string strDine = "tcm:" + strPubid + "-2150-2";
            string strEnt = "tcm:" + strPubid + "-2151-2";
            string strStay = "tcm:" + strPubid + "-2152-2";

            OrganizationalItem ShopFolder = m_Engine.GetObject(strShop) as OrganizationalItem;
            OrganizationalItem DineFolder = m_Engine.GetObject(strDine) as OrganizationalItem;
            OrganizationalItem EntertatmentFolder = m_Engine.GetObject(strEnt) as OrganizationalItem;
            OrganizationalItem StayFolder = m_Engine.GetObject(strStay) as OrganizationalItem;


            StringBuilder strHtml = new StringBuilder();

            strHtml.Append("{");
            strHtml.Append(Environment.NewLine);
                strHtml.Append("\"stores\": { ");
                strHtml.Append(Environment.NewLine);
                    strHtml.Append("\"store\": [");
                    strHtml.Append(Environment.NewLine);
                   


                
                    IList<Component> componentsshop = ShopFolder.Components(true);
                    foreach (Component c in componentsshop)
                    {

                        if (c.Schema.Title.Equals("TDM-Shop"))
                        {
                            strHtml.Append("{");
                                strHtml.Append(Environment.NewLine);
                                strHtml.Append("\"floor\": \"\",");
                                strHtml.Append(Environment.NewLine);

                                ItemFields itemfieldname;
                                itemfieldname = new ItemFields(c.Content, c.Schema);
                                strHtml.Append("\"name\": \"" + getrawtextName(itemfieldname["title"].StringValue()) + "\",");

                                //strHtml.Append("\"name\": \"" + (itemfieldname["title"].StringValue()) + "\",");

                                strHtml.Append(Environment.NewLine);
                                strHtml.Append("\"telephone\": \"" + c.XHTMLValue("telephone") + "\",");
                                strHtml.Append(Environment.NewLine);
                                strHtml.Append("\"website\": \"" + c.StringValue("website") + "\",");
                                strHtml.Append(Environment.NewLine);

                                Component LogoImage = c.ComponentValue("logo");
                                if (LogoImage != null)
                                {
                                    strHtml.Append("\"Logoimage\": \"" + PublishBinary(LogoImage) + "\",");
                                    strHtml.Append(Environment.NewLine);
                                }

                                ItemFields itemfield;
                                itemfield = new ItemFields(c.Content, c.Schema);
                                strHtml.Append("\"description\": \"" + getrawtext(itemfield["description"].StringValue()) + "\",");

                                strHtml.Append(Environment.NewLine);

                                strHtml.Append("\"emaargift\": \"" + c.StringValue("emaargift") + "\",");

                                strHtml.Append(Environment.NewLine);


                                Component Imag;
                                IList<Component> listimages = c.ComponentValues("galleryimage");
                                if (listimages != null)
                                {
                                    if (listimages.Count > 0)
                                    {
                                        Imag = listimages[0];
                                        if (Imag != null)
                                        {
                                            strHtml.Append("\"image\": \"" + GenerateThumbnail(Imag, "stl", 165, 110, "#fff") + "\",");
                                        }
                                    }
                                }

                                strHtml.Append(Environment.NewLine);

                                strHtml.Append("\"_type\": \"" + Shop + "\",");

                                strHtml.Append(Environment.NewLine);

                                strHtml.Append("\"_uri\": \"" + c.Id + "\",");

                                strHtml.Append(Environment.NewLine);

                                strHtml.Append("\"_id\": \"" + c.StringValue("shopid") + "\",");

                                strHtml.Append(Environment.NewLine);

                                strHtml.Append("\"_storefrontcode\": \"" + splitspaces(c.StringValue("StoreFrontCode")) + "\",");

                                strHtml.Append(Environment.NewLine);

                                strHtml.Append("\"_category\": \"" + c.KeywordMetaValue("category").Description + "\"");

                                strHtml.Append(Environment.NewLine);

                                strHtml.Append("},");
                                strHtml.Append(Environment.NewLine);
                        }

                    }



                    IList<Component> componentsDine = DineFolder.Components(true);

                    CompCount = Convert.ToInt16(componentsDine.Count());

                    foreach (Component c in componentsDine)
                    {

                        if (c.Schema.Title.Equals("TDM-Dine"))
                        {


                            

                            strHtml.Append("{");
                            strHtml.Append(Environment.NewLine);
                            strHtml.Append("\"floor\": \"\",");
                            strHtml.Append(Environment.NewLine);


                            ItemFields itemfieldname;
                            itemfieldname = new ItemFields(c.Content, c.Schema);
                            strHtml.Append("\"name\": \"" + getrawtextName(itemfieldname["title"].StringValue()) + "\",");

                            //strHtml.Append("\"name\": \"" + (itemfieldname["title"].StringValue()) + "\",");


                            strHtml.Append(Environment.NewLine);
                            strHtml.Append("\"telephone\": \"" + c.StringValue("telephone") + "\",");
                            strHtml.Append(Environment.NewLine);
                            strHtml.Append("\"website\": \"" + c.StringValue("website") + "\",");
                            strHtml.Append(Environment.NewLine);

                            Component LogoImage = c.ComponentValue("logo");
                            if (LogoImage != null)
                            {
                                strHtml.Append("\"Logoimage\": \"" + PublishBinary(LogoImage) + "\",");
                                strHtml.Append(Environment.NewLine);
                            }

                            ItemFields itemfield;
                            itemfield = new ItemFields(c.Content, c.Schema);
                            strHtml.Append("\"description\": \"" + getrawtext(itemfield["description"].StringValue()) + "\",");


                            strHtml.Append(Environment.NewLine);

                            strHtml.Append("\"emaargift\": \"" + c.StringValue("emaargift") + "\",");

                            strHtml.Append(Environment.NewLine);


                            Component Imag;
                            IList<Component> listimages = c.ComponentValues("galleryimage");
                            if (listimages != null)
                            {
                                if (listimages.Count > 0)
                                {
                                    Imag = listimages[0];
                                    if (Imag != null)
                                    {
                                        strHtml.Append("\"image\": \"" + GenerateThumbnail(Imag, "stl", 165, 110, "#fff") + "\",");
                                    }
                                }
                            }

                            strHtml.Append(Environment.NewLine);

                            strHtml.Append("\"_type\": \"" + Dine + "\",");

                            strHtml.Append(Environment.NewLine);

                            strHtml.Append("\"_uri\": \"" + c.Id + "\",");

                            strHtml.Append(Environment.NewLine);

                            strHtml.Append("\"_id\": \"" + c.StringValue("shopid") + "\",");

                            strHtml.Append(Environment.NewLine);

                            strHtml.Append("\"_storefrontcode\": \"" + splitspaces(c.StringValue("StoreFrontCode")) + "\",");

                            strHtml.Append(Environment.NewLine);

                            strHtml.Append("\"_category\": \"" + c.KeywordMetaValue("category").Description + "\"");

                            strHtml.Append(Environment.NewLine);


                            if (loopcount != CompCount)
                                strHtml.Append("},");
                            else
                                strHtml.Append("}");

                            strHtml.Append(Environment.NewLine);

                            loopcount++;

                        }

                    }



                    /*
                    IList<Component> componentsEnt = EntertatmentFolder.Components(true);
                    foreach (Component c in componentsEnt)
                    {

                        if (c.Schema.Title.Equals("TDM-Entertain"))
                        {
                            strHtml.Append("{");
                            strHtml.Append(Environment.NewLine);
                            strHtml.Append("\"floor\": \"\",");
                            strHtml.Append(Environment.NewLine);
                            strHtml.Append("\"name\": " + c.StringValue("title") + ",");
                            strHtml.Append(Environment.NewLine);
                            strHtml.Append("\"telephone\": " + c.StringValue("telephone") + ",");
                            strHtml.Append(Environment.NewLine);
                            strHtml.Append("\"website\": " + c.StringValue("website") + ",");
                            strHtml.Append(Environment.NewLine);

                            Component LogoImage = c.ComponentValue("logo");
                            if (LogoImage != null)
                            {
                                strHtml.Append("\"Logoimage\": " + PublishBinary(LogoImage) + ",");
                                strHtml.Append(Environment.NewLine);
                            }


                            ItemFields itemfield;
                            itemfield = new ItemFields(c.Content, c.Schema);
                            strfulldesc = itemfield["description"].StringValue();
                            strfulldesc = "<content>" + strfulldesc + "</content>";
                            XmlDocument doc = new XmlDocument();
                            doc.LoadXml(strfulldesc);

                            strfulldesc = doc.InnerText;

                            if (strfulldesc.Length > 150)
                                strHtml.Append("\"description\": " + strfulldesc.Substring(0, 150) + ",");
                            else
                                strHtml.Append("\"description\": " + strfulldesc + ",");


                            strHtml.Append(Environment.NewLine);

                            strHtml.Append("\"emaargift\": " + c.StringValue("emaargift") + ",");

                            strHtml.Append(Environment.NewLine);


                            Component Imag;
                            IList<Component> listimages = c.ComponentValues("galleryimage");
                            if (listimages != null)
                            {
                                if (listimages.Count > 0)
                                {
                                    Imag = listimages[0];
                                    if (Imag != null)
                                    {
                                        strHtml.Append("\"image\": " + GenerateThumbnail(Imag, "stl", 165, 110, "#fff") + ",");
                                    }
                                }
                            }

                            strHtml.Append(Environment.NewLine);

                            strHtml.Append("\"_type\": " + Entertain + ",");

                            strHtml.Append(Environment.NewLine);

                            strHtml.Append("\"_uri\": " + c.Id + ",");

                            strHtml.Append(Environment.NewLine);

                            strHtml.Append("\"_id\": " + c.StringValue("shopid") + ",");

                            strHtml.Append(Environment.NewLine);

                            strHtml.Append("\"_storefrontcode\": " + splitspaces(c.StringValue("StoreFrontCode")) + ",");

                            strHtml.Append(Environment.NewLine);

                            strHtml.Append("\"_category\": " + c.KeywordMetaValue("category").Description + ",");

                            strHtml.Append(Environment.NewLine);

                            strHtml.Append("},");
                            strHtml.Append(Environment.NewLine);
                        }

                    }
                    */


                    



                    strHtml.Append(Environment.NewLine);
                    strHtml.Append("]");
                strHtml.Append(Environment.NewLine);
                strHtml.Append("}");
            strHtml.Append(Environment.NewLine);
            strHtml.Append("}");


            Package.AddXml(Package.OutputName, strHtml.ToString());

        }


        private string splitspaces(string val)
        {
            if (val.Contains(' '))
            {
                string _returnVal = "";
                val.Split(new string[] { " " }, StringSplitOptions.None).ToList().ForEach(_d =>
                {
                    _returnVal += _d;
                });
                return _returnVal;
            }
            else
                return val;

        }

        private string getrawtext(string val)
        {

            string strfulldesc = string.Empty;

            strfulldesc = val.Replace("<br/>", "");
            strfulldesc = strfulldesc.Replace("<br xmlns=\"http://www.w3.org/1999/xhtml\" />",""); 
            

            strfulldesc = "<content>" + strfulldesc + "</content>";
            XmlDocument doc = new XmlDocument();
            doc.LoadXml(strfulldesc);

            strfulldesc = doc.InnerText;
            strfulldesc = Regex.Replace(strfulldesc, @"\t|\n|\r", "");
            strfulldesc = Regex.Replace(strfulldesc, "\"[^\"]*\"", string.Empty);


            if (strfulldesc.Length > 150)
                strfulldesc = strfulldesc.Substring(0, 150);

            return strfulldesc;
        
        }

        private string getrawtextName(string val)
        {

            string strfulldesc = string.Empty;

            strfulldesc = val.Replace("<br/>", "");
            strfulldesc = strfulldesc.Replace("<br xmlns=\"http://www.w3.org/1999/xhtml\" />", "");
            strfulldesc = strfulldesc.Replace("<p xmlns=\"http://www.w3.org/1999/xhtml\">", "");
            strfulldesc = strfulldesc.Replace("</p>", "");
            strfulldesc = strfulldesc.Replace("&amp;", "");

            strfulldesc = Regex.Replace(strfulldesc, @"\t|\n|\r", "");
            strfulldesc = Regex.Replace(strfulldesc, "\"[^\"]*\"", string.Empty);


            return strfulldesc;

        }


    }
}
