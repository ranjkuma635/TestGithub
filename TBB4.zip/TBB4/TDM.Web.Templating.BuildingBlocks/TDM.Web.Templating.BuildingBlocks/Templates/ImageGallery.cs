﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Xml;
using System.IO;
using Tridion.ContentManager;
using Tridion.ContentManager.CommunicationManagement;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Expression;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.Templating.Dreamweaver;
using Tridion;
using Tridion.ContentManager.ContentManagement.Fields;
using Tridion.Extensions.ContentManager.Templating;
using Publishing = Tridion.ContentManager.Publishing;
using Tridion.ContentManager.ContentManagement;
using Tridion.ContentManager.Publishing.Rendering;
using System.Text.RegularExpressions;
using Emaar.Web.Tridion.System.Extensions;
using Tridion.ContentManager.Publishing;

namespace TDM.Web.Templating.BuildingBlocks.Templates
{

    //This it to populate the Image Gallery XML file.

    [TcmTemplateTitle("Image Gallery XML")]
    public class ImageGallery : TemplateBase
    {

        public override void Transform(Engine engine, Package package)
        {

            base.Transform(engine, package);

            Engine m_Engine;
            m_Engine = engine;

            string strDate = string.Empty;
            DateTime dtm = new DateTime(); 

            string strPubid = Page.ComponentPresentations[0].Component.Id.PublicationId.ToString();

            string strImageFolderID = "tcm:" + strPubid + "-" + Page.ComponentPresentations[0].Component.OrganizationalItem.Id.ItemId.ToString()+ "-2";

            OrganizationalItem ShopFolder = m_Engine.GetObject(strImageFolderID) as OrganizationalItem;

            using (StringWriter sw = new StringWriter())
            {
                using (XmlTextWriter xml = new XmlTextWriter(sw))
                {


                    xml.WriteStartElement("images");

                    IList<Component> componentsshop = ShopFolder.Components(true);

                    foreach (Component c in componentsshop)
                    {
                        if (c.Schema.Title.Equals("TDM - Media Gallery"))
                        {

                            if (c != null)
                            {

                                    xml.WriteStartElement("image");

                                    xml.WriteAttributeString("uri", c.Id);
                                    xml.WriteElementString("LargeImage", PublishBinary(c));
                                    xml.WriteElementString("ThumbNailImage", GenerateThumbnail(c, "thumb", 101, 76, "#fff"));
                                    xml.WriteElementString("Title", c.StringMetaValue("title"));
                                    xml.WriteElementString("Description", c.StringMetaValue("Description"));

                                    if (c.DateMetaValue("Date").ToString("dd/MM/yyyy") != "01/01/0001")
                                        strDate = c.DateMetaValue("Date").ToString("dd/MM/yyyy");
                                    else
                                        strDate = c.CreationDate.ToString("dd/MM/yyyy");





                                    xml.WriteElementString("Date", strDate);

                                    xml.WriteElementString("SortDate", GetSortDate(strDate));

                                    xml.WriteEndElement(); // Data


                            }

                        }

                    }

                    xml.WriteEndElement();
                }

                Package.AddXml(Package.OutputName, sw.ToString());
            }

        }

        private string GetSortDate(string strDate)
        {

            string strRetval = "";


            string[] datetime = strDate.Split(new char[] { '/' });

            string Year = datetime[2];
            string Month = datetime[1];
            string Day = datetime[0];

            if (Month.Length == 1)
                Month = "0" + Month;

            if (Day.Length == 1)
                Day = "0" + Day;

            strRetval = Year + Month + Day;

            return strRetval;

        }


    }
}
