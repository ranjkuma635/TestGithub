﻿using System.Collections.Generic;
using System.Xml;
using System.IO;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.Extensions.ContentManager.Templating;
using Publishing = Tridion.ContentManager.Publishing.Rendering;
using Tridion.ContentManager.ContentManagement;
using Tridion.ContentManager.ContentManagement.Fields;
using Emaar.Web.Tridion.System.Extensions;

namespace TDM.Web.Templating.BuildingBlocks.Templates
{
    [TcmTemplateTitle("Footer Links XML")]
    public class FooterLinksXML : TemplateBase
    {
        /// <summary>
        /// Transforms the current component.
        /// </summary>
        /// <param name="engine">The engine.</param>
        /// <param name="package">The package.</param>
        public override void Transform(Engine engine, Package package)
        {
            base.Transform(engine, package);
            using (StringWriter sw = new StringWriter())
            {
                using (XmlTextWriter xml = new XmlTextWriter(sw))
                {
                    xml.WriteStartElement("footer");
                    if (IsComponent)
                    {
                        IList<Component> components = Component.OrganizationalItem.Components(true);
                        foreach (Component c in components)
                        {
                            if (c.Schema.Title.Equals("TDM-Links"))
                            {
                                xml.WriteStartElement("section");

                                xml.WriteElementString("title", c.StringValue("ftitle"));

                                IList<ItemFields> iFields = c.EmbeddedValues("flinks");

                                foreach (ItemFields fields in iFields)
                                {
                                    xml.WriteStartElement("link");

                                    xml.WriteElementString("text", fields.StringValue("flinktext"));

                                    Component cc = fields.ComponentValue("fcomponentlink");
                                    if(cc!=null)
                                     xml.WriteElementString("componentlink", cc.Id);

                                    xml.WriteElementString("externallink", fields.StringValue("fexternallink"));
                                    xml.WriteEndElement(); // end of link

                                }

                                xml.WriteEndElement();//End Section
                            }

                        }
                    }
                    xml.WriteEndElement();
                }
                Package.AddXml(Package.OutputName, sw.ToString());
            }
        }
    }
}
