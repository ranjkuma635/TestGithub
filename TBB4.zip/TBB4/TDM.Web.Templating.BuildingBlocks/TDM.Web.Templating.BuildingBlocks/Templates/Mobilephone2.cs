﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Xml;
using System.IO;
using Tridion.ContentManager;
using Tridion.ContentManager.CommunicationManagement;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Expression;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.Templating.Dreamweaver;
using Tridion;
using Tridion.ContentManager.ContentManagement.Fields;
using Tridion.Extensions.ContentManager.Templating;
using Publishing = Tridion.ContentManager.Publishing.Rendering;
using Tridion.ContentManager.ContentManagement;
using Tridion.ContentManager.Publishing.Rendering;
using System.Text.RegularExpressions;
using Emaar.Web.Tridion.System.Extensions;

namespace TDM.Web.Templating.BuildingBlocks.Templates
{
    [TcmTemplateTitle("Mobile Phone Shop List XML -2")]
    public class Mobilephone2 : TemplateBase
    {
        /// <summary>
        /// Transforms the current component.
        /// </summary>
        /// <param name="engine">The engine.</param>
        /// <param name="package">The package.</param>
        public override void Transform(Engine engine, Package package)
        {

            string s = string.Empty;

            string strfulldesc = string.Empty;

            base.Transform(engine, package);

            Engine m_Engine;
            m_Engine = engine;

            string strPubid = Page.ComponentPresentations[0].Component.Id.PublicationId.ToString();

            string strShop = "tcm:" + strPubid + "-2149-2";
            string strDine = "tcm:" + strPubid + "-2150-2";
            string strEnt = "tcm:" + strPubid + "-2151-2";
            string strStay = "tcm:" + strPubid + "-2152-2";

            OrganizationalItem ShopFolder = m_Engine.GetObject(strShop) as OrganizationalItem;
            OrganizationalItem DineFolder = m_Engine.GetObject(strDine) as OrganizationalItem;
            OrganizationalItem EntertatmentFolder = m_Engine.GetObject(strEnt) as OrganizationalItem;
            OrganizationalItem StayFolder = m_Engine.GetObject(strStay) as OrganizationalItem;

            using (StringWriter sw = new StringWriter())
            {
                using (XmlTextWriter xml = new XmlTextWriter(sw))
                {
                    xml.WriteStartElement("stores");


                    IList<Component> componentsshop = ShopFolder.Components(true);
                    foreach (Component c in componentsshop)
                    {
                        if (c.Schema.Title.Equals("TDM-Shop"))
                        {
                            xml.WriteStartElement("store");

                            xml.WriteAttributeString("storefrontcode", (c.StringValue("StoreFrontCode")));


                            Component Imag;
                            IList<Component> listimages = c.ComponentValues("galleryimage");
                            if (listimages != null)
                            {
                                if (listimages.Count > 0)
                                {
                                    Imag = listimages[0];
                                    if (Imag != null)
                                    {
                                        xml.WriteAttributeString("image", PublishBinary(Imag));
                                    }
                                }
                            }

                            xml.WriteEndElement();
                        }
                    }


                    xml.WriteEndElement();
                }
                Package.AddXml(Package.OutputName, sw.ToString());
            }



        }


    }
}
