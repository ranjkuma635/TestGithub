﻿using System;
using System.Collections.Generic;
using Tridion.ContentManager.Templating.Assembly;
using Emaar.Web.Tridion.System;

namespace Sega.Web.Templating.BuildingBlocks.Templates
{

    [TcmTemplateTitle("Page Variables")]
    public class PageVariables : PageVariablesTemplate
    {

        private List<String> mIncludeFields;
        private List<String> mInheritedFields;

        public PageVariables()
            : base()
        {


        }
    }
}
