﻿using System;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.Extensions.ContentManager.Templating;
using Emaar.Web.Tridion.System.Extensions;

namespace Sega.Web.Templating.BuildingBlocks.Templates
{
    [TcmTemplateTitle("Check for promotions")]
    public class Checkpromotions : TemplateBase
    {
        string strpromo = "No";

        public override void Transform(Engine engine, Package package)
        {
            base.Transform(engine, package);

            if (Page.ComponentPresentations.Count > 0)
            {
                if (Page.ComponentPresentations[0].Component.Schema.Title == "SEGA - Promotions")
                    strpromo = "Yes";
            }

            Package.AddString("Promotions", strpromo);

        }

    }

}
