﻿using System;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.ContentManagement.Fields;

using Tridion.ContentManager.ContentManagement;
using Tridion.Extensions.ContentManager.Templating;
using Emaar.Web.Tridion.System.Extensions;

namespace Sega.Web.Templating.BuildingBlocks.Templates
{
    [TcmTemplateTitle("Get Main Image")]
    public class Getmainimage : TemplateBase
    {

        string strText = string.Empty;

        public override void Transform(Engine engine, Package package)
        {
            base.Transform(engine, package);

            if (Page.Metadata != null)
            {
                ItemFields metadataField = new ItemFields(Page.Metadata, Page.MetadataSchema);
                ComponentLinkField mainimage = null;

                mainimage = (ComponentLinkField)metadataField["fmainimage"];
                Component Image = (Component)mainimage.Value;

                strText = metadataField["fheadertext"].ToString();

                if (string.IsNullOrEmpty(strText))
                {
                    if (Image != null)
                    {
                        Package.AddString("Mainimage", PublishBinary(Image));
                    }
                    else
                    {
                        Package.AddString("Mainimage", PublishCalloutsSG(Page.OrganizationalItem));
                    }
                }
                else
                {
                    Package.AddString("MainText", strText);
                }

            }
            else 
            {
                Package.AddString("Mainimage", PublishCalloutsSG(Page.OrganizationalItem));
            }

        }

        private string PublishCalloutsSG(OrganizationalItem oRecurSG )
        {
            OrganizationalItem oParentSG;

            string strImageValue = string.Empty;

            if (oRecurSG != null)
            {
                if (oRecurSG.Metadata != null)
                {
                    ItemFields metadataFields = new ItemFields(oRecurSG.Metadata, oRecurSG.MetadataSchema);
                    ComponentLinkField featureField = null;

                    featureField = (ComponentLinkField)metadataFields["fmainimage"];
                    Component Image = (Component)featureField.Value;

                    if (Image != null)
                    {
                        strImageValue = PublishBinary(Image); 

                    }
                    else
                    {
                        oParentSG = oRecurSG.OrganizationalItem;
                        PublishCalloutsSG(oParentSG);
                    }
                }
                else
                {
                    oParentSG = oRecurSG.OrganizationalItem;
                    PublishCalloutsSG(oParentSG);
                }
            }

            return strImageValue;

        }


    }
}
