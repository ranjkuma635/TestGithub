﻿using System;
using System.Collections.Generic;
using Tridion.ContentManager.Templating.Assembly;

namespace Sega.Web.Templating.BuildingBlocks.Templates
{
    [TcmTemplateTitle("Navigation XML")]
    public class Navigation : Emaar.Web.Tridion.System.Navigation
    {
        private List<String> mFields;
        private List<String> mLinks;

        public Navigation()
            : base()
        {
            mLinks = new List<String>();

            mLinks.Add("fcomponentlink");
        }

        protected override bool IncludeMetadata(String FieldName)
        {
            return true;
        }

        protected override bool AsComponentLink(String FieldName)
        {
            return mLinks.Contains(FieldName);
        }
    }
}
