﻿using System;
using Tridion.ContentManager.Templating.Assembly;
using Emaar.Web.Tridion.System;

namespace Sega.Web.Templating.BuildingBlocks.Templates
{
    [TcmTemplateTitle("Get Common Data")]
    public class CommonData : GetCommonData
    {

        public CommonData()
            : base()
        {

        }
    }
}
