﻿using System;
using System.Linq;

namespace TGV.Web.Templating.BuildingBlocks
{
    public static class Utility
    {
        public static string removeXHTMLtags(string html)
        {
            return html;
        }
    }
}
