﻿using System;
using System.Linq;
using Tridion.ContentManager.CommunicationManagement;
using Tridion.ContentManager.Templating;
using Tridion.Extensions.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Emaar.Web.Tridion.System.Extensions;

namespace TGV.Web.Templating.BuildingBlocks.Templates
{
    /// <summary>
    /// Class to Create the BreadCrumb
    /// </summary>
    [TcmTemplateTitle("Breadcrumb")]
    public class Breadcrumb : TemplateBase
    {
        /// <summary>
        /// Creates breadcrumb
        /// </summary>
        /// <param name="engine">Provides access to the Tridion System</param>
        /// <param name="package">Stack containing all output variables</param>
        public override void Transform(Engine engine, Package package)
        {
            Logger.Info("Inside Breadcrumb");
            base.Transform(engine, package);


            if (Page != null)
            {
                //string curSGPattern = "<a href=\"{0}\">{1}</a>";
                string curPagePattern = "{0}";
                string genPattern = "<a href=\"{0}\">{1}</a>  >  ";
                string noParentSGPattern = "<a href=\"{0}\">{1}</a>";
                string innerBreadcrumb = string.Empty;
                string breadcrumb = string.Empty;
                bool currentPage = true;

                if (String.IsNullOrEmpty(Page.StringMetaValue("ishomepage")) || (Page.StringMetaValue("ishomepage").Equals("Yes"))) return;

                StructureGroup sg = Page.OrganizationalItem as StructureGroup;
                string pageTitle = Page.Title;

                breadcrumb = "<div id=\"breadcrumb\">{0}</div>";

                while (sg != null)
                {
                    if (currentPage && sg.OrganizationalItem != null)
                    {
                        innerBreadcrumb = String.Format(curPagePattern, GetTitle(sg)) + innerBreadcrumb;
                        currentPage = false;
                    }
                    else if (currentPage && sg.OrganizationalItem == null)
                    {
                        //For the pages under home SG
                        //innerBreadcrumb = String.Format(genPattern, String.Format("{0}{1}", sg.PublishLocationUrl, "/index.aspx"), GetTitle(sg)) + Page.Title;
                        innerBreadcrumb = String.Format(noParentSGPattern, String.Format("{0}{1}", sg.PublishLocationUrl, "/index.aspx"), GetTitle(sg)) + innerBreadcrumb;
                        currentPage = false;
                    }
                    else
                    {
                        innerBreadcrumb = String.Format(genPattern, String.Format("{0}{1}", sg.PublishLocationUrl, "/index.aspx"), GetTitle(sg)) + innerBreadcrumb;
                    }
                    sg = sg.OrganizationalItem as StructureGroup;
                }

                breadcrumb = String.Format(breadcrumb, innerBreadcrumb);

                Package.PushItem("breadcrumb", package.CreateStringItem(ContentType.Html, breadcrumb));
            }

        }
        private string GetTitle(StructureGroup SG)
        {
            string sgTitle = SG.Title;

            if (sgTitle.Contains('.'))
            {
                sgTitle = sgTitle.Split('.')[1].Trim();
            }

            SG = SG.OrganizationalItem as StructureGroup;

            if (SG == null) sgTitle = "Home";

            return sgTitle;
        }


    }
}
