﻿using System;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.CommunicationManagement;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.ContentManagement;
using Tridion.ContentManager.ContentManagement.Fields;
using System.IO;
using System.IO.Compression;
using Tridion.Extensions.ContentManager.Templating;

namespace TGV.Web.Templating.BuildingBlocks.Templates
{
    /// 
    /// This TBB takes the component that is being published and places it in a
    /// specific structure group based on a TCM number or on WebDav path.
    /// 
    /// 
    [TcmTemplateTitle("Publish Dynamic Multimedia Item")]
    public class PublishDynamicMultimediaItem : TemplateBase
    {
        public override void Transform(Engine engine, Package package)
        {
            // Declair the structure group that will hold the file
            StructureGroup sg = null;

            // Get the component from the package
            Component component = engine.GetObject(package.GetByName(Package.ComponentName).GetValue("ID")) as Component;

            Logger.Debug(String.Format("Publishing component: {0}", component));

            // Get the metadata fields from the folder to see if there is a specific structure group that needs the file, 
            // if the metafields are not tagged...skip
            string sguri = null;

            try
            {
                // Create the ItemFields to store the meta
                ItemFields folderMetaFields = new ItemFields(component.OrganizationalItem.Metadata, component.OrganizationalItem.MetadataSchema);

                // Pull out the structure group URI for pathing
                sguri = folderMetaFields["sguri"].ToString();
            }
            catch
            {
                //ignore
                Logger.Info("Structure Group URI is not specified, therefore proceeding with trying to publish to SG that mirror's the component's folder path");
            }

            Logger.Debug(String.Format("sguri: {0}", sguri));

            // IF the sguri is null or empty, try to WebDav path the item
            if (String.IsNullOrEmpty(sguri))
            {
                // Get the WebDav path of the component
                string compFolderWebDavUrl = component.OrganizationalItem.WebDavUrl;

                //Get the folder's relative path excluding "Building%20Blocks/Content"
                int indexOfRootFolder = compFolderWebDavUrl.IndexOf("Building%20Blocks/Content");
                string firstPath = compFolderWebDavUrl.Substring(0, indexOfRootFolder);
                string relativeFolderPath = compFolderWebDavUrl.Replace(firstPath + "Building%20Blocks/Content", string.Empty);

                // Get the publicaiton of the component
                Publication pub = component.ContextRepository as Publication;

                // Get the root structure group of the publiction for pathing
                string pubSGWebDavUrl = pub.RootStructureGroup.WebDavUrl;

                // Propend the folder path of the component to try and make the path
                string publishSGWebDavUrl = pubSGWebDavUrl + relativeFolderPath;

                // If the structrue group comes back null, throw an error that the WebDav path for publishing does not exist
                sg = engine.GetObject(publishSGWebDavUrl) as StructureGroup;

                if (sg == null)
                {
                    throw new InvalidDataException("The structure group mirroring the asset folder does not exist.  SG=" + publishSGWebDavUrl);
                }
            }
            else
            {
                // If a sguri was specified, try and get the structure group and catch if the sguri is not valid
                try
                {
                    sg = engine.GetObject(sguri) as StructureGroup;
                }
                catch (Exception e)
                {
                    throw new InvalidDataException("The structure group listed in the fodler metadata is not valid.  SG=" + sguri, e);
                }
            }

            // Push the structure group WebDav url to the package for safe keeping
            package.PushItem("sg", package.CreateStringItem(ContentType.Text, sg.WebDavUrl));

            // Create the template object
            Template template = engine.PublishingContext.ResolvedItem.Template;

            // Create the memory byte stream of the component
            MemoryStream ms = new MemoryStream();
            component.BinaryContent.WriteToStream(ms);

            /////////////////////////////////////////////////////////////////////
            //Not needed as of now//

            MemoryStream outMS = new MemoryStream();


            using (GZipStream Decompress = new GZipStream(ms, CompressionMode.Decompress))
            {
                // Copy the decompression stream 
                // into the output file.
                Decompress.CopyTo(outMS);

                Logger.Info("ms.Length: " + ms.Length);
                Logger.Info("outMS.Length: " + outMS.Length);
                Logger.Info("outMS.CanRead: " + outMS.CanRead);

            }

            /////////////////////////////////////////////////////////////////////



            // Get the file name of the component
            string filename = component.BinaryContent.Filename;

            //Strip off the file system path and only get the filename
            if (filename.Contains(@"\"))
            {
                int pos = filename.LastIndexOf(@"\");
                filename = filename.Substring(pos + 1);
            }

            //publish the binary under the variant ID of this template so that it doesn't clash with any binaries published for the
            //same multimedia component by a DWT.
            engine.AddBinary(engine.LocalizeUri(component.Id), engine.LocalizeUri(template.Id), engine.LocalizeUri(sg.Id), ms.ToArray(), filename);
        }
    }
}