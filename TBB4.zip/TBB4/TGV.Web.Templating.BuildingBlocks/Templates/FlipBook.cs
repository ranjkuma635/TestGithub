﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Tridion.ContentManager.CommunicationManagement;
using Tridion.ContentManager.Publishing;
using Tridion.ContentManager.Templating;
using Tridion.Extensions.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.ContentManagement;
using Emaar.Web.Tridion.System.Extensions;
using System.Xml;
using System.IO;
using Tridion.ContentManager;
using Tridion.ContentManager.ContentManagement.Fields;
using System.Text.RegularExpressions;
using Tridion.ContentManager.Publishing.Rendering;


namespace TGV.Web.Templating.BuildingBlocks.Templates
{
    /// <summary>
    /// Class to Publish a Dynamic Component
    /// </summary>
    [TcmTemplateTitle("FlipBook")]
    public class FlipBook : TemplateBase
    {
        /// <summary>
        /// Creates a DCP XML
        /// </summary>
        /// <param name="engine">Provides access to the Tridion System</param>
        /// <param name="package">Stack containing all output variables</param>
        public override void Transform(Engine engine, Package package)
        {
            base.Transform(engine, package);
            Component component = engine.GetObject(package.GetByType(ContentType.Component).GetAsSource().GetValue("ID")) as Component;


                    if (Component != null)
                    {
                        switch (Component.Schema.Title.Split('-')[1].Trim())
                        {
                            case "Flip Book":
                                createFlipBook(component, xml);
                                break;                            
                            default:
                                createDCP(component, xml);
                                break;
                        }
                    }
                    Package.AddXml(Package.OutputName, sw.ToString());
        }

      


        /// <summary>
        /// Renders Ads contents in xml format
        /// </summary>
        /// <param name="component">Provides access to the Tridion Component</param>
        /// <param name="xml">Object of Xml text writer</param>
        private void createFlipBook(Component component, XmlTextWriter xml)
        {
            xml.WriteStartElement("ad");
            xml.WriteAttributeString("uri", Component.Id);
            xml.WriteAttributeString("id", Component.Id.ToString().Split('-')[1]);
            xml.WriteAttributeString("schema", Component.Schema.Title.Split('-')[1].Trim());
            xml.WriteAttributeString("title", Component.Title);
            ItemField desc = null;

            ItemFields fields = new ItemFields(component.Content, component.Schema);
            foreach (ItemField field in fields)
            {
                if (field.Name.ToLower().Equals("desc"))
                {
                    desc = field;
                }
                else if (field.Name.ToLower().Equals("ads"))
                {
                    EmbeddedSchemaField ads = field as EmbeddedSchemaField;
                    foreach (ItemFields ad in ads.Values)
                    {
                        foreach (ItemField emAd in ad)
                        {
                            EmbeddedSchemaField emAdFields = emAd as EmbeddedSchemaField;
                            foreach (ItemFields adFields in emAdFields.Values)
                            {
                                xml.WriteStartElement(emAd.Name);
                                if (desc != null)
                                {
                                    TextField description = desc as TextField;
                                    if (description.Value != null)
                                        xml.WriteAttributeString("desc", description.Value);

                                }
                                foreach (ItemField adField in adFields)
                                {
                                    if (adField.Name.Equals("image"))
                                    {
                                        MultimediaLinkField image = adField as MultimediaLinkField;
                                        if (image.Value != null)
                                            xml.WriteAttributeString("adimage", PublishBinary(image.Value));
                                        string altText = image.Value.StringMetaValue("alttext");
                                        xml.WriteAttributeString("alttext", altText);
                                    }

                                    if (adField.Name.Equals("externallink"))
                                    {
                                        TextField externallink = adField as TextField;
                                        if (!String.IsNullOrEmpty(externallink.Value))
                                            xml.WriteAttributeString("externallink", externallink.Value);
                                    }

                                    if (adField.Name.Equals("componentlink"))
                                    {
                                        ComponentLinkField componentlink = adField as ComponentLinkField;
                                        if (componentlink.Value != null)
                                        {
                                            xml.WriteAttributeString("componentlink", componentlink.Value.Id.ToString());
                                            xml.WriteAttributeString("linkschema", componentlink.Value.Schema.Title.Split('-')[1].Trim());
                                        }
                                    }

                                    if (adField.Name.Equals("multimedialink"))
                                    {
                                        MultimediaLinkField multimedialink = adField as MultimediaLinkField;
                                        if (multimedialink.Value != null)
                                            xml.WriteAttributeString("multimedialink", PublishBinary(multimedialink.Value));
                                    }

                                }
                                xml.WriteEndElement();
                            }
                        }
                    }
                }
            }
            xml.WriteEndElement();
        }


       
        /// <summary>
        /// Renders Schema contents in xml format
        /// </summary>
        /// <param name="component">Provides access to the Tridion Component</param>
        /// <param name="xml">Object of Xml text writer</param>
        private void createDCP(Component component, XmlTextWriter xml)
        {
            xml.WriteStartElement("item");
            xml.WriteAttributeString("uri", Component.Id);
            xml.WriteAttributeString("id", Component.Id.ToString().Split('-')[1]);
            xml.WriteAttributeString("schema", Component.Schema.Title.Split('-')[1].Trim());

            if (!string.IsNullOrEmpty(Component.StringValue("title")))
                xml.WriteAttributeString("title", Component.StringValue("title"));

            if (Component.DateMetaValue("date") != null)
            {
                DateTime date = new DateTime();
                date = DateTime.Parse(Component.DateMetaValue("date").ToString());
                string convDate = date.ToString("yyyyMMdd");
                string convDateDetail = date.ToString("yyyy-MM-dd ddd");
                string fulldate = date.ToString("dd MMMM yyyy");
                xml.WriteAttributeString("date", convDate);
                //Detail date attribute
                xml.WriteAttributeString("detaildate", convDateDetail);
                //Full Detail date attribute
                xml.WriteAttributeString("fulldate", fulldate);

                //Year of the gallery
                string year = date.ToString("yyyy");
                xml.WriteAttributeString("year", year);

            }

            if (!string.IsNullOrEmpty(Component.StringMetaValue("itemcategory")))
                xml.WriteAttributeString("itemcategory", Component.StringMetaValue("itemcategory"));

            if (Component.StringMetaValues("displayin") != null)
            {
                IList<string> displayinList = Component.StringMetaValues("displayin");
                string displayinAttr = string.Empty;
                foreach (string displayin in displayinList)
                {
                    displayinAttr = displayin + " " + displayinAttr;
                }
                xml.WriteAttributeString("displayin", displayinAttr);
            }

            if (Component.StringMetaValue("nodetails") != null)
            {
                xml.WriteAttributeString("nodetails", Component.StringMetaValue("nodetails"));
            }

            if (!string.IsNullOrEmpty(Component.StringValue("bannertext")))
                xml.WriteElementString("bannertext", getHtml(Component.StringValue("bannertext")));

            if (!string.IsNullOrEmpty(Component.StringValue("slidertext")))
                xml.WriteElementString("slidertext", getHtml(Component.StringValue("slidertext")));

            if (!string.IsNullOrEmpty(Component.StringValue("summary")))
                xml.WriteElementString("summary", getHtml(Component.StringValue("summary")));

            if (!string.IsNullOrEmpty(Component.StringValue("description")))
                xml.WriteElementString("description", replaceHref(Component.StringValue("description")));

            //Redirect Component for other items in slider kit
            if (Component.ComponentMetaValue("redirectcomp") != null)
            {
                Component redirectcomp = Component.ComponentMetaValue("redirectcomp");
                xml.WriteElementString("redirectcomp", redirectcomp.Id);
            }
            if (Component.ComponentMetaValue("redirectmultimedia") != null)
            {
                Component redirectmultimedia = Component.ComponentMetaValue("redirectmultimedia");
                xml.WriteElementString("redirectmultimedia", PublishBinary(redirectmultimedia));
            }

            if (Component.ExternalLinkMetaValue("externallink") != null)
            {
                string redirectexternal = Component.ExternalLinkMetaValue("externallink");
                xml.WriteElementString("redirectexternal", redirectexternal);
            }

            if (Component.ComponentMetaValue("smallbinaryimage") != null)
            {
                Component smallbinaryimage = Component.ComponentMetaValue("smallbinaryimage");
                xml.WriteElementString("leadimagesmall", PublishBinary(smallbinaryimage));
            }

            if (Component.ComponentMetaValue("largebinaryimage") != null)
            {
                Component largebinaryimage = Component.ComponentMetaValue("largebinaryimage");
                xml.WriteElementString("leadimagelarge", PublishBinary(largebinaryimage));
            }

            if (Component.ComponentValue("bannerimage") != null)
            {
                Component bannerimage = Component.ComponentValue("bannerimage");
                xml.WriteElementString("bannerimage", PublishBinary(bannerimage));
            }

            if (Component.ComponentValue("summaryimage") != null)
            {
                Component summaryImage = Component.ComponentValue("summaryimage");
                xml.WriteElementString("summaryimage", PublishBinary(summaryImage));
            }

            //Gallery images and thumbnails in separate nodes
            if (Component.ComponentValues("images") != null)
            {
                IList<Component> multimediaLinks = Component.ComponentValues("images");
                xml.WriteStartElement("images");
                foreach (Component multimediaLink in multimediaLinks)
                {
                    xml.WriteStartElement("image");
                    xml.WriteAttributeString("src", PublishBinary(multimediaLink));
                    xml.WriteAttributeString("thumb", GenerateThumbnail(multimediaLink, "thumb", 82, 82));
                    xml.WriteEndElement();
                }
                xml.WriteEndElement();

            }
            xml.WriteEndElement();
        }

        private string getHtml(string html)
        {
            return Utility.removeXHTMLtags(html);
        }


        public Binary PublishBinary(Engine engine, Package package, Component multimediaComponent)
        {

            BinaryContent binaryContent = multimediaComponent.BinaryContent;
            Session session = engine.GetSession();
            TcmUri structureGroupUri = new TcmUri(8575, ItemType.StructureGroup, 137);
            StructureGroup structureGroup = new StructureGroup(structureGroupUri, session);

            Binary binary = engine.PublishingContext.RenderedItem.AddBinary(multimediaComponent, structureGroup, Regex.Replace(binaryContent.Filename, "\\W", string.Empty));

            return binary;
        }

    }
}
