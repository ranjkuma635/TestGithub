﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Tridion.ContentManager.Templating.Assembly;

namespace TGV.Web.Templating.BuildingBlocks.Templates
{
    [TcmTemplateTitle("Navigation XML")]
    class Navigation:Emaar.Web.Tridion.System.Navigation
    {
        private List<String> mFields;
        private List<String> mLinks;

        public Navigation()
            : base()
        {

        }
        protected override bool IncludeMetadata(string FieldName)
        {
            return true;
        }
        protected override bool AsComponentLink(string FieldName)
        {
            return true;
        }


    }
}
