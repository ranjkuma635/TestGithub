﻿using Emaar.Web.Tridion.System.Extensions;
using System.Collections.Generic;
using Tridion.ContentManager.CommunicationManagement;
using Tridion.ContentManager.ContentManagement;
using Tridion.ContentManager.Publishing.Rendering;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.Extensions.ContentManager.Templating;


namespace TGV.Web.Templating.BuildingBlocks.Templates
{
    /// <summary>
    /// Class to Create the BreadCrumb
    /// </summary>

    [TcmTemplateTitle("Content Page")]
    public class ContentPage : TemplateBase
    {

        public override void Transform(Engine engine, Package package)
        {
            base.Transform(engine, package);
            string SEOImage = string.Empty;
            string SEODescription = string.Empty;
            string SEOKeywords = string.Empty;
            
            if (((ICollection<Tridion.ContentManager.CommunicationManagement.ComponentPresentation>)Page.ComponentPresentations).Count > 0)
            {
                Component component = this.Page.ComponentPresentations[0].Component;

                //pageTitle = Extensions.StringValue(itemFields, "fPageTitle");
                SEODescription = component.StringMetaValue("seodescription");
                SEOKeywords = component.StringMetaValue("seokeywords");
                //SEOImage = this.GenerateThumbnail(Extensions.ComponentValue(itemFields, "fSEOImage"), "seo", 100, 100);

                //Extensions.AddString(package, "PageTitle", pageTitle);
                Extensions.AddString(package, "SEODescription", SEODescription);
                Extensions.AddString(package, "SEOKeywords", SEOKeywords);                
                //Extensions.AddString(package, "SEOImage", SEOImage);
            }

        }

        private Page GetPage(Engine engine, Package package)
        {
            this.CheckInitialized();
            RenderContext renderContext = engine.PublishingContext.RenderContext;
            if (renderContext != null)
            {
                Page page = renderContext.ContextItem as Page;
                if (page != null)
                    return page;
            }
            Item byType = package.GetByType((ContentType)ContentType.Page);
            if (byType != null)
                return (Page)engine.GetObject(byType.GetAsSource().GetValue("ID"));
            else
                return (Page)null;
        }
    }
}