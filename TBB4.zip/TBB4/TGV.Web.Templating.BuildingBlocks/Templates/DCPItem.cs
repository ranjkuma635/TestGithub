﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Tridion.ContentManager.CommunicationManagement;
using Tridion.ContentManager.Publishing;
using Tridion.ContentManager.Templating;
using Tridion.Extensions.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.ContentManagement;
using Emaar.Web.Tridion.System.Extensions;
using System.Xml;
using System.IO;
using Tridion.ContentManager;
using Tridion.ContentManager.ContentManagement.Fields;
using System.Text.RegularExpressions;


namespace TGV.Web.Templating.BuildingBlocks.Templates
{
    /// <summary>
    /// Class to Publish a Dynamic Component
    /// </summary>
    [TcmTemplateTitle("DCPItem")]
    public class DCPItem : TemplateBase
    {
        /// <summary>
        /// Creates a DCP XML
        /// </summary>
        /// <param name="engine">Provides access to the Tridion System</param>
        /// <param name="package">Stack containing all output variables</param>
        public override void Transform(Engine engine, Package package)
        {
            base.Transform(engine, package);
            Component component = engine.GetObject(package.GetByType(ContentType.Component).GetAsSource().GetValue("ID")) as Component;


            using (StringWriter sw = new StringWriter())
            {
                using (XmlTextWriter xml = new XmlTextWriter(sw))
                {
                    if (Component != null)
                    {
                        switch (Component.Schema.Title.Split('-')[1].Trim())
                        {
                            case "FAQ":
                                createFAQ(component, xml);
                                break;
                            case "Gallery":
                                createGallery(component, xml);
                                break;
                            case "Download":
                                createMultimedia(component, xml);
                                break;
                            case "Ads":
                                createAds(component, xml);
                                break;
                            default:
                                createDCP(component, xml);
                                break;
                        }
                    }
                    Package.AddXml(Package.OutputName, sw.ToString());
                }

            }



        }

        /// <summary>
        /// replaceHref
        /// </summary>
        /// <param name="string">String in which links to be resolved</param>
        /// <param name="xml">Object of Xml text writer</param>
        private string replaceHref(string fieldText)
        {
            string pattern = "href=\"(tcm:.*?)\"";
            MatchCollection collection = Regex.Matches(fieldText, pattern);
            foreach (Match match in collection)
            {
                string matchedString = match.Groups[1].Value;
                //string matchedStringwithAttr = match.Groups[0].Value;
                TcmUri tcmId = new TcmUri(matchedString + "-16");
                Component component = GetComponent(tcmId);
                if (component.Schema.Purpose.Equals(SchemaPurpose.Multimedia))
                {
                    string publishedPath = PublishBinary(component);
                    string fileName = component.BinaryContent.Filename;
                    string fileType = fileName.Substring(fileName.LastIndexOf('.') + 1, fileName.Length - fileName.LastIndexOf('.') - 1);
                    switch (fileType.ToLower())
                    {
                        case "jpeg":
                        case "gif":
                        case "jpg":
                        case "png":
                            fieldText = fieldText.Replace(matchedString, publishedPath);
                            fieldText = fieldText.Replace("xlink:href", "src");
                            break;
                        case "doc":
                        case "docx":
                        case "pdf":
                            fieldText = fieldText.Replace(matchedString, publishedPath);
                            fieldText = fieldText.Replace("xlink:href", "href");
                            break;
                        default: fieldText = fieldText.Replace(matchedString, publishedPath);
                            fieldText = fieldText.Replace("xlink:href", "href"); break;
                    }
                }
            }
            return fieldText;
        }


        /// <summary>
        /// Renders Ads contents in xml format
        /// </summary>
        /// <param name="component">Provides access to the Tridion Component</param>
        /// <param name="xml">Object of Xml text writer</param>
        private void createAds(Component component, XmlTextWriter xml)
        {
            xml.WriteStartElement("ad");
            xml.WriteAttributeString("uri", Component.Id);
            xml.WriteAttributeString("id", Component.Id.ToString().Split('-')[1]);
            xml.WriteAttributeString("schema", Component.Schema.Title.Split('-')[1].Trim());
            xml.WriteAttributeString("title", Component.Title);
            ItemField desc = null;

            ItemFields fields = new ItemFields(component.Content, component.Schema);
            foreach (ItemField field in fields)
            {
                if (field.Name.ToLower().Equals("desc"))
                {
                    desc = field;
                }
                else if (field.Name.ToLower().Equals("ads"))
                {
                    EmbeddedSchemaField ads = field as EmbeddedSchemaField;
                    foreach (ItemFields ad in ads.Values)
                    {
                        foreach (ItemField emAd in ad)
                        {
                            EmbeddedSchemaField emAdFields = emAd as EmbeddedSchemaField;
                            foreach (ItemFields adFields in emAdFields.Values)
                            {
                                xml.WriteStartElement(emAd.Name);
                                if (desc != null)
                                {
                                    TextField description = desc as TextField;
                                    if (description.Value != null)
                                        xml.WriteAttributeString("desc", description.Value);

                                }
                                foreach (ItemField adField in adFields)
                                {
                                    if (adField.Name.Equals("image"))
                                    {
                                        MultimediaLinkField image = adField as MultimediaLinkField;
                                        if (image.Value != null)
                                            xml.WriteAttributeString("adimage", PublishBinary(image.Value));
                                        string altText = image.Value.StringMetaValue("alttext");
                                        xml.WriteAttributeString("alttext", altText);
                                    }

                                    if (adField.Name.Equals("externallink"))
                                    {
                                        TextField externallink = adField as TextField;
                                        if (!String.IsNullOrEmpty(externallink.Value))
                                            xml.WriteAttributeString("externallink", externallink.Value);
                                    }

                                    if (adField.Name.Equals("componentlink"))
                                    {
                                        ComponentLinkField componentlink = adField as ComponentLinkField;
                                        if (componentlink.Value != null)
                                        {
                                            xml.WriteAttributeString("componentlink", componentlink.Value.Id.ToString());
                                            xml.WriteAttributeString("linkschema", componentlink.Value.Schema.Title.Split('-')[1].Trim());
                                        }
                                    }

                                    if (adField.Name.Equals("multimedialink"))
                                    {
                                        MultimediaLinkField multimedialink = adField as MultimediaLinkField;
                                        if (multimedialink.Value != null)
                                            xml.WriteAttributeString("multimedialink", PublishBinary(multimedialink.Value));
                                    }

                                }
                                xml.WriteEndElement();
                            }
                        }
                    }
                }
            }
            xml.WriteEndElement();
        }


        /// <summary>
        /// Renders FAQ contents in xml format
        /// </summary>
        /// <param name="component">Provides access to the Tridion Component</param>
        /// <param name="xml">Object of Xml text writer</param>
        private void createFAQ(Component component, XmlTextWriter xml)
        {
            xml.WriteStartElement("faqdata");
            xml.WriteAttributeString("uri", Component.Id);
            xml.WriteAttributeString("id", Component.Id.ToString().Split('-')[1]);
            xml.WriteAttributeString("schema", Component.Schema.Title.Split('-')[1].Trim());
            xml.WriteAttributeString("faqtitle", Component.Title);

            ItemFields fields = new ItemFields(component.Content, component.Schema);
            foreach (ItemField field in fields)
            {
                if (field.Name.Equals("activeimage"))
                {
                    ComponentLinkField cLinkField = field as ComponentLinkField;
                    xml.WriteElementString("activeimage", PublishBinary(cLinkField.Value));
                }

                if (field.Name.Equals("inactiveimage"))
                {
                    ComponentLinkField cLinkField = field as ComponentLinkField;
                    xml.WriteElementString("inactiveimage", PublishBinary(cLinkField.Value));
                }

                if (field.Name.Equals("class"))
                {
                    TextField classname = field as TextField;
                    xml.WriteElementString("classname", classname.Value);
                }

                if (field.Name.Equals("data"))
                {
                    EmbeddedSchemaField emFields = field as EmbeddedSchemaField;
                    foreach (ItemFields emField in emFields.Values)
                    {
                        foreach (ItemField faqdata in emField)
                        {
                            if (faqdata.Name.Equals("header"))
                            {
                                TextField header = faqdata as TextField;
                                xml.WriteElementString("header", header.Value);
                            }

                            if (faqdata.Name.Equals("headertitle"))
                            {
                                TextField headertitle = faqdata as TextField;
                                xml.WriteElementString("headertitle", headertitle.Value);
                            }

                            if (faqdata.Name.Equals("faqs"))
                            {
                                EmbeddedSchemaField faqs = faqdata as EmbeddedSchemaField;
                                foreach (ItemFields faq in faqs.Values)
                                {
                                    xml.WriteStartElement("faq");
                                    foreach (ItemField faqItem in faq)
                                    {
                                        if (faqItem.Name.Equals("question"))
                                        {
                                            TextField question = faqItem as TextField;
                                            xml.WriteElementString("question", question.Value);
                                        }

                                        if (faqItem.Name.Equals("answer"))
                                        {
                                            TextField answer = faqItem as TextField;
                                            xml.WriteElementString("answer", replaceHref(answer.Value));
                                        }
                                    }
                                    xml.WriteEndElement();
                                }
                            }
                        }
                    }
                }
            }
            xml.WriteEndElement();
        }

        /// <summary>
        /// Renders Photo Gallery in xml format
        /// </summary>
        /// <param name="component">Provides access to the Tridion Component</param>
        /// <param name="xml">Object of Xml text writer</param>
        private void createGallery(Component component, XmlTextWriter xml)
        {
            try
            {
                xml.WriteStartElement("galleryitem");
                xml.WriteAttributeString("uri", Component.Id);
                xml.WriteAttributeString("id", Component.Id.ToString().Split('-')[1]);
                xml.WriteAttributeString("schema", Component.Schema.Title.Split('-')[1].Trim());

                ItemFields metaFields = new ItemFields(Component.Metadata, Component.Schema);
                foreach (ItemField metaField in metaFields)
                {
                    if (metaField.Name.Equals("date"))
                    {
                        DateTime date = DateTime.Parse((metaField as DateField).ToString());
                        string convDate = date.ToString("yyyyMMdd");
                        string convDateDetail = date.ToString("yyyy-MM-dd ddd");
                        string fulldate = date.ToString("dd MMMM yyyy");
                        string year = date.ToString("yyyy");
                        //Date for sorting
                        xml.WriteAttributeString("date", convDate);
                        //Detail date attribute
                        xml.WriteAttributeString("detaildate", convDateDetail);
                        //Full date
                        xml.WriteAttributeString("fulldate", fulldate);
                        //Year of the gallery
                        xml.WriteAttributeString("year", year);
                    }
                    if (metaField.Name.Equals("gallerytype"))
                    {
                        TextField galleryType = metaField as TextField;
                        //Gallery type attribute
                        xml.WriteAttributeString("gallerytype", galleryType.Value);
                    }
                }


                ItemFields fields = new ItemFields(component.Content, component.Schema);
                foreach (ItemField field in fields)
                {
                    if (field.Name.Equals("menuname"))
                    {
                        TextField menuname = field as TextField;
                        xml.WriteElementString("menuname", menuname.Value);
                    }

                    if (field.Name.Equals("title"))
                    {
                        TextField title = field as TextField;
                        xml.WriteElementString("title", title.Value);
                    }

                    if (field.Name.Equals("description"))
                    {
                        TextField description = field as TextField;
                        xml.WriteElementString("description", description.Value);
                    }

                    if (field.Name.Equals("flickr"))
                    {
                        TextField flickr = field as TextField;
                        xml.WriteElementString("flickr", flickr.Value);
                    }

                    if (field.Name.Equals("images"))
                    {
                        ComponentLinkField images = field as ComponentLinkField;

                        foreach (Component image in images.Values)
                        {
                            xml.WriteStartElement("images");

                            xml.WriteElementString("image", PublishBinary(image));
                            xml.WriteElementString("thumb_image", GenerateThumbnail(image, "thumb", 82, 82));
                            xml.WriteEndElement();
                        }
                    }

                    if (field.Name.Equals("videourl"))
                    {
                        TextField videourl = field as TextField;
                        string uniqueId = string.Empty;
                        string[] pattern = null;
                        if (videourl.Values != null)
                        {
                            foreach (string url in videourl.Values)
                            {
                                if (url.Contains("http://"))
                                {
                                    pattern = new String[] { "http://www.youtube.com/watch?v=" };
                                }
                                else if (url.Contains("https://"))
                                {
                                    pattern = new String[] { "https://www.youtube.com/watch?v=" };
                                }

                                uniqueId = url.Split(pattern, StringSplitOptions.None)[1];
                                xml.WriteElementString("videourl", uniqueId);
                            }
                        }

                    }

                    if (field.Name.Equals("footertext"))
                    {
                        TextField footertext = field as TextField;
                        xml.WriteElementString("footertext", replaceHref(footertext.Value));
                    }
                }

                xml.WriteEndElement();
            }
            catch (Exception ex)
            {
                Logger.Error("Error occured in Create Gallery method: " + ex.Message + "--" + ex.StackTrace);
            }
        }

        /// <summary>
        /// Renders Multimedia in xml format for Forms and Factsheets purpose
        /// </summary>
        /// <param name="component">Provides access to the Tridion Component</param>
        /// <param name="xml">Object of Xml text writer</param>
        private void createMultimedia(Component component, XmlTextWriter xml)
        {
            xml.WriteStartElement("multimediaitem");
            xml.WriteAttributeString("uri", Component.Id);
            xml.WriteAttributeString("id", Component.Id.ToString().Split('-')[1]);
            xml.WriteAttributeString("schema", Component.Schema.Title.Split('-')[1].Trim());

            //Write the organization folder name
            xml.WriteAttributeString("parentfolder", Component.OrganizationalItem.Title);

            ItemFields metaFields = new ItemFields(Component.Metadata, Component.Schema);
            foreach (ItemField metaField in metaFields)
            {
                if (metaField.Name.Equals("title"))
                {
                    TextField title = metaField as TextField;
                    //Gallery type attribute
                    xml.WriteElementString("title", title.Value);
                }
                if (metaField.Name.Equals("simpletitle"))
                {
                    TextField simpletitle = metaField as TextField;
                    //Multimedia type attribute
                    xml.WriteElementString("simpletitle", simpletitle.Value);
                }
                if (metaField.Name.Equals("sortorder"))
                {
                    NumberField sortorder = metaField as NumberField;
                    //Sort order attribute
                    xml.WriteElementString("sortorder", sortorder.Value.ToString());
                }
                if (metaField.Name.Equals("thumb"))
                {
                    ComponentLinkField thumb = metaField as ComponentLinkField;

                    xml.WriteStartElement("thumbnail");

                    ItemFields thumbMetaFields = new ItemFields(thumb.Value.Metadata, thumb.Value.Schema);

                    foreach (ItemField thumbMetaField in thumbMetaFields)
                    {
                        if (thumbMetaField.Name.Equals("alttext"))
                        {
                            TextField altText = thumbMetaField as TextField;
                            xml.WriteAttributeString("alttext", altText.Value);
                        }
                    }

                    xml.WriteElementString("publishpath", PublishBinary(thumb.Value));

                    xml.WriteEndElement();
                }

                if (metaField.Name.Equals("date"))
                {
                    DateField dateField = metaField as DateField;
                    DateTime date = dateField.Value;

                    string convDate = date.ToString("yyyyMMdd");
                    string convDateDetail = date.ToString("yyyy-MM-dd ddd");
                    string fulldate = date.ToString("dd MMMM yyyy");

                    xml.WriteStartElement("dateinfo");

                    xml.WriteAttributeString("date", convDate);
                    //Detail date attribute
                    xml.WriteAttributeString("detaildate", convDateDetail);
                    //Full Detail date attribute
                    xml.WriteAttributeString("fulldate", fulldate);

                    //Year of the gallery
                    string year = date.ToString("yyyy");
                    xml.WriteAttributeString("year", year);

                    xml.WriteEndElement();

                }
            }

            //Publish the same Multimedia itself
            xml.WriteElementString("multimediapath", PublishBinary(Component));

            xml.WriteEndElement();
        }

        /// <summary>
        /// Renders Schema contents in xml format
        /// </summary>
        /// <param name="component">Provides access to the Tridion Component</param>
        /// <param name="xml">Object of Xml text writer</param>
        private void createDCP(Component component, XmlTextWriter xml)
        {
            xml.WriteStartElement("item");
            xml.WriteAttributeString("uri", Component.Id);
            xml.WriteAttributeString("id", Component.Id.ToString().Split('-')[1]);
            xml.WriteAttributeString("schema", Component.Schema.Title.Split('-')[1].Trim());

            if (!string.IsNullOrEmpty(Component.StringValue("title")))
                xml.WriteAttributeString("title", Component.StringValue("title"));

            if (Component.DateMetaValue("date") != null)
            {
                DateTime date = new DateTime();
                date = DateTime.Parse(Component.DateMetaValue("date").ToString());
                string convDate = date.ToString("yyyyMMdd");
                string convDateDetail = date.ToString("yyyy-MM-dd ddd");
                string fulldate = date.ToString("dd MMMM yyyy");
                xml.WriteAttributeString("date", convDate);
                //Detail date attribute
                xml.WriteAttributeString("detaildate", convDateDetail);
                //Full Detail date attribute
                xml.WriteAttributeString("fulldate", fulldate);

                //Year of the gallery
                string year = date.ToString("yyyy");
                xml.WriteAttributeString("year", year);

            }

            if (!string.IsNullOrEmpty(Component.StringMetaValue("itemcategory")))
                xml.WriteAttributeString("itemcategory", Component.StringMetaValue("itemcategory"));

            if (Component.StringMetaValues("displayin") != null)
            {
                IList<string> displayinList = Component.StringMetaValues("displayin");
                string displayinAttr = string.Empty;
                foreach (string displayin in displayinList)
                {
                    displayinAttr = displayin + " " + displayinAttr;
                }
                xml.WriteAttributeString("displayin", displayinAttr);
            }

            if (Component.StringMetaValue("nodetails") != null)
            {
                xml.WriteAttributeString("nodetails", Component.StringMetaValue("nodetails"));
            }

            if (!string.IsNullOrEmpty(Component.StringValue("bannertext")))
                xml.WriteElementString("bannertext", Component.StringValue("bannertext"));

            if (!string.IsNullOrEmpty(Component.StringValue("slidertext")))
                xml.WriteElementString("slidertext", Component.StringValue("slidertext"));

            if (!string.IsNullOrEmpty(Component.StringValue("summary")))
                xml.WriteElementString("summary", Component.StringValue("summary"));

            if (!string.IsNullOrEmpty(Component.StringValue("description")))
                xml.WriteElementString("description", replaceHref(Component.StringValue("description")));

            //Redirect Component for other items in slider kit
            if (Component.ComponentMetaValue("redirectcomp") != null)
            {
                Component redirectcomp = Component.ComponentMetaValue("redirectcomp");
                xml.WriteElementString("redirectcomp", redirectcomp.Id);
            }
            if (Component.ComponentMetaValue("redirectmultimedia") != null)
            {
                Component redirectmultimedia = Component.ComponentMetaValue("redirectmultimedia");
                xml.WriteElementString("redirectmultimedia", PublishBinary(redirectmultimedia));
            }

            if (Component.ExternalLinkMetaValue("externallink") != null)
            {
                string redirectexternal = Component.ExternalLinkMetaValue("externallink");
                xml.WriteElementString("redirectexternal", redirectexternal);
            }

            if (Component.ComponentMetaValue("smallbinaryimage") != null)
            {
                Component smallbinaryimage = Component.ComponentMetaValue("smallbinaryimage");
                xml.WriteElementString("leadimagesmall", PublishBinary(smallbinaryimage));
            }

            if (Component.ComponentMetaValue("largebinaryimage") != null)
            {
                Component largebinaryimage = Component.ComponentMetaValue("largebinaryimage");
                xml.WriteElementString("leadimagelarge", PublishBinary(largebinaryimage));
            }

            if (Component.ComponentValue("bannerimage") != null)
            {
                Component bannerimage = Component.ComponentValue("bannerimage");
                xml.WriteElementString("bannerimage", PublishBinary(bannerimage));
            }

            if (Component.ComponentValue("summaryimage") != null)
            {
                Component summaryImage = Component.ComponentValue("summaryimage");
                xml.WriteElementString("summaryimage", PublishBinary(summaryImage));
            }

            //Gallery images and thumbnails in separate nodes
            if (Component.ComponentValues("images") != null)
            {
                IList<Component> multimediaLinks = Component.ComponentValues("images");
                xml.WriteStartElement("images");
                foreach (Component multimediaLink in multimediaLinks)
                {
                    xml.WriteStartElement("image");
                    xml.WriteAttributeString("src", PublishBinary(multimediaLink));
                    xml.WriteAttributeString("thumb", GenerateThumbnail(multimediaLink, "thumb", 82, 82));
                    xml.WriteEndElement();
                }
                xml.WriteEndElement();

            }
            xml.WriteEndElement();
        }

    }
}
