﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Emaar.Web.Tridion.System;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.ContentManagement.Fields;
using Tridion.ContentManager.ContentManagement;
using Emaar.Web.Tridion.System.Extensions;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.CommunicationManagement;
using Tridion.Logging;

namespace TGV.Web.Templating.BuildingBlocks.Templates
{
    [TcmTemplateTitle("PageVariables")]
    class PageVariables : PageVariablesTemplate
    {
        private List<String> mIncludeFields;
        private List<String> mInheritedFields;

        public PageVariables()
            : base()
        {
            mInheritedFields = new List<String>();
            mInheritedFields.Add("fbodyclass");
            mInheritedFields.Add("showleftnavigation");
            mInheritedFields.Add("pagetitle");
            mInheritedFields.Add("hidefromsearch");
        }
        public override void Transform(Engine engine, Package package)
        {
            base.Transform(engine, package);

            //Publish the images attached to the page metadata
            if (Page == null) return;

            if (Page.MetadataSchema != null && Page.Metadata != null)
            {
                ItemFields fields = new ItemFields(Page.Metadata, Page.MetadataSchema);
                foreach (ItemField field in fields)
                {
                    if ((field != null) && (field.ComponentValue() != null))
                    {
                        if (field.Name.Equals("largebinaryimage"))
                            Package.PushItem("largebinaryimage", package.CreateStringItem(ContentType.Text, PublishBinary(fields["largebinaryimage"].ComponentValue())));
                        if (field.Name.Equals("smallbinaryimage"))
                            Package.PushItem("smallbinaryimage", package.CreateStringItem(ContentType.Text, PublishBinary(fields["smallbinaryimage"].ComponentValue())));
                    }
                }
            }

        }

    }
}
