﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Emaar.Web.Tridion.System;
using Tridion.ContentManager.Templating.Assembly;

namespace TGV.Web.Templating.BuildingBlocks.Templates
{
    [TcmTemplateTitle("PublicationVariables")]
    class PublicationVariables:PublicationVariablesTemplate
    {
        public PublicationVariables() : base() { }
    }
}
