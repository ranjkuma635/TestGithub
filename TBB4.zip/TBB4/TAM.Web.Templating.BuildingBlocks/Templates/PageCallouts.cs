﻿using System;
using System.Linq;
using Tridion.ContentManager.CommunicationManagement;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.ContentManagement.Fields;
using Tridion.Extensions.ContentManager.Templating;
using Tridion.ContentManager.ContentManagement;
using Tridion.ContentManager.Publishing.Rendering;
using Emaar.Web.Tridion.System.Extensions;
using System.Xml;
using Tridion.ContentManager;

namespace TAM.Web.Templating.BuildingBlocks.Templates {
    [TcmTemplateTitle("PageCallouts")]
    public class PageCallouts : TemplateBase
    {

        public override void Transform(Engine engine, Package package) {
            base.Transform(engine, package);
            string sideOutput = string.Empty;
            Component widgetList = ExtractCallouts(Page);
            if (widgetList != null)
            {
                foreach (Component comp in widgetList.ComponentValues("list"))
                {
                    sideOutput = sideOutput + engine.RenderComponentPresentation(comp.Id, new TcmUri(57882, ItemType.ComponentTemplate, Publication.Id.ItemId));

                }
            }
            Package.AddHtml("sideOutput", sideOutput);

        }

      




        private Component ExtractCallouts(Page Page)
        {

            StructureGroup sg = Page.OrganizationalItem as StructureGroup;
            XmlNode xImage = null;
            XmlNode xBanner = null;
            XmlNodeList xBannerList = null;
            if (xImage == null)
            {
                if (Page.Metadata != null)
                {
                    xBannerList = Page.Metadata.ChildNodes;
                    foreach (XmlNode item in xBannerList)
                    {
                        if (item.Name.Equals("fWidget"))
                        {
                            xBanner = item;
                            break;
                        }

                    }
                }

                if (xBanner == null)
                {
                    do
                    {
                        if (sg.Metadata != null)
                        {
                            xBannerList = sg.Metadata.ChildNodes;
                            foreach (XmlNode item in xBannerList)
                            {
                                if (item.Name.Equals("fWidget"))
                                {
                                    xBanner = item;
                                    break;
                                }
                            }
                        }
                        if (sg.Title.Equals("Root"))
                        {
                            break;
                        }
                        else
                        {
                            sg = sg.OrganizationalItem as StructureGroup;
                        }
                    }
                    while (xBanner == null);
                }


                if (xBanner != null)
                {
                    if (xBanner.Attributes["xlink:href"] != null)
                    {
                        string widgetID = xBanner.Attributes["xlink:href"].Value;

                        if (!String.IsNullOrEmpty(widgetID) && widgetID.Contains("tcm:"))
                        {
                            return GetComponent(widgetID);
                        }
                    }
                }
            }
            return null;
        }
    }
}
