﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml;
using System.IO;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.ContentManagement.Fields;
using Tridion.Extensions.ContentManager.Templating;
using Tridion.ContentManager.ContentManagement;
using Emaar.Web.Tridion.System.Extensions;

namespace TAM.Web.Templating.BuildingBlocks.Templates
{

    [TcmTemplateTitle("DCPItem")]
    public class DCPItem : TemplateBase
    {
        /// <summary>
        /// Transforms the current component.
        /// </summary>
        /// <param name="engine">The engine.</param>
        /// <param name="package">The package.</param>
        public override void Transform(Engine engine, Package package)
        {
            base.Transform(engine, package);

            using (StringWriter sw = new StringWriter())
            {

                using (XmlTextWriter xml = new XmlTextWriter(sw))
                {

                    string itemId = Component.Id;

                    if (Component != null)
                    {


                        if (Component.Schema.Title.Equals("TAM - Event"))
                        {

                            xml.WriteStartElement("item");
                            xml.WriteAttributeString("uri", Component.Id.ToString());
                            xml.WriteAttributeString("title", Component.StringValue("title"));
                            xml.WriteAttributeString("location", Component.StringValue("location"));
                            DateTime startDate = Component.DateValue("date");
                            if (startDate.ToString("dd/MM/yyyy") != "01/01/0001")
                            {
                                xml.WriteAttributeString("day", startDate.ToString("dd").TrimStart(new Char[] { '0' }));
                                xml.WriteAttributeString("month", startDate.ToString("MMM"));
                                xml.WriteAttributeString("sortDate", GetSortDate(startDate.ToString("dd/MM/yyyy")));
                                xml.WriteStartElement("date");
                                xml.WriteElementString("endDate", startDate.ToString("yyyy-MM-dd"));
                                xml.WriteEndElement();//date  
                            }
                            xml.WriteEndElement();//item    
                        }


                        if (Component.Schema.Title.Equals("TAM - News"))
                        {

                            xml.WriteStartElement("item");
                            xml.WriteAttributeString("uri", Component.Id.ToString());
                            if (Component.EmbeddedMetaValue("callout").ComponentValue("image") != null)
                            {
                                xml.WriteAttributeString("src", PublishBinary(Component.EmbeddedMetaValue("callout").ComponentValue("image")));
                            }
                            else
                            {
                                xml.WriteAttributeString("src", PublishBinary(Component.ComponentValue("image")));
                            }
                            if (!String.IsNullOrEmpty(Component.EmbeddedMetaValue("callout").StringValue("text")))
                            {
                                xml.WriteAttributeString("title", Component.EmbeddedMetaValue("callout").StringValue("text"));
                            }
                            else
                            {
                                xml.WriteAttributeString("title", Component.StringValue("title"));
                            }
                            if (!String.IsNullOrEmpty(Component.EmbeddedMetaValue("callout").StringValue("value")))
                            {
                                xml.WriteAttributeString("description", Component.EmbeddedMetaValue("callout").StringValue("value"));
                            }
                            else
                            {
                                string shortSummary = Component.StringValue("description");
                                if (shortSummary.Length > 120)
                                {
                                    shortSummary = shortSummary.Substring(0, 120);
                                    shortSummary = shortSummary.Substring(0, shortSummary.LastIndexOf(" "));
                                }
                                xml.WriteAttributeString("description", shortSummary);
                            }
                            DateTime pubDate = Component.DateValue("date");
                            if (pubDate.ToString("dd/MM/yyyy") != "01/01/0001")
                            {
                                string sortDate = GetSortDate(pubDate.ToString("dd/MM/yyyy"));
                                xml.WriteAttributeString("sortDate", sortDate);
                                DateTime dt = DateTime.ParseExact(pubDate.ToString("dd/MM/yyyy"), "dd/MM/yyyy", null);
                                xml.WriteAttributeString("formatDate", String.Format("{0:dddd, MMMM d, yyyy}", dt));
                            }
                            xml.WriteEndElement();//item    
                        }

                        if (Component.Schema.Title.Equals("TAM - Offer"))
                        {
                            DateTime pubDate;

                            xml.WriteStartElement("item");
                            xml.WriteAttributeString("uri", Component.Id.ToString());
                            if (Component.EmbeddedMetaValue("callout").ComponentValue("image") != null)
                            {
                                xml.WriteAttributeString("src", PublishBinary(Component.EmbeddedMetaValue("callout").ComponentValue("image")));
                            }
                            else
                            {
                                xml.WriteAttributeString("src", PublishBinary(Component.ComponentValue("image")));
                            }
                            if (!String.IsNullOrEmpty(Component.EmbeddedMetaValue("callout").StringValue("text")))
                            {
                                xml.WriteAttributeString("title", Component.EmbeddedMetaValue("callout").StringValue("text"));
                            }
                            else
                            {
                                xml.WriteAttributeString("title", Component.StringValue("title"));
                            }
                            if (!String.IsNullOrEmpty(Component.EmbeddedMetaValue("callout").StringValue("value")))
                            {
                                xml.WriteAttributeString("description", Component.EmbeddedMetaValue("callout").StringValue("value"));
                            }
                            else
                            {
                                string shortSummary = Component.StringValue("description");
                                if (shortSummary.Length > 120)
                                {
                                    shortSummary = shortSummary.Substring(0, 120);
                                    shortSummary = shortSummary.Substring(0, shortSummary.LastIndexOf(" "));
                                }
                                xml.WriteAttributeString("description", shortSummary);
                            }

                            xml.WriteAttributeString("category", Component.KeywordValue("category").Key);

                            xml.WriteEndElement();//item    
                        }


                        if (Component.Schema.Title.Equals("TAM - Image"))
                        {

                            if (Component.OrganizationalItem.Id.ItemId.ToString() == "7577")
                            {
                                xml.WriteStartElement("item");
                                xml.WriteAttributeString("uri", Component.Id.ToString());
                                xml.WriteAttributeString("src", PublishBinary(Component));
                                if (!String.IsNullOrEmpty(Component.StringMetaValue("altText")))
                                {
                                    xml.WriteAttributeString("text", Component.StringMetaValue("altText"));
                                }
                                else
                                {
                                    xml.WriteAttributeString("text", Component.Title);
                                }
                                xml.WriteEndElement();//item    
                            }
                        }


                        if (Component.Schema.Title.Equals("TAM - Document"))
                        {
                            xml.WriteStartElement("item");
                            xml.WriteAttributeString("uri", Component.Id.ToString());
                            xml.WriteAttributeString("title", Component.Title);
                            xml.WriteAttributeString("document ", PublishBinary(Component.ComponentValue("document")));
                            xml.WriteAttributeString("text", Component.StringValue("text"));
                            DateTime date = Component.DateValue("date");
                            if (date.ToString("dd/MM/yyyy") != "01/01/0001"){
                                string sortDate = GetSortDate(date.ToString("dd/MM/yyyy"));
                                xml.WriteAttributeString("sortDate", sortDate);
                                xml.WriteAttributeString("year", sortDate.Substring(0,4));
                            }
                            xml.WriteEndElement();//item    
                        }

                    }

                    Package.AddXml(Package.OutputName, sw.ToString());
                }
            }
        }

        private static string getHtml(string html)
        {
            return Utility.removeXHTMLtags(html);
        }


        private string GetSortDate(string strDate)
        {

            string strRetval = "";


            string[] datetime = strDate.Split(new char[] { '/' });

            string Year = datetime[2];
            string Month = datetime[1];
            string Day = datetime[0];

            if (Month.Length == 1)
                Month = "0" + Month;

            if (Day.Length == 1)
                Day = "0" + Day;

            strRetval = Year + Month + Day;

            return strRetval;

        }
    }
}