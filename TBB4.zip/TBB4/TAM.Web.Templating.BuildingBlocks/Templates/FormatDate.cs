﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager;
using Tridion.ContentManager.ContentManagement;
using Emaar.Web.Tridion.System.Extensions;
using Tridion.Extensions.ContentManager.Templating;
using System.Globalization;

namespace TAM.Web.Templating.BuildingBlocks.Templates
{
    [TcmTemplateTitle("FormatDate")]
    public class FormatDate : TemplateBase
    {
        public override void Transform(Engine engine, Package package)
        {
            base.Transform(engine, package);
            if (Component.DateValue("date") != null)
            {
                DateTime pubDate = Component.DateValue("date");
                if (pubDate.ToString("dd/MM/yyyy") != "01/01/0001")
                {
                    DateTime dt = DateTime.ParseExact(pubDate.ToString("dd/MM/yyyy"), "dd/MM/yyyy", null);
                    Package.AddHtml("FormatDate", String.Format("{0:dddd, MMMM d, yyyy}", dt));
                }
            }
            
        }
    }
            
}
