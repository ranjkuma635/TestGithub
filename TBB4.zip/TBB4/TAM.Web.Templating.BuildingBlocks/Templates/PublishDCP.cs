﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager;
using Tridion.ContentManager.ContentManagement;
using Emaar.Web.Tridion.System.Extensions;
using Tridion.Extensions.ContentManager.Templating;

namespace TAM.Web.Templating.BuildingBlocks.Templates
{
    [TcmTemplateTitle("Publish Attached DCP")]
    public class PublishDCP : TemplateBase
    {
        public override void Transform(Engine engine, Package package)
        {
            base.Transform(engine, package);
            IComponentPresentationList componentPresentations = package.ItemAsComponentList(Package.ComponentsName);

            foreach (ComponentPresentation componentPresentation in componentPresentations) {
                Component component = GetComponent(componentPresentation.ComponentUri);
                String schemaTitle = component.Schema.Title;
                if (component != null){
                    switch (schemaTitle) {
                        case "TAM - News":
                        case "TAM - Event":
                        case "TAM - Offer":
                            engine.RenderComponentPresentation(component.Id, new TcmUri(57285, ItemType.ComponentTemplate, Publication.Id.ItemId));
                            break;
                        default:
                            break;
                    }
                }

            }
            
        }
    }
}
