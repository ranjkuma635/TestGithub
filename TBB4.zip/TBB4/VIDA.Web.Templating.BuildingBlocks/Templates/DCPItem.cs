﻿using System;
using System.Xml;
using System.IO;
using Tridion.ContentManager;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.ContentManagement.Fields;
using Tridion.Extensions.ContentManager.Templating;
using Tridion.ContentManager.ContentManagement;
using Emaar.Web.Tridion.System.Extensions;
using Tridion.ContentManager.Publishing;
using System.Text.RegularExpressions;

namespace VIDA.Web.Templating.BuildingBlocks.Templates
{

    [TcmTemplateTitle("DCPItem")]
    public class DCPItem : TemplateBase
    {
        /// <summary>
        /// Transforms the current component.
        /// </summary>
        /// <param name="engine">The engine.</param>
        /// <param name="package">The package.</param>
        public override void Transform(Engine engine, Package package)
        {
            base.Transform(engine, package);

            using (StringWriter sw = new StringWriter())
            {

                using (XmlTextWriter xml = new XmlTextWriter(sw))
                {

                    string itemId = Component.Id;

                    if (Component != null)
                    {
                        if (Component.Schema.Title.Equals("Vida - Blogs"))
                        {
                            xml.WriteStartElement("item");
                            xml.WriteAttributeString("uri", Component.Id);
                            xml.WriteAttributeString("id", itemId.Split('-')[1]);
                            xml.WriteAttributeString("schema", Component.Schema.Title.Split('-')[1].TrimStart());
                            if (Component.KeywordMetaValue("blogcategory") != null)
                            {
                                xml.WriteAttributeString("blogcategory", Component.KeywordMetaValue("blogcategory").Description);
                                xml.WriteAttributeString("blogcategoryId", Component.KeywordMetaValue("blogcategory").Key);
                            }
                            else
                            {
                                xml.WriteAttributeString("blogcategory", "");
                                xml.WriteAttributeString("blogcategoryId", "");
                            }
                            xml.WriteAttributeString("title", Component.StringValue("title"));
                            xml.WriteAttributeString("brief", Component.StringValue("brief"));
                            xml.WriteAttributeString("description", Component.StringValue("description"));
                            Component image = Component.ComponentValue("image");
                            if (image != null)
                            {
                                xml.WriteAttributeString("src", PublishBinary(image));
                                xml.WriteAttributeString("altText", image.StringMetaValue("altText"));
                            }
                            if (!string.IsNullOrEmpty(Component.NumberMetaValue("ranking").ToString()))
                            {
                                xml.WriteAttributeString("ranking", Component.NumberMetaValue("ranking").ToString());
                            }

                            Component thumbImage = Component.ComponentMetaValue("thumbimage");
                            if (thumbImage != null)
                            {
                                xml.WriteAttributeString("thumbsrc", PublishBinary(thumbImage));
                                xml.WriteAttributeString("thumbaltText", thumbImage.StringMetaValue("altText"));
                            }

                            DateTime startDate = Component.DateMetaValue("publishDate");
                            if (startDate != null && startDate.ToString("dd/MM/yyyy") != "01/01/0001")
                            {
                                xml.WriteStartElement("date");
                                xml.WriteAttributeString("startDate", startDate.ToString("dd/MM/yyyy"));
                                xml.WriteAttributeString("endDate", "");
                                xml.WriteAttributeString("sortDate", GetSortDate(startDate.ToString("dd/MM/yyyy")));
                                xml.WriteAttributeString("year", GetSortDate(startDate.ToString("dd/MM/yyyy")).Substring(0, 4));
                                xml.WriteEndElement();//item
                            }
                            else if (startDate == null || startDate.ToString("dd/MM/yyyy") == "01/01/0001")
                            {
                                Logger.Info("Blog Item with Empty PublishDate found>>> " + Component.Title);
                                
                                    xml.WriteStartElement("date");
                                    xml.WriteAttributeString("startDate", DateTime.Now.ToString("dd/MM/yyyy"));
                                    xml.WriteAttributeString("endDate", "");
                                    xml.WriteAttributeString("sortDate", GetSortDate(DateTime.Now.ToString("dd/MM/yyyy")));
                                    xml.WriteAttributeString("year", GetSortDate(DateTime.Now.ToString("dd/MM/yyyy")).Substring(0, 4));
                                    xml.WriteEndElement();//close date
                                
                                // If Component is Published to Live with NO Publish Date Metadata set, Update the Component Metadata!
                                if(engine.RenderMode == RenderMode.Publish && engine.PublishingContext.PublicationTarget.Title.ToLower().Contains("live"))
                                {
                                    Logger.Info("Blog Component with empty PublishDate meta field was published to Live>>> " + Component.Title);
                                    SetPublishDateForBlogItem();
                                }                                
                            }

                            xml.WriteEndElement();//item
                        }                        
                    }

                    Package.AddXml(Package.OutputName, sw.ToString());
                }
            }
        }

        /// <summary>
        /// Function to set the Publish Date Metadata field for Blog Items
        /// </summary>
        private void SetPublishDateForBlogItem()
        {
            if (Component != null)
            {
                if (Component.Schema.Title.Equals("TAHR - Blogs"))
                {
                    XmlNode dateNode = null;
                    TcmUri componentURI = null;

                    if (Component.IsShared)
                    {
                        componentURI = new TcmUri(Component.Id.ItemId, Component.Id.ItemType, int.Parse(Component.OwningRepository.Id.ToString().Split('-').GetValue(1).ToString().Trim()));

                        // Shared Component cannot be updated. Get the 02C publication component and update it!
                        TcmUri owningPublicationUri = Component.OwningRepository.Id;

                        Logger.Info("SetPublishDateForItem>>>>: Component Is a Shared Item, Original Item URI>>>" + componentURI.ToString());

                        Component _component = (Component)Engine.GetSession().GetObject(componentURI);

                        ItemFields metaFields = new ItemFields(_component.Metadata, _component.MetadataSchema);
                        DateField publishDateField = metaFields["publishDate"] as DateField;
                        DateTime publishDate = publishDateField.Value;

                        Logger.Info("SetPublishDateForItem>>>>: Original Publish Date>>>" + publishDate.ToString());

                        Logger.Info("SetPublishDateForItem>>>>: Original Metadata XML>>>" + _component.Metadata.OuterXml);

                        /* Component Metadata format: 
                         * <Metadata xmlns="uuid:FD691C95-F833-4A07-8C95-02454F80FC6D"><publishDate>2017-08-30T05:39:13</publishDate><blogcategory>Explore</ blogcategory><ranking>10</ranking></Metadata>
                        */
                        if (publishDate.ToString("dd/MM/yyyy") == "01/01/0001" && !Component.IsPublishedInContext)
                        {
                            // This is the first Time component is being published
                            Logger.Info("Component is published for first time!");

                            dateNode = _component.Metadata.OwnerDocument.CreateNode(XmlNodeType.Element, "publishDate", _component.Metadata.OwnerDocument.DocumentElement.NamespaceURI);
                            dateNode.InnerText = DateTime.Now.ToString("yyyy-MM-dd") + "T" + DateTime.Now.ToString("hh:mm:ss");
                        }
                        else if (publishDate.ToString("dd/MM/yyyy") == "01/01/0001" && Component.IsPublishedInContext)
                        {
                            //Component is published already but PublishDate Metadata field was not set
                            Logger.Info("Component is published already but PublishDate Metadata field was not set. Setting the same to today's date for now!!");

                            dateNode = _component.Metadata.OwnerDocument.CreateNode(XmlNodeType.Element, "publishDate", _component.Metadata.OwnerDocument.DocumentElement.NamespaceURI);
                            //Update the Publish date to today's date
                            dateNode.InnerText = DateTime.Now.ToString("yyyy-MM-dd") + "T" + DateTime.Now.ToString("hh:mm:ss");
                        }

                        try
                        {
                            if (dateNode != null)
                            {
                                Logger.Info("PublishDateValue>>>>: " + dateNode.InnerText);
                                Logger.Info("SetPublishDateForItem>>>>: Before CheckOUt Status" + _component.IsCheckedOut);
                                if (_component.IsCheckedOut)
                                {
                                    //_component.CheckIn(true);
                                    _component.UndoCheckOut(true);
                                }

                                _component.CheckOut(true);

                                Logger.Info("SetPublishDateForItem>>>>: After CheckOUt Status" + _component.IsCheckedOut);

                                //necessary for crossing XmlDocument contexts
                                XmlNode importNode = _component.Metadata.OwnerDocument.ImportNode(dateNode, true);

                                // If publishDate node already exists, remove it and re insert to update.
                                if (_component.Metadata.OwnerDocument.DocumentElement.FirstChild.Name.ToLower().Equals("publishdate"))
                                {
                                    _component.Metadata.OwnerDocument.DocumentElement.RemoveChild(_component.Metadata.OwnerDocument.DocumentElement.FirstChild);
                                }

                                //Add the publishDate node as first child node
                                _component.Metadata.OwnerDocument.DocumentElement.PrependChild(importNode);

                                Logger.Info("SetPublishDateForItem>>>>: Saving Component");

                                _component.Save(true);
                                _component.CheckIn(true);

                                Logger.Info("SetPublishDateForItem>>>>: Saved & Checked In Component Successfully!");
                            }
                        }
                        catch (Exception ex)
                        {
                            _component.UndoCheckOut(true);
                            Logger.Info("SetPublishDateForItem>>>> ERROR While Saving Item :" + ex.Message);
                        }
                    }
                }
            }
        }

        private static string getHtml(string html)
        {
            return Utility.removeXHTMLtags(html);
        }

        private string GetSortDate(string strDate)
        {

            string strRetval = "";


            string[] datetime = strDate.Split(new char[] { '/' });

            string Year = datetime[2];
            string Month = datetime[1];
            string Day = datetime[0];

            if (Month.Length == 1)
                Month = "0" + Month;

            if (Day.Length == 1)
                Day = "0" + Day;

            strRetval = Year + Month + Day;

            return strRetval;

        }

        /// <summary>
        /// replaceHref
        /// </summary>
        /// <param name="string">String in which links to be resolved</param>
        /// <param name="xml">Object of Xml text writer</param>
        private string replaceHref(string fieldText)
        {
            string pattern = "href=\"(tcm:.*?)\"";
            MatchCollection collection = Regex.Matches(fieldText, pattern);
            foreach (Match match in collection)
            {
                string matchedString = match.Groups[1].Value;
                //string matchedStringwithAttr = match.Groups[0].Value;
                TcmUri tcmId = new TcmUri(matchedString + "-16");
                Component component = GetComponent(tcmId);
                if (component.Schema.Purpose.Equals(SchemaPurpose.Multimedia))
                {
                    string publishedPath = PublishBinary(component);
                    string fileName = component.BinaryContent.Filename;
                    string fileType = fileName.Substring(fileName.LastIndexOf('.') + 1, fileName.Length - fileName.LastIndexOf('.') - 1);
                    switch (fileType.ToLower())
                    {
                        case "jpeg":
                        case "gif":
                        case "jpg":
                        case "png":
                            fieldText = fieldText.Replace(matchedString, publishedPath);
                            fieldText = fieldText.Replace("xlink:href", "src");
                            break;
                        case "doc":
                        case "docx":
                        case "pdf":
                            fieldText = fieldText.Replace(matchedString, publishedPath);
                            fieldText = fieldText.Replace("xlink:href", "href");
                            break;
                        default: fieldText = fieldText.Replace(matchedString, publishedPath);
                            fieldText = fieldText.Replace("xlink:href", "href"); break;
                    }
                }
                //else
                //{
                //    fieldText = fieldText.Replace("xlink:href", "tridion:ComponentLink");
                //}
            }
            return fieldText;
        }
    }
}