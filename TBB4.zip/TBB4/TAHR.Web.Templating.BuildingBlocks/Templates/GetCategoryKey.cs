﻿using System;
using System.Collections.Generic;
using System.Xml;
using Tridion.ContentManager.ContentManagement.Fields;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager;
using System.Collections;
using Tridion.ContentManager.ContentManagement;
using Tridion.ContentManager.CommunicationManagement;
using System.Xml.XPath;
using System.Web;
using Tridion.Extensions.ContentManager.Templating;
using System.IO;
using Emaar.Web.Tridion.System.Extensions;


namespace TAHR.Web.Templating.BuildingBlocks.Templates {
    [TcmTemplateTitle("GetCategoryKey")]
    public class GetCategoryKey : TemplateBase {

        public override void Transform(Engine engine, Package package) {
            base.Transform(engine, package);
            string strPubid = package.GetValue("PublicationVariable.PubID");
            string strHotel = "tcm:" + strPubid + "-4385-512";
            string hotelTCM = package.GetValue("PageVariable.fhotelName");

            Filter f = new Filter();
            Category categoryHotel = engine.GetObject(strHotel) as Category;
            IList<Keyword> catHotel = categoryHotel.GetKeywords(f);
            foreach (Keyword key in catHotel) {
                if (key.Id.ToString().Equals(hotelTCM)) {
                    package.AddString("hotelKey", key.Key);
                    package.AddString("hotelName", key.Description);
                }
            }

        }
    }
}
