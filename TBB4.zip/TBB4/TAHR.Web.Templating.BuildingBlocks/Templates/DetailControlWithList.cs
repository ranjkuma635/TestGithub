﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Xml;
using System.IO;
using System.Web;
using Tridion.ContentManager;
using Tridion.ContentManager.CommunicationManagement;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Expression;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.Templating.Dreamweaver;
using Tridion;
using Tridion.ContentManager.ContentManagement.Fields;
using Tridion.Extensions.ContentManager.Templating;
using Publishing = Tridion.ContentManager.Publishing.Rendering;
using Tridion.ContentManager.ContentManagement;
using Tridion.ContentManager.Publishing.Rendering;
using System.Text.RegularExpressions;
using Emaar.Web.Tridion.System.Extensions;
using Emaar.Web.Tridion.System.Dreamweaver_Extension;

namespace TAHR.Web.Templating.BuildingBlocks.Templates
{
    [TcmTemplateTitle("DetailControlWithList")]
    public class DetailControlWithList : Emaar.Web.Tridion.System.ControlTemplate
    {
        /// <summary>
        /// Transforms the current component.
        /// </summary>
        /// <param name="engine">The engine.</param>
        /// <param name="package">The package.</param>
        public override void Transform(Engine engine, Package package)
        {

            // base.Transform(engine, package);

            mEngine = engine;
            mPackage = package;

            Emaar.Web.Tridion.System.Dreamweaver_Extension.Templating controlTag = new Emaar.Web.Tridion.System.Dreamweaver_Extension.Templating();

            string strItemId = Component.Id.ToString();
            string strPubid = Component.Id.PublicationId.ToString();

            String detailXSLT = "";
            String listXSLT = "";
            String itemId = "";
            String listXML ="";
            String XML = "";
            String type = "";
            String itemType ="";
            String componentID = Component.Id;
            String schema = "";
            String category = "";
            String heading = "HighlightsHeadingMoreOptions";
            String listHeading = "ListsHeadingMoreOptions";
            
            switch (Component.Schema.Title) {
                case "TAHR - Offering":
                    itemType = Component.KeywordMetaValue("type").Key;
                    category = Component.KeywordMetaValue("category").Key;
                    if (!String.IsNullOrEmpty(itemType)){
                        switch (itemType){
                            case "1":
                                listXSLT = "dines.xslt";
                                listXML = "dines.xml";
                                schema = "Restaurent";
                                type = "single";
                                detailXSLT = "experienceDetail.xslt";
                                XML = "experiences.xml";
                                heading = "HighlightsHeadingDineOfferings";
                                switch (category){
                                    case "100":
                                        listHeading = "ExperienceHeadingAfternoonTea";
                                        break;
                                    case "200":
                                        listHeading = "ExperienceHeadingBrunch";
                                        break;
                                    case "300":
                                        listHeading = "ExperienceHeadingFineDining";
                                        break;   
                                }
                                break;
                                
                            case "2":
                                listXSLT = "eventvenues.xslt";
                                listXML = "eventvenues.xml";
                                schema = "EventVenue";
                                detailXSLT = "offeringDetail.xslt";
                                XML = "offerings.xml";
                                heading = "HighlightsHeadingEventOfferings";
                                type = "multivalued";
                                switch (category)
                                {
                                    case "800":
                                        listHeading = "EventHeadingMeetingVenues";
                                        break;
                                    case "900":
                                        listHeading = "EventHeadingWeddingVenues";
                                        break;  
                                }

                                break;
                        }
                    }
                    itemId = componentID;
                   
                    break;
            }

            string strDetailControl = "tcm:" + strPubid + "-4570-2";

            OrganizationalItem detailControlFolder = engine.GetObject(strDetailControl) as OrganizationalItem;

            IList<Component> compList = detailControlFolder.Components(true);
            foreach (Component comp in compList){
                if (comp != null && comp.Schema.Title.Equals("User Controls") && comp.Title.Equals("Detail Control with List")){
                    package.AddString("ItemID", itemId);
                    package.AddString("detailXSLT", detailXSLT);
                    package.AddString("xml", XML);
                    package.AddString("listXSLT", listXSLT);
                    package.AddString("listXML", listXML);
                    package.AddString("type", type);
                    package.AddString("schema", schema);
                    package.AddString("heading", heading);
                    package.AddString("listHeading", listHeading);
                    //Package.AddHtml(Package.OutputName, controlTag.GetControlTag(comp));
                }
            }
        }
    }
}