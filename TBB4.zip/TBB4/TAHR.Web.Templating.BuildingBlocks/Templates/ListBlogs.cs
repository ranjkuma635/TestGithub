﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Linq;
using System.Linq;
using System.Xml;
using System.IO;
using Tridion.ContentManager;
using Tridion.ContentManager.CommunicationManagement;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Expression;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.Templating.Dreamweaver;
using Tridion;
using Tridion.ContentManager.ContentManagement.Fields;
using Tridion.Extensions.ContentManager.Templating;
using Publishing = Tridion.ContentManager.Publishing.Rendering;
using Tridion.ContentManager.ContentManagement;
using Tridion.ContentManager.Publishing.Rendering;
using System.Text.RegularExpressions;
using Emaar.Web.Tridion.System.Extensions;
using Tridion.ContentManager.Publishing;

namespace TAHR.Web.Templating.BuildingBlocks.Templates
{
    [TcmTemplateTitle("ListBlogs")]
    public class ListBlogs : TemplateBase
    {
        /// <summary>
        /// Transforms the current component.
        /// </summary>
        /// <param name="engine">The engine.</param>
        /// <param name="package">The package.</param>
        public override void Transform(Engine engine, Package package)
        {
            int i = 1;

            base.Transform(engine, package);

            string BlogsFolderTcmUri = Component.OrganizationalItem.Id;

            OrganizationalItem BlogsFolder = engine.GetObject(BlogsFolderTcmUri) as OrganizationalItem;

            using (StringWriter sw = new StringWriter())
            {
                using (XmlTextWriter xml = new XmlTextWriter(sw))
                {
                    xml.WriteStartElement("list");

                    i = 1;
                    IList<Component> blogsList = BlogsFolder.Components(true);

                    Logger.Info("Blog List Count>>>: " + blogsList.Count.ToString());

                    foreach (Component currentComponent in blogsList)
                    {
                        if (currentComponent.Schema.Title.Equals("TAHR - Blogs"))
                        {
                            xml.WriteStartElement("item");

                            xml.WriteAttributeString("No", i.ToString());
                            xml.WriteAttributeString("uri", currentComponent.Id);
                            xml.WriteAttributeString("id", currentComponent.Id.ToString().Split('-')[1]);
                            xml.WriteAttributeString("schema", currentComponent.Schema.Title.Split('-')[1].TrimStart());
                            if (currentComponent.KeywordMetaValue("blogcategory") != null)
                            {
                                xml.WriteAttributeString("blogcategory", currentComponent.KeywordMetaValue("blogcategory").Description);
                                xml.WriteAttributeString("blogcategoryId", currentComponent.KeywordMetaValue("blogcategory").Key);
                            }
                            else
                            {
                                xml.WriteAttributeString("blogcategory", "Explore");
                                xml.WriteAttributeString("blogcategoryId", "explore");
                            }
                            xml.WriteAttributeString("title", currentComponent.StringValue("title"));
                            xml.WriteAttributeString("brief", currentComponent.StringValue("brief"));
                            xml.WriteAttributeString("description", currentComponent.StringValue("description"));
                            Component image = currentComponent.ComponentValue("image");
                            if (image != null)
                            {
                                xml.WriteAttributeString("src", PublishBinary(image));
                                xml.WriteAttributeString("altText", image.StringMetaValue("altText"));
                            }
                            if (!string.IsNullOrEmpty(currentComponent.NumberMetaValue("ranking").ToString()))
                            {
                                xml.WriteAttributeString("ranking", currentComponent.NumberMetaValue("ranking").ToString());
                            }

                            DateTime startDate = currentComponent.DateMetaValue("publishDate");
                            if (startDate != null && startDate.ToString("dd/MM/yyyy") != "01/01/0001")
                            {
                                xml.WriteStartElement("date");
                                xml.WriteAttributeString("startDate", startDate.ToString("dd/MM/yyyy"));
                                xml.WriteAttributeString("endDate", "");
                                xml.WriteAttributeString("sortDate", GetSortDate(startDate.ToString("dd/MM/yyyy")));
                                xml.WriteAttributeString("year", GetSortDate(startDate.ToString("dd/MM/yyyy")).Substring(0, 4));
                                xml.WriteEndElement();//close date element
                            }
                            else if (startDate == null || startDate.ToString("dd/MM/yyyy") == "01/01/0001")
                            {
                                Logger.Info("Blog Item with Empty PublishDate found>>> " + Component.Title);

                                if (engine.RenderMode == RenderMode.Publish && engine.PublishingContext.PublicationTarget.Title.ToLower().Contains("staging"))
                                {
                                    Logger.Info("Blog Item with Empty PublishDate Found!");

                                    xml.WriteStartElement("date");
                                    xml.WriteAttributeString("startDate", DateTime.Now.ToString("dd/MM/yyyy"));
                                    xml.WriteAttributeString("endDate", "");
                                    xml.WriteAttributeString("sortDate", GetSortDate(DateTime.Now.ToString("dd/MM/yyyy")));
                                    xml.WriteAttributeString("year", GetSortDate(DateTime.Now.ToString("dd/MM/yyyy")).Substring(0, 4));
                                    xml.WriteEndElement();//item
                                }                                
                                else if (engine.RenderMode == RenderMode.Publish && engine.PublishingContext.PublicationTarget.Title.ToLower().Contains("live"))
                                {
                                    Logger.Info("Blog Component with empty PublishDate meta field Found>>> " + Component.Title);
                                }
                            }

                            xml.WriteEndElement();//close item element
                            i++;
                        }
                    }

                    xml.WriteEndElement(); //list                
                }

                Package.AddXml(Package.OutputName, sw.ToString());
            }
        }

        private string GetSortDate(string strDate)
        {

            string strRetval = "";


            string[] datetime = strDate.Split(new char[] { '/' });

            string Year = datetime[2];
            string Month = datetime[1];
            string Day = datetime[0];

            if (Month.Length == 1)
                Month = "0" + Month;

            if (Day.Length == 1)
                Day = "0" + Day;

            strRetval = Year + Month + Day;

            return strRetval;

        }
    }
}

