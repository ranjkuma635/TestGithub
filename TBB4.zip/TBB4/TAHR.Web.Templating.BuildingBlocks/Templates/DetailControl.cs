﻿using System;
using System.Collections.Generic;
using System.Linq;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.ContentManagement;
using Emaar.Web.Tridion.System.Extensions;

namespace TAHR.Web.Templating.BuildingBlocks.Templates
{
    [TcmTemplateTitle("DetailControl")]
    public class DetailControl : Emaar.Web.Tridion.System.ControlTemplate {
        /// <summary>
        /// Transforms the current component.
        /// </summary>
        /// <param name="engine">The engine.</param>
        /// <param name="package">The package.</param>
        public override void Transform(Engine engine, Package package) {

           // base.Transform(engine, package);

            mEngine = engine;
            mPackage = package;

            Emaar.Web.Tridion.System.Dreamweaver_Extension.Templating controlTag = new Emaar.Web.Tridion.System.Dreamweaver_Extension.Templating();

            string strItemId = Component.Id.ToString();
            string strPubid = Component.Id.PublicationId.ToString();

            String detailXSLT="";
            String itemId = "";

            String componentID = Component.Id;

            switch (Component.Schema.Title) {
                case "TAHR - Room":
                    detailXSLT = "roomDetail.xslt";
                    break;
                case "TAHR - Residence":
                    detailXSLT = "residenceDetail.xslt";
                    break;
                case "TAHR - Spa":
                    detailXSLT = "spaDetail.xslt";
                    break;
                case "TAHR - Hotel":
                    detailXSLT = "hotelDetail.xslt";
                    break;
                case "TAHR - Offer":
                    detailXSLT = "offerDetail.xslt";
                    break;
                case "TAHR - Event Venue":
                    detailXSLT = "eventVenueDetail.xslt";
                    break;
                case "TAHR - Event":
                    detailXSLT = "eventDetail.xslt";
                    break;
                case "TAHR - Amenity":
                    detailXSLT = "amenityDetail.xslt";
                    break;
                case "TAHR - Restaurent":
                    detailXSLT = "dineDetail.xslt";
                    break;
                case "TAHR - Treatment":
                    detailXSLT = "treatmentDetail.xslt";
                    break;
                case "TAHR - Offering":
                    detailXSLT = "offeringDetail.xslt";
                    break;
                case "TAHR - Location":
                    detailXSLT = "locationDetail.xslt";
                    break;
                case "TAHR - Apartment":
                    detailXSLT = "stayDetail.xslt";
                    break;
                case "TAHR - Residence Amenity":
                    detailXSLT = "residenceAmenityDetail.xslt";
                    break;
                case "TAHR - News":
                    detailXSLT = "newsDetail.xslt";
                    break;
            }

            itemId = componentID;

            string strDetailControl = "tcm:" + strPubid + "-4570-2";

            OrganizationalItem detailControlFolder = engine.GetObject(strDetailControl) as OrganizationalItem;

            IList<Component> compList = detailControlFolder.Components(true);
            foreach (Component comp in compList)  {
                if (comp != null && comp.Schema.Title.Equals("User Controls") && comp.Title.Equals("Detail Control")) {
                    package.AddValue(ContentType.String,"ItemID", itemId);
                    package.AddValue(ContentType.String,"detailXSLT", detailXSLT);
                    //Package.AddHtml(Package.OutputName, controlTag.GetControlTag(comp));
                }
            }
        }
    }
}