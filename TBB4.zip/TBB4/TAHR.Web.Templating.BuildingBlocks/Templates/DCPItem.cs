﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Xml;
using System.IO;
using Tridion.ContentManager;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.ContentManagement.Fields;
using Tridion.Extensions.ContentManager.Templating;
using Tridion.ContentManager.ContentManagement;
using Emaar.Web.Tridion.System.Extensions;
using System.Drawing;
using Tridion.ContentManager.Publishing;
using System.Globalization;
using System.Text.RegularExpressions;

namespace TAHR.Web.Templating.BuildingBlocks.Templates
{

    [TcmTemplateTitle("DCPItem")]
    public class DCPItem : TemplateBase
    {
        /// <summary>
        /// Transforms the current component.
        /// </summary>
        /// <param name="engine">The engine.</param>
        /// <param name="package">The package.</param>
        public override void Transform(Engine engine, Package package)
        {
            base.Transform(engine, package);

            using (StringWriter sw = new StringWriter())
            {

                using (XmlTextWriter xml = new XmlTextWriter(sw))
                {

                    string itemId = Component.Id;

                    if (Component != null)
                    {

                        if (Component.Schema.Title.Equals("TAHR - Hotel"))
                        {

                            xml.WriteStartElement("item");
                            xml.WriteAttributeString("uri", Component.Id);
                            xml.WriteAttributeString("id", itemId.Split('-')[1]);
                            xml.WriteAttributeString("index", Component.Title.Substring(0, 3));
                            xml.WriteAttributeString("schema", Component.Schema.Title.Split('-')[1].TrimStart());
                            xml.WriteAttributeString("hotelId", Component.KeywordMetaValue("hotel").Key);
                            xml.WriteAttributeString("hotel", Component.KeywordMetaValue("hotel").Description);
                            xml.WriteAttributeString("code", Component.StringMetaValue("code"));
                            xml.WriteAttributeString("location", Component.KeywordMetaValue("location").Description);
                            xml.WriteAttributeString("locationId", Component.StringMetaValue("locationId"));
                            xml.WriteAttributeString("title", Component.StringValue("title"));
                            xml.WriteAttributeString("summary", Component.StringValue("summary"));
                            xml.WriteAttributeString("map", PublishBinary(Component.ComponentMetaValue("map")));
                            xml.WriteAttributeString("follow", Component.ExternalLinkMetaValue("follow"));
                            xml.WriteAttributeString("manager", Component.StringMetaValue("manager"));
                            xml.WriteAttributeString("welcome", Component.StringMetaValue("welcome"));
                            xml.WriteAttributeString("review", Component.ExternalLinkMetaValue("review"));
                            if (Component.ComponentMetaValue("newsletter") != null)
                            {
                                xml.WriteAttributeString("newsletter", PublishBinary(Component.ComponentMetaValue("newsletter")));
                            }
                            if (Component.StringMetaValue("featured").Equals("Yes"))
                            {
                                xml.WriteAttributeString("featured", "Yes");
                            }
                            else
                            {
                                xml.WriteAttributeString("featured", "No");
                            }
                            Component image = Component.ComponentValue("image");
                            if (image != null)
                            {
                                xml.WriteAttributeString("src", PublishBinary(image));
                                xml.WriteAttributeString("altText", image.StringMetaValue("altText"));
                            }

                            xml.WriteElementString("info", Component.StringMetaValue("info"));
                            xml.WriteElementString("weCareUrl", Component.ExternalLinkMetaValue("weCareUrl"));


                            if (Component.EmbeddedValues("features") != null)
                            {
                                IList<ItemFields> features = Component.EmbeddedValues("features");
                                foreach (ItemFields feature in features)
                                {
                                    xml.WriteStartElement("feature");
                                    xml.WriteAttributeString("fName", feature.StringValue("parameter"));
                                    xml.WriteAttributeString("fValue", feature.StringValue("value").Replace("<ul", "<ul style=" + "\"" + "list-style: initial;/"));
                                    xml.WriteEndElement();//feature
                                }
                            }

                            if (Component.StringValues("keys") != null)
                            {
                                IList<String> keys = Component.StringValues("keys");
                                foreach (String key in keys)
                                {
                                    xml.WriteElementString("key", key);
                                }
                            }

                            IList<Component> highlights = Component.ComponentValues("highlights");
                            foreach (Component highlight in highlights)
                            {
                                xml.WriteStartElement("highlight");
                                xml.WriteAttributeString("heading", highlight.StringValue("heading"));
                                IList<Component> rows = highlight.ComponentValues("rows");
                                int size = 100 / rows.Count;
                                string gridClass = "grid-" + size + " mobile-grid-100";
                                xml.WriteAttributeString("gridClass", gridClass);
                                foreach (Component row in rows)
                                {
                                    ItemFields callout = row.EmbeddedMetaValue("callout");
                                    xml.WriteStartElement("row");
                                    xml.WriteAttributeString("calloutId", row.Id);
                                    xml.WriteAttributeString("calloutTitle", callout.StringValue("calloutTitle"));
                                    xml.WriteAttributeString("calloutText", callout.StringValue("calloutText"));
                                    xml.WriteAttributeString("calloutLinkText", callout.StringValue("calloutLinkText"));
                                    xml.WriteAttributeString("calloutImage", PublishBinary(callout.ComponentValue("calloutImage")));
                                    xml.WriteEndElement();//row
                                }
                                xml.WriteEndElement();//higlight
                            }


                            int j = 1;
                            IList<ItemFields> gallery = Component.EmbeddedValues("gallery");
                            xml.WriteStartElement("gallery");
                            foreach (ItemFields galleryModule in gallery)
                            {
                                if (galleryModule.StringValue("type").Equals("Image"))
                                {
                                    Component imageComp = galleryModule.ComponentValue("component");
                                    xml.WriteStartElement("module");
                                    xml.WriteAttributeString("count", j.ToString());
                                    xml.WriteAttributeString("type", "image");
                                    xml.WriteAttributeString("src", "/images/editorial/gallery/0.png");
                                    xml.WriteAttributeString("data-src", PublishBinary(imageComp));
                                    xml.WriteAttributeString("thumbnil", GenerateThumbnail(imageComp, "fthumb", 96, 79));
                                    xml.WriteAttributeString("altText", imageComp.StringMetaValue("altText"));
                                    xml.WriteEndElement(); //module
                                    j++;
                                }
                                if (galleryModule.StringValue("type").Equals("Video"))
                                {
                                    Component videoComp = galleryModule.ComponentValue("component");
                                    Component thumbImageComp = videoComp.ComponentMetaValue("thumbnailImage");
                                    xml.WriteStartElement("module");
                                    xml.WriteAttributeString("count", j.ToString());
                                    xml.WriteAttributeString("type", "video");
                                    xml.WriteAttributeString("src", PublishBinary(videoComp));
                                    xml.WriteAttributeString("poster", PublishBinary(thumbImageComp));
                                    xml.WriteAttributeString("thumbnil", GenerateThumbnail(thumbImageComp, "fthumb", 96, 79));
                                    xml.WriteAttributeString("altText", videoComp.StringMetaValue("altText"));
                                    xml.WriteEndElement(); //module
                                    j++;
                                }
                            }
                            xml.WriteEndElement();//gallery

                            xml.WriteEndElement();//item
                        }



                        if (Component.Schema.Title.Equals("TAHR - Room"))
                        {

                            OrganizationalItem folder = engine.GetObject(Component.OrganizationalItem.Id) as OrganizationalItem;

                            xml.WriteStartElement("item");
                            xml.WriteAttributeString("uri", Component.Id);
                            xml.WriteAttributeString("id", itemId.Split('-')[1]);
                            xml.WriteAttributeString("index", Component.Title.Substring(0, 3));
                            xml.WriteAttributeString("schema", Component.Schema.Title.Split('-')[1].TrimStart());
                            //xml.WriteAttributeString("hotelId", Component.KeywordMetaValue("hotel").Key);
                            //xml.WriteAttributeString("hotel", Component.KeywordMetaValue("hotel").Description);
                            xml.WriteAttributeString("hotel", folder.KeywordMetaValue("hotel").Description);
                            xml.WriteAttributeString("hotelId", folder.KeywordMetaValue("hotel").Key);
                            xml.WriteAttributeString("title", Component.StringValue("title"));
                            xml.WriteAttributeString("summary", Component.StringValue("summary"));
                            xml.WriteAttributeString("description", Component.StringValue("description"));
                            Component image = Component.ComponentValue("image");
                            if (image != null)
                            {
                                xml.WriteAttributeString("src", PublishBinary(image));
                                xml.WriteAttributeString("altText", image.StringMetaValue("altText"));
                            }

                            ItemFields callout = Component.EmbeddedMetaValue("callout");
                            if (callout != null)
                            {
                                xml.WriteAttributeString("calloutId", Component.Id.ToString());
                                xml.WriteAttributeString("calloutTitle", callout.StringValue("calloutTitle"));
                                xml.WriteAttributeString("calloutText", callout.StringValue("calloutText"));
                                xml.WriteAttributeString("calloutLinkText", callout.StringValue("calloutLinkText"));
                                if (callout.ComponentValue("calloutImage") != null)
                                {
                                    xml.WriteAttributeString("calloutImage", PublishBinary(callout.ComponentValue("calloutImage")));
                                }
                                else
                                {
                                    xml.WriteAttributeString("calloutImage", PublishBinary(image));
                                }
                            }

                            IList<String> features = Component.StringValues("feature");
                            foreach (String feature in features)
                            {
                                xml.WriteElementString("feature", feature);
                            }

                            IList<String> parameters = Component.StringValues("parameter");
                            foreach (String parameter in parameters)
                            {
                                xml.WriteElementString("parameter", parameter);
                            }

                            if (Component.ComponentValues("gallery") != null)
                            {
                                IList<Component> list = Component.ComponentValues("gallery");
                                int j = 1;
                                foreach (Component imageComp in list)
                                {
                                    xml.WriteStartElement("module");
                                    xml.WriteAttributeString("src", PublishBinary(imageComp));
                                    xml.WriteAttributeString("altText", imageComp.StringMetaValue("altText"));
                                    xml.WriteEndElement();//module
                                    j++;
                                }
                            }

                            if (Component.ComponentValue("facility") != null)
                            {
                                Component facilityComp = Component.ComponentValue("facility");
                                xml.WriteStartElement("facilities");
                                xml.WriteAttributeString("heading", facilityComp.StringValue("heading"));
                                IList<ItemFields> facilities = facilityComp.EmbeddedValues("rows");
                                foreach (ItemFields facility in facilities)
                                {
                                    xml.WriteStartElement("facility");
                                    xml.WriteAttributeString("parameter", facility.StringValue("parameter"));
                                    IList<String> values = facility.StringValues("value");
                                    foreach (string value in values)
                                    {
                                        xml.WriteElementString("value", value);
                                    }
                                    xml.WriteEndElement();//facility
                                }
                                xml.WriteEndElement();//facilities
                            }
                            else
                            {
                                List<ItemFields> facilities = (List<ItemFields>)Component.EmbeddedValues("facilities");
                                xml.WriteStartElement("facilities");
                                foreach (ItemFields facility in facilities)
                                {
                                    xml.WriteStartElement("facility");
                                    xml.WriteAttributeString("parameter", facility.StringValue("parameter"));
                                    IList<String> values = facility.StringValues("value");
                                    foreach (string value in values)
                                    {
                                        xml.WriteElementString("value", value);
                                    }
                                    xml.WriteEndElement();//facility
                                }
                                xml.WriteEndElement();//facilities

                            }

                            xml.WriteEndElement();//item
                        }


                        if (Component.Schema.Title.Equals("TAHR - Apartment"))
                        {

                            xml.WriteStartElement("item");
                            xml.WriteAttributeString("uri", Component.Id);
                            xml.WriteAttributeString("id", itemId.Split('-')[1]);
                            xml.WriteAttributeString("schema", Component.Schema.Title.Split('-')[1].TrimStart());
                            xml.WriteAttributeString("hotelId", Component.KeywordMetaValue("hotel").Key);
                            xml.WriteAttributeString("hotel", Component.KeywordMetaValue("hotel").Description);
                            xml.WriteAttributeString("title", Component.StringValue("title"));
                            xml.WriteAttributeString("summary", Component.StringValue("summary"));
                            xml.WriteAttributeString("description", Component.StringValue("description"));
                            xml.WriteAttributeString("contact", Component.StringMetaValue("contact"));
                            xml.WriteAttributeString("email", Component.StringMetaValue("email"));

                            Component image = Component.ComponentValue("image");
                            if (image != null)
                            {
                                xml.WriteAttributeString("src", PublishBinary(image));
                                xml.WriteAttributeString("altText", image.StringMetaValue("altText"));
                            }

                            IList<String> features = Component.StringValues("features");
                            foreach (String feature in features)
                            {
                                xml.WriteElementString("feature", feature);
                            }

                            int j = 1;
                            xml.WriteStartElement("gallery");
                            IList<Component> gallery = Component.ComponentValues("gallery");
                            foreach (Component imageComp in gallery)
                            {
                                xml.WriteStartElement("module");
                                xml.WriteAttributeString("count", j.ToString());
                                xml.WriteAttributeString("type", "image");
                                xml.WriteAttributeString("src", "/images/editorial/gallery/0.png");
                                xml.WriteAttributeString("data-src", PublishBinary(imageComp));
                                xml.WriteAttributeString("thumbnil", GenerateThumbnail(imageComp, "fthumb", 96, 79));
                                xml.WriteAttributeString("altText", imageComp.StringMetaValue("altText"));
                                xml.WriteEndElement();//module
                                j++;
                            }
                            xml.WriteEndElement();//gallery


                            IList<Component> list = Component.ComponentValues("explore");
                            xml.WriteStartElement("callouts");
                            foreach (Component comp in list)
                            {
                                ItemFields callout = comp.EmbeddedMetaValue("callout");
                                if (callout != null)
                                {
                                    xml.WriteStartElement("row");
                                    xml.WriteAttributeString("calloutId", comp.Id.ToString());
                                    xml.WriteAttributeString("calloutTitle", callout.StringValue("calloutTitle"));
                                    xml.WriteAttributeString("calloutText", callout.StringValue("calloutText"));
                                    xml.WriteAttributeString("calloutLinkText", callout.StringValue("calloutLinkText"));
                                    if (callout.ComponentValue("calloutImage") != null)
                                    {
                                        xml.WriteAttributeString("calloutImage", PublishBinary(callout.ComponentValue("calloutImage")));
                                    }
                                    else
                                    {
                                        xml.WriteAttributeString("calloutImage", PublishBinary(comp.ComponentValue("image")));
                                    }
                                    xml.WriteEndElement();//row
                                }
                            }
                            xml.WriteEndElement();//callouts


                            xml.WriteEndElement();//item
                        }


                        if (Component.Schema.Title.Equals("TAHR - Residence Amenity"))
                        {

                            xml.WriteStartElement("item");
                            xml.WriteAttributeString("uri", Component.Id);
                            xml.WriteAttributeString("id", itemId.Split('-')[1]);
                            xml.WriteAttributeString("schema", Component.Schema.Title.Split('-')[1].TrimStart());
                            xml.WriteAttributeString("hotelId", Component.KeywordMetaValue("hotel").Key);
                            xml.WriteAttributeString("hotel", Component.KeywordMetaValue("hotel").Description);
                            xml.WriteAttributeString("title", Component.StringValue("title"));
                            xml.WriteAttributeString("description", Component.StringValue("description"));

                            Component image = Component.ComponentValue("image");
                            if (image != null)
                            {
                                xml.WriteAttributeString("src", PublishBinary(image));
                                xml.WriteAttributeString("altText", image.StringMetaValue("altText"));
                            }

                            IList<ItemFields> amenities = Component.EmbeddedValues("amenity");
                            foreach (ItemFields amenity in amenities)
                            {
                                xml.WriteStartElement("amenity");
                                xml.WriteAttributeString("name", amenity.StringValue("param"));
                                xml.WriteAttributeString("value", amenity.StringValue("value"));
                                xml.WriteEndElement();//amenity
                            }
                            ItemFields feature = Component.EmbeddedValue("features");
                            xml.WriteStartElement("features");
                            xml.WriteAttributeString("heading", feature.StringValue("parameter"));
                            IList<String> features = feature.StringValues("value");
                            foreach (String value in features)
                            {
                                xml.WriteElementString("value", value);
                            }
                            xml.WriteEndElement();//features

                            ItemFields service = Component.EmbeddedValue("services");
                            xml.WriteStartElement("services");
                            xml.WriteAttributeString("heading", service.StringValue("parameter"));
                            IList<String> services = service.StringValues("value");
                            foreach (String value in services)
                            {
                                xml.WriteElementString("value", value);
                            }
                            xml.WriteEndElement();//services

                            xml.WriteEndElement();//item
                        }



                        if (Component.Schema.Title.Equals("TAHR - Residence"))
                        {

                            xml.WriteStartElement("item");
                            xml.WriteAttributeString("uri", Component.Id);
                            xml.WriteAttributeString("id", itemId.Split('-')[1]);
                            xml.WriteAttributeString("schema", Component.Schema.Title.Split('-')[1].TrimStart());
                            xml.WriteAttributeString("hotelId", Component.KeywordMetaValue("hotel").Key);
                            xml.WriteAttributeString("hotel", Component.KeywordMetaValue("hotel").Description);
                            xml.WriteAttributeString("catName", Component.KeywordMetaValue("category").Description);
                            xml.WriteAttributeString("catKey", Component.KeywordMetaValue("category").Key);
                            xml.WriteAttributeString("title", Component.StringValue("title"));
                            xml.WriteAttributeString("heading", Component.StringValue("heading"));
                            xml.WriteAttributeString("summary", Component.StringValue("summary"));
                            xml.WriteAttributeString("description", Component.StringValue("description"));

                            Component image = Component.ComponentValue("image");
                            if (image != null)
                            {
                                xml.WriteAttributeString("src", PublishBinary(image));
                                xml.WriteAttributeString("altText", image.StringMetaValue("altText"));
                            }

                            ItemFields callout = Component.EmbeddedMetaValue("callout");
                            if (callout != null)
                            {
                                xml.WriteAttributeString("calloutId", Component.Id.ToString());
                                xml.WriteAttributeString("calloutTitle", callout.StringValue("calloutTitle"));
                                xml.WriteAttributeString("calloutText", callout.StringValue("calloutText"));
                                xml.WriteAttributeString("calloutLinkText", callout.StringValue("calloutLinkText"));
                                if (callout.ComponentValue("calloutImage") != null)
                                {
                                    xml.WriteAttributeString("calloutImage", PublishBinary(callout.ComponentValue("calloutImage")));
                                }
                                else
                                {
                                    xml.WriteAttributeString("calloutImage", PublishBinary(image));
                                }
                            }

                            IList<String> features = Component.StringValues("features");
                            foreach (String feature in features)
                            {
                                xml.WriteElementString("feature", feature);
                            }


                            if (Component.StringValues("amenity") != null)
                            {
                                IList<String> amenities = Component.StringValues("amenity");
                                foreach (String amenity in amenities)
                                {
                                    xml.WriteElementString("amenity", amenity);
                                }
                            }

                            if (Component.ComponentValues("gallery") != null)
                            {
                                IList<Component> list = Component.ComponentValues("gallery");
                                int j = 1;
                                foreach (Component imageComp in list)
                                {
                                    xml.WriteStartElement("module");
                                    xml.WriteAttributeString("src", PublishBinary(imageComp));
                                    xml.WriteAttributeString("altText", imageComp.StringMetaValue("altText"));
                                    xml.WriteEndElement();//module
                                    j++;
                                }
                            }

                            xml.WriteEndElement();//item
                        }



                        if (Component.Schema.Title.Equals("TAHR - Restaurent"))
                        {

                            xml.WriteStartElement("item");
                            xml.WriteAttributeString("uri", Component.Id);
                            xml.WriteAttributeString("id", itemId.Split('-')[1]);
                            xml.WriteAttributeString("schema", Component.Schema.Title.Split('-')[1].TrimStart());
                            xml.WriteAttributeString("hotelId", Component.KeywordMetaValue("hotel").Key);
                            xml.WriteAttributeString("hotel", Component.KeywordMetaValue("hotel").Description);
                            if (Regex.IsMatch(Component.Title, @"^[0-9]+[.]{1}.*$"))
                            {
                                xml.WriteAttributeString("sortid", Component.Title.Substring(0, Component.Title.IndexOf(".")));
                            }
                            else
                            {
                                xml.WriteAttributeString("sortid", "999");
                            }
                            if (Component.KeywordMetaValue("experience") != null)
                            {
                                xml.WriteAttributeString("catKey", Component.KeywordMetaValue("experience").Key);
                                xml.WriteAttributeString("catName", Component.KeywordMetaValue("experience").Description);
                            }
                            xml.WriteAttributeString("title", Component.StringValue("title"));
                            xml.WriteAttributeString("heading", Component.StringValue("heading"));
                            xml.WriteAttributeString("cuisine", Component.StringValue("cuisine"));
                            xml.WriteAttributeString("summary", Component.StringValue("summary"));
                            xml.WriteAttributeString("description", Component.StringValue("description"));
                            xml.WriteAttributeString("location", Component.StringValue("location"));
                            xml.WriteAttributeString("dressCode", Component.StringValue("dress"));
                            xml.WriteAttributeString("email", Component.StringMetaValue("email"));
                            xml.WriteAttributeString("contact", Component.StringMetaValue("contact"));

                            if (Component.StringMetaValue("show").Equals("Yes"))
                            {
                                xml.WriteAttributeString("showReservation", "Yes");
                            }

                            if (null != Component.NumberMetaValue("areaId"))
                            {
                                xml.WriteAttributeString("area", Component.NumberMetaValue("areaId").ToString());
                            }
                            if (!String.IsNullOrEmpty(Component.StringMetaValue("ibuId")))
                            {
                                xml.WriteAttributeString("ibu", Component.StringMetaValue("ibuId"));
                            }


                            Component image = Component.ComponentValue("image");
                            if (image != null)
                            {
                                xml.WriteAttributeString("src", PublishBinary(image));
                                xml.WriteAttributeString("altText", image.StringMetaValue("altText"));
                            }

                            ItemFields callout = Component.EmbeddedMetaValue("callout");
                            if (callout != null)
                            {
                                xml.WriteAttributeString("calloutId", Component.Id.ToString());
                                xml.WriteAttributeString("calloutTitle", callout.StringValue("calloutTitle"));
                                xml.WriteAttributeString("calloutText", callout.StringValue("calloutText"));
                                xml.WriteAttributeString("calloutLinkText", callout.StringValue("calloutLinkText"));
                                if (callout.ComponentValue("calloutImage") != null)
                                {
                                    xml.WriteAttributeString("calloutImage", PublishBinary(callout.ComponentValue("calloutImage")));
                                }
                                else
                                {
                                    xml.WriteAttributeString("calloutImage", PublishBinary(image));
                                }
                            }

                            IList<String> openings = Component.StringValues("opening");
                            foreach (String opening in openings)
                            {
                                xml.WriteElementString("opening", opening);
                            }

                            Component menu = Component.ComponentValue("menu");
                            if (menu != null)
                            {
                                xml.WriteStartElement("menu");
                                xml.WriteAttributeString("src", PublishBinary(menu));
                                xml.WriteAttributeString("altText", menu.StringMetaValue("altText"));
                                xml.WriteEndElement(); //download
                            }


                            if (Component.ComponentValue("download") != null)
                            {
                                Component download = Component.ComponentValue("download");
                                xml.WriteStartElement("download");
                                xml.WriteAttributeString("downloadFile", PublishBinary(download));
                                xml.WriteAttributeString("downloadTitle", download.StringMetaValue("title"));
                                xml.WriteAttributeString("downloadinfo", download.StringMetaValue("info"));
                                xml.WriteEndElement(); //download
                            }

                            ItemFields interior = Component.EmbeddedValue("interior");
                            if (interior != null)
                            {
                                xml.WriteStartElement("interior");
                                xml.WriteAttributeString("heading", interior.StringValue("heading"));
                                xml.WriteAttributeString("description", getHtml(interior.StringValue("description")));
                                Component iImage = interior.ComponentValue("image");
                                if (iImage != null)
                                {
                                    xml.WriteAttributeString("src", PublishBinary(iImage));
                                    xml.WriteAttributeString("altText", iImage.StringMetaValue("altText"));
                                }
                                xml.WriteEndElement();//interior
                            }


                            ItemFields dishes = Component.EmbeddedValue("dishes");
                            if (dishes != null)
                            {
                                xml.WriteStartElement("dishes");
                                xml.WriteAttributeString("heading", dishes.StringValue("heading"));
                                xml.WriteAttributeString("description", dishes.StringValue("description"));

                                IList<ItemFields> carousels = dishes.EmbeddedValues("carousels");
                                int i = 1;
                                foreach (ItemFields carousel in carousels)
                                {
                                    if (carousel != null)
                                    {
                                        xml.WriteStartElement("carousel");
                                        xml.WriteAttributeString("no", i.ToString());
                                        xml.WriteAttributeString("headingOne", carousel.StringValue("headingOne"));
                                        xml.WriteAttributeString("headingTwo", carousel.StringValue("headingTwo"));
                                        Component cImage = carousel.ComponentValue("image");
                                        if (cImage != null && cImage.BinaryContent != null)
                                        {
                                            xml.WriteAttributeString("src", PublishBinary(cImage));
                                            xml.WriteAttributeString("altText", cImage.StringMetaValue("altText"));
                                        }
                                        xml.WriteEndElement();//carousel
                                        i++;
                                    }
                                }
                                xml.WriteEndElement();//dishes
                            }

                            if (Component.KeywordMetaValues("category") != null)
                            {
                                IList<Keyword> categories = Component.KeywordMetaValues("category");
                                foreach (Keyword category in categories)
                                {
                                    xml.WriteStartElement("category");
                                    xml.WriteAttributeString("catName", category.Description);
                                    xml.WriteAttributeString("catKey", category.Key);
                                    xml.WriteEndElement();//category
                                }
                            }


                            if (Component.ComponentValues("gallery") != null)
                            {
                                IList<Component> gallery = Component.ComponentValues("gallery");
                                foreach (Component imageComp in gallery)
                                {
                                    xml.WriteStartElement("module");
                                    xml.WriteAttributeString("src", PublishBinary(imageComp));
                                    xml.WriteAttributeString("altText", imageComp.StringMetaValue("altText"));
                                    xml.WriteEndElement();//module
                                }
                            }

                            xml.WriteEndElement();//item
                        }






                        if (Component.Schema.Title.Equals("TAHR - Spa"))
                        {

                            xml.WriteStartElement("item");
                            xml.WriteAttributeString("uri", Component.Id);
                            xml.WriteAttributeString("id", itemId.Split('-')[1]);
                            xml.WriteAttributeString("schema", Component.Schema.Title.Split('-')[1].TrimStart());
                            xml.WriteAttributeString("hotelId", Component.KeywordMetaValue("hotel").Key);
                            xml.WriteAttributeString("hotel", Component.KeywordMetaValue("hotel").Description);
                            xml.WriteAttributeString("title", Component.StringValue("title"));
                            xml.WriteAttributeString("summary", Component.StringValue("summary"));
                            xml.WriteAttributeString("heading", Component.StringValue("heading"));
                            xml.WriteAttributeString("description", Component.StringValue("description"));
                            xml.WriteAttributeString("email", Component.StringMetaValue("email"));

                            Component image = Component.ComponentValue("image");
                            if (image != null)
                            {
                                xml.WriteAttributeString("src", PublishBinary(image));
                                xml.WriteAttributeString("altText", image.StringMetaValue("altText"));
                            }

                            xml.WriteEndElement();//item
                        }



                        if (Component.Schema.Title.Equals("TAHR - Treatment"))
                        {

                            xml.WriteStartElement("item");
                            xml.WriteAttributeString("uri", Component.Id);
                            xml.WriteAttributeString("id", itemId.Split('-')[1]);
                            xml.WriteAttributeString("schema", Component.Schema.Title.Split('-')[1].TrimStart());
                            xml.WriteAttributeString("hotelId", Component.KeywordMetaValue("hotel").Key);
                            xml.WriteAttributeString("hotel", Component.KeywordMetaValue("hotel").Description);
                            xml.WriteAttributeString("catName", Component.KeywordMetaValue("category").Description);
                            xml.WriteAttributeString("catKey", Component.KeywordMetaValue("category").Key);
                            xml.WriteAttributeString("title", Component.StringValue("title"));
                            xml.WriteAttributeString("heading", Component.StringValue("heading"));
                            xml.WriteAttributeString("summary", Component.StringValue("summary"));
                            xml.WriteAttributeString("description", Component.StringValue("description"));
                            xml.WriteAttributeString("location", Component.StringValue("location"));
                            xml.WriteAttributeString("opening", Component.StringValue("opening"));
                            xml.WriteAttributeString("email", Component.StringMetaValue("email"));
                            xml.WriteAttributeString("contact", Component.StringMetaValue("contact"));

                            Component image = Component.ComponentValue("image");
                            if (image != null)
                            {
                                xml.WriteAttributeString("src", PublishBinary(image));
                                xml.WriteAttributeString("altText", image.StringMetaValue("altText"));
                            }

                            ItemFields callout = Component.EmbeddedMetaValue("callout");
                            if (callout != null)
                            {
                                xml.WriteAttributeString("calloutId", Component.Id.ToString());
                                xml.WriteAttributeString("calloutTitle", callout.StringValue("calloutTitle"));
                                xml.WriteAttributeString("calloutText", callout.StringValue("calloutText"));
                                xml.WriteAttributeString("calloutLinkText", callout.StringValue("calloutLinkText"));
                                if (callout.ComponentValue("calloutImage") != null)
                                {
                                    xml.WriteAttributeString("calloutImage", PublishBinary(callout.ComponentValue("calloutImage")));
                                }
                                else
                                {
                                    xml.WriteAttributeString("calloutImage", PublishBinary(image));
                                }
                            }


                            if (Component.ComponentValue("download") != null)
                            {
                                Component download = Component.ComponentValue("download");
                                xml.WriteStartElement("download");
                                xml.WriteAttributeString("downloadFile", PublishBinary(download));
                                xml.WriteAttributeString("downloadTitle", download.StringMetaValue("title"));
                                xml.WriteAttributeString("downloadinfo", download.StringMetaValue("info"));
                                xml.WriteEndElement(); //download
                            }

                            if (Component.StringValues("keys") != null)
                            {
                                xml.WriteElementString("keyTitle", Component.StringValue("keyTitle"));
                                IList<String> keys = Component.StringValues("keys");
                                foreach (String key in keys)
                                {
                                    xml.WriteElementString("key", key);
                                }
                            }



                            IList<ItemFields> treatments = Component.EmbeddedValues("treatment");
                            foreach (ItemFields treatment in treatments)
                            {
                                xml.WriteStartElement("treatment");
                                xml.WriteAttributeString("title", treatment.StringValue("title"));
                                xml.WriteAttributeString("description", treatment.StringValue("description"));
                                IList<ItemFields> sections = treatment.EmbeddedValues("section");
                                foreach (ItemFields section in sections)
                                {
                                    xml.WriteStartElement("section");
                                    xml.WriteAttributeString("name", section.StringValue("name"));
                                    xml.WriteAttributeString("description", section.StringValue("description"));
                                    IList<ItemFields> treats = section.EmbeddedValues("val");
                                    foreach (ItemFields treat in treats)
                                    {
                                        xml.WriteStartElement("treat");
                                        xml.WriteAttributeString("param", treat.StringValue("param"));
                                        xml.WriteAttributeString("value", treat.StringValue("value"));
                                        xml.WriteEndElement();//treat
                                    }
                                    xml.WriteEndElement();//section
                                }
                                xml.WriteEndElement();//treatment
                            }

                            ItemFields practice = Component.EmbeddedValue("practice");
                            if (practice != null)
                            {
                                xml.WriteStartElement("practice");
                                xml.WriteAttributeString("title", practice.StringValue("title"));
                                xml.WriteAttributeString("description", practice.StringValue("description"));

                                IList<ItemFields> psections = practice.EmbeddedValues("section");

                                foreach (ItemFields psection in psections)
                                {
                                    xml.WriteStartElement("section");
                                    xml.WriteAttributeString("name", psection.StringValue("param"));
                                    xml.WriteAttributeString("description", psection.StringValue("value"));
                                    xml.WriteEndElement();//section
                                }
                                xml.WriteEndElement();//practice
                            }

                            xml.WriteEndElement();//item
                        }


                        if (Component.Schema.Title.Equals("TAHR - Event"))
                        {

                            xml.WriteStartElement("item");
                            xml.WriteAttributeString("uri", Component.Id);
                            xml.WriteAttributeString("id", itemId.Split('-')[1]);
                            xml.WriteAttributeString("schema", Component.Schema.Title.Split('-')[1].TrimStart());
                            xml.WriteAttributeString("hotelId", Component.KeywordMetaValue("hotel").Key);
                            xml.WriteAttributeString("hotel", Component.KeywordMetaValue("hotel").Description);
                            xml.WriteAttributeString("title", Component.StringValue("title"));
                            xml.WriteAttributeString("heading", Component.StringValue("heading"));
                            xml.WriteAttributeString("summary", Component.StringValue("summary"));
                            xml.WriteAttributeString("description", Component.StringValue("description"));

                            Component image = Component.ComponentValue("image");
                            if (image != null)
                            {
                                xml.WriteAttributeString("src", PublishBinary(image));
                                xml.WriteAttributeString("altText", image.StringMetaValue("altText"));
                            }

                            IList<Component> items = Component.ComponentValues("item");
                            foreach (Component item in items)
                            {
                                xml.WriteStartElement("comp");
                                xml.WriteAttributeString("title", item.StringValue("title"));
                                xml.WriteAttributeString("uri", item.Id);
                                xml.WriteEndElement();//comp
                            }

                            xml.WriteEndElement();//item
                        }



                        if (Component.Schema.Title.Equals("TAHR - Offering"))
                        {

                            xml.WriteStartElement("item");
                            xml.WriteAttributeString("uri", Component.Id);
                            xml.WriteAttributeString("id", itemId.Split('-')[1]);
                            xml.WriteAttributeString("schema", Component.Schema.Title.Split('-')[1].TrimStart());
                            if (Component.KeywordMetaValue("hotel") != null)
                            {
                                xml.WriteAttributeString("hotel", Component.KeywordMetaValue("hotel").Description);
                                xml.WriteAttributeString("hotelId", Component.KeywordMetaValue("hotel").Key);
                            }
                            else
                            {
                                xml.WriteAttributeString("hotel", "");
                                xml.WriteAttributeString("hotelId", "");
                            }
                            xml.WriteAttributeString("catName", Component.KeywordMetaValue("category").Description);
                            xml.WriteAttributeString("catKey", Component.KeywordMetaValue("category").Key);
                            xml.WriteAttributeString("type", Component.KeywordMetaValue("type").Description);
                            xml.WriteAttributeString("typeId", Component.KeywordMetaValue("type").Key);
                            xml.WriteAttributeString("title", Component.StringValue("title"));
                            xml.WriteAttributeString("heading", Component.StringValue("heading"));
                            xml.WriteAttributeString("summary", Component.StringValue("summary"));
                            xml.WriteAttributeString("description", replaceHref(Component.StringValue("description")));

                            Component image = Component.ComponentValue("image");
                            if (image != null)
                            {
                                xml.WriteAttributeString("src", PublishBinary(image));
                                xml.WriteAttributeString("altText", image.StringMetaValue("altText"));
                            }

                            ItemFields callout = Component.EmbeddedMetaValue("callout");
                            if (callout != null)
                            {
                                xml.WriteAttributeString("calloutId", Component.Id.ToString());
                                xml.WriteAttributeString("calloutTitle", callout.StringValue("calloutTitle"));
                                xml.WriteAttributeString("calloutText", callout.StringValue("calloutText"));
                                xml.WriteAttributeString("calloutLinkText", callout.StringValue("calloutLinkText"));
                                if (callout.ComponentValue("calloutImage") != null)
                                {
                                    xml.WriteAttributeString("calloutImage", PublishBinary(callout.ComponentValue("calloutImage")));
                                }
                                else
                                {
                                    xml.WriteAttributeString("calloutImage", PublishBinary(image));
                                }
                            }


                            if (Component.ComponentValue("download") != null)
                            {
                                Component download = Component.ComponentValue("download");
                                xml.WriteStartElement("download");
                                xml.WriteAttributeString("downloadFile", PublishBinary(download));
                                xml.WriteAttributeString("downloadTitle", download.StringMetaValue("title"));
                                xml.WriteAttributeString("downloadinfo", download.StringMetaValue("info"));
                                xml.WriteEndElement(); //download
                            }

                            xml.WriteEndElement();//item
                        }


                        if (Component.Schema.Title.Equals("TAHR - Event Venue"))
                        {

                            xml.WriteStartElement("item");
                            xml.WriteAttributeString("uri", Component.Id);
                            xml.WriteAttributeString("index", Component.Title.Split('.')[0].TrimStart());
                            xml.WriteAttributeString("id", itemId.Split('-')[1]);
                            xml.WriteAttributeString("schema", Component.Schema.Title.Split('-')[1].TrimStart());
                            xml.WriteAttributeString("hotelId", Component.KeywordMetaValue("hotel").Key);
                            xml.WriteAttributeString("hotel", Component.KeywordMetaValue("hotel").Description);
                            xml.WriteAttributeString("title", Component.StringValue("title"));
                            xml.WriteAttributeString("bsummary", Component.StringValue("bdescription"));
                            xml.WriteAttributeString("lsummary", Component.StringValue("ldescription"));
                            Component image = Component.ComponentValue("image");
                            if (image != null)
                            {
                                xml.WriteAttributeString("src", PublishBinary(image));
                                xml.WriteAttributeString("altText", image.StringMetaValue("altText"));
                            }

                            ItemFields callout = Component.EmbeddedMetaValue("callout");
                            if (callout != null)
                            {
                                xml.WriteAttributeString("calloutId", Component.Id.ToString());
                                xml.WriteAttributeString("calloutTitle", callout.StringValue("calloutTitle"));
                                xml.WriteAttributeString("calloutText", callout.StringValue("calloutText"));
                                xml.WriteAttributeString("calloutLinkText", callout.StringValue("calloutLinkText"));
                                if (callout.ComponentValue("calloutImage") != null)
                                {
                                    xml.WriteAttributeString("calloutImage", PublishBinary(callout.ComponentValue("calloutImage")));
                                }
                                else
                                {
                                    xml.WriteAttributeString("calloutImage", PublishBinary(image));
                                }
                            }

                            IList<Keyword> categories = Component.KeywordMetaValues("category");
                            foreach (Keyword category in categories)
                            {
                                xml.WriteStartElement("category");
                                xml.WriteAttributeString("catName", category.Description);
                                xml.WriteAttributeString("catKey", category.Key);
                                xml.WriteEndElement(); //category
                            }

                            if (Component.StringValues("keys") != null)
                            {
                                IList<String> keys = Component.StringValues("keys");
                                foreach (String key in keys)
                                {
                                    xml.WriteElementString("key", key);
                                }
                            }

                            xml.WriteEndElement();//item
                        }


                        if (Component.Schema.Title.Equals("TAHR - Amenity"))
                        {

                            xml.WriteStartElement("item");
                            xml.WriteAttributeString("uri", Component.Id.ToString());
                            xml.WriteAttributeString("id", Component.Id.ToString().Split('-')[1]);
                            xml.WriteAttributeString("schema", Component.Schema.Title.Split('-')[1].TrimStart());
                            xml.WriteAttributeString("title", Component.StringValue("title"));
                            xml.WriteAttributeString("summary", Component.StringValue("description"));
                            xml.WriteAttributeString("hotel", Component.KeywordMetaValue("hotel").Description);
                            xml.WriteAttributeString("hotelId", Component.KeywordMetaValue("hotel").Key);
                            xml.WriteAttributeString("opening", Component.StringValue("opening"));
                            xml.WriteAttributeString("location", Component.StringValue("location"));
                            xml.WriteAttributeString("contact", Component.StringMetaValue("contact"));
                            Component image = Component.ComponentValue("image");
                            if (image != null)
                            {
                                xml.WriteAttributeString("src", PublishBinary(image));
                                xml.WriteAttributeString("altText", image.StringMetaValue("altText"));
                            }

                            IList<String> keys = Component.StringValues("keys");
                            foreach (String key in keys)
                            {
                                xml.WriteElementString("key", key);
                            }

                            IList<ItemFields> links = Component.EmbeddedValues("links");
                            foreach (ItemFields link in links)
                            {
                                if (link != null)
                                {
                                    xml.WriteStartElement("link");
                                    xml.WriteAttributeString("linkText", link.StringValue("linkText"));
                                    xml.WriteAttributeString("externalLink", link.ExternalLinkValue("externalLink"));
                                    xml.WriteEndElement();//link
                                }
                            }
                            xml.WriteEndElement(); //item

                        }


                        if (Component.Schema.Title.Equals("TAHR - Location"))
                        {

                            xml.WriteStartElement("item");
                            xml.WriteAttributeString("uri", Component.Id);
                            xml.WriteAttributeString("id", itemId.Split('-')[1]);
                            xml.WriteAttributeString("schema", Component.Schema.Title.Split('-')[1].TrimStart());
                            xml.WriteAttributeString("title", Component.StringValue("title"));
                            xml.WriteAttributeString("description", Component.StringValue("description"));
                            Component image = Component.ComponentValue("image");
                            if (image != null)
                            {
                                xml.WriteAttributeString("src", PublishBinary(image));
                                xml.WriteAttributeString("altText", image.StringMetaValue("altText"));
                            }

                            IList<Component> list = Component.ComponentValues("list");
                            foreach (Component type in list)
                            {
                                xml.WriteStartElement("type");
                                xml.WriteAttributeString("heading", type.StringValue("heading"));
                                if (!String.IsNullOrEmpty(type.StringValue("description")))
                                {
                                    xml.WriteAttributeString("description", type.StringValue("description"));
                                }
                                IList<Component> places = type.ComponentValues("rows");
                                foreach (Component row in places)
                                {
                                    xml.WriteStartElement("row");
                                    xml.WriteAttributeString("title", row.StringValue("heading"));
                                    xml.WriteAttributeString("summary", row.StringValue("description"));
                                    Component locationImage = row.ComponentValue("image");
                                    if (locationImage != null)
                                    {
                                        xml.WriteAttributeString("src", PublishBinary(locationImage));
                                        xml.WriteAttributeString("altText", locationImage.StringMetaValue("altText"));
                                    }
                                    xml.WriteEndElement();//row
                                }
                                xml.WriteEndElement();//type
                            }

                            xml.WriteEndElement();//item
                        }


                        if (Component.Schema.Title.Equals("TAHR - Offer"))
                        {

                            string strStartDate = "";
                            string strEndDate = "";

                            if (Component.DateMetaValue("startDate") != null && Component.DateMetaValue("startDate").ToString("dd/MM/yyyy") != "01/01/0001")
                                strStartDate = Component.DateMetaValue("startDate").ToString("dd/MM/yyyy");
                            if (Component.DateMetaValue("endDate") != null && Component.DateMetaValue("endDate").ToString("dd/MM/yyyy") != "01/01/0001")
                                strEndDate = Component.DateMetaValue("endDate").ToString("dd/MM/yyyy");

                            xml.WriteStartElement("item");
                            xml.WriteAttributeString("uri", Component.Id);
                            xml.WriteAttributeString("id", itemId.Split('-')[1]);
                            if (!String.IsNullOrEmpty(Component.StringMetaValue("hide")))
                                xml.WriteAttributeString("hide", Component.StringMetaValue("hide"));
                            xml.WriteAttributeString("schema", Component.Schema.Title.Split('-')[1].TrimStart());
                            TextInfo textInfo = new CultureInfo("en-US", false).TextInfo;
                            // xml.WriteAttributeString("title", textInfo.ToTitleCase(Component.StringValue("title")));
                            xml.WriteAttributeString("title", (Component.StringValue("title")));
                            xml.WriteAttributeString("summary", Component.StringValue("summary"));

                            if (!String.IsNullOrEmpty(Component.ExternalLinkValue("link")))
                            {
                                OrganizationalItem folder = engine.GetObject(Component.OrganizationalItem.Id) as OrganizationalItem;
                                folder = folder.OrganizationalItem;
                                //xml.WriteAttributeString("hotel", folder.KeywordMetaValue("hotel").Description);
                                //xml.WriteAttributeString("hotelKey", "https://reservations.theaddress.com/HomePage.aspx?hotelId=" + folder.KeywordMetaValue("hotel").Key);
                                xml.WriteAttributeString("hotelKey", Component.ExternalLinkValue("link"));
                                xml.WriteAttributeString("link", Component.ExternalLinkValue("link"));
                            }
                            if (String.IsNullOrEmpty(Component.ExternalLinkValue("link")))
                            {
                                OrganizationalItem folder = engine.GetObject(Component.OrganizationalItem.Id) as OrganizationalItem;
                                folder = folder.OrganizationalItem;
                                xml.WriteAttributeString("hotelKey", "https://reservations.theaddress.com/HomePage.aspx?hotelId=" + folder.KeywordMetaValue("hotel").Key);
                                xml.WriteAttributeString("link", "");
                            }
                            //to enable reserve table button of offers
                            if (Component.KeywordMetaValue("category").Key.Equals("1"))
                            {

                                if (Component.ComponentValue("component") != null)
                                {
                                    if (null != Component.ComponentValue("component").NumberMetaValue("areaId"))
                                    {
                                        if (!String.IsNullOrEmpty(Component.ComponentValue("component").NumberMetaValue("areaId").ToString()))
                                            xml.WriteAttributeString("area", Component.ComponentValue("component").NumberMetaValue("areaId").ToString());
                                    }
                                    if (!String.IsNullOrEmpty(Component.ComponentValue("component").StringMetaValue("ibuId")))
                                    {
                                        xml.WriteAttributeString("ibu", Component.ComponentValue("component").StringMetaValue("ibuId"));
                                    }
                                }
                            }

                            if (!String.IsNullOrEmpty(Component.StringValue("price")))
                            {
                                xml.WriteAttributeString("price", Component.StringValue("price"));
                            }
                            if (!String.IsNullOrEmpty(Component.StringValue("time")))
                            {
                                xml.WriteAttributeString("time", Component.StringValue("time"));
                            }
                            if (!String.IsNullOrEmpty(Component.StringValue("terms")))
                            {
                                xml.WriteAttributeString("terms", Component.StringValue("terms"));
                            }
                            if (Component.StringMetaValue("all").Equals("Yes"))
                            {
                                xml.WriteAttributeString("all", Component.StringMetaValue("all"));
                            }
                            if (Component.StringMetaValue("featured").Equals("Yes"))
                            {
                                xml.WriteAttributeString("featured", Component.StringMetaValue("featured"));
                                xml.WriteAttributeString("ftitle", Component.StringMetaValue("ftitle"));
                            }
                            if (!String.IsNullOrEmpty(strStartDate))
                            {
                                xml.WriteAttributeString("sortDate", GetSortDate(strStartDate));
                            }
                            else
                            {
                                xml.WriteAttributeString("sortDate", GetSortDate(DateTime.Now.ToString("dd/MM/yyyy")));
                            }
                            Component image = Component.ComponentValue("image");
                            if (image != null)
                            {
                                xml.WriteAttributeString("src", PublishBinary(image));
                            }
                            /*
                        else{
                            image=Component.ComponentValue("component").ComponentValue("image");
                            xml.WriteAttributeString("src", PublishBinary(image));
                        }*/
                            if (!String.IsNullOrEmpty(Component.StringValue("description")))
                            {
                                xml.WriteAttributeString("description", Component.StringValue("description"));
                            }
                            bool contact = false;
                            bool email = false;
                            if (!String.IsNullOrEmpty(Component.StringValue("email")))
                            {
                                xml.WriteAttributeString("email", Component.StringValue("email"));
                                email = true;
                            }
                            if (!String.IsNullOrEmpty(Component.StringValue("contact")))
                            {
                                xml.WriteAttributeString("contact", Component.StringValue("contact"));
                                contact = true;
                            }

                            if (Component.ComponentValue("component") != null)
                            {
                                if (email == false)
                                {
                                    if (!String.IsNullOrEmpty(Component.ComponentValue("component").StringMetaValue("email")))
                                    {
                                        xml.WriteAttributeString("email", Component.ComponentValue("component").StringMetaValue("email"));
                                    }
                                }
                                if (contact == false)
                                {
                                    if (!String.IsNullOrEmpty(Component.ComponentValue("component").StringMetaValue("contact")))
                                    {
                                        xml.WriteAttributeString("contact", Component.ComponentValue("component").StringMetaValue("contact"));
                                    }
                                }
                                xml.WriteAttributeString("compText", Component.ComponentValue("component").StringValue("title"));
                                xml.WriteAttributeString("compId", Component.ComponentValue("component").Id.ToString().Split('-')[1]);
                                xml.WriteAttributeString("component", Component.ComponentValue("component").Id);
                            }

                            xml.WriteAttributeString("calloutId", Component.Id.ToString());
                            xml.WriteAttributeString("calloutTitle", Component.StringValue("title"));
                            string shortSummary = Component.StringValue("summary");
                            if (shortSummary.Length > 130)
                            {
                                shortSummary = shortSummary.Substring(0, 130);
                                shortSummary = shortSummary.Substring(0, shortSummary.LastIndexOf(" "));
                            }
                            xml.WriteAttributeString("calloutText", removeParagraphs(shortSummary));
                            if (image != null)
                            {
                                xml.WriteAttributeString("calloutImage", PublishBinary(image));
                            }


                            xml.WriteStartElement("hotel");
                            xml.WriteAttributeString("hotel", Component.KeywordMetaValue("hotel").Description);
                            xml.WriteAttributeString("hotelId", Component.KeywordMetaValue("hotel").Key);
                            xml.WriteEndElement();//hotel
                            xml.WriteStartElement("category");
                            xml.WriteAttributeString("catName", Component.KeywordMetaValue("category").Description);
                            xml.WriteAttributeString("catKey", Component.KeywordMetaValue("category").Key);
                            xml.WriteEndElement();//category

                            xml.WriteStartElement("date");
                            xml.WriteAttributeString("startDate", strStartDate);
                            xml.WriteAttributeString("endDate", strEndDate);
                            xml.WriteEndElement();//date

                            

                            xml.WriteEndElement();//item
                        }



                        if (Component.Schema.Title.Equals("TAHR - Featured Offer"))
                        {

                            string strStartDate = "";
                            string strEndDate = "";

                            if (Component.DateMetaValue("startDate") != null && Component.DateMetaValue("startDate").ToString("dd/MM/yyyy") != "01/01/0001")
                                strStartDate = Component.DateMetaValue("startDate").ToString("dd/MM/yyyy");
                            if (Component.DateMetaValue("endDate") != null && Component.DateMetaValue("endDate").ToString("dd/MM/yyyy") != "01/01/0001")
                                strEndDate = Component.DateMetaValue("endDate").ToString("dd/MM/yyyy");


                            xml.WriteStartElement("item");
                            xml.WriteAttributeString("uri", Component.Id);
                            xml.WriteAttributeString("id", itemId.Split('-')[1]);
                            if (!String.IsNullOrEmpty(Component.StringMetaValue("hide")))
                                xml.WriteAttributeString("hide", Component.StringMetaValue("hide"));
                            xml.WriteAttributeString("schema", Component.Schema.Title.Split('-')[1].TrimStart());
                            TextInfo textInfo = new CultureInfo("en-US", false).TextInfo;
                            //xml.WriteAttributeString("title", textInfo.ToTitleCase(Component.StringValue("title")));
                            xml.WriteAttributeString("title", (Component.StringValue("title")));
                            xml.WriteAttributeString("summary", Component.StringValue("summary"));
                            if (!String.IsNullOrEmpty(Component.StringValue("terms")))
                            {
                                xml.WriteAttributeString("terms", Component.StringValue("terms"));
                            }
                            if (Component.StringMetaValue("featured").Equals("Yes"))
                            {
                                xml.WriteAttributeString("featured", Component.StringMetaValue("featured"));
                            }

                            if (!String.IsNullOrEmpty(strStartDate))
                            {
                                xml.WriteAttributeString("sortDate", GetSortDate(strStartDate));
                            }
                            else
                            {
                                xml.WriteAttributeString("sortDate", GetSortDate(DateTime.Now.ToString("dd/MM/yyyy")));
                            }

                            Component image = Component.ComponentValue("image");
                            if (image != null)
                            {
                                xml.WriteAttributeString("src", PublishBinary(image));
                                xml.WriteAttributeString("altText", image.StringMetaValue("altText"));
                            }

                            if (!String.IsNullOrEmpty(Component.StringValue("description")))
                            {
                                xml.WriteAttributeString("description", replaceHref(Component.StringValue("description")));
                            }
                            if (!String.IsNullOrEmpty(Component.StringValue("email")))
                            {
                                xml.WriteAttributeString("email", Component.StringValue("email"));
                            }
                            if (!String.IsNullOrEmpty(Component.StringValue("contact")))
                            {
                                xml.WriteAttributeString("contact", Component.StringValue("contact"));
                            }
                            xml.WriteAttributeString("calloutId", Component.Id.ToString());
                            xml.WriteAttributeString("calloutTitle", Component.StringValue("title"));
                            string shortSummary = Component.StringValue("summary");
                            if (shortSummary.Length > 130)
                            {
                                shortSummary = shortSummary.Substring(0, 130);
                                shortSummary = shortSummary.Substring(0, shortSummary.LastIndexOf(" "));
                            }

                            xml.WriteAttributeString("calloutText", removeParagraphs(shortSummary));
                            xml.WriteAttributeString("calloutImage", PublishBinary(Component.ComponentValue("image")));

                            IList<Component> components = Component.ComponentValues("offers");                          

                            if (Component.KeywordMetaValues("hotel").Count > 0)
                            {
                                IList<Keyword> hotels = Component.KeywordMetaValues("hotel");
                                foreach (Keyword hotel in hotels)
                                {
                                    xml.WriteStartElement("hotel");
                                    xml.WriteAttributeString("hotel", hotel.Description);
                                    xml.WriteAttributeString("hotelId", hotel.Key);
                                    xml.WriteEndElement();//hotel
                                }
                            }
                            else
                            {

                                if (components != null)
                                {
                                    string checkHotel = "";
                                    foreach (Component component in components)
                                    {
                                        if (component.Schema.Title.Equals("TAHR - Offer"))
                                        {
                                            if (checkHotel.Contains(component.KeywordMetaValue("hotel").Key) == false)
                                            {
                                                checkHotel = checkHotel + "$" + component.KeywordMetaValue("hotel").Key;
                                                xml.WriteStartElement("hotel");
                                                xml.WriteAttributeString("hotel", component.KeywordMetaValue("hotel").Description);
                                                xml.WriteAttributeString("hotelId", component.KeywordMetaValue("hotel").Key);
                                                xml.WriteEndElement();//hotel
                                            }
                                        }
                                        else
                                        {
                                            IList<Component> icomponents = component.ComponentValues("offers");
                                            if (icomponents != null)
                                            {
                                                foreach (Component icomponent in icomponents)
                                                {
                                                    if (icomponent.Schema.Title.Equals("TAHR - Offer"))
                                                    {
                                                        if (checkHotel.Contains(icomponent.KeywordMetaValue("hotel").Key) == false)
                                                        {
                                                            checkHotel = checkHotel + "$" + icomponent.KeywordMetaValue("hotel").Key;
                                                            xml.WriteStartElement("hotel");
                                                            xml.WriteAttributeString("hotel", icomponent.KeywordMetaValue("hotel").Description);
                                                            xml.WriteAttributeString("hotelId", icomponent.KeywordMetaValue("hotel").Key);
                                                            xml.WriteEndElement();//hotel
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }

                                }
                            }

                            if (Component.KeywordMetaValues("category").Count > 0)
                            {
                                IList<Keyword> categories = Component.KeywordMetaValues("category");
                                foreach (Keyword category in categories)
                                {
                                    xml.WriteStartElement("category");
                                    xml.WriteAttributeString("catName", category.Description);
                                    xml.WriteAttributeString("catKey", category.Key);
                                    xml.WriteEndElement();//category
                                }
                            }
                            else
                            {
                                if (components != null)
                                {
                                    string checkCategory = "";
                                    foreach (Component component in components)
                                    {

                                        if (component.Schema.Title.Equals("TAHR - Offer"))
                                        {
                                            if (checkCategory.Contains(component.KeywordMetaValue("category").Key) == false)
                                            {
                                                checkCategory = checkCategory + "$" + component.KeywordMetaValue("category").Key;
                                                xml.WriteStartElement("category");
                                                xml.WriteAttributeString("catName", component.KeywordMetaValue("category").Description);
                                                xml.WriteAttributeString("catKey", component.KeywordMetaValue("category").Key);
                                                xml.WriteEndElement();//category
                                            }
                                        }
                                        else
                                        {
                                            IList<Component> jcomponents = component.ComponentValues("offers");
                                            if (jcomponents != null)
                                            {
                                                foreach (Component jcomponent in jcomponents)
                                                {
                                                    if (jcomponent.Schema.Title.Equals("TAHR - Offer"))
                                                    {
                                                        if (checkCategory.Contains(jcomponent.KeywordMetaValue("category").Key) == false)
                                                        {
                                                            checkCategory = checkCategory + "$" + jcomponent.KeywordMetaValue("category").Key;
                                                            xml.WriteStartElement("category");
                                                            xml.WriteAttributeString("catName", jcomponent.KeywordMetaValue("category").Description);
                                                            xml.WriteAttributeString("catKey", jcomponent.KeywordMetaValue("category").Key);
                                                            xml.WriteEndElement();//category
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            xml.WriteStartElement("date");
                            xml.WriteAttributeString("startDate", strStartDate);
                            xml.WriteAttributeString("endDate", strEndDate);
                            xml.WriteEndElement();//date

                            foreach (Component component in components)
                            {

                                //publish all inner component as DCP, these are imporatant for listing under outlet as promotions of that entity will not be part of listing elsewhere
                                engine.RenderComponentPresentation(component.Id, new TcmUri(36102, ItemType.ComponentTemplate, Publication.Id.ItemId));

                                if (component.Schema.Title.Equals("TAHR - Offer"))
                                {
                                    xml.WriteStartElement("offer");
                                    xml.WriteAttributeString("uri", component.Id);
                                    xml.WriteAttributeString("id", itemId.Split('-')[1]);
                                    xml.WriteAttributeString("schema", component.Schema.Title.Split('-')[1].TrimStart());
                                    xml.WriteAttributeString("title", (component.StringValue("title")));
                                    //xml.WriteAttributeString("title", textInfo.ToTitleCase(component.StringValue("title")));
                                    xml.WriteAttributeString("summary", component.StringValue("summary"));
                                    if (!String.IsNullOrEmpty(component.ExternalLinkValue("link")))
                                    {
                                        OrganizationalItem folder = engine.GetObject(component.OrganizationalItem.Id) as OrganizationalItem;
                                        folder = folder.OrganizationalItem;
                                        xml.WriteAttributeString("hotelKey", component.ExternalLinkValue("link"));
                                        xml.WriteAttributeString("link", component.ExternalLinkValue("link"));
                                    }
                                    if (String.IsNullOrEmpty(component.ExternalLinkValue("link")))
                                    {
                                        OrganizationalItem folder = engine.GetObject(component.OrganizationalItem.Id) as OrganizationalItem;
                                        folder = folder.OrganizationalItem;
                                        xml.WriteAttributeString("hotelKey", "https://reservations.theaddress.com/HomePage.aspx?hotelId=" + folder.KeywordMetaValue("hotel").Key);
                                        xml.WriteAttributeString("link", "");
                                    }
                                    if (!String.IsNullOrEmpty(component.StringValue("price")))
                                    {
                                        xml.WriteAttributeString("price", component.StringValue("price"));
                                    }
                                    if (!String.IsNullOrEmpty(component.StringValue("time")))
                                    {
                                        xml.WriteAttributeString("time", component.StringValue("time"));
                                    }
                                    if (!String.IsNullOrEmpty(component.StringValue("terms")))
                                    {
                                        xml.WriteAttributeString("terms", component.StringValue("terms"));
                                    }
                                    Component iimage = component.ComponentValue("image");
                                    if (iimage != null)
                                    {
                                        xml.WriteAttributeString("src", PublishBinary(iimage));
                                        xml.WriteAttributeString("altText", image.StringMetaValue("altText"));
                                    }
                                    if (!String.IsNullOrEmpty(component.StringValue("description")))
                                    {
                                        xml.WriteAttributeString("description", component.StringValue("description"));
                                    }


                                    //to enable reserve table button of offers
                                    if (component.KeywordMetaValue("category").Key.Equals("1"))
                                    {

                                        if (component.ComponentValue("component") != null)
                                        {
                                            if (null != component.ComponentValue("component").NumberMetaValue("areaId"))
                                            {
                                                if (!String.IsNullOrEmpty(component.ComponentValue("component").NumberMetaValue("areaId").ToString()))
                                                    xml.WriteAttributeString("area", component.ComponentValue("component").NumberMetaValue("areaId").ToString());
                                            }
                                            if (!String.IsNullOrEmpty(component.ComponentValue("component").StringMetaValue("ibuId")))
                                            {
                                                xml.WriteAttributeString("ibu", component.ComponentValue("component").StringMetaValue("ibuId"));
                                            }
                                        }
                                    }

                                    bool contactc = false;
                                    bool emailc = false;
                                    if (!String.IsNullOrEmpty(component.StringValue("email")))
                                    {
                                        xml.WriteAttributeString("email", component.StringValue("email"));
                                        emailc = true;
                                    }
                                    if (!String.IsNullOrEmpty(component.StringValue("contact")))
                                    {
                                        xml.WriteAttributeString("contact", component.StringValue("contact"));
                                        contactc = true;
                                    }

                                    if (component.ComponentValue("component") != null)
                                    {
                                        if (emailc == false)
                                        {
                                            if (!String.IsNullOrEmpty(component.ComponentValue("component").StringMetaValue("email")))
                                            {
                                                xml.WriteAttributeString("email", component.ComponentValue("component").StringMetaValue("email"));
                                            }
                                        }
                                        if (contactc == false)
                                        {
                                            if (!String.IsNullOrEmpty(component.ComponentValue("component").StringMetaValue("contact")))
                                            {
                                                xml.WriteAttributeString("contact", component.ComponentValue("component").StringMetaValue("contact"));
                                            }
                                        }
                                        xml.WriteAttributeString("compText", component.ComponentValue("component").StringValue("title"));
                                        xml.WriteAttributeString("compId", component.ComponentValue("component").Id.ToString().Split('-')[1]);
                                        xml.WriteAttributeString("component", component.ComponentValue("component").Id);
                                    }

                                    strStartDate = "";
                                    strEndDate = "";

                                    if (component.DateMetaValue("startDate") != null && component.DateMetaValue("startDate").ToString("dd/MM/yyyy") != "01/01/0001")
                                        strStartDate = component.DateMetaValue("startDate").ToString("dd/MM/yyyy");
                                    if (component.DateMetaValue("endDate") != null && component.DateMetaValue("endDate").ToString("dd/MM/yyyy") != "01/01/0001")
                                        strEndDate = component.DateMetaValue("endDate").ToString("dd/MM/yyyy");

                                    xml.WriteStartElement("date");
                                    xml.WriteAttributeString("startDate", strStartDate);
                                    xml.WriteAttributeString("endDate", strEndDate);
                                    xml.WriteEndElement();//date

                                    xml.WriteEndElement();//offer
                                }
                                else
                                {
                                    xml.WriteStartElement("offer");
                                    xml.WriteAttributeString("uri", component.Id);
                                    xml.WriteAttributeString("id", itemId.Split('-')[1]);
                                    xml.WriteAttributeString("schema", component.Schema.Title.Split('-')[1].TrimStart());
                                    xml.WriteAttributeString("title", textInfo.ToTitleCase(component.StringValue("title")));

                                    xml.WriteAttributeString("summary", component.StringValue("summary"));
                                    if (!String.IsNullOrEmpty(component.StringValue("terms")))
                                    {
                                        xml.WriteAttributeString("terms", component.StringValue("terms"));
                                    }
                                    Component iimage = component.ComponentValue("image");
                                    if (iimage != null)
                                    {
                                        xml.WriteAttributeString("src", PublishBinary(iimage));
                                        xml.WriteAttributeString("altText", image.StringMetaValue("altText"));
                                    }
                                    if (!String.IsNullOrEmpty(component.StringValue("description")))
                                    {
                                        xml.WriteAttributeString("description", component.StringValue("description"));
                                    }


                                    if (component.DateMetaValue("startDate") != null && component.DateMetaValue("startDate").ToString("dd/MM/yyyy") != "01/01/0001")
                                        strStartDate = component.DateMetaValue("startDate").ToString("dd/MM/yyyy");
                                    if (component.DateMetaValue("endDate") != null && component.DateMetaValue("endDate").ToString("dd/MM/yyyy") != "01/01/0001")
                                        strEndDate = component.DateMetaValue("endDate").ToString("dd/MM/yyyy");


                                    xml.WriteStartElement("date");
                                    xml.WriteAttributeString("startDate", strStartDate);
                                    xml.WriteAttributeString("endDate", strEndDate);
                                    xml.WriteEndElement();//date

                                    xml.WriteEndElement();//offer
                                }
                            }
                            IList<Component> tabcomponents = Component.ComponentValues("tabs");
                            foreach (Component component in tabcomponents)
                            {
                                if (component.Schema.Title.Equals("TAHR - Tab"))
                                {
                                    
                                    xml.WriteStartElement("tabs");
                                    xml.WriteAttributeString("title", component.StringValue("title"));

                                    Component tabimage = component.ComponentValue("image");
                                    if (tabimage != null)
                                    {
                                        xml.WriteAttributeString("src", PublishBinary(tabimage));
                                        xml.WriteAttributeString("altText", tabimage.StringMetaValue("altText"));
                                    }
                                    if (!String.IsNullOrEmpty(component.StringValue("description")))
                                    {
                                        xml.WriteAttributeString("description", component.StringValue("description"));
                                    }
                                    if (!String.IsNullOrEmpty(component.StringValue("internallinktext")))
                                    {
                                        xml.WriteAttributeString("internallinktext", component.StringValue("internallinktext"));
                                    }
                                    if (!String.IsNullOrEmpty(component.ExternalLinkValue("internallinkurl")))
                                    {
                                        xml.WriteAttributeString("internallinkurl", component.ExternalLinkValue("internallinkurl"));
                                    }
                                    if (!String.IsNullOrEmpty(component.StringValue("externallinktext")))
                                    {
                                        xml.WriteAttributeString("externallinktext", component.StringValue("externallinktext"));
                                    }
                                    if (!String.IsNullOrEmpty(component.ExternalLinkValue("externallinkurl")))
                                    {
                                        xml.WriteAttributeString("externallinkurl", component.ExternalLinkValue("externallinkurl"));
                                    }
                                    //optional
                                    if (!String.IsNullOrEmpty(component.StringValue("price")))
                                    {
                                        xml.WriteAttributeString("price", component.StringValue("price"));
                                    }
                                    if (!String.IsNullOrEmpty(component.StringValue("email")))
                                    {
                                        xml.WriteAttributeString("email", component.StringValue("email"));
                                    }
                                    if (!String.IsNullOrEmpty(component.StringValue("contact")))
                                    {
                                        xml.WriteAttributeString("contact", component.StringValue("contact"));
                                    }
                                    if (!String.IsNullOrEmpty(component.StringValue("terms")))
                                    {
                                        xml.WriteAttributeString("terms", component.StringValue("terms"));
                                    }
                                    if (!String.IsNullOrEmpty(component.DateValue("startDate").ToString()))
                                    {
                                        if (component.DateValue("startDate").ToString("dd/MM/yyyy") != "01/01/0001")
                                        {
                                            xml.WriteAttributeString("startDate", component.DateValue("startDate").ToString("dd/MM/yyyy"));    
                                        }
                                        
                                    }
                                    if (!String.IsNullOrEmpty(component.DateValue("endDate").ToString()))
                                    {
                                        if (component.DateValue("endDate").ToString("dd/MM/yyyy") != "01/01/0001")
                                        {
                                            xml.WriteAttributeString("endDate", component.DateValue("endDate").ToString("dd/MM/yyyy"));    
                                        }
                                        
                                    }
                                    xml.WriteEndElement();//tabs
                                }
                            }
                            xml.WriteEndElement();//item
                        }


                        if (Component.Schema.Title.Equals("TAHR - Content Category"))
                        {
                            OrganizationalItem HotelsFolder = engine.GetObject(Component.OrganizationalItem.Id) as OrganizationalItem;
                            xml.WriteStartElement("list");
                            int k = 1;
                            IList<Component> hotelsList = HotelsFolder.Components(true);
                            foreach (Component comp in hotelsList)
                            {

                                if (comp.Schema.Title.Equals("TAHR - Image"))
                                {
                                    Filter f = new Filter();
                                    f.Conditions["ItemType"] = ItemType.Component;

                                    if (PublishEngine.IsPublished(comp))
                                    {
                                        xml.WriteStartElement("item");
                                        xml.WriteAttributeString("index", k.ToString());
                                        xml.WriteAttributeString("uri", comp.Id.ToString());
                                        string thmbFile = GenerateThumbnail(comp, "thumb", 200, 200);
                                        xml.WriteAttributeString("thumbsrc", thmbFile);
                                        thmbFile = thmbFile.Replace("_", "-");
                                        xml.WriteAttributeString("src", thmbFile.Replace("thumb-", comp.Title + "_"));
                                        xml.WriteAttributeString("altText", comp.StringMetaValue("altText").Replace("-", " "));
                                        xml.WriteEndElement();//item
                                    }

                                    k++;
                                }
                            }
                            xml.WriteEndElement();
                        }




                        if (Component.Schema.Title.Equals("TAHR - Photo Gallery"))
                        {

                            OrganizationalItem ImageFolder = engine.GetObject(Component.OrganizationalItem.Id) as OrganizationalItem;
                            xml.WriteStartElement("item");
                            xml.WriteAttributeString("uri", Component.Id.ToString());
                            xml.WriteAttributeString("schema", Component.Schema.Title.Split('-')[1].TrimStart());
                            xml.WriteAttributeString("hotel", ImageFolder.KeywordMetaValue("hotel").Description);
                            xml.WriteAttributeString("hotelId", ImageFolder.KeywordMetaValue("hotel").Key);
                            xml.WriteAttributeString("src", PublishBinary(Component));
                            if (!String.IsNullOrEmpty(Component.StringMetaValue("altText")))
                            {
                                xml.WriteAttributeString("altText", Component.StringMetaValue("altText").Replace("-", " "));
                            }
                            else
                            {
                                xml.WriteAttributeString("altText", Component.Title.Replace("-", " "));
                            }
                            xml.WriteEndElement();//item
                        }


                        if (Component.Schema.Title.Equals("TAHR - News Ticker"))
                        {

                            xml.WriteStartElement("item");
                            xml.WriteAttributeString("text", Component.StringValue("text"));
                            DateTime startDate = Component.DateValue("startDate");
                            DateTime endDate = Component.DateValue("endDate");
                            if (startDate.ToString("dd/MM/yyyy") != "01/01/0001")
                            {
                                xml.WriteAttributeString("startDate", Component.DateValue("startDate").ToString("dd/MM/yyyy"));
                            }
                            if (endDate.ToString("dd/MM/yyyy") != "01/01/0001")
                            {
                                xml.WriteAttributeString("endDate", Component.DateValue("endDate").ToString("dd/MM/yyyy"));
                            }
                            if (Component.EmbeddedValue("link") != null)
                            {
                                xml.WriteAttributeString("linkText", Component.EmbeddedValue("link").StringValue("linkText"));
                                xml.WriteAttributeString("componentLink ", Component.EmbeddedValue("link").ComponentValue("componentLink").Id);
                            }
                            xml.WriteEndElement();//item
                        }



                        if (Component.Schema.Title.Equals("TAHR - RespakPromo"))
                        {

                            if (Component.EmbeddedValues("code") != null)
                            {
                                xml.WriteStartElement("item");
                                IList<ItemFields> codes = Component.EmbeddedValues("code");
                                foreach (ItemFields code in codes)
                                {
                                    xml.WriteStartElement("code");
                                    xml.WriteAttributeString("text", code.StringValue("text"));
                                    DateTime startDate = code.DateValue("start");
                                    DateTime endDate = code.DateValue("expiry");
                                    if (startDate.ToString("dd/MM/yyyy") != "01/01/0001")
                                    {
                                        xml.WriteAttributeString("startDate", code.DateValue("start").ToString("dd/MM/yyyy"));
                                    }
                                    if (endDate.ToString("dd/MM/yyyy") != "01/01/0001")
                                    {
                                        xml.WriteAttributeString("endDate", code.DateValue("expiry").ToString("dd/MM/yyyy"));
                                    }
                                    xml.WriteEndElement();//code
                                }
                                xml.WriteEndElement();//item
                            }
                        }

                        if (Component.Schema.Title.Equals("TAHR - Job"))
                        {

                            xml.WriteStartElement("item");
                            xml.WriteAttributeString("uri", Component.Id);
                            xml.WriteAttributeString("id", itemId.Split('-')[1]);
                            xml.WriteAttributeString("schema", Component.Schema.Title.Split('-')[1].TrimStart());
                            xml.WriteAttributeString("hotelId", Component.KeywordMetaValue("hotel").Key);
                            xml.WriteAttributeString("hotel", Component.KeywordMetaValue("hotel").Description);
                            xml.WriteAttributeString("catKey", Component.KeywordMetaValue("department").Key);
                            xml.WriteAttributeString("catName", Component.KeywordMetaValue("department").Description);
                            xml.WriteAttributeString("title", Component.StringValue("title"));

                            DateTime endDate = Component.DateMetaValue("endDate");
                            DateTime startDate = DateTime.Now;

                            xml.WriteStartElement("date");
                            if (startDate.ToString("dd/MM/yyyy") != "01/01/0001")
                            {
                                xml.WriteAttributeString("startDate", startDate.ToString("dd/MM/yyyy"));
                            }
                            if (endDate.ToString("dd/MM/yyyy") != "01/01/0001")
                            {
                                xml.WriteAttributeString("endDate", Component.DateMetaValue("endDate").ToString("dd/MM/yyyy"));
                            }
                            xml.WriteEndElement(); //date

                            if (Component.EmbeddedValues("detail") != null)
                            {
                                IList<ItemFields> details = Component.EmbeddedValues("detail");
                                foreach (ItemFields detail in details)
                                {
                                    xml.WriteStartElement("detail");
                                    xml.WriteAttributeString("title", detail.StringValue("title"));
                                    xml.WriteAttributeString("text", getHtml(detail.StringValue("text")));
                                    xml.WriteEndElement();//detail
                                }
                            }

                            xml.WriteEndElement();//item
                        }


                        if (Component.Schema.Title.Equals("TAHR - PressRelease"))
                        {

                            xml.WriteStartElement("item");
                            xml.WriteAttributeString("uri", Component.Id);
                            xml.WriteAttributeString("id", itemId.Split('-')[1]);
                            xml.WriteAttributeString("schema", Component.Schema.Title.Split('-')[1].TrimStart());
                            if (Component.KeywordMetaValue("hotel") != null)
                            {
                                xml.WriteAttributeString("hotel", Component.KeywordMetaValue("hotel").Description);
                                xml.WriteAttributeString("hotelId", Component.KeywordMetaValue("hotel").Key);
                            }
                            else
                            {
                                xml.WriteAttributeString("hotel", "");
                                xml.WriteAttributeString("hotelId", "");
                            }
                            xml.WriteAttributeString("title", Component.StringValue("title"));
                            xml.WriteAttributeString("description", Component.StringValue("description"));
                            Component image = Component.ComponentValue("image");
                            if (image != null)
                            {
                                xml.WriteAttributeString("src", PublishBinary(image));
                                xml.WriteAttributeString("altText", image.StringMetaValue("altText"));
                            }
                            Component linkComp = Component.ComponentValue("link");
                            if (linkComp != null)
                            {
                                xml.WriteAttributeString("linkInfo", linkComp.StringMetaValue("description"));
                                xml.WriteAttributeString("pdf", PublishBinary(linkComp));
                            }

                            DateTime startDate = Component.DateMetaValue("publishDate");
                            if (startDate.ToString("dd/MM/yyyy") != "01/01/0001")
                            {
                                xml.WriteStartElement("date");
                                xml.WriteAttributeString("startDate", startDate.ToString("dd/MM/yyyy"));
                                xml.WriteAttributeString("endDate", "");
                                xml.WriteAttributeString("sortDate", GetSortDate(startDate.ToString("dd/MM/yyyy")));
                                xml.WriteAttributeString("year", GetSortDate(startDate.ToString("dd/MM/yyyy")).Substring(0, 4));
                                xml.WriteEndElement();//item
                            }

                            xml.WriteEndElement();//item
                        }

                        if (Component.Schema.Title.Equals("TAHR - Blogs"))
                        {

                            xml.WriteStartElement("item");
                            xml.WriteAttributeString("uri", Component.Id);
                            xml.WriteAttributeString("id", itemId.Split('-')[1]);
                            xml.WriteAttributeString("schema", Component.Schema.Title.Split('-')[1].TrimStart());
                            if (Component.KeywordMetaValue("blogcategory") != null)
                            {
                                xml.WriteAttributeString("blogcategory", Component.KeywordMetaValue("blogcategory").Description);
                                xml.WriteAttributeString("blogcategoryId", Component.KeywordMetaValue("blogcategory").Key);
                            }
                            else
                            {
                                xml.WriteAttributeString("blogcategory", "");
                                xml.WriteAttributeString("blogcategoryId", "");
                            }
                            xml.WriteAttributeString("title", Component.StringValue("title"));
                            xml.WriteAttributeString("brief", Component.StringValue("brief"));
                            xml.WriteAttributeString("description", Component.StringValue("description"));
                            Component image = Component.ComponentValue("image");
                            if (image != null)
                            {
                                xml.WriteAttributeString("src", PublishBinary(image));
                                xml.WriteAttributeString("altText", image.StringMetaValue("altText"));
                            }
                            if (!string.IsNullOrEmpty(Component.NumberMetaValue("ranking").ToString()))
                            {
                                xml.WriteAttributeString("ranking", Component.NumberMetaValue("ranking").ToString());
                            }

                            DateTime startDate = Component.DateMetaValue("publishDate");
                            if (startDate != null && startDate.ToString("dd/MM/yyyy") != "01/01/0001")
                            {
                                xml.WriteStartElement("date");
                                xml.WriteAttributeString("startDate", startDate.ToString("dd/MM/yyyy"));
                                xml.WriteAttributeString("endDate", "");
                                xml.WriteAttributeString("sortDate", GetSortDate(startDate.ToString("dd/MM/yyyy")));
                                xml.WriteAttributeString("year", GetSortDate(startDate.ToString("dd/MM/yyyy")).Substring(0, 4));
                                xml.WriteEndElement();//item
                            }
                            else if (startDate == null || startDate.ToString("dd/MM/yyyy") == "01/01/0001")
                            {
                                Logger.Info("Blog Item with Empty PublishDate found>>> " + Component.Title);
                                
                                    xml.WriteStartElement("date");
                                    xml.WriteAttributeString("startDate", DateTime.Now.ToString("dd/MM/yyyy"));
                                    xml.WriteAttributeString("endDate", "");
                                    xml.WriteAttributeString("sortDate", GetSortDate(DateTime.Now.ToString("dd/MM/yyyy")));
                                    xml.WriteAttributeString("year", GetSortDate(DateTime.Now.ToString("dd/MM/yyyy")).Substring(0, 4));
                                    xml.WriteEndElement();//close date
                                
                                // If Component is Published to Live with NO Publish Date Metadata set, Update the Component Metadata!
                                if(engine.RenderMode == RenderMode.Publish && engine.PublishingContext.PublicationTarget.Title.ToLower().Contains("live"))
                                {
                                    Logger.Info("Blog Component with empty PublishDate meta field was published to Live>>> " + Component.Title);
                                    SetPublishDateForBlogItem();
                                }                                
                            }

                            xml.WriteEndElement();//item
                        }


                        if (Component.Schema.Title.Equals("TAHR - Image") || Component.Schema.Title.Equals("TAHR - Download"))
                        {
                            PublishBinary(Component);
                        }
                    }

                    Package.AddXml(Package.OutputName, sw.ToString());
                }
            }
        }

        /// <summary>
        /// Function to set the Publish Date Metadata field for Blog Items
        /// </summary>
        private void SetPublishDateForBlogItem()
        {
            if (Component != null)
            {
                if (Component.Schema.Title.Equals("TAHR - Blogs"))
                {
                    XmlNode dateNode = null;
                    TcmUri componentURI = null;

                    if (Component.IsShared)
                    {
                        componentURI = new TcmUri(Component.Id.ItemId, Component.Id.ItemType, int.Parse(Component.OwningRepository.Id.ToString().Split('-').GetValue(1).ToString().Trim()));

                        // Shared Component cannot be updated. Get the 02C publication component and update it!
                        TcmUri owningPublicationUri = Component.OwningRepository.Id;

                        Logger.Info("SetPublishDateForItem>>>>: Component Is a Shared Item, Original Item URI>>>" + componentURI.ToString());

                        Component _component = (Component)Engine.GetSession().GetObject(componentURI);

                        ItemFields metaFields = new ItemFields(_component.Metadata, _component.MetadataSchema);
                        DateField publishDateField = metaFields["publishDate"] as DateField;
                        DateTime publishDate = publishDateField.Value;

                        Logger.Info("SetPublishDateForItem>>>>: Original Publish Date>>>" + publishDate.ToString());

                        Logger.Info("SetPublishDateForItem>>>>: Original Metadata XML>>>" + _component.Metadata.OuterXml);

                        /* Component Metadata format: 
                         * <Metadata xmlns="uuid:FD691C95-F833-4A07-8C95-02454F80FC6D"><publishDate>2017-08-30T05:39:13</publishDate><blogcategory>Explore</ blogcategory><ranking>10</ranking></Metadata>
                        */
                        if (publishDate.ToString("dd/MM/yyyy") == "01/01/0001" && !Component.IsPublishedInContext)
                        {
                            // This is the first Time component is being published
                            Logger.Info("Component is published for first time!");

                            dateNode = _component.Metadata.OwnerDocument.CreateNode(XmlNodeType.Element, "publishDate", _component.Metadata.OwnerDocument.DocumentElement.NamespaceURI);
                            dateNode.InnerText = DateTime.Now.ToString("yyyy-MM-dd") + "T" + DateTime.Now.ToString("hh:mm:ss");
                        }
                        else if (publishDate.ToString("dd/MM/yyyy") == "01/01/0001" && Component.IsPublishedInContext)
                        {
                            //Component is published already but PublishDate Metadata field was not set
                            Logger.Info("Component is published already but PublishDate Metadata field was not set. Setting the same to today's date for now!!");

                            dateNode = _component.Metadata.OwnerDocument.CreateNode(XmlNodeType.Element, "publishDate", _component.Metadata.OwnerDocument.DocumentElement.NamespaceURI);
                            //Update the Publish date to today's date
                            dateNode.InnerText = DateTime.Now.ToString("yyyy-MM-dd") + "T" + DateTime.Now.ToString("hh:mm:ss");
                        }

                        try
                        {
                            if (dateNode != null)
                            {
                                Logger.Info("PublishDateValue>>>>: " + dateNode.InnerText);
                                Logger.Info("SetPublishDateForItem>>>>: Before CheckOUt Status" + _component.IsCheckedOut);
                                if (_component.IsCheckedOut)
                                {
                                    //_component.CheckIn(true);
                                    _component.UndoCheckOut(true);
                                }

                                _component.CheckOut(true);

                                Logger.Info("SetPublishDateForItem>>>>: After CheckOUt Status" + _component.IsCheckedOut);

                                //necessary for crossing XmlDocument contexts
                                XmlNode importNode = _component.Metadata.OwnerDocument.ImportNode(dateNode, true);

                                // If publishDate node already exists, remove it and re insert to update.
                                if (_component.Metadata.OwnerDocument.DocumentElement.FirstChild.Name.ToLower().Equals("publishdate"))
                                {
                                    _component.Metadata.OwnerDocument.DocumentElement.RemoveChild(_component.Metadata.OwnerDocument.DocumentElement.FirstChild);
                                }

                                //Add the publishDate node as first child node
                                _component.Metadata.OwnerDocument.DocumentElement.PrependChild(importNode);

                                Logger.Info("SetPublishDateForItem>>>>: Saving Component");

                                _component.Save(true);
                                _component.CheckIn(true);

                                Logger.Info("SetPublishDateForItem>>>>: Saved & Checked In Component Successfully!");
                            }
                        }
                        catch (Exception ex)
                        {
                            _component.UndoCheckOut(true);
                            Logger.Info("SetPublishDateForItem>>>> ERROR While Saving Item :" + ex.Message);
                        }
                    }
                }
            }
        }

        private static string getHtml(string html)
        {
            return Utility.removeXHTMLtags(html);
        }

        private static string removeParagraphs(string html)
        {
            return Utility.removeParagraphs(html);
        }



        private string GetSortDate(string strDate)
        {

            string strRetval = "";


            string[] datetime = strDate.Split(new char[] { '/' });

            string Year = datetime[2];
            string Month = datetime[1];
            string Day = datetime[0];

            if (Month.Length == 1)
                Month = "0" + Month;

            if (Day.Length == 1)
                Day = "0" + Day;

            strRetval = Year + Month + Day;

            return strRetval;

        }

        /// <summary>
        /// replaceHref
        /// </summary>
        /// <param name="string">String in which links to be resolved</param>
        /// <param name="xml">Object of Xml text writer</param>
        private string replaceHref(string fieldText)
        {
            string pattern = "href=\"(tcm:.*?)\"";
            MatchCollection collection = Regex.Matches(fieldText, pattern);
            foreach (Match match in collection)
            {
                string matchedString = match.Groups[1].Value;
                //string matchedStringwithAttr = match.Groups[0].Value;
                TcmUri tcmId = new TcmUri(matchedString + "-16");
                Component component = GetComponent(tcmId);
                if (component.Schema.Purpose.Equals(SchemaPurpose.Multimedia))
                {
                    string publishedPath = PublishBinary(component);
                    string fileName = component.BinaryContent.Filename;
                    string fileType = fileName.Substring(fileName.LastIndexOf('.') + 1, fileName.Length - fileName.LastIndexOf('.') - 1);
                    switch (fileType.ToLower())
                    {
                        case "jpeg":
                        case "gif":
                        case "jpg":
                        case "png":
                            fieldText = fieldText.Replace(matchedString, publishedPath);
                            fieldText = fieldText.Replace("xlink:href", "src");
                            break;
                        case "doc":
                        case "docx":
                        case "pdf":
                            fieldText = fieldText.Replace(matchedString, publishedPath);
                            fieldText = fieldText.Replace("xlink:href", "href");
                            break;
                        default: fieldText = fieldText.Replace(matchedString, publishedPath);
                            fieldText = fieldText.Replace("xlink:href", "href"); break;
                    }
                }
                //else
                //{
                //    fieldText = fieldText.Replace("xlink:href", "tridion:ComponentLink");
                //}
            }
            return fieldText;
        }
    }
}