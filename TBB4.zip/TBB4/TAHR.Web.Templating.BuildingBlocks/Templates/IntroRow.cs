﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Xml;
using System.IO;
using Tridion.ContentManager;
using Tridion.ContentManager.CommunicationManagement;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Expression;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.Templating.Dreamweaver;
using Tridion;
using Tridion.ContentManager.ContentManagement.Fields;
using Tridion.Extensions.ContentManager.Templating;
using Publishing = Tridion.ContentManager.Publishing.Rendering;
using Tridion.ContentManager.ContentManagement;
using Tridion.ContentManager.Publishing.Rendering;
using System.Text.RegularExpressions;
using Emaar.Web.Tridion.System.Extensions;

namespace TAHR.Web.Templating.BuildingBlocks.Templates{
    [TcmTemplateTitle("IntroRow")]
    public class IntroRow : TemplateBase {
        /// <summary>
        /// Transforms the current component.
        /// </summary>
        /// <param name="engine">The engine.</param>
        /// <param name="package">The package.</param>
        public override void Transform(Engine engine, Package package) {

            base.Transform(engine, package);

            Engine m_Engine;
            m_Engine = engine;
            Component comp = Component;
            if (comp.Schema.Title.Equals("TAHR - Intro Row"))
            {
                Filter filter = new Filter();
                filter.Conditions["ItemType"] = ItemType.Component;

                package.PushItem("title", package.CreateHtmlItem(comp.StringValue("title")));
                package.PushItem("description", package.CreateHtmlItem(Utility.removeXHTMLtags(comp.StringValue("description"))));

                Component image = comp.ComponentValue("image");
                if (image != null)
                {
                    if (image.Schema.Title.Equals("TAHR - Image"))
                    {
                        package.PushItem("image", package.CreateHtmlItem(PublishBinary(image)));
                        package.PushItem("imageTitle", package.CreateHtmlItem(image.StringMetaValue("title")));
                        package.PushItem("imageInfo", package.CreateHtmlItem(image.StringMetaValue("info")));

                    }
                    if (image.Schema.Title.Equals("TAHR - Brochure"))
                    {
                        Component download = image.ComponentMetaValue("pdf");
                        package.PushItem("image", package.CreateHtmlItem(PublishBinary(image)));
                        package.PushItem("download", package.CreateHtmlItem(PublishBinary(download)));
                        package.PushItem("downloadHeading", package.CreateHtmlItem(download.StringMetaValue("title")));
                        package.PushItem("downloadInfo", package.CreateHtmlItem(download.StringMetaValue("info")));
                    }
                }

                Component compLink = comp.ComponentValue("component");
                if (compLink != null) {
                    package.PushItem("control", package.CreateTridionItem(ContentType.Component, compLink));
                }
            }
        }
    }
}
