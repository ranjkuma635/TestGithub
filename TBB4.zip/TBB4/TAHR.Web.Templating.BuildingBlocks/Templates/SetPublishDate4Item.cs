﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Xml;
using System.IO;
using Tridion.ContentManager;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.ContentManagement.Fields;
using Tridion.Extensions.ContentManager.Templating;
using Tridion.ContentManager.ContentManagement;
using Emaar.Web.Tridion.System.Extensions;
using System.Drawing;
using Tridion.ContentManager.Publishing;
using System.Globalization;
using System.Text.RegularExpressions;

namespace SetPublishDate4Item
{
    [TcmTemplateTitle("SetPublishDateForItem")]
    class SetPublishDate4Item : TemplateBase
    {
        /// <summary>
        /// Transforms the current component.
        /// </summary>
        /// <param name="engine">The engine.</param>
        /// <param name="package">The package.</param>
        public override void Transform(Engine engine, Package package)
        {
            base.Transform(engine, package);
            string itemId = Component.Id;

            Logger.Info("SetPublishDateForItem>>>>: Publication_Target>>>" + engine.PublishingContext.PublicationTarget.Title);

            // publishDate metafield will be checked and updated only for Publish Action on Live Target!
            if (engine.RenderMode == RenderMode.Publish && engine.PublishingContext.PublicationTarget.Title.ToLower().Contains("live"))
            {
                if (Component != null)
                {
                    if (Component.Schema.Title.Equals("TAHR - Blogs"))
                    {
                        XmlNode dateNode = null;
                        TcmUri componentURI = null;

                        if (Component.IsShared)
                        {
                            componentURI = new TcmUri(Component.Id.ItemId, Component.Id.ItemType, int.Parse(Component.OwningRepository.Id.ToString().Split('-').GetValue(1).ToString().Trim()));
                            TcmUri owningPublicationUri = Component.OwningRepository.Id;
                            Logger.Info("SetPublishDateForItem>>>>: Component Is a Shared Item, Original Item URI>>>" + componentURI.ToString());

                            Component _component = (Component)Engine.GetSession().GetObject(componentURI);

                            ItemFields metaFields = new ItemFields(_component.Metadata, _component.MetadataSchema);
                            DateField publishDateField = metaFields["publishDate"] as DateField;
                            DateTime publishDate = publishDateField.Value;

                            Logger.Info("SetPublishDateForItem>>>>: Original Publish Date>>>" + publishDate.ToString());

                            Logger.Info("SetPublishDateForItem>>>>: Original Metadata XML>>>" + _component.Metadata.OuterXml);

                            if (publishDate.ToString("dd/MM/yyyy") == "01/01/0001" && !Component.IsPublishedInContext)
                            {
                                // This is the first Time component is being published
                                Logger.Info("Component is published for first time!");

                                dateNode = _component.Metadata.OwnerDocument.CreateNode(XmlNodeType.Element, "publishDate", _component.Metadata.OwnerDocument.DocumentElement.NamespaceURI);
                                dateNode.InnerText = DateTime.Now.ToString("yyyy-MM-dd") + "T" + DateTime.Now.ToString("hh:mm:ss");
                            }
                            else if (publishDate.ToString("dd/MM/yyyy") == "01/01/0001" && Component.IsPublishedInContext)
                            {
                                //Component is published already but PublishDate Metadata field was not set
                                Logger.Info("Component is published already but PublishDate Metadata field was not set. Setting the same to today's date for now!!");

                                dateNode = _component.Metadata.OwnerDocument.CreateNode(XmlNodeType.Element, "publishDate", _component.Metadata.OwnerDocument.DocumentElement.NamespaceURI);
                                //Update the Publish date to today's date
                                dateNode.InnerText = DateTime.Now.ToString("yyyy-MM-dd") + "T" + DateTime.Now.ToString("hh:mm:ss");
                            }
                            
                            try
                            {
                                if (dateNode != null)
                                {
                                    Logger.Info("PublishDateValue>>>>: " + dateNode.InnerText);
                                    Logger.Info("SetPublishDateForItem>>>>: Before CheckOUt Status" + _component.IsCheckedOut);
                                    if (_component.IsCheckedOut)
                                    {
                                        _component.CheckIn(true);
                                    }

                                    _component.CheckOut(true);

                                    Logger.Info("SetPublishDateForItem>>>>: After CheckOUt Status" + _component.IsCheckedOut);

                                    //necessary for crossing XmlDocument contexts
                                    XmlNode importNode = _component.Metadata.OwnerDocument.ImportNode(dateNode, true);

                                    // If publishDate node already exists, remove it and re insert to update.
                                    if (_component.Metadata.OwnerDocument.DocumentElement.FirstChild.Name.ToLower().Equals("publishdate"))
                                    {
                                        _component.Metadata.OwnerDocument.DocumentElement.RemoveChild(_component.Metadata.OwnerDocument.DocumentElement.FirstChild);
                                    }

                                    //Add the publishDate node as first child node
                                    _component.Metadata.OwnerDocument.DocumentElement.PrependChild(importNode);

                                    Logger.Info("SetPublishDateForItem>>>>: Saving Component");

                                    _component.Save(true);
                                    _component.CheckIn(true);

                                    Logger.Info("SetPublishDateForItem>>>>: Saved & Checked In Component Successfully!");
                                }
                            }
                            catch (Exception ex)
                            {
                                _component.UndoCheckOut(true);
                                Logger.Info("SetPublishDateForItem>>>> ERROR While Saving Item :" + ex.Message);
                            }
                        }
                    }
                }
            }
        }
    }
}
