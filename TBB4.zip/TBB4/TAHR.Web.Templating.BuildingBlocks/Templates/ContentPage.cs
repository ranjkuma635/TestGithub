﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using Tridion.ContentManager;
using Tridion.ContentManager.CommunicationManagement;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Expression;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.Templating.Dreamweaver;
using Tridion;
using Tridion.ContentManager.ContentManagement.Fields;
using Tridion.Extensions.ContentManager.Templating;
using Publishing = Tridion.ContentManager.Publishing.Rendering;
using Tridion.ContentManager.ContentManagement;
using Tridion.ContentManager.Publishing.Rendering;
using System.Text.RegularExpressions;
using Emaar.Web.Tridion.System.Extensions;
using System.Xml;

namespace TAHR.Web.Templating.BuildingBlocks.Templates {
    [TcmTemplateTitle("Content Page")]
    public class ContentPage : TemplateBase {

        public override void Transform(Engine engine, Package package) {
            base.Transform(engine, package);
            String seoImage = String.Empty; ;
            String seoDescription = String.Empty;
            String seoKeywords = String.Empty;
            String pageTitle = string.Empty;

            if (Page.ComponentPresentations.Count > 0) {
                Component component = Page.ComponentPresentations[0].Component;

                if (component.EmbeddedMetaValue("seometadata") != null) {
                    ItemFields seoMetadata = component.EmbeddedMetaValue("seometadata");
                    pageTitle = seoMetadata.StringValue("fPageTitle");
                    seoDescription = seoMetadata.StringValue("fSEODescription");
                    seoKeywords = seoMetadata.StringValue("fSEOKeywords");
                    seoImage = GenerateThumbnail(seoMetadata.ComponentValue("fSEOImage"), "seo", 600, 600);
                }

                else if (component.Content != null) {
                    if (component.StringValue("title") != null) {
                        pageTitle = component.StringValue("title");
                    }

                    Component imageComponent = component.ComponentValue("image");
                    if (imageComponent != null) {
                        seoImage = GenerateThumbnail(imageComponent, "seo", 100, 100);
                    }
                }

                package.AddString("PageTitle", pageTitle);
                package.AddString("SEODescription", seoDescription);
                package.AddString("SEOKeywords", seoKeywords);
                package.AddString("SEOImage", seoImage);
            }

            Page page = this.GetPage(engine, package);
            //Create the final (non-link) part of the breadcrumb
            String result = "";

            bool isIndex = false;
            bool carouselsPath = false;
            bool hotelPath = false;
            if (page.FileName == "index")
                isIndex = true;

            //Loop up through all the parent Structure Groups writing them out as links
            StructureGroup sg = page.OrganizationalItem as StructureGroup;
                //First time round check if this is an index page, if not the title is shown plain text
                if (sg!= null && !sg.Equals(RootStructureGroup)) {
                    result = sg.PublishLocationUrl;
                    package.PushItem("NavPath", package.CreateHtmlItem(result));
                    package.PushItem("NavParentPageTitle", package.CreateHtmlItem(StripPrefix(sg.Title)));
                    if (sg.KeywordMetaValue("fhotelName") != null && hotelPath==false) {
                        hotelPath = true;
                        package.PushItem("HotelPath", package.CreateHtmlItem(result));
                    }

                    if (sg.StringMetaValue("fcarousels") != null && carouselsPath==false){
                        if (sg.StringMetaValue("fcarousels").Equals("Self")) {
                            carouselsPath = true;
                            package.PushItem("CarouselsPath", package.CreateHtmlItem(result));
                        }
                    }

                    sg = sg.OrganizationalItem as StructureGroup;
                    if (sg != null) {
                        result = sg.PublishLocationUrl;
                        package.PushItem("NavParentPath", package.CreateHtmlItem(result));
                        package.PushItem("NavSG", package.CreateHtmlItem(sg.Id));
                        if (sg.KeywordMetaValue("fhotelName") != null && hotelPath == false) {
                            hotelPath = true;
                            package.PushItem("HotelPath", package.CreateHtmlItem(result));
                        }

                        if (sg.StringMetaValue("fcarousels") != null && carouselsPath == false){
                            if (sg.StringMetaValue("fcarousels").Equals("Self")){
                                carouselsPath = true;
                                package.PushItem("CarouselsPath", package.CreateHtmlItem(result));
                            }
                        }

                        sg = sg.OrganizationalItem as StructureGroup;
                        if (sg != null && !isIndex) {
                            result = sg.PublishLocationUrl;
                            package.PushItem("LastBranchPage", package.CreateHtmlItem("Yes"));
                            if (sg.KeywordMetaValue("fhotelName") != null && hotelPath == false) {
                                hotelPath = true; 
                                package.PushItem("HotelPath", package.CreateHtmlItem(result));
                            }
                            if (sg.StringMetaValue("fcarousels") != null && carouselsPath == false) {
                                if (sg.StringMetaValue("fcarousels").Equals("Self")){
                                    carouselsPath = true;
                                    package.PushItem("CarouselsPath", package.CreateHtmlItem(result));
                                }
                            }
                        }
                    }
                }
            
        }

      
        public string StripPrefix(string title)
        {
            if (title.IndexOf(".").ToString() == "-1")
                return title;
            int length = 4;
            if (title.Length < 4)
                length = title.Length - 1;
            string prefix = title.Substring(0, length);
            int result = 0;
            //Handle number prefix
            if (int.TryParse(prefix, out result))
            {
                title = title.Substring(title.IndexOf(" ") + 1);
            }
            title = title.Split('.')[1];
            title = title.Trim();
            return title;
        }


        private Page GetPage(Engine engine, Package package)
        {
            CheckInitialized();
            //first try to get from the render context
            RenderContext renderContext = engine.PublishingContext.RenderContext;
            if (renderContext != null)
            {
                Page contextPage = renderContext.ContextItem as Page;
                if (contextPage != null)
                    return contextPage;
            }
            Item pageItem = package.GetByType(ContentType.Page);
            if (pageItem != null)
                return (Page)engine.GetObject(pageItem.GetAsSource().GetValue("ID"));

            return null;
        }

        public string ExtractImage(Component component, string field)
        {
            String sHtml = component.XHTMLValue(field);
            String WithoutNameSpace;
            if (!String.IsNullOrEmpty(sHtml))
            {
                XmlDocument xHtml = new XmlDocument();
                xHtml.LoadXml("<root>" + sHtml + "</root>");
                WithoutNameSpace = xHtml.RemoveNameSpaces();
                xHtml = new XmlDocument();
                xHtml.LoadXml(WithoutNameSpace);
                XmlNode image = xHtml.SelectSingleNode("/root//img");
                if (image != null)
                {
                    String imageID = image.GetAttribute("href");
                    if (!String.IsNullOrEmpty(imageID) && imageID.Contains("tcm:"))
                    {
                        return GenerateThumbnail(GetComponent(imageID), "s_thumb", 61, 46, "#fff");
                    }
                }
            }
            return String.Empty;
        }
    }
}
