﻿using System;
using System.Collections.Generic;
using System.Xml;
using Tridion.ContentManager.ContentManagement.Fields;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager;
using System.Collections;
using Tridion.ContentManager.ContentManagement;
using Tridion.ContentManager.CommunicationManagement;
using System.Xml.XPath;
using System.Web;
using Tridion.Extensions.ContentManager.Templating;
using System.IO;
using Emaar.Web.Tridion.System.Extensions;

namespace TAHR.Web.Templating.BuildingBlocks.Templates {

    [TcmTemplateTitle("CategoryList")]
    public class CategoryList : TemplateBase {

        public override void Transform(Engine engine, Package package) {

            base.Transform(engine, package);

            string strPubid = Component.Id.PublicationId.ToString();

            string strCuisine = "tcm:" + strPubid + "-4398-512";
            string strHotel = "tcm:" + strPubid + "-4385-512";
            string strLocation = "tcm:" + strPubid + "-4436-512";
            string strServices = "tcm:" + strPubid + "-4383-512";
            string strTreatment = "tcm:" + strPubid + "-4412-512";

            Filter f = new Filter();

            Category categoryCuisine = engine.GetObject(strCuisine) as Category;
            Category categoryHotel = engine.GetObject(strHotel) as Category;
            Category categoryLocation = engine.GetObject(strLocation) as Category;
            Category categoryService = engine.GetObject(strServices) as Category;
            Category categoryTreatment = engine.GetObject(strTreatment) as Category;

            using (StringWriter sw = new StringWriter()) {

                using (XmlTextWriter xml = new XmlTextWriter(sw)) {
                    xml.WriteStartElement("list");

                    IList<Keyword> catCuisine = categoryCuisine.GetKeywords(f);
                    foreach (Keyword c in catCuisine) {
                        xml.WriteStartElement("cuisine");
                        xml.WriteAttributeString("description", c.Description);
                        xml.WriteAttributeString("key", c.Key);
                        xml.WriteEndElement();
                    }

                    IList<Keyword> catHotel = categoryHotel.GetKeywords(f);
                    foreach (Keyword c in catHotel){
                        xml.WriteStartElement("hotel");
                        xml.WriteAttributeString("description", c.Description);
                        xml.WriteAttributeString("key", c.Key);
                        xml.WriteEndElement();
                    }

                    IList<Keyword> catLocation = categoryLocation.GetKeywords(f);
                    foreach (Keyword c in catLocation){
                        xml.WriteStartElement("location");
                        xml.WriteAttributeString("description", c.Description);
                        xml.WriteAttributeString("key", c.Key);
                        xml.WriteEndElement();
                    }

                    IList<Keyword> catService = categoryService.GetKeywords(f);
                    foreach (Keyword c in catLocation) {
                        xml.WriteStartElement("service");
                        xml.WriteAttributeString("description", c.Description);
                        xml.WriteAttributeString("key", c.Key);
                        xml.WriteEndElement();
                    }

                    IList<Keyword> catTreatment = categoryTreatment.GetKeywords(f);
                    foreach (Keyword c in catLocation) {
                        xml.WriteStartElement("treatment");
                        xml.WriteAttributeString("description", c.Description);
                        xml.WriteAttributeString("key", c.Key);
                        xml.WriteEndElement();
                    }
                    
                    xml.WriteEndElement();//list
                }

                Package.AddXml(Package.OutputName, sw.ToString());
            }

        }
    }
}
