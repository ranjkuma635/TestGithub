﻿using System;
using System.Collections.Generic;
using System.Linq;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.ContentManagement;
using Emaar.Web.Tridion.System.Extensions;

namespace TAHR.Web.Templating.BuildingBlocks.Templates
{
    [TcmTemplateTitle("DetailControlWithHighlights")]
    public class DetailControlWithHighlights : Emaar.Web.Tridion.System.ControlTemplate {
        /// <summary>
        /// Transforms the current component.
        /// </summary>
        /// <param name="engine">The engine.</param>
        /// <param name="package">The package.</param>
        public override void Transform(Engine engine, Package package) {

           // base.Transform(engine, package);

            mEngine = engine;
            mPackage = package;

            Emaar.Web.Tridion.System.Dreamweaver_Extension.Templating controlTag = new Emaar.Web.Tridion.System.Dreamweaver_Extension.Templating();

            string strItemId = Component.Id.ToString();
            string strPubid = Component.Id.PublicationId.ToString();

            String detailXSLT="";
            String XML = "";
            String itemId = "";
            String heading = "HighlightsHeadingMoreOptions";

            String componentID = Component.Id;


            switch (Component.Schema.Title) {
                case "TAHR - Room":
                    detailXSLT = "roomDetail.xslt";
                    XML = "rooms.xml";
                    itemId = componentID;
                    heading = "HighlightsHeadingRooms";
                    break;
                case "TAHR - Residence":
                    detailXSLT = "residenceDetail.xslt";
                    XML = "residences.xml";
                    itemId = componentID;
                    heading = "HighlightsHeadingResidences";
                    break;
                case "TAHR - Hotel":
                    detailXSLT = "hotelDetail.xslt";
                    XML = "hotels.xml";
                    itemId = componentID;
                    heading = "HighlightsHeadingHotels";
                    break;
                case "TAHR - Offer":
                    detailXSLT = "offerDetail.xslt";
                    XML = "offers.xml";
                    itemId = componentID;
                    heading = "HighlightsHeadingOffers";
                    break;
                case "TAHR - Event Venue":
                    detailXSLT = "eventVenueDetail.xslt";
                    XML = "eventvenues.xml";
                    itemId = componentID;
                    heading = "HighlightsHeadingEventVenues";
                    break;
                case "TAHR - Event":
                    detailXSLT = "eventDetail.xslt";
                    XML = "offerings.xml";
                    itemId = componentID;
                    break;
                case "TAHR - Amenity":
                    detailXSLT = "AmenityDetail.xslt";
                    XML = "amenities.xml";
                    itemId = componentID;
                    heading = "HighlightsHeadingKeepExploring";
                    break;
                case "TAHR - Restaurent":
                    detailXSLT = "dineDetail.xslt";
                    XML = "dines.xml";
                    itemId = componentID;
                    heading = "HighlightsHeadingDines";
                    break;
                case "TAHR - Treatment":
                    detailXSLT = "treatmentDetail.xslt";
                    XML = "treatments.xml";
                    itemId = componentID;
                    heading = "HighlightsHeadingKeepExploring";
                    break;
                case "TAHR - Offering":
                    detailXSLT = "offeringDetail.xslt";
                    XML = "offerings.xml";
                    itemId = componentID;
                    heading = "HighlightsHeadingKeepExploring";
                    break;
                case "TAHR - Blogs":
                    detailXSLT = "blogDetail.xslt";
                    XML = "blogs.xml";
                    itemId = componentID;
                    heading = "HighlightsHeadingKeepExploring";
                    break;
            }

            string strDetailControl = "tcm:" + strPubid + "-4570-2";

            OrganizationalItem detailControlFolder = engine.GetObject(strDetailControl) as OrganizationalItem;

            IList<Component> compList = detailControlFolder.Components(true);
            foreach (Component comp in compList)  {
                if (comp != null && comp.Schema.Title.Equals("User Controls") && comp.Title.Equals("Detail Control with Highlights")) {
                    package.AddString("ItemID", itemId);
                    package.AddString("detailXSLT", detailXSLT);
                    package.AddString("XML", XML);
                    package.AddString("heading", heading);
                    //Package.AddHtml(Package.OutputName, controlTag.GetControlTag(comp));
                }
            }
        }
    }
}