﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Xml;
using System.Xml.XPath;
using System.Xml.Xsl;
using System.IO;
using Tridion.ContentManager;
using Tridion.ContentManager.CommunicationManagement;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Expression;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.Templating.Dreamweaver;
using Tridion;
using Tridion.ContentManager.ContentManagement.Fields;
using Tridion.Extensions.ContentManager.Templating;
using Publishing = Tridion.ContentManager.Publishing.Rendering;
using Tridion.ContentManager.ContentManagement;
using Tridion.ContentManager.Publishing.Rendering;
using System.Text.RegularExpressions;
using Emaar.Web.Tridion.System.Extensions;

namespace TAHR.Web.Templating.BuildingBlocks.Templates {
    [TcmTemplateTitle("ListDineExperience")]
    public class ListDineExperience : TemplateBase {
        /// <summary>
        /// Transforms the current component.
        /// </summary>
        /// <param name="engine">The engine.</param>
        /// <param name="package">The package.</param>
        public override void Transform(Engine engine, Package package) {
            int i = 1;
            int j = 1;

            base.Transform(engine, package);

            Engine m_Engine;
            m_Engine = engine;


            Folder folder = (Folder)Component.OrganizationalItem;

            using (StringWriter sw = new StringWriter()) {

                using (XmlTextWriter xml = new XmlTextWriter(sw)) {

                    xml.WriteStartElement("list");
                    i = 1;

                    IList<Component> dineList = folder.Components(true);

                    foreach (Component comp in dineList) {

                        if (comp.Schema.Title.Equals("TAHR - Offering")){

                            string itemId = comp.Id;

                            Filter f = new Filter();
                            f.Conditions["ItemType"] = ItemType.Component;
                            xml.WriteStartElement("item");
                            xml.WriteAttributeString("index", i.ToString());
                            xml.WriteAttributeString("id", itemId.Split('-')[1]);
                            xml.WriteAttributeString("catKey", comp.KeywordMetaValue("category").Key);
                            xml.WriteAttributeString("catName", comp.KeywordMetaValue("category").Description);
                            xml.WriteAttributeString("hotel", "");
                            xml.WriteAttributeString("hotelId", "");
                            if (comp.KeywordMetaValue("type") != null) {
                                xml.WriteAttributeString("type", comp.KeywordMetaValue("type").Description);
                                xml.WriteAttributeString("typeId", comp.KeywordMetaValue("type").Key);
                            }
                            ItemFields callout = comp.EmbeddedMetaValue("callout");
                            if (callout != null) {
                                xml.WriteAttributeString("calloutId", comp.Id.ToString());
                                xml.WriteAttributeString("calloutTitle", callout.StringValue("calloutTitle"));
                                xml.WriteAttributeString("calloutText", callout.StringValue("calloutText"));
                                xml.WriteAttributeString("calloutLinkText", callout.StringValue("calloutLinkText"));
                                if (callout.ComponentValue("calloutImage") != null){
                                    xml.WriteAttributeString("calloutImage", PublishBinary(callout.ComponentValue("calloutImage")));
                                }
                                else{
                                    xml.WriteAttributeString("calloutImage", PublishBinary(Component.ComponentValue("image")));
                                }
                            }
                            xml.WriteEndElement();//item
                        }
                    }
                    
                    xml.WriteEndElement(); //list                
                }
       
                Package.AddXml(Package.OutputName, sw.ToString());
            }
        }
    }
}
