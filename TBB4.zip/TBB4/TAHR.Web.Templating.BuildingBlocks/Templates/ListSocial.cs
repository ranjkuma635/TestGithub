﻿using System;
using System.Collections.Generic;
using System.Xml;
using Tridion.ContentManager.ContentManagement.Fields;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager;
using System.Collections;
using Tridion.ContentManager.ContentManagement;
using Tridion.ContentManager.CommunicationManagement;
using System.Xml.XPath;
using System.Web;
using Tridion.Extensions.ContentManager.Templating;
using System.IO;
using Emaar.Web.Tridion.System.Extensions;


namespace TAHR.Web.Templating.FooterXML.Templates {

    [TcmTemplateTitle("ListSocial")]
    public class ListSocial : TemplateBase {

        /// <summary>
        /// Transforms the current component.
        /// </summary>
        /// <param name="engine">The engine.</param>
        /// <param name="package">The package.</param>
        public override void Transform(Engine engine, Package package) {

            base.Transform(engine, package);

            using (StringWriter sw = new StringWriter()) {

                using (XmlTextWriter xml = new XmlTextWriter(sw)) {

                    if (Component != null)  {

                        xml.WriteStartElement("list");

                        List<ItemFields> items = (List<ItemFields>)Component.EmbeddedValues("item");

                        foreach (ItemFields item in items){
                            xml.WriteStartElement("item");
                            xml.WriteAttributeString("media", item.StringValue("media"));
                            xml.WriteAttributeString("link", item.StringValue("href"));
                            xml.WriteEndElement(); //item
                        }

                        xml.WriteEndElement(); //item
                    }
                }
                     
                Package.AddXml(Package.OutputName, sw.ToString());
            }

        }

    }
}
