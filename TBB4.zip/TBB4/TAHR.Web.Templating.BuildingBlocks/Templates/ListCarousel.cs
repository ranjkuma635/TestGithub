﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Xml;
using System.IO;
using Tridion.ContentManager;
using Tridion.ContentManager.CommunicationManagement;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Expression;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.Templating.Dreamweaver;
using Tridion;
using Tridion.ContentManager.ContentManagement.Fields;
using Tridion.Extensions.ContentManager.Templating;
using Publishing = Tridion.ContentManager.Publishing.Rendering;
using Tridion.ContentManager.ContentManagement;
using Tridion.ContentManager.Publishing.Rendering;
using System.Text.RegularExpressions;
using Emaar.Web.Tridion.System.Extensions;

namespace TAHR.Web.Templating.BuildingBlocks.Templates {
    [TcmTemplateTitle("ListCarousel")]
    public class ListCarousel : TemplateBase {
        /// <summary>
        /// Transforms the current component.
        /// </summary>
        /// <param name="engine">The engine.</param>
        /// <param name="package">The package.</param>
        public override void Transform(Engine engine, Package package)
        {
            int i = 1;
            int j = 1;

            base.Transform(engine, package);

            Engine m_Engine;
            m_Engine = engine;

            using (StringWriter sw = new StringWriter()) {
                using (XmlTextWriter xml = new XmlTextWriter(sw)) {
                    xml.WriteStartElement("list");
                        if (Component.Schema.Title.Equals("TAHR - List")){
                            Filter f = new Filter();
                            f.Conditions["ItemType"] = ItemType.Component;
                            string itemId = Component.Id;
                            xml.WriteStartElement("item");
                            xml.WriteAttributeString("uri", Component.Id.ToString());
                            xml.WriteAttributeString("id", itemId.Split('-')[1]);
                            IList<Component> images = Component.ComponentValues("rows");
                            i = 1;
                            foreach (Component image in images) {
                                if (image != null) {
                                    xml.WriteStartElement("carousel");
                                    xml.WriteAttributeString("index", i.ToString());
                                    xml.WriteAttributeString("src", PublishBinary(image));
                                    xml.WriteAttributeString("altText", image.StringMetaValue("altText"));
                                    if (image.KeywordMetaValue("hotel") != null) {
                                        xml.WriteAttributeString("hotel", image.KeywordMetaValue("hotel").Description);
                                        xml.WriteAttributeString("hotelId", image.KeywordMetaValue("hotel").Key);
                                    }
                                    if (image.KeywordMetaValue("category")!= null){
                                        xml.WriteAttributeString("catName", image.KeywordMetaValue("category").Description);
                                        xml.WriteAttributeString("catKey", image.KeywordMetaValue("category").Key);
                                    }
                                    xml.WriteEndElement();//carousel
                                    i++;
                                }
                            }
                            xml.WriteEndElement();//item
                        }
                    xml.WriteEndElement();//list
                }  
                Package.AddXml(Package.OutputName, sw.ToString());
            }
        }
    }
}
