﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Xml;
using System.IO;
using Tridion.ContentManager;
using Tridion.ContentManager.CommunicationManagement;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Expression;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.Templating.Dreamweaver;
using Tridion;
using Tridion.ContentManager.ContentManagement.Fields;
using Tridion.Extensions.ContentManager.Templating;
using Publishing = Tridion.ContentManager.Publishing.Rendering;
using Tridion.ContentManager.ContentManagement;
using Tridion.ContentManager.Publishing.Rendering;
using System.Text.RegularExpressions;
using Emaar.Web.Tridion.System.Extensions;

namespace TAHR.Web.Templating.BuildingBlocks.Templates
{
    [TcmTemplateTitle("HomepageboxXML")]
    public class HomepageboxXML : TemplateBase
    {
        /// <summary>
        /// Transforms the current component.
        /// </summary>
        /// <param name="engine">The engine.</param>
        /// <param name="package">The package.</param>
        public override void Transform(Engine engine, Package package)
        {

            base.Transform(engine, package);

            Engine m_Engine;
            m_Engine = engine;

            using (StringWriter sw = new StringWriter())
            {
                using (XmlTextWriter xml = new XmlTextWriter(sw))
                {
                    xml.WriteStartElement("list");

                    xml.WriteAttributeString("heading", Component.StringValue("heading"));
                    xml.WriteAttributeString("uri", Component.Id.ToString());

                    IList<Component> components = Component.ComponentValues("rows");

                    foreach (Component comp in components)
                    {
                        if (comp.Schema.Title.Equals("TAHR - Homepage Box") || comp.Schema.Title.Equals("TAHR - Homepage Control Box"))
                        {
                            Filter filter = new Filter();
                            filter.Conditions["ItemType"] = ItemType.Component;
                            xml.WriteStartElement("item");
                            xml.WriteAttributeString("uri", comp.Id.ToString());
                            xml.WriteAttributeString("text", comp.StringValue("text"));

                            Component image = comp.ComponentValue("image");
                            if (image != null)
                            {
                                string src = PublishBinary(image);
                                xml.WriteAttributeString("src", src);
                                xml.WriteAttributeString("altText", image.StringMetaValue("altText"));
                            }

                            ItemFields linkFields = comp.EmbeddedValue("link");
                            if (linkFields != null)
                            {
                                Component compLink = linkFields.ComponentValue("componentLink");
                                string externalLink = linkFields.ExternalLinkValue("externalLink");
                                if (compLink != null)
                                {
                                    xml.WriteAttributeString("componentLink", compLink.Id.ToString());
                                }
                                else
                                {
                                    xml.WriteAttributeString("externalLink", externalLink);
                                }
                                xml.WriteAttributeString("linkText", linkFields.StringValue("linkText"));
                            }
                            string boxdivClass = "box-container";
                            string boxStyle = comp.StringMetaValue("boxStyle");
                            if (!boxStyle.Equals("no-style"))
                            {
                                boxdivClass = boxdivClass + " " + boxStyle;
                            }
                            xml.WriteAttributeString("boxdivClass", boxdivClass);


                            string gridSize = comp.StringMetaValue("gridSize");
                            string divClass = "";
                            if (gridSize != null)
                            {
                                divClass = gridSize;
                                string hideOnMobile = comp.StringMetaValue("hideOnMobile");
                                if (hideOnMobile.Equals("Yes"))
                                {
                                    divClass = divClass + " hide-on-mobile";
                                }
                                else
                                {
                                    divClass = divClass + " mobile-grid-100";
                                }
                                xml.WriteAttributeString("divClass", divClass);
                            }

                            Component bgImage = comp.ComponentMetaValue("bgImage");
                            if (bgImage != null)
                            {
                                string bgsrc = PublishBinary(bgImage);
                                xml.WriteAttributeString("bgImage", "background: url('" + bgsrc + "') no-repeat 0 0; background-size: cover;");
                            }

                            xml.WriteEndElement(); //item 
                        }
                    }

                    xml.WriteEndElement(); //list              
                }

                Package.AddXml(Package.OutputName, sw.ToString());
            }
        }
    }
}