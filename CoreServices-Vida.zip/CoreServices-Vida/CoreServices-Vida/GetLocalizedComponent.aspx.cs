﻿using System;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;
using Tridion.ContentManager.CoreService.Client;

namespace CoreServices_Vida
{
    public partial class GetLocalizedComponent : System.Web.UI.Page
    {
        CoreServiceClient client = new CoreServiceClient();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                client.ChannelFactory.Credentials.Windows.ClientCredential = new System.Net.NetworkCredential();
                client.Open();
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(txtPublication.Text))
                {
                    string fileName = "d:\\LocalizedItem" + DateTime.Now.ToFileTime() + ".txt";
                    System.IO.StreamWriter file = new System.IO.StreamWriter(fileName);
                    
                    var types = ItemType.Component;
                    if (rblItemType.SelectedValue.Equals("page"))
                        types = ItemType.Page;

                    RepositoryItemsFilterData filter = new RepositoryItemsFilterData
                    {
                        Recursive = true,
                        ItemTypes = new ItemType[] { types }
                    };

                    string pubId = txtPublication.Text;
                    string pubTCMId = "tcm:0-" + pubId + "-1";

                    var resultxml = client.GetListXml(pubTCMId, filter).Elements()
                        .Where(a => a.Attribute("OwningPublicationID").Value.Equals(pubId, StringComparison.OrdinalIgnoreCase))
                        .Select(a => a.Attribute("ID").Value).ToList();
                    if (resultxml != null)
                    {
                        foreach (var itemId in resultxml)
                            file.WriteLine(itemId);
                    }
                    file.Close();
                }
            }
            catch (Exception ex)
            {

            }
        }
    }
}


