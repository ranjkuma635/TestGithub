﻿using System;
using System.Web.UI;
using Tridion.ContentManager.CoreService.Client;

namespace CoreServices_Vida
{
    public partial class GetTBBs : System.Web.UI.Page
    {
        CoreServiceClient client = new CoreServiceClient();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                client.ChannelFactory.Credentials.Windows.ClientCredential = new System.Net.NetworkCredential();
                client.Open();
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(txtFolder.Text))
                {
                    OrganizationalItemItemsFilterData filter = new OrganizationalItemItemsFilterData
                    {
                        Recursive = true,
                        BaseColumns = ListBaseColumns.IdAndTitle,
                        ItemTypes = new ItemType[] { ItemType.TemplateBuildingBlock }
                    };

                    var resultxml = client.GetListXml(txtFolder.Text, filter);
                    string fileName = "d:\\TBBItem" + DateTime.Now.ToFileTime() + ".txt";
                    System.IO.StreamWriter file = new System.IO.StreamWriter(fileName);
                    file.Write(resultxml);
                    file.Close();
                }
            }
            catch (Exception ex)
            {

            }
        }
    }
}