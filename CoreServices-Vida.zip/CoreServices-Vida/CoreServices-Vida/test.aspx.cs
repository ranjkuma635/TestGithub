﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml.Linq;
using Tridion.ContentManager.CoreService.Client;

namespace CoreServices_Vida
{
    public partial class test : System.Web.UI.Page
    {
        CoreServiceClient client = new CoreServiceClient();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                client.ChannelFactory.Credentials.Windows.ClientCredential = new System.Net.NetworkCredential();
                client.Open();
            }

            // ************* Get multimedia from the component *********************
            IEnumerable<XElement> links = null;
            IEnumerable<XElement> metaLinks = null;
            IEnumerable<XElement> mmLinks = null;
            XNamespace xLinkNS = XNamespace.Get("http://www.w3.org/1999/xlink");

            ComponentData component = (ComponentData)client.Read("tcm:150-87101", new ReadOptions());
            if (!string.IsNullOrEmpty(component.Content))
            {
                XElement xContent = XElement.Parse(component.Content);
                links = xContent.Descendants().Where(w => w.Attributes(xLinkNS + "href").Count() > 0);
            }
            if (!string.IsNullOrEmpty(component.Metadata))
            {
                XElement xMetaContent = XElement.Parse(component.Metadata);
                metaLinks = xMetaContent.Descendants().Where(w => w.Attributes(xLinkNS + "href").Count() > 0);
            }

            mmLinks = links.Concat(metaLinks);
            foreach (XElement link in mmLinks)
            {
                string title = link.Attribute(xLinkNS + "title").Value;
                string id = link.Attribute(xLinkNS + "href").Value;
            }
            // *************************************************************************

            //// ********** Get Multimedia component from the folder *******************
            //OrganizationalItemItemsFilterData filter = new OrganizationalItemItemsFilterData
            //{
            //    ItemTypes = new ItemType[] { ItemType.Component },
            //    ComponentTypes = new ComponentType[] { ComponentType.Multimedia },
            //    Recursive = true,
            //    BaseColumns = ListBaseColumns.Extended
            //};
            //XElement items = client.GetListXml("tcm:229-7726-2", filter);
            //var compList = items.Elements().Where(a => a.Attribute("SchemaId").Value.Equals("tcm:229-58288-8", StringComparison.OrdinalIgnoreCase)).ToList();//.Select(a => a.Attribute("ID").Value, a => a.Attribute("Title").Value).ToArray();
            //string aa = compList.ToString();
            //// *****************************************************************************

            //254-113124
            //var compData = (ComponentData)client.Read("tcm:150-64334", new ReadOptions());
            //var component = (ComponentData)client.GetDefaultData(ItemType.Component, compData.LocationInfo.OrganizationalItem.IdRef, new ReadOptions());

            ////var msc = (SchemaData)client.Read("tcm:254-108733-8", new ReadOptions());
            ////component.Schema = new LinkToSchemaData { IdRef = "tcm:254-108733-8" };
            ////component.MetadataSchema = msc.MetadataSchema;
            ////component.Metadata = msc.Metadata;
            ////client.Save(component, new ReadOptions());


            //var schemaId = "tcm:254-108739-8";
            //SchemaData schemaData = (SchemaData)client.Read(schemaId, null);
            ////string xml = string.Format("<{0} xmlns=\"{1}\">{2}</{0}>", schemaData.RootElementName, schemaData.NamespaceUri, fields);

            //ComponentData componentData = new ComponentData
            //{
            //    Content = compData.Content,
            //    ComponentType = ComponentType.Normal,
            //    Title = compData.Title + "1",
            //    Schema = new LinkToSchemaData { IdRef = schemaId },
            //    LocationInfo = new LocationInfo { OrganizationalItem = new LinkToOrganizationalItemData { IdRef = "tcm:254-13124-2" } },
            //    Id = "tcm:0-0-0",
            //    MetadataSchema = schemaData.MetadataSchema,
            //    Metadata = compData.Metadata
            //};

            //try
            //{
            //    componentData = client.Save(componentData, new ReadOptions()) as ComponentData;
            //    componentData = client.CheckIn(componentData.Id, new ReadOptions()) as ComponentData;

            //}
            //catch (Exception exception)
            //{

            //}
        }
    }
}