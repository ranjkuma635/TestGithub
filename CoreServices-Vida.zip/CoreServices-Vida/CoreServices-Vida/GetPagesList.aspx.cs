﻿using System;
using System.Linq;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml.Linq;
using Tridion.ContentManager.CoreService.Client;

namespace CoreServices_Vida
{
    public partial class GetPagesList : System.Web.UI.Page
    {
        CoreServiceClient client = new CoreServiceClient();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                //client.ClientCredentials.Windows.ClientCredential.UserName = ConfigurationManager.AppSettings["UserId"];
                //client.ClientCredentials.Windows.ClientCredential.Password = ConfigurationManager.AppSettings["Password"];
                client.ChannelFactory.Credentials.Windows.ClientCredential = new System.Net.NetworkCredential();
                client.Open();
            }

        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(txtSchema.Text))
                {
                    UsingItemsFilterData filterCriteria = new UsingItemsFilterData
                    {
                        BaseColumns = ListBaseColumns.Extended,
                        IncludeLocalCopies = true
                    };
                    var resultList = client.GetListXml(txtSchema.Text, filterCriteria).Elements()
                        .Where(a => a.Attribute("IsPublished").Value.Equals("true", StringComparison.OrdinalIgnoreCase))
                        .Select(a => a.Attribute("ID").Value).ToList();

                    StringBuilder sb = new StringBuilder();

                    foreach (string result in resultList)
                    {
                        var page = (PageData)client.Read(result, new ReadOptions());
                        XElement xMetadata = XElement.Parse(page.Metadata);
                        string redirectURL = ((System.Xml.Linq.XElement)xMetadata.FirstNode).Value;
                        PublishLocationInfo info = (PublishLocationInfo)page.LocationInfo;
                        string publishURL = info.PublishLocationUrl;
                        sb = sb.AppendFormat("PageID:{0}\t\tPublish:{1}\t\tRedirect:{2}", result, publishURL, redirectURL).AppendLine();
                    }

                    string fileName = "d:\\EmaarRedirect" + DateTime.Now.ToFileTime() + ".txt";
                    using (System.IO.StreamWriter file = new System.IO.StreamWriter(fileName))
                    {
                        file.WriteLine(sb.ToString());
                        file.Close();
                    }
                }
            }
            catch (Exception ex)
            {

            }
        }
    }
}