﻿using System;
using System.Linq;
using System.Web.UI;
using System.Xml.Linq;
using Tridion.ContentManager.CoreService.Client;

namespace CoreServices_Vida
{
    public partial class MultimediaComponent : System.Web.UI.Page
    {
        CoreServiceClient client = new CoreServiceClient();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                client.ChannelFactory.Credentials.Windows.ClientCredential = new System.Net.NetworkCredential();
                client.Open();
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtFolder.Text == "")
                {
                    lblMessage.Visible = true;
                    lblMessage.Text = "Please enter the folder ID";
                }
                else if (txtFolderNew.Text == "")
                {
                    lblMessage.Visible = true;
                    lblMessage.Text = "Please enter the new folder ID";
                }
                else
                {
                    lblMessage.Visible = false;
                    //string[] componentList = GetComponentList();
                    //foreach (string componentId in componentList)
                    CreateMultimediaComonent("tcm:150-59234", txtFolderNew.Text);
                    //tcm:229-105716
                }
            }
            catch (Exception ex)
            {

            }
        }

        private string[] GetComponentList()
        {
            string folderId = txtFolder.Text;
            OrganizationalItemItemsFilterData filter = new OrganizationalItemItemsFilterData
            {
                ItemTypes = new ItemType[] { ItemType.Component },
                ComponentTypes = new ComponentType[] { ComponentType.Multimedia },
                Recursive = chkRecursive.Checked,
                BaseColumns = ListBaseColumns.Extended
            };
            XElement items = client.GetListXml(folderId, filter);
            string[] compList = items.Elements().Select(a => a.Attribute("ID").Value).ToArray();
            //string[] compList = items.Elements().Where(a=>a.Attribute("SchemaId").Value.Equals("tcm:229-58288-8",StringComparison.OrdinalIgnoreCase)).Select(a => a.Attribute("ID").Value).ToArray();
            return compList;
        }

        private void CreateMultimediaComonent(string componentId, string targetComponentLocationId)
        {
            var targetPubId = targetComponentLocationId.Split('-')[0];
            var compData = (ComponentData)client.Read(componentId, new ReadOptions());
            var component = (ComponentData)client.GetDefaultData(ItemType.Component, compData.LocationInfo.OrganizationalItem.IdRef, new ReadOptions());

            var schemaId = compData.Schema.IdRef.Split('-')[1];
            var targetSchemaId = targetPubId + "-" + schemaId + "-8";
            component.Id = "tcm:0-0-0";
            component.Title = compData.Title;
            component.Schema.IdRef = targetSchemaId; //compData.Schema.IdRef;
            component.Content = compData.Content;

            if (!String.IsNullOrEmpty(compData.Metadata))
                component.Metadata = compData.Metadata;

            if (compData.BinaryContent != null)
            {
                string origFilename = compData.BinaryContent.Filename;
                string extension = origFilename.Substring(origFilename.LastIndexOf('.') + 1);
                string tempPath = string.Empty;

                using (var suClient = new StreamUploadClient("streamUpload_basicHttp_2013"))
                using (var sdClient = new StreamDownloadClient("streamDownload_basicHttp_2013"))
                using (var tempStream = sdClient.DownloadBinaryContent(compData.Id))
                {
                    tempPath = suClient.UploadBinaryContent(origFilename, tempStream);
                }

                // Find multimedia type
                var list = client.GetSystemWideList(new MultimediaTypesFilterData());
                var multimediaType = list.OfType<MultimediaTypeData>().Single(mt => mt.FileExtensions.Contains(extension));

                // Set binary content of component
                component.BinaryContent = new BinaryContentData
                {
                    UploadFromFile = tempPath,
                    Filename = origFilename,
                    MultimediaType = new LinkToMultimediaTypeData { IdRef = multimediaType.Id }
                };
            }
            component.LocationInfo = new LocationInfo
            {
                OrganizationalItem = new LinkToOrganizationalItemData
                {
                    IdRef = targetComponentLocationId
                }
            };

            try
            {
                component = (ComponentData)client.Create(component, new ReadOptions());
            }
            catch (Exception ex)
            {

            }
        }
    }
}