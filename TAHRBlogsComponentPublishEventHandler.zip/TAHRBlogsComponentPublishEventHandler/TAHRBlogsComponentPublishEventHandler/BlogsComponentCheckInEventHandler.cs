﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Configuration;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Tridion.ContentManager;
using Tridion.ContentManager.CommunicationManagement;
using Tridion.ContentManager.ContentManagement;
using Tridion.ContentManager.ContentManagement.Fields;
using Tridion.ContentManager.Extensibility;
using Tridion.ContentManager.Extensibility.Events;
using System.Xml;
using Tridion.ContentManager.Publishing;
using System.Reflection;

namespace TAHRBlogsComponentCheckInEventHandler
{
    /// <summary>
    /// Component Publish Event Handler
    /// </summary>
    [TcmExtension("BlogsComponentCheckInEventHandlerExtension")]
    public class BlogsComponentCheckInEventHandler : TcmExtension
    {
        private const string ITEM_TYPE_SG = "4";
        private const string ITEM_TYPE_CT = "32";
        private const string ITEM_TYPE_PT = "128";
        string BlogsStructureGroupIdPath = "";
        string ComponentTemplateIdPath = "";
        string PageTemplateIdPath = "";
        string LogsFilePath = "";
        string PublicationID = "";
        string BlogsSchemaName = "";
        List<string> PublicationIDs = new List<string>();

        /// <summary>
        /// Class Constructor - Subscribe to the component events to handle.
        /// </summary>
        public BlogsComponentCheckInEventHandler()
        {
            EventSystem.Subscribe<Component, CheckInEventArgs>(OnComponentCheckIn, EventPhases.TransactionCommitted);
        }

        /// <summary>
        /// On Component Publish Pre event handler
        /// </summary>
        /// <param name="component">The blog component published</param>
        /// <param name="args">The PublishEventArgs instance.</param>
        /// <param name="phase">The EventPhase enum.</param>
        private void OnComponentCheckIn(Component component, CheckInEventArgs args, EventPhases phase)
        {
            InitializeConfigData();

            WriteLog("BlogsComponentCheckInEventHandler: OnComponentCheckIn Event called!");
            if (component.Schema.Title.ToLower().Replace(" ", "").Equals(BlogsSchemaName) && !ComponentHasPage(component))
            {
                WriteLog("Component:  '" + component.Title + "'  using Blogs Schema doesn't has any Page. Creating a page for now");
                CreateBlogPage(component);
            }
        }

        /// <summary>
        /// Creates a page and adds the component to it.
        /// </summary>
        /// <param name="component">The component to create the page for.</param>
        private void CreateBlogPage(Component component)
        {
            try
            {
                Session session = component.Session;

                WriteLog("Context Repository: " + component.ContextRepository.Id);

                //BluePrintNodesFilter ndfilter = new BluePrintNodesFilter(component.Session);
                ////ndfilter.ForItem = component;
                //ndfilter.ForRepository = component.OwningRepository;
                
                //SystemManager tridionSM = session.SystemManager;
                //IEnumerable<BluePrintNode> nodes = tridionSM.GetBluePrintNodes(ndfilter);
                //foreach(BluePrintNode nd in nodes)
                //{
                //    WriteLog("NODE: >> " + nd.Title + " , " + nd.Id.PublicationId);
                //    if(nd.Parents.Contains(component.OwningRepository) && nd.Title.StartsWith("05") && nd.PublicationType == "")
                //    {
                //        WriteLog("Inherited In Publication>> " + nd.Title);
                //    }
                //}

                StructureGroup blogsStructureGroup = session.GetObject("tcm:" + PublicationID + "-" + BlogsStructureGroupIdPath + "-" + ITEM_TYPE_SG) as StructureGroup;

                if (blogsStructureGroup == null)
                {
                    throw new Exception("BlogsComponentCheckInEventHandler: Unable to get blogsStructureGroup");
                }

                // Read the WebDav Url/ TCM Uri through Configuration file using separate keys
                // Either use WebDav Url or the TCM Uri
                ComponentTemplate blogComponentTemplate = session.GetObject("tcm:" + PublicationID + "-" + ComponentTemplateIdPath + "-" + ITEM_TYPE_CT) as ComponentTemplate;

                if (blogComponentTemplate == null)
                {
                    throw new Exception("BlogsComponentCheckInEventHandler Error: Unable to read componentTemplate");
                }

                // Read the WebDav Url/ TCM Uri through Configuration file using separate keys
                // Either use WebDav Url or the TCM Uri
                PageTemplate blogPageTemplate = session.GetObject("tcm:" + PublicationID + "-" + PageTemplateIdPath + "-" + ITEM_TYPE_PT) as PageTemplate;

                if (blogPageTemplate == null)
                {
                    throw new Exception("BlogsComponentCheckInEventHandler Error: Unable to read pageTemplate");
                }

                OrganizationalItemItemsFilter filter = new OrganizationalItemItemsFilter(session);
                filter.ItemTypes = new List<ItemType> { ItemType.StructureGroup };

                Page newBlogPage = blogsStructureGroup.GetNewObject<Page>();
                newBlogPage.PageTemplate = blogPageTemplate;
                newBlogPage.Title = component.Title;
                newBlogPage.FileName = GetPageFileName(component.Title);

                Component contextPublicationComponent = session.GetObject(new TcmUri(component.Id.ItemId, ItemType.Component, blogsStructureGroup.Id.PublicationId)) as Component;
                ComponentPresentation compPresn = new ComponentPresentation(contextPublicationComponent, blogComponentTemplate);
                newBlogPage.ComponentPresentations.Add(compPresn);

                newBlogPage.Save(true);

                //Publish the Page on Staging
                List<IdentifiableObject> items = new List<IdentifiableObject>();
                items.Add(newBlogPage);
                List<TargetType> stagingTarget = new List<TargetType> { new TargetType(new TcmUri(2, ItemType.TargetType), component.Session) };
                PublishInstruction instruction = new PublishInstruction(component.Session);
                WriteLog("Publishing the Page: " + newBlogPage.Title);
                PublishEngine.Publish(items, instruction, stagingTarget, PublishPriority.Normal);
                WriteLog("Successfully published the Page: " + newBlogPage.Title);
            }
            catch (Exception ex)
            {
                WriteLog(ex.Message + Environment.NewLine + ex.StackTrace + ex.InnerException);
            }
        }

        /// <summary>
        /// Reads and sets the configuration values from an XML based file
        /// </summary>
        private void InitializeConfigData()
        {
            XmlDocument configDoc = new XmlDocument();
            string customConfigFile = "BlogsComponentCheckInEventHandler.config";
            WriteLog("Reading Configuration Data");

            Assembly assembly = Assembly.GetExecutingAssembly();
            Stream stream = assembly.GetManifestResourceStream(this.GetType(), customConfigFile);

            try
            {
                if (stream != null)
                {
                    configDoc.Load(stream);
                }
            }
            catch (Exception ex)
            {
                WriteLog("Error in reading Embedded Config File: " + ex.Message + ex.StackTrace);
            }

            if (configDoc.DocumentElement != null && configDoc.DocumentElement.HasChildNodes)
            {
                XmlNodeList configurationData = configDoc.GetElementsByTagName("add");

                LogsFilePath = configurationData.Cast<XmlNode>().Where(node => node.Attributes["key"].Value == "LogsFilePath").Select(x => x.Attributes["value"].Value).FirstOrDefault();
                WriteLog("LogsFilePath: " + LogsFilePath);

                ComponentTemplateIdPath = configurationData.Cast<XmlNode>().Where(node => node.Attributes["key"].Value == "ComponentTemplateIdPath").Select(x => x.Attributes["value"].Value).FirstOrDefault();
                WriteLog("ComponentTemplateIdPath: " + ComponentTemplateIdPath);

                PageTemplateIdPath = configurationData.Cast<XmlNode>().Where(node => node.Attributes["key"].Value == "PageTemplateIdPath").Select(x => x.Attributes["value"].Value).FirstOrDefault();
                WriteLog("PageTemplateIdPath: " + PageTemplateIdPath);

                BlogsStructureGroupIdPath = configurationData.Cast<XmlNode>().Where(node => node.Attributes["key"].Value == "BlogsStructureGroupIdPath").Select(x => x.Attributes["value"].Value).FirstOrDefault();
                WriteLog("BlogsStructureGroupIdPath: " + BlogsStructureGroupIdPath);

                PublicationID = configurationData.Cast<XmlNode>().Where(node => node.Attributes["key"].Value == "PublicationID").Select(x => x.Attributes["value"].Value).FirstOrDefault();

                BlogsSchemaName = configurationData.Cast<XmlNode>().Where(node => node.Attributes["key"].Value == "BlogsSchemaName").Select(x => x.Attributes["value"].Value).FirstOrDefault();
                WriteLog("BlogsSchemaName: " + BlogsSchemaName);
            }
            configDoc = null;
        }

        /// <summary>
        /// Checks if component is used on a Page
        /// </summary>
        /// <param name="component">The blog component to check.</param>
        /// <returns>True if no page is found.</returns>
        private bool ComponentHasPage(Component component)
        {
            UsingItemsFilter filter = new UsingItemsFilter(component.Session);
            filter.ItemTypes = new List<ItemType> { ItemType.Page };
            filter.IncludedVersions = VersionCondition.OnlyLatestVersions;
            WriteLog("Component has Page:" + (component.GetUsingItems(filter).Count() != 0).ToString());
            return component.GetUsingItems(filter).Count() != 0;
        }

        /// <summary>
        /// Creates a url friendly title.
        /// </summary>
        /// <param name="title">The title to simplify.</param>
        /// <returns>A URL friendly title.</returns>        
        private string GetPageFileName(string title)
        {
            WriteLog("Page Title: " + title);
            title = Regex.Replace(title, @"[^a-zA-Z0-9\s-]", ""); // Keep only alphabets/numerals/spaces/hyphens
            title = Regex.Replace(title, @"\s+", " ").Trim(); // replace multiple spaces,if any, into one space                
            title = Regex.Replace(title, @"\s", "-"); // replace all one space with hyphens            
            WriteLog("Page File Name: " + title);
            return title;
        }

        /// <summary>
        /// Logs the specific messages
        /// </summary>
        /// <param name="logMessage">The Log Message to write</param>
        private void WriteLog(string logMessage)
        {
            if (!string.IsNullOrEmpty(LogsFilePath))
            {
                using (StreamWriter writer = new StreamWriter(@LogsFilePath + "BlogsComponentCheckInEventHandlerLogs" + DateTime.Now.ToString("MM-dd-yyyy") + ".txt", true)) // True parameter to append the log messages
                {
                    writer.WriteLine(DateTime.Now.ToString("MM-dd-yyyy hh:mm:ss >> ") + logMessage);
                }
            }
        }
    }
}
