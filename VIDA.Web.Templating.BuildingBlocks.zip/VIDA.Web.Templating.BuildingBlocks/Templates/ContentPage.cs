﻿using System;
using System.Linq;
using Tridion.ContentManager.CommunicationManagement;
using Tridion.ContentManager.Templating;
using Tridion.ContentManager.Templating.Assembly;
using Tridion.ContentManager.ContentManagement.Fields;
using Tridion.Extensions.ContentManager.Templating;
using Tridion.ContentManager.ContentManagement;
using Tridion.ContentManager.Publishing.Rendering;
using Emaar.Web.Tridion.System.Extensions;
using System.Xml;
using Tridion.ContentManager;

namespace VIDA.Web.Templating.BuildingBlocks.Templates {
    [TcmTemplateTitle("Content Page")]
    public class ContentPage : TemplateBase {

        public override void Transform(Engine engine, Package package) {
            base.Transform(engine, package);
            base.Transform(engine, package);
            String seoDescription = String.Empty;
            String seoKeywords = String.Empty;
            String seoImage = String.Empty;
            String spageTitle = String.Empty;
            String pub = String.Empty;
            String ExtentionLessURL = String.Empty;
            String CanonicalURL = String.Empty;
            String RelativeURL = String.Empty;

            if (Page.ComponentPresentations.Count > 0)
            {
                Component component = Page.ComponentPresentations[0].Component;


                if (component.EmbeddedMetaValue("seodata") != null)
                {
                    ItemFields seoMetadata = component.EmbeddedMetaValue("seodata");

                    if (!String.IsNullOrEmpty(seoMetadata.StringValue("pageTitle"))){
                        spageTitle = seoMetadata.StringValue("pageTitle");
                    }

                    if (seoMetadata.StringValue("SEODescription") != null){
                        seoDescription = seoMetadata.StringValue("SEODescription");
                    }
                    if (seoMetadata.StringValue("SEOKeywords") != null){
                        seoKeywords = seoMetadata.StringValue("SEOKeywords");
                    }
                }
                seoImage = calloutImage(component);

                if (String.IsNullOrEmpty(spageTitle)){
                    spageTitle=calloutText(component);
                }
                if (String.IsNullOrEmpty(spageTitle)){
                    spageTitle = PageTitle(Page);
                }

                if (String.IsNullOrEmpty(seoDescription)){
                    seoDescription = calloutText(component);
                }

                //package.AddString("PageTitle", formatPageTitle(spageTitle));
                package.AddString("PageTitle", spageTitle);
                package.AddString("SEODescription", seoDescription);
                package.AddString("SEOKeywords", seoKeywords);
                package.AddString("SEOImage", seoImage);
                package.AddString("PageURL", Page.PublishLocationUrl);
                package.AddString("pub", Page.PublishLocationUrl.Split('/')[1]);

                try
                {
                    pub = Page.PublishLocationUrl.Split('/')[1];
                    ExtentionLessURL = Page.PublishLocationUrl.Split('.')[0];
                    CanonicalURL = ExtentionLessURL.Replace("/index", "/");
                    RelativeURL = CanonicalURL.Replace("/" + pub, "");

                    package.AddString("CanonicalURL", CanonicalURL);
                    package.AddString("RelativeURL", RelativeURL);
                }
                catch (Exception ex) {
                    Logger.Error(ex.Message);
                }


            }

            package.AddHtml("Banner", BannerImage(Page, engine));

            StructureGroup sg = Page.OrganizationalItem as StructureGroup;
            if (sg != null){
                package.PushItem("NavParentPath", package.CreateHtmlItem(sg.PublishLocationUrl));
                package.AddString("NavigationParent", sg.Id.ToString());
            }
            
        }

        private String PageTitle(Page Page)
        {
            string navTitle = "";
            if (Page.Title.IndexOf(".") != -1)
            {
                navTitle = Page.Title.Substring(Page.Title.IndexOf(".") + 1).Trim();
            }
            else
            {
                navTitle = Page.Title.Trim();
            }

            return navTitle;
        }

        public string StripPrefix(string title)
        {
            int length = 4;
            if (title.Length < 4)
                length = title.Length - 1;
            string prefix = title.Substring(0, length);
            int result = 0;
            //Handle number prefix
            if (int.TryParse(prefix, out result))
            {
                title = title.Substring(title.IndexOf(" ") + 1);
            }
            title = title.Split('.')[1];
            title = title.Trim();
            return title;
        }

        private Page GetPage(Engine engine, Package package)
        {
            CheckInitialized();
            //first try to get from the render context
            RenderContext renderContext = engine.PublishingContext.RenderContext;
            if (renderContext != null)
            {
                Page contextPage = renderContext.ContextItem as Page;
                if (contextPage != null)
                    return contextPage;
            }
            Item pageItem = package.GetByType(ContentType.Page);
            if (pageItem != null)
                return (Page)engine.GetObject(pageItem.GetAsSource().GetValue("ID"));

            return null;
        }

        private string calloutImage(Component component)
        {

            if (component.EmbeddedMetaValue("callout") != null)
            {
                ItemFields callout = component.EmbeddedMetaValue("callout");

                if (callout.ComponentValue("image") != null)
                {
                    Logger.Info("calloutImage " + callout.ComponentValue("image"));
                    return PublishBinary(callout.ComponentValue("image"));
                }
                else if (component.ComponentValue("image") != null)
                {
                    Logger.Info("compImage " + component.ComponentValue("image"));
                    return PublishBinary(component.ComponentValue("image"));
                }
            }
            return string.Empty;
        }

        private string calloutText(Component component)
        {

            if (component.EmbeddedMetaValue("callout") != null)
            {
                ItemFields callout = component.EmbeddedMetaValue("callout");

                if (!String.IsNullOrEmpty(callout.StringValue("value")))
                {
                    return callout.StringValue("value");
                }
            }
            if (component.StringValue("title") != null){
                        return component.StringValue("title");
            }
            return string.Empty;
        }

        private string BannerImage(Page Page,Engine engine)
        {

            StructureGroup sg = Page.OrganizationalItem as StructureGroup;
            XmlNode xImage = null;
            XmlNode xBanner = null;
            XmlNodeList xBannerList = null;
            if (xImage == null)
            {
                if (Page.Metadata != null)
                {
                    xBannerList = Page.Metadata.ChildNodes;
                    foreach (XmlNode item in xBannerList)
                    {
                        if (item.Name.Equals("fBanner"))
                        {
                            xBanner = item;
                            break;
                        }

                    }
                }

                if (xBanner == null)
                {
                    do
                    {
                        if (sg.Metadata != null)
                        {
                            xBannerList = sg.Metadata.ChildNodes;
                            foreach (XmlNode item in xBannerList)
                            {
                                if (item.Name.Equals("fBanner"))
                                {
                                    xBanner = item;
                                    break;
                                }
                            }
                        }
                        if (sg.Title.Equals("Root"))
                        {
                            break;
                        }
                        else
                        {
                            sg = sg.OrganizationalItem as StructureGroup;
                        }
                    }
                    while (xBanner == null);
                }


                if (xBanner != null)
                {
                    if (xBanner.Attributes["xlink:href"] != null)
                    {
                        string heroID = xBanner.Attributes["xlink:href"].Value;

                        if (!String.IsNullOrEmpty(heroID) && heroID.Contains("tcm:"))
                        {
                            if (Page.PageTemplate.Title.Equals("Vida Site Page Template") || Page.PageTemplate.Title.Equals("Vida Footer Page Template"))
                            {
                                return engine.RenderComponentPresentation(GetComponent(heroID).Id, new TcmUri(58516, ItemType.ComponentTemplate, Publication.Id.ItemId));
                            }
                            else 
                            {
                                return engine.RenderComponentPresentation(GetComponent(heroID).Id, new TcmUri(58727, ItemType.ComponentTemplate, Publication.Id.ItemId));
                            }
                        }
                    }
                }
            }
            return "";
        }


        private string formatPageTitle(string title)
        {
            if (Page.PageTemplate.Title.Equals("Vida Home Page Template"))
            {
                return title;
            }

            if (Page.PageTemplate.Title.Equals("Vida Main Page Template"))
            {
                return title;
            }

            if (Page.PageTemplate.Title.Equals("Vida Footer Page Template"))
            {
                return Package.GetValue("VHRTitle") + " - " + title;
            }

            if (Package.GetValue("hotel").Equals("vida"))
            {
                return Package.GetValue("VDDTitle") + " - " + title;
            }

            if (Package.GetValue("hotel").Equals("manzil"))
            {
                return Package.GetValue("MDDTitle") + " - " + title;
            }

            return title;
        }


    }
}
