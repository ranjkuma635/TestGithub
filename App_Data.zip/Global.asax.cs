﻿using Autofac;
using Autofac.Integration.Mvc;
using DD4T.DI.Autofac;
using log4net.Config;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Web;
using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Routing;

namespace Emaar.PierSeven.Web
{
    public class MvcApplication : System.Web.HttpApplication
    {
        private ILifetimeScope DD4T_Start()
        {
            var builder = new ContainerBuilder();
            builder.UseDD4T();

            // Register All MVC controllers
            builder.RegisterControllers(Assembly.GetExecutingAssembly());
            return builder.Build();
        }

        protected void Application_Start()
        {
            // Clear all View Engines and keep razor only.
            // This will prevent Asp.NET MVC from searching for .aspx/.ascx views
            ViewEngines.Engines.Clear();
            ViewEngines.Engines.Add(new RazorViewEngine());

            // Load log4net configuration
            string logFilePath = System.Web.Hosting.HostingEnvironment.MapPath(@"\Config\Log4Net.config");
            FileInfo finfo = new FileInfo(logFilePath);
            log4net.Config.XmlConfigurator.Configure(finfo);

            // Initialize the Autofac Dependency 
            var diContainer = DD4T_Start();
            DependencyResolver.SetResolver(new AutofacDependencyResolver(diContainer));
            
            AreaRegistration.RegisterAllAreas();
            BundleConfig.RegisterBundles(BundleTable.Bundles);
            RouteConfig.RegisterRoutes(RouteTable.Routes);
        }

    }
}
