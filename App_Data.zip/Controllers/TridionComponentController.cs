﻿using DD4T.ContentModel;
using DD4T.ContentModel.Contracts.Configuration;
using DD4T.ContentModel.Contracts.Logging;
using DD4T.ContentModel.Factories;
using DD4T.Mvc.Controllers;
using log4net;
using System.Web.Mvc;

namespace Emaar.PierSeven.Web.Controllers
{
    public class TridionComponentController : TridionControllerBase
    {
        
        public TridionComponentController(IPageFactory pageFactor,
                                IComponentPresentationFactory componentPresentationFactory,
                                ILogger logger,
                                IDD4TConfiguration configuration)
              :base(pageFactor, componentPresentationFactory, logger, configuration)
            {

            }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="componentPresentation"></param>
        /// <returns></returns>
        public ActionResult Component(ComponentPresentation componentPresentation)
        {
            //IPage currentPage = GetModelForPage(pageId);
            //IComponent primaryComponent;
            //string primaryComponentUrl;
            //LinkFactory linkFactory = new LinkFactory();
            //foreach (var cp in currentPage.ComponentPresentations)
            //{
            //    primaryComponent = cp.Component;
            //    primaryComponentUrl = linkFactory.ResolveLink(primaryComponent.Id);
            //    if (primaryComponentUrl.Equals(pageId))
            //    {
            //        ViewBag.PrimaryComponent = primaryComponent;
            //        ViewBag.PrimaryComponentUrl = primaryComponentUrl;

            //        break;
            //    }
            //}
            //ViewBag.pageId = ViewBag.pageId;

            return base.ComponentPresentation();
        }

        
    }
}