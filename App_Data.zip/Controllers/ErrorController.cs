﻿/*
 * Controller to handle all errors on Page requests
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;

namespace Emaar.PierSeven.Web
{
    public class ErrorController : Controller
    {

        [AcceptVerbs(HttpVerbs.Get)]
        public ViewResult NotFound()
        {
            this.Response.StatusCode = (int)HttpStatusCode.NotFound;
            return View();
        }
    }
}