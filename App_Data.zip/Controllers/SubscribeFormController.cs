﻿using System;
using System.IO;
using System.Web;
using System.Linq;
using System.Web.Mvc;
using System.Net.Mail;
using System.Configuration;
using System.Collections.Generic;
using DD4T.ContentModel;
using DD4T.Mvc.Controllers;
using DD4T.ContentModel.Factories;
using DD4T.ContentModel.Contracts.Logging;
using DD4T.ContentModel.Contracts.Configuration;
using Emaar.PierSeven.Web;
using Emaar.PierSeven.Web.Models;
using Emaar.PierSeven.Web.Helpers;
//using Pier7.DVO;
//using Pier7.DAO;

namespace Emaar.PierSeven.Web.Controllers
{
    public class SubscribeFormController : TridionControllerBase
    {
        public SubscribeFormController(IPageFactory pageFactor,
                                IComponentPresentationFactory componentPresentationFactory,
                                ILogger logger,
                                IDD4TConfiguration configuration)
              :base(pageFactor, componentPresentationFactory, logger, configuration)
            {

            }

        Subscribe subscribeData = new Subscribe();
        // GET: /SubscribeForm/
        [HttpGet]
        public ActionResult Subscribe(string PageUrl)
        {
            TempData["LeftContainer"] = BrokerHelper.GetComponentBySchema(ConfigurationHelper.LeftContainerCompoSchemaName, ConfigurationHelper.GetAppsettingValue("LeftContainerComponentTitle"));

            #region Fetch Header & Footer from Broker DB
            //Logger.WriteLog(LogLevel.DEBUG, "Getting header component");
            TempData["Footer"] = WebHelper.GetSiteFooter();

            //Logger.WriteLog(LogLevel.DEBUG, "Getting footer component");
            TempData["Header"] = WebHelper.GetSiteHeader();
            #endregion
            
            //Set Page SEO & Metadata
            GetPageSEOMetadata(WebHelper.ScanPageURL(PageUrl));
            ViewBag.ModelState = "FORM_GET";
            return View();
        }

        [HttpPost]
        public ActionResult Subscribe(Subscribe subscribeModel)
        {
            if (!ModelState.IsValid)
            {
                ViewBag.ModelState = "STATE_INVALID";
                return View();
            }

            ContactUsDVO cDVO = null;
            ContactUsHelper cDAO = null;
            subscribeData = subscribeModel;

            try
            {
                cDVO = new ContactUsDVO();
                cDAO = new ContactUsHelper();

                if (subscribeModel.EmailId == "")
                {
                    cDVO.Name = subscribeModel.Name;
                    cDVO.Contactno = subscribeModel.Contact;
                    cDVO.Email = subscribeModel.EmailId;
                    cDVO.Message = subscribeModel.Message;

                    //cDAO.Addcontactus(cDVO);
                    SendMail(ConfigurationManager.AppSettings["Toemail"].ToString(), subscribeModel.EmailId, ConfigurationManager.AppSettings["Subject"].ToString());
                    
                    subscribeModel.Name = "";
                    subscribeModel.Contact = "";
                    subscribeModel.EmailId = "";
                    subscribeModel.Message = "";

                    //maindiv.Visible = false;
                    //thankyiou.Visible = true;                   
                }
            }
            catch (Exception ex) { }
            finally
            {
                cDVO = null;
                cDAO = null;
            }

            //return Content("<p>Thank you for subscribing to receive email updates about restaurants in Pier 7.</p>");
            ViewBag.ModelState = "STATE_VALID";
            return View();
        }

        private void GetPageSEOMetadata(string pageURL)
        {
            string pageSeoCacheKey = Request.Url.AbsolutePath + ConfigurationHelper.PageSEOCacheKey;
            PageSEOMeta pageSEO = CacheHelper.Get<PageSEOMeta>(pageSeoCacheKey);

            if (pageSEO == null)
            {
                // Set page SEO
                IPage page = base.GetPage(pageURL);
                if (page != null)
                {
                    pageSEO = WebHelper.MapPageSEOMetaData(page);
                    CacheHelper.Add<PageSEOMeta>(pageSEO, pageSeoCacheKey, ConfigurationHelper.CacheExpirationTime);
                }
            }
            ViewBag.SEO = pageSEO;
        }
        
        private string GenerateBody(Subscribe subscribeGetData)
        {
            string _printHTMLTemptalate = System.IO.File.ReadAllText(Server.MapPath("/include/enquiries.htm"));

            string _tempReciept = _printHTMLTemptalate;

            _tempReciept = _tempReciept.Replace("[Name]", subscribeGetData.Name);
            _tempReciept = _tempReciept.Replace("[ContactNumber]", subscribeGetData.Contact);
            _tempReciept = _tempReciept.Replace("[EmailAddress]", subscribeGetData.EmailId);
            _tempReciept = _tempReciept.Replace("[Comment]", subscribeGetData.Message);

            return _tempReciept.ToString();
        }

        private void SendMail(string Toemailaddress, string Fromemailaddress, string Subject)
        {
            MailMessage mail = null;
            try
            {
                mail = new MailMessage();
                
                mail.SubjectEncoding = System.Text.Encoding.UTF8;

                MailAddress add = new MailAddress(Fromemailaddress);
                mail.From = add;

                mail.To.Add(Toemailaddress);

                mail.Subject = Subject;

                mail.BodyEncoding = System.Text.Encoding.UTF8;
                mail.IsBodyHtml = true;
                
                mail.Body = GenerateBody(subscribeData);

                SmtpClient mSmtpClient = new SmtpClient(ConfigurationManager.AppSettings["SmtpClient"].ToString());
                mSmtpClient.Send(mail);

            }
            catch (Exception) { }
            finally
            {
                mail = null;

            }
        }
    }
}