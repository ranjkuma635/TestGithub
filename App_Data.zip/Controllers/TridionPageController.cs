﻿using DD4T.ContentModel.Contracts.Configuration;
using DD4T.ContentModel.Contracts.Logging;
using DD4T.ContentModel.Factories;
using DD4T.Mvc.Controllers;
using DD4T.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;
using System.Configuration;
using Tridion.ContentDelivery.DynamicContent.Query;
using Tridion.ContentDelivery.DynamicContent;
using log4net;
using Emaar.PierSeven.Web.Helpers;
using Emaar.PierSeven.Web.Models;
using DD4T.ContentModel;

namespace Emaar.PierSeven.Web
{
    public class TridionPageController : TridionControllerBase
    {
       
        public TridionPageController(IPageFactory pageFactor,
                                IComponentPresentationFactory componentPresentationFactory,
                                ILogger logger,
                                IDD4TConfiguration configuration)
              :base(pageFactor, componentPresentationFactory, logger, configuration)
            {

            }

        #region ACTION METHODS
        /// <summary>
        /// Action method to handle all requests
        /// </summary>
        /// <param name="PageUrl"></param>
        /// <returns></returns>
        //  [OutputCache(CacheProfile = "PageCache")]
        public override ActionResult Page(string PageUrl)
        {
            ActionResult result = null;
            string _updatedPageUrl = string.Empty;

            //try
            //{
                _updatedPageUrl = WebHelper.ScanPageURL(PageUrl);            
                result = base.Page(_updatedPageUrl);
            //}
            //catch (Exception ex)
            //{
            //    System.Web.Routing.RouteData routeData = new System.Web.Routing.RouteData();
            //    //Setting the Controller to be used for Error Handling in MVC
            //    routeData.Values.Add("controller", "Error");

            //    Logger.WriteException(LogLevel.FATAL, "Application Exception in Page Controller", ex);

            //    //Setting the Action method to be executed
            //    routeData.Values.Add("action", "NotFound");

            //    //Execute the ErrorController Action Method: NotFound()
            //    IController controller = new ErrorController();
            //    controller.Execute(new RequestContext(new HttpContextWrapper(System.Web.HttpContext.Current), routeData));
            //}

                #region Fetch Header & Footer from Broker DB
                //Logger.WriteLog(LogLevel.DEBUG, "Getting header component");
                TempData["Footer"] = WebHelper.GetSiteFooter();

                //Logger.WriteLog(LogLevel.DEBUG, "Getting footer component");
                 TempData["Header"] = WebHelper.GetSiteHeader();
                #endregion

                //Set Page SEO & Metadata
                GetPageSEOMetadata(_updatedPageUrl);
            return result;
        }

        #endregion 

        #region PRIVATE METHODS

          
        private void GetPageSEOMetadata(string pageURL)
        {
            string pageSeoCacheKey = Request.Url.AbsolutePath + ConfigurationHelper.PageSEOCacheKey;
            PageSEOMeta pageSEO = CacheHelper.Get<PageSEOMeta>(pageSeoCacheKey);

            if (pageSEO == null)
            {
                // Set page SEO
                IPage page = base.GetPage(pageURL);
                if (page != null)
                {
                    pageSEO = WebHelper.MapPageSEOMetaData(page);
                    CacheHelper.Add<PageSEOMeta>(pageSEO, pageSeoCacheKey, ConfigurationHelper.CacheExpirationTime);
                }
            }
            ViewBag.SEO = pageSEO;
        }

        #endregion 

        #region ERROR HANDLING

        /// <summary>
        /// Method to write all exception that occurs in a request
        /// </summary>
        /// <param name="filterContext"> Filter context </param>
        protected override void OnException(ExceptionContext filterContext)
        {
            if (filterContext == null)
            {
                return;
            }

            // log exception
            var ex = filterContext.Exception;
            if (ex != null)
            {
                //Logger.WriteException(LogLevel.ERROR, "Exception in Page Controller", ex);
                DD4T.Utils.Logger.Debug("ERROR", new string[] { "TEST" });
                LoggerService.Debug("ERROR", new string[] { "TEST" });
            }

            // This is explicitly commented to avoid MVC looking for an Error view.
            // base.OnException(filterContext);
        }

        #endregion 
    }
}