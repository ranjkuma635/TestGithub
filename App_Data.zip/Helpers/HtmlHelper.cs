﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using DD4T.ContentModel;
using DD4T.Factories;
using DD4T.Utils;
using Tridion.ContentDelivery.DynamicContent.Query;
using System.Configuration;
using Emaar.PierSeven.Web.Constants;
using Emaar.PierSeven.Web.Models;
using DD4T.ContentModel.Factories;
using System.Web.Mvc;
using DD4T.ContentModel.Contracts.Providers;
using System.Web;
using System.Xml;
using System.Xml.Xsl;
using System.IO;
using System.Globalization;

namespace Emaar.PierSeven.Web.Helpers
{
    public enum NavigationType
    {
        Header = 0,
        Footer,
        BreadCrumb,
        DineList,
        PreviousNext,
        Sitemap
    }
    public static class HtmlHelperExtensions
    {       

        public static string GetNavigation(this HtmlHelper helper, NavigationType navigationType)
        {
            //Logger.WriteLog(LogLevel.INFO, "----------GETTING NAVIGATION FOR----------" + navigationType.ToString());
            XmlDocument navigationXMLDoc = new XmlDocument();
            XslCompiledTransform xslt = new XslCompiledTransform();
            XsltArgumentList args = new XsltArgumentList();
            //MemoryStream xsltMemoryStream = new MemoryStream();
            string resultHtml = string.Empty;

            try
            {
                navigationXMLDoc.Load(HttpContext.Current.Server.MapPath(ConfigurationManager.AppSettings["NavigationFileXMLPath"]));

                if (navigationType == NavigationType.Header)
                {
                    xslt.Load(HttpContext.Current.Server.MapPath("/system/xsl/MainNavigation.xslt"));
                }
                else if (navigationType == NavigationType.Footer)
                {
                    xslt.Load(HttpContext.Current.Server.MapPath("/system/xsl/Footer.xslt"));
                }
                else if(navigationType == NavigationType.DineList)
                {
                    xslt.Load(HttpContext.Current.Server.MapPath("/system/xsl/DineList.xslt"));
                }
                else if(navigationType == NavigationType.BreadCrumb)
                {
                    xslt.Load(HttpContext.Current.Server.MapPath("/system/xsl/BreadCrumbs.xslt"));
                }
                else if (navigationType == NavigationType.PreviousNext)
                {
                    xslt.Load(HttpContext.Current.Server.MapPath("/system/xsl/PreviousNext.xslt"));
                }
                else if(navigationType == NavigationType.Sitemap)
                {
                    xslt.Load(HttpContext.Current.Server.MapPath("/system/xsl/Sitemap.xslt"));
                }

                PageData pageData = BrokerHelper.GetPageData(HttpContext.Current.Request.RawUrl);
                PublicationData PagePublicationData = BrokerHelper.GetPublicationData(pageData.PublicationID.ToString().Split('-').GetValue(1).ToString().Trim());
                //Add XSLT Arguments
                args.AddParam("langCode", "", CultureInfo.CurrentCulture.ToString());
                args.AddParam("basePage", "", HttpContext.Current.Request.Url.AbsolutePath);
                
                //Logger.WriteLog(LogLevel.INFO, "PAGE ID:: " + pageData.PageURI);
                args.AddParam("PageID", "", pageData.PageURI);

                //Logger.WriteLog(LogLevel.INFO, "SG ID:: " + pageData.StructureGroupID);
                args.AddParam("StructureGroupID", "", pageData.StructureGroupID);

                args.AddParam("pageTitle", "", pageData.PageTitle);
                args.AddParam("CustompageTitle", "", pageData.PageTitle);
                args.AddParam("navParent", "", pageData.NavParent);
                args.AddParam("publicationID", "", PagePublicationData.PublicationID);
                args.AddParam("publicationUrl", "", PagePublicationData.PublicationURL);
                args.AddParam("Title", "", pageData.PageTitle);

                using (MemoryStream xsltMemoryStream = new MemoryStream())
                {
                    xslt.Transform(navigationXMLDoc, args, xsltMemoryStream);
                    xsltMemoryStream.Position = 0;
                    using (StreamReader xsltStreamReader = new StreamReader(xsltMemoryStream))
                    {
                        resultHtml = xsltStreamReader.ReadToEnd();
                        //Logger.WriteLog(LogLevel.INFO, "XML for Type: " + navigationType.ToString()+ ">>> XML:: " + resultHtml);
                    }
                }
                args.Clear();

                return resultHtml;
            }
            catch(Exception ex)
            {
                Logger.WriteException(LogLevel.ERROR, "Error in GetNavigation Function, ", ex);
                args.Clear();
                return "";
            }
            
        }
    }
        
}
