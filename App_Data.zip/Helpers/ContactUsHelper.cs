﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using Emaar.PierSeven.Web.Models;
using System.Data.SqlClient;

namespace Emaar.PierSeven.Web.Helpers
{
    public class ContactUsHelper
    {
        private string getConnectionString()
        {
            return ConfigurationManager.ConnectionStrings["PierSevenContactUsConnectionStr"].ToString();
        }

        public void AddContactUs(ContactUsDVO cDVO)
        {
            using (SqlConnection sqlConnection = new SqlConnection(getConnectionString()))
            {
                try
                {
                    sqlConnection.Open();
                    using (SqlCommand sqlCommand = new SqlCommand())
                    {
                        sqlCommand.Connection = sqlConnection;
                        sqlCommand.CommandType = System.Data.CommandType.StoredProcedure;
                        sqlCommand.CommandText = "sp_Piersevencontact";
                        sqlCommand.Parameters.AddWithValue("Name", cDVO.Name);
                        sqlCommand.Parameters.AddWithValue("Contactno", cDVO.Contactno);
                        sqlCommand.Parameters.AddWithValue("Email", cDVO.Email);
                        sqlCommand.Parameters.AddWithValue("Message", cDVO.Message);
                        sqlCommand.ExecuteNonQuery();
                    }
                }
                catch (Exception ex)
                {
                    Logger.WriteException(LogLevel.ERROR, ">>>>ERROR ADDING CONTACT>>>>", ex);
                }
            }
        }
    }
}