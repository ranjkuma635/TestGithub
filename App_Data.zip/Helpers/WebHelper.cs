﻿using DD4T.ContentModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Emaar.PierSeven.Web.Models;
using Emaar.PierSeven.Web.Constants;
using System.Web.Caching;

namespace Emaar.PierSeven.Web.Helpers
{
    public class WebHelper
    {
        public static dynamic GetSiteFooter()
        {
            string footerCacheKey = "footerCache";
            IComponent siteFooter = CacheHelper.Get<IComponent>(footerCacheKey);

            if (siteFooter == null)
            {
                siteFooter = BrokerHelper.GetComponentBySchema("PIER7-FooterMarginalMenus");
                CacheHelper.Add<IComponent>(siteFooter, footerCacheKey, ConfigurationHelper.CacheExpirationTime);
            }

            return siteFooter;
        }
        public static IComponent GetSiteHeader()
        {
            string headerCacheKey = "headerCache";
            IComponent siteHeader = CacheHelper.Get<IComponent>(headerCacheKey);

            if (siteHeader == null)
            {
                siteHeader = BrokerHelper.GetComponentBySchema("PIER7-HeaderMarginalMenus");
                CacheHelper.Add<IComponent>(siteHeader, headerCacheKey, ConfigurationHelper.CacheExpirationTime);
            }

            return siteHeader;
        }
        /// <summary>
        /// Fill SEO Data 
        /// </summary>
        /// <param name="page"> Page object </param>
        /// <param name="pageSEO"> Page SEO </param>
        public static PageSEOMeta MapPageSEOMetaData(IPage page)
        {
            PageSEOMeta pageSEOMeta = new PageSEOMeta();
            if (page != null && page.MetadataFields != null)
            {
               
                if (page.MetadataFields.ContainsKey(ItemFieldConstants.PIER7_OG_TYPE))
                {
                    pageSEOMeta.OgType = page.MetadataFields[ItemFieldConstants.PIER7_OG_TYPE].Value;
                }
                if (page.MetadataFields.ContainsKey(ItemFieldConstants.PIER7_META_TITLE))
                {
                    pageSEOMeta.SEOTitle = page.MetadataFields[ItemFieldConstants.PIER7_META_TITLE].Value;
                    pageSEOMeta.OgTitle = pageSEOMeta.SEOTitle;
                }
                if (page.MetadataFields.ContainsKey(ItemFieldConstants.PIER7_META_DESCRIPTION))
                {
                    pageSEOMeta.SEODescription = page.MetadataFields[ItemFieldConstants.PIER7_META_DESCRIPTION].Value;
                    pageSEOMeta.OgDescription = pageSEOMeta.SEODescription;
                }
                if (page.MetadataFields.ContainsKey(ItemFieldConstants.PIER7_META_KEYWORDS))
                {
                    pageSEOMeta.SEOKeywords = page.MetadataFields[ItemFieldConstants.PIER7_META_KEYWORDS].Value;
                }
                if (page.MetadataFields.ContainsKey(ItemFieldConstants.PIER7_OG_TITLE))
                {
                    pageSEOMeta.OgTitle = page.MetadataFields[ItemFieldConstants.PIER7_OG_TITLE].Value;
                }
                if (page.MetadataFields.ContainsKey(ItemFieldConstants.PIER7_OG_DESCRIPTION))
                {
                    pageSEOMeta.OgDescription = page.MetadataFields[ItemFieldConstants.PIER7_OG_DESCRIPTION].Value;
                }
                if (page.MetadataFields.ContainsKey(ItemFieldConstants.PIER7_OG_IMAGE))
                {
                    string imageTcmId = page.MetadataFields[ItemFieldConstants.PIER7_OG_IMAGE].Value;
                    pageSEOMeta.OgImageUrl = BrokerHelper.GetURLForBinary(imageTcmId);
                }
            }
             return pageSEOMeta;
        }

        /// <summary>
        /// Corrections to the Page Url
        /// </summary>
        /// <param name="pageUrl">page url of the current page request</param>
        /// <returns>corrected page url</returns>
        public static string ScanPageURL(string pageUrl)
        {
            if (pageUrl.IndexOf(".html") == -1)
            {
                if (pageUrl.EndsWith("/"))
                {
                    pageUrl = pageUrl + "index.html";
                }
                else
                {
                    pageUrl = pageUrl + "/index.html";
                }
            }
            return pageUrl;
        }     

        public static string GetResourceValue(string Key)
        {
            WebResources KeyValueCollection = CacheHelper.Get<WebResources>("WebResourcesKeyPairCache");
            if (KeyValueCollection == null)
            {
                KeyValueCollection = new WebResources();
                CacheDependency xmlDependency = new CacheDependency(System.Web.Hosting.HostingEnvironment.MapPath(KeyValueCollection.resourceXmlPath));
                CacheHelper.Add<WebResources>(KeyValueCollection, "WebResourcesKeyPairCache", xmlDependency, ConfigurationHelper.CacheExpirationTime);
            }
            return KeyValueCollection.GetResourceValue(Key);
        }
    }
}