﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using DD4T.ContentModel;
using DD4T.Factories;
using DD4T.Utils;
using Tridion.ContentDelivery.DynamicContent.Query;
using System.Configuration;
using Emaar.PierSeven.Web.Constants;
using Emaar.PierSeven.Web.Models;
using DD4T.ContentModel.Factories;
using System.Web.Mvc;
using DD4T.ContentModel.Contracts.Providers;
using System.Web;
using System.Data.SqlClient;
using System.Data;

namespace Emaar.PierSeven.Web.Helpers
{
    public static class BrokerHelper
    {
        #region variables
        private static ConcurrentDictionary<string, string> binaryURLList = new ConcurrentDictionary<string, string>();
        #endregion


        #region COMPONENT HELPERS

        /// <summary>
        /// Returns a component object based on component tcm id.
        /// </summary>
        /// <param name="tcmUri">TCM id of the component</param>
        /// <returns>IComponent object</returns>
        public static IComponent GetComponent(string tcmUri)
        {
            ComponentFactory factory = new ComponentFactory(DependencyResolver.Current.GetService<IComponentPresentationFactory>(), DependencyResolver.Current.GetService<IFactoryCommonServices>());

            IComponent component = null;

            if (factory.TryGetComponent(tcmUri, out component))
            {
                return component;
            }
            else
            {
                return null;
            }
        }

        /// <summary>
        /// Returns a component object based on 
        /// component tcm id.
        /// </summary>
        /// <param name="tcmUri">TCM ID of the component</param>
        /// <returns>ICompoennt object list</returns>
        public static IList<IComponent> GetComponents(string[] tcmUris)
        {
            IList<IComponent> componentList = new List<IComponent>();
            if (tcmUris != null && tcmUris.Count() > 0)
            {
                ComponentFactory factory = new ComponentFactory(DependencyResolver.Current.GetService<IComponentPresentationFactory>(), DependencyResolver.Current.GetService<IFactoryCommonServices>());
                componentList = factory.GetComponents(tcmUris);

                //factory.PublicationResolver = new MobileWebPublicationResolver();
                //IComponent component = null;
                //foreach (string tcmuri in tcmUris)
                //{
                //    if (factory.TryGetComponent(tcmuri, out component))
                //    {
                //        componentList.Add(component);
                //    }
                //}
            }

            return componentList;
        }

        /// <summary>
        /// Get Component by Schema from Component Presentations
        /// </summary>
        /// <param name="page"></param>
        /// <param name="schema"></param>
        /// <returns>IComponent</returns>
        public static IComponent GetComponent(IPage page, string schema)
        {
            foreach (IComponentPresentation cp in page.ComponentPresentations)
            {
                if (cp.Component.Schema.Title.ToLower().Equals(schema.ToLower()))
                {
                    return cp.Component;
                }
            }           
            return null;
        }


        /// <summary>
        /// Returns Component based on schema and component title, in case many same schema components are added to a page.
        /// </summary>
        /// <param name="page"></param>
        /// <param name="schema"></param>
        /// <param name="componentTitle"></param>
        /// <returns></returns>
        public static IComponent GetComponent(IPage page, string schema, string componentTitle)
        {
            foreach (IComponentPresentation cp in page.ComponentPresentations)
            {
                if (cp.Component.Schema.Title.Equals(schema) && cp.Component.Title.ToLower().Contains(componentTitle))
                {
                    return cp.Component;
                }
            }
            return null;
        }

        /// <summary>
        /// Returns content schema's or embedded schema's field value
        /// </summary>
        /// <param name="component"></param>
        /// <param name="embeddedSchema"></param>
        /// <param name="field"></param>
        /// <returns></returns>
        public static string GetEmbeddedFieldValue(IComponent component, string embeddedSchema, string embeddedField)
        {
            if (null != component)
            {
                if (component.Fields.ContainsKey(embeddedSchema))
                {
                    foreach (FieldSet fields in component.Fields[embeddedSchema].EmbeddedValues)
                    {
                        if (fields.ContainsKey(embeddedField))
                        {
                            return fields[embeddedField].Value;
                        }
                    }
                }
            }
            return string.Empty;
        }

        /// <summary>
        /// This methos id used to check null fields and its value
        /// </summary>
        /// <param name="fields"></param>
        /// <param name="fieldName"></param>
        /// <returns></returns>
        public static string GetFieldValue(IFieldSet fields, string fieldName)
        {
            if (fields != null)
            {
                if (fields.ContainsKey(fieldName) && fields[fieldName] != null)
                {
                    return fields[fieldName].Value;
                }
            }

            return string.Empty;
        }

        /// <summary>
        /// Returns content schema's or embedded schema's field value
        /// </summary>
        /// <param name="component"></param>
        /// <param name="embeddedSchema"></param>
        /// <param name="field"></param>
        /// <returns></returns>
        public static string GetFieldValue(IComponent component, string field, string embeddedSchema = "")
        {
            if (component != null)
            {
                if (string.IsNullOrEmpty(embeddedSchema) && component.Fields.ContainsKey(field))
                {
                    return component.Fields[field].Value;
                }
                else if (!string.IsNullOrEmpty(embeddedSchema))
                {
                    foreach (FieldSet fields in component.Fields[embeddedSchema].EmbeddedValues)
                    {
                        if (fields.ContainsKey(field))
                        {
                            return fields[field].Value;
                        }
                    }
                }
            }

            return string.Empty;
        }

        /// <summary>
        /// Gets component using schema name.
        /// </summary>
        /// <param name="schemaName">Name of the schema</param>
        /// <returns>First component found with given schema</returns>
        public static IComponent GetComponentBySchema(string schemaName, string componentFilter = "")
        {
            SchemaTitleCriteria schemaCriteria = new SchemaTitleCriteria(schemaName);
            ItemTypeCriteria itemCriteria = new ItemTypeCriteria(ItemFieldConstants.ITEM_TYPE_COMPONENT);
            PublicationCriteria publicationCriteria = new PublicationCriteria(ConfigurationHelper.PublicationId);

            Criteria criteria = CriteriaFactory.And(new Criteria[] { schemaCriteria, itemCriteria, publicationCriteria });
            if (!string.IsNullOrEmpty(componentFilter))
            {
                IList<IComponent> list = BrokerHelper.ExecuteQuery(criteria);               
                return list.Where(comp => comp.Title.ToLower().Equals(componentFilter.ToLower())).First();
            }
            else
            {
                return BrokerHelper.ExecuteQuery(criteria).FirstOrDefault();
            }
        }

        /// <summary>
        /// Get URL for internal link.
        /// </summary>
        /// <param name="tcmID">TCM ID of the component</param>
        /// <returns>URL of the page which has component attached to it.</returns>
        public static string GetURLForComponent(string tcmID)
        {
            //Logger.WriteLog(LogLevel.DEBUG, "TEST");
            DD4T.Utils.Logger.Debug("DEBUG", new string[] { "TEST" });
            LinkFactory factory = new LinkFactory(DependencyResolver.Current.GetService<ILinkProvider>(), DependencyResolver.Current.GetService<IFactoryCommonServices>());
            return factory.ResolveLink(tcmID);
        }

        /// <summary>
        /// Executes Broker DB query and returns list 
        /// of components.
        /// </summary>
        /// <param name="criteria">Query criteria</param>
        /// <returns>List of TcmUri found</returns>
        public static IList<IComponent> ExecuteQuery(Criteria criteria)
        {
            Query query = new Query();
            query.Criteria = criteria;
            return GetComponents(query.ExecuteQuery());
        }
        #endregion


        #region COMPONENT PRESENTATION HELPERS
        /// <summary>
        /// Helper function to get component presentation 
        /// for a particular schema.
        /// </summary>
        /// <param name="schema"></param>
        /// <param name="componentPresentations"></param>
        /// <returns></returns>
        public static IComponentPresentation GetComponentPresentation(string schema, IList<IComponentPresentation> componentPresentations)
        {
            IComponentPresentation componentPresentation = null;

            if (componentPresentations != null && componentPresentations.Count > 0)
            {
                var presentations = from c in componentPresentations where c.Component.Schema.Title == schema select c;

                //return the first presentaion found in the list
                foreach (var cpresentation in presentations)
                {
                    componentPresentation = cpresentation;
                    break;
                }
            }

            return componentPresentation;
        }

        /// <summary>
        /// Get component presentation by view name.
        /// </summary>
        /// <param name="ViewName">view name</param>
        /// <param name="componentPresentations">component presentaiton list</param>
        /// <returns></returns>
        public static IComponentPresentation GetPresentationByView(string viewName, IList<IComponentPresentation> componentPresentations)
        {
            IComponentPresentation componentPresentation = null;
            if (componentPresentations != null && componentPresentations.Count > 0)
            {
                var presentations = from c in componentPresentations where c.ComponentTemplate.MetadataFields["view"].Value == viewName select c;

                //return the first presentaion found in the list
                foreach (var cpresentation in presentations)
                {
                    componentPresentation = cpresentation;
                    break;
                }
            }
            return componentPresentation;
        }
        #endregion


        #region SEO HELPERS
        /// <summary>
        /// Function to get SEO embedded Fields 
        /// from component.
        /// </summary>
        /// <param name="component"></param>
        public static SiteSEO GetSEO(IComponent component)
        {
            SiteSEO simpleSEO = new SiteSEO();
            if (component != null && component.Fields.Values != null)
            {
                foreach (IField field in component.Fields.Values)
                {
                    if (field.Name.Equals("SEO") && field.EmbeddedValues != null)
                    {
                        //Get SEO fieldset
                        IFieldSet fieldSet = field.EmbeddedValues.FirstOrDefault();
                        foreach (IField subField in fieldSet.Values)
                        {
                            if (subField.Name.Equals("SEOTitle"))
                            {
                                simpleSEO.SEOTitle = subField.Value;
                            }

                            if (subField.Name.Equals("SEODescription"))
                            {
                                simpleSEO.SEODescription = subField.Value;
                            }

                            if (subField.Name.Equals("Keywords"))
                            {
                                simpleSEO.Keywords = subField.Value;
                            }

                            if (subField.Name.Equals("SEOURLText"))
                            {
                                simpleSEO.SEOURLText = subField.Value.ToLower();
                            }
                        }
                    }
                }
            }
            return simpleSEO;
        }

        /// <summary>
        /// Fetch SEO from page 
        /// presentation.
        /// </summary>
        /// <param name="componentPresentations">list of presentations on the page</param>
        /// <returns>object of simpleSEO</returns>
        public static SiteSEO GetSEO(IList<IComponentPresentation> componentPresentations)
        {
            SiteSEO simpleSEO = null;
            if (componentPresentations != null)
            {
                IComponentPresentation seoPresentation = GetComponentPresentation("SEOPageMetaData", componentPresentations);
                if (seoPresentation != null && seoPresentation.Component != null)
                {
                    simpleSEO = new SiteSEO();
                    if (seoPresentation.Component.Fields.ContainsKey("SEOTitle"))
                    {
                        simpleSEO.SEOTitle = seoPresentation.Component.Fields["SEOTitle"].Value != null ? seoPresentation.Component.Fields["SEOTitle"].Value : string.Empty;
                    }

                    if (seoPresentation.Component.Fields.ContainsKey("SEODescription"))
                    {
                        simpleSEO.SEODescription = seoPresentation.Component.Fields["SEODescription"].Value != null ? seoPresentation.Component.Fields["SEODescription"].Value : string.Empty;
                    }

                    if (seoPresentation.Component.Fields.ContainsKey("Keywords"))
                    {
                        simpleSEO.Keywords = seoPresentation.Component.Fields["Keywords"].Value != null ? seoPresentation.Component.Fields["Keywords"].Value : string.Empty;
                    }

                }
            }
            return simpleSEO;
        }


        /// <summary>
        /// Setting the page information
        /// </summary>
        /// <param name="Title"></param>
        /// <param name="Description"></param>
        /// <param name="Keywords"></param>
        public static SiteSEO GetSEO(string Title, string Description, string Keywords)
        {
            SiteSEO simpleSEOReturnObj = new SiteSEO();
            try
            {
                simpleSEOReturnObj.Keywords = Keywords;
                simpleSEOReturnObj.SEOTitle = Title;
                simpleSEOReturnObj.SEODescription = Description;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return simpleSEOReturnObj;
        }
        #endregion


        #region BINARY HELPERS
        /// <summary>
        /// Get url for binary 
        /// files e.g. image, docs
        /// </summary>
        /// <param name="tcmID"></param>
        /// <returns></returns>
        public static string GetURLForBinary(string tcmID)
        {
            string outputURL = string.Empty;
            try
            {
                if (binaryURLList.ContainsKey(tcmID) && !string.IsNullOrEmpty(binaryURLList[tcmID]))
                {
                    outputURL = binaryURLList[tcmID];
                }
                else
                {
                    BinaryFactory factory = new BinaryFactory(DependencyResolver.Current.GetService<IBinaryProvider>(), DependencyResolver.Current.GetService<IFactoryCommonServices>());

                    outputURL = factory.GetUrlForUri(tcmID);
                    if (!binaryURLList.ContainsKey(tcmID))
                    {
                        binaryURLList.TryAdd(tcmID, outputURL);
                    }
                }
            }
            catch (Exception ex)
            {
                DD4T.Utils.Logger.Error("GetURLForBinary: TCM ID:-" + tcmID + ex.ToString());
                Logger.WriteException(LogLevel.ERROR, "GetURLForBinary: TCM ID:-" + tcmID, ex);
            }
            return outputURL;
        }

        /// <summary>
        /// Returns image url
        /// </summary>
        /// <param name="component"></param>
        /// <param name="field"></param>
        /// <returns></returns>
        public static string GetImageFieldValue(IComponent component, string fieldName, string embeddedSchema = "")
        {
            if (string.IsNullOrEmpty(embeddedSchema) && component.Fields.ContainsKey(fieldName) && component.Fields[fieldName] != null)
            {
                if (component.Fields[fieldName].LinkedComponentValues.Count > 0)
                {
                    return component.Fields[fieldName].LinkedComponentValues[0].Multimedia.Url;
                }
            }
            else if (!string.IsNullOrEmpty(embeddedSchema))
            {
                foreach (FieldSet fields in component.Fields[embeddedSchema].EmbeddedValues)
                {
                    if (fields.ContainsKey(fieldName))
                    {
                        return fields[fieldName].LinkedComponentValues[0].Multimedia.Url;
                    }
                }

            }
            return string.Empty;
        }
        /// <summary>
        /// Returns the property of a multimedia component
        /// </summary>
        /// <param name="component"></param>
        /// <param name="property"></param>
        /// <returns></returns>
        public static string GetMultimediaPropertyValue(ref IMultimedia component, string property)
        {
            switch (property.ToUpper())
            {
                case ItemFieldConstants.ALT:
                    return component.AltText;
                case ItemFieldConstants.TITLE:
                    return component.AltText;
                case ItemFieldConstants.HEIGHT:
                    return component.Height.ToString();
                case ItemFieldConstants.WIDTH:
                    return component.Width.ToString();
                default:
                    return component.Url;
            }
        }

        /// <summary>
        /// Get image alternate text 
        /// and 
        /// </summary>
        /// <param name="fieldSet">Fieldset of component</param>
        /// <param name="field">image field name</param>
        /// <returns>string: Alternate text of image</returns>
        public static string GetImageAltText(IFieldSet fieldSet, string field)
        {
            string imageAltText = null;

            if (fieldSet[field] != null && fieldSet[field].LinkedComponentValues != null &&
                fieldSet[field].LinkedComponentValues[0].MetadataFields.ContainsKey("AltText"))
            {
                imageAltText = fieldSet[field].LinkedComponentValues[0].MetadataFields["AltText"].Value;
            }

            return imageAltText;
        }

        /// <summary>
        /// Get image alternate text based on image tcmid.
        /// </summary>
        /// <param name="helper"></param>
        /// <param name="imageTCMID">TCM id of image</param>
        /// <returns>Alternate text of image</returns>
        public static string GetImageAltText(string imageTCMID)
        {
            string imageAltText = string.Empty;

            if (!string.IsNullOrEmpty(imageTCMID))
            {
                //Get image component
                IComponent component = BrokerHelper.GetComponent(imageTCMID);
                if (component != null && component.MetadataFields != null && component.MetadataFields.ContainsKey("AltText"))
                {
                    imageAltText = component.MetadataFields["AltText"].Value;
                }
            }

            return imageAltText;
        }
        #endregion

        #region PAGE HELPERS
        public static PageData GetPageData(string pageURL)
        {
            PageFactory factory = new PageFactory(DependencyResolver.Current.GetService<IPageProvider>(), DependencyResolver.Current.GetService<IComponentPresentationFactory>(), DependencyResolver.Current.GetService<IFactoryCommonServices>());
            IPage currentPage = factory.FindPage(pageURL);

            if (currentPage != null)
            {
                // Fetch Page Data
                PageData _pageData = new PageData();
                _pageData.NavParent = currentPage.Id;
                _pageData.PageURI = currentPage.Id;
                _pageData.PageTitle = currentPage.Title;
                _pageData.PublicationID = currentPage.Publication.Id;
                _pageData.StructureGroupID = currentPage.StructureGroup.Id;
                return _pageData;
            }
            return null;
        }
        #endregion

        #region GENERIC HELPER METHODS
        public static PublicationData GetPublicationData(string publicationID)
        {
            PublicationData _pubData = new PublicationData();

            string SQL_QUERY = string.Format("SELECT * FROM PUBLICATIONS WHERE PUBLICATION_ID={0}", publicationID);
            using (SqlConnection CONN = new SqlConnection(ConfigurationManager.ConnectionStrings["PierSevenBrokerConnectionString"].ConnectionString))
            {
                CONN.Open();
                /* Only for debugging
                conn.InfoMessage += delegate (object sender, SqlInfoMessageEventArgs e)
                {
                    Console.Write(e.Message);
                };*/
                using (SqlCommand cmd = new SqlCommand(SQL_QUERY, CONN))
                {
                    cmd.CommandType = CommandType.Text;
                    try
                    {
                        using (SqlDataReader dr = cmd.ExecuteReader())
                        {
                            if (dr.HasRows)
                            {
                                while (dr.Read())
                                {
                                    _pubData.PublicationID = dr["PUBLICATION_ID"].ToString();
                                    _pubData.PublicationTitle = dr["PUBLICATION_TITLE"].ToString();
                                    _pubData.PublicationKey = dr["PUBLICATION_KEY"].ToString();
                                    _pubData.PublicationPath = dr["PUBLICATION_PATH"].ToString();
                                    _pubData.PublicationURL = dr["PUBLICATION_URL"].ToString();
                                    _pubData.PublicationMediaPath = dr["MULTIMEDIA_PATH"].ToString();
                                    _pubData.PublicationMediaUrl = dr["MULTIMEDIA_URL"].ToString();
                                }
                            }
                        }
                    }
                    catch(SqlException sqlEX)
                    {
                        Logger.WriteException(LogLevel.ERROR, "ERROR IN SQL CONNECT: ", sqlEX);

                    }
                }
            }//using statement end

            return _pubData;
        }

        #endregion
    }
}
