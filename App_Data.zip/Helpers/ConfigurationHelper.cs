﻿////=====================================================
// Name             : ConfigurationHelper
// Description      : Defines various configurations available.
////=====================================================
using System;
using System.Configuration;

namespace Emaar.PierSeven.Web.Helpers
{

    /// <summary>
    /// Helper class to read correctly the App Settings values from configuration file
    /// </summary>
    public static class ConfigurationHelper
    {
        // Data Cache expiration time.
        public static int CacheExpirationTime
        {
            get
            {
                return GetAppsettingAsInt("CacheExpirationTime");
            }
        }

        public static int PublicationId
        {
            get
            {
                return GetAppsettingAsInt("DD4T.PublicationId");
            }
        }

        public static int CookieTimeInMonth
        {
            get
            {
                return GetAppsettingAsInt("CookieTimeInMonth");
            }
        }

        /// <summary>
        /// Host name to be used when on secure connection.
        /// </summary>
        public static string SecureSiteUrl
        {
            get
            {
                return GetAppsettingValue("SecureSiteUrl");
            }
        }

        public static string FBShareUrl
        {
            get
            {
                return GetAppsettingValue("FBShareUrl");
            }
        }

        public static string FBAppId
        {
            get
            {
                return GetAppsettingValue("FBAppId");
            }
        }

        public static string NonSecureSiteUrl
        {
            get
            {
                return GetAppsettingValue("NonSecureSiteUrl");
            }
        }

        public static string PageLanguage
        {
            get
            {
                return GetAppsettingValue("PageLanguage");
            }
        }

        public static bool EnableOptimizations
        {
            get
            {
                return GetAppsettingAsBoolean("EnableOptimizations");
            }
        }

        public static string ResourceXMLPath
        {
            get
            {
                return GetAppsettingValue("ResourceFileXMLPath");
            }
        }

        public static string LoggerClass
        {
            get
            {
                return GetAppsettingValue("DD4T.LoggerClass");
            }
        }

        public static string ContactUsURL
        {
            get
            {
                return GetAppsettingValue("ContactUsURL");
            }
        }

        public static string PressReleaseURL
        {
            get
            {
                return GetAppsettingValue("PressReleaseURL");
            }
        }

        public static string PageSEOCacheKey
        {
            get
            {
                return GetAppsettingValue("PageSeoCache");
            }
        }

        public static string LeftContainerCompoSchemaName
        {
            get
            {
                return GetAppsettingValue("LeftContainerCompoSchemaName");
            }
        }       


        #region Public Methods
        public static string GetAppsettingValue(string key)
        {
            try
            {
                string value = ConfigurationManager.AppSettings[key];
                if (!string.IsNullOrEmpty(value))
                {
                    return value;
                }
                else
                {
                    Logger.WriteLog(LogLevel.ERROR, "App.config key does't exists :- " + key);
                }
            }
            catch
            {
                Logger.WriteLog(LogLevel.ERROR, "App.config key does't exists :- " + key);
                throw;
            }

            return string.Empty;
        }

        #endregion

        #region Private Methods
        /// <summary>
        /// Gets appsetting value fron web configuration file as Boolean
        /// </summary>
        /// <param name="key">Appsetting Key</param>
        /// <returns>Boolean conversion of AppSettings values</returns>
        private static bool GetAppsettingAsBoolean(string key)
        {
            string valueStr = GetAppsettingValue(key);
            bool value;

            if (!bool.TryParse(valueStr, out value))
            {
                value = false;
            }

            return value;
        }

        /// <summary>
        /// Gets appsetting value fron web configuration file as Int32
        /// </summary>
        /// <param name="key">Appsetting Key</param>
        /// <returns>Int32 conversion of AppSettings values</returns>
        private static int GetAppsettingAsInt(string key)
        {
            string valueStr = GetAppsettingValue(key);
            int value;

            if (!int.TryParse(valueStr, out value))
            {
                return value;
            }

            return value;
        }
        #endregion

    }
}

