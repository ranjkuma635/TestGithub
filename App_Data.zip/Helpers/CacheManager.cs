﻿#region Namespace
using System;
using System.Web;
using System.Web.Caching;
using System.Collections.Generic;
#endregion

namespace Emaar.PierSeven.Web.Helpers
{
    /// <summary>
    /// This class is used to get/set object in Cache
    /// </summary>
    public static class CacheHelper
    {
        /// <summary>
        /// Insert value into the cache using
        /// appropriate name/value pairs and a single dependency
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="obj"></param>
        /// <param name="key"></param>
        /// <param name="dependency"></param>
        /// <param name="expirationTime"></param>
        public static void Add<T>(T obj, string key, CacheDependency dependency, double expirationTime)
        {
            System.Web.HttpRuntime.Cache.Insert(
                key,
                obj,
                dependency,
                DateTime.Now.AddMinutes(expirationTime),
                System.Web.Caching.Cache.NoSlidingExpiration);
        }

        /// <summary>
        /// Insert value into the cache using
        /// appropriate name/value pairs
        /// </summary>
        /// <typeparam name="T">Type of cached item</typeparam>
        /// <param name="obj">Item to be cached</param>
        /// <param name="key">Name of item</param>
        public static void Add<T>(T obj, string key, double expirationTime)
        {
            System.Web.HttpRuntime.Cache.Insert(
                key,
                obj,
                null,
                DateTime.Now.AddMinutes(expirationTime),
                System.Web.Caching.Cache.NoSlidingExpiration);
        }

        /// <summary>
        /// Insert value into the cache using
        /// appropriate name/value pairs
        /// </summary>
        /// <typeparam name="T">Type of cached item</typeparam>
        /// <param name="obj">Item to be cached</param>
        /// <param name="key">Name of item</param>
        public static void AddCacheForCallBack<T>(T obj, string key, double expirationTime, CacheItemRemovedCallback onRemove)
        {
            System.Web.HttpRuntime.Cache.Insert(
                key,
                obj,
                null,
                DateTime.Now.AddMinutes(expirationTime),
                System.Web.Caching.Cache.NoSlidingExpiration,
                CacheItemPriority.Default, onRemove);
        }

        /// <summary>
        /// Remove item from cache
        /// </summary>
        /// <param name="key">Name of cached item</param>
        public static void Clear(string key)
        {
            System.Web.HttpRuntime.Cache.Remove(key);
        }

        /// <summary>
        /// Check for item in cache
        /// </summary>
        /// <param name="key">Name of cached item</param>
        /// <returns></returns>
        public static bool Exists(string key)
        {
            try
            {
                return System.Web.HttpRuntime.Cache[key] != null;
            }
            catch (KeyNotFoundException)
            {
                return false;
            }
        }

        /// <summary>
        /// Gets object from Cache
        /// </summary>
        /// <typeparam name="T">Class type object</typeparam>
        /// <param name="key">Cache key</param>
        /// <returns>Object from cache</returns>
        public static T Get<T>(string key) where T : class
        {
            if (!Exists(key))
            {
                return default(T);
            }

            return System.Web.HttpRuntime.Cache.Get(key) as T;
        }
    }

}