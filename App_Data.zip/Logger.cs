﻿/*
 * Custom Logger Implementation for Application Specific Logging
 * DD4T's Internal Logging logs lots of data and can cause performance issues and should not be turned on, on a production environment
 */
using System;
using log4net;

namespace Emaar.PierSeven.Web
{
    public enum LogLevel
    {
        DEBUG = 0,
        ERROR,
        FATAL,
        INFO,
        WARN
    }

    public static class Logger
    {

        #region Members
        private static readonly ILog logger = LogManager.GetLogger(typeof(DD4T.Utils.Logger));
        #endregion

        #region Constructors
        static Logger()
        {
            //XmlConfigurator.Configure();
        }
        #endregion

        #region Methods

        public static void WriteLog(LogLevel logType, string log)
        {
            switch (logType)
            {
                case LogLevel.DEBUG:
                    logger.Debug(log);
                    break;
                case LogLevel.ERROR:
                    logger.Error(log);
                    break;
                case LogLevel.FATAL:
                    logger.Fatal(log);
                    break;
                case LogLevel.INFO:
                    logger.Info(log);
                    break;
                case LogLevel.WARN:
                    logger.Warn(log);
                    break;
                default:
                    break;
            }
        }

        public static void WriteException(LogLevel logType, string log, Exception ex)
        {
            if (logType.Equals(LogLevel.ERROR))
            {
                logger.Error(log, ex);
            }
        }

        #endregion
    }
}
