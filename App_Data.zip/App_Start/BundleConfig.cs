﻿namespace Emaar.PierSeven.Web
{
    using System.Web.Optimization;
    using System.Collections.Generic;
    using System.Linq;
    using Helpers;

    /// <summary>
    /// Minimizes and bundles JS/CSS.
    /// </summary>
    public class BundleConfig
    {
        // For more information on Bundling, visit https://docs.microsoft.com/en-us/aspnet/mvc/overview/performance/bundling-and-minification

        /// <summary>
        /// Use bundles for minimizing and bundling JS/CSS
        /// </summary>
        /// <param name="bundles">Bundle collection</param>
        public static void RegisterBundles(BundleCollection bundles)
        {
            BundleTable.EnableOptimizations = ConfigurationHelper.EnableOptimizations;

            ScriptBundle bottomScripts = new ScriptBundle("~/scripts/bottomScripts");
            bottomScripts.Include("~/assets/js/jquery.js",
                "~/assets/js/jquery.mCustomScrollbar.min.js",
                "~/assets/js/script.js"
                );

            bundles.Add(bottomScripts);

            // Bundle for CSS
            bundles.Add(new StyleBundle("~/en/assets/css/styles").Include(
                "~/en/assets/css/style.css",
                "~/en/assets/css/jquery.mCustomScrollbar.css",
                "~/en/assets/css/custom.css"
            ));
        }

    }
}

