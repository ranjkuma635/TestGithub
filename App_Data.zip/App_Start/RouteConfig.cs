﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace Emaar.PierSeven.Web
{
    public class RouteConfig
    {
        public static void RegisterRoutes(RouteCollection routes)
        {
            routes.IgnoreRoute("{resource}.axd/{*pathInfo}");

            //For Subcribe form
            routes.MapRoute(
                "Subscribe",
                 "{*PageUrl}",
                defaults: new { controller = "SubscribeForm", action = "Subscribe" },
                 constraints: new { PageUrl = @"^(en/Subscribe.html)$" }
                );

            routes.MapRoute(
                  name: "TridionPage",
                  url: "{*PageUrl}",
                  defaults: new { controller = "TridionPage", action = "Page" },
                  constraints: new { PageUrl = @"^(.*)?$" }
                  );

            // default MVC route that is necessary to render the component presentations
            routes.MapRoute(
                "Default",
                "{controller}/{action}");

            //routes.MapRoute(
            //    name: "Default",
            //    url: "{controller}/{action}/{id}",
            //    defaults: new { controller = "Home", action = "Index", id = UrlParameter.Optional }
            //);
        }
    }
}
