﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Emaar.PierSeven.Web.Constants
{
    public class ItemFieldConstants
    {
        public const string URL = "furl";
        public const string ALT = "falt";
        public const string TITLE = "ftitle";
        public const string HEIGHT = "fheight";
        public const string WIDTH = "fwidth";
        public const string YES = "Yes";
        public const string NO = "No";
        public const string BLANK = "_blank";
        public const string SELF = "_self";
        public const string EMBED_CODE = "EmbedCode";
        public const string LINK = "Link";
        public const string LINKS = "Links";
        public const string LINK_TEXT = "LinkText";
        public const string INTERNAL_LINK_URL = "InternalLinkUrl";
        public const string LINK_URL = "LinkURL";
        public const string LINK_TYPE = "LinkType";
        public const string LINK_TYPE_YES = "Yes";
        public const short ITEM_TYPE_COMPONENT = 16;

        #region SEO Constants
        public const string PIER7_OG_TYPE = "PageType";
        public const string PIER7_PAGEMETADATA = "VaselinePageMetadata";
        public const string PIER7_META_TITLE = "MetaTitle";
        public const string PIER7_META_DESCRIPTION = "MetaDescription";
        public const string PIER7_META_KEYWORDS = "MetaKeywords";
        public const string PIER7_OG_TITLE = "OgTitle";
        public const string PIER7_OG_DESCRIPTION = "OgDescription";
        public const string PIER7_OG_IMAGE = "OgImage";
        #endregion
    }
}