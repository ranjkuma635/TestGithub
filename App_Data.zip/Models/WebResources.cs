﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Emaar.PierSeven.Web.Helpers;
using System.Xml;
using DD4T.Utils;

namespace Emaar.PierSeven.Web.Models
{
    public class WebResources
    {
        public string resourceXmlPath;
        private XmlDocument resourceXMLDoc = new XmlDocument();
        private Dictionary<string, string> KeyValuePair = new Dictionary<string, string>();

        public WebResources():this(ConfigurationHelper.ResourceXMLPath)
        {
           
        }
        public WebResources(string path)
        {
            resourceXmlPath = path;

            try
            {
                resourceXMLDoc.Load(System.Web.Hosting.HostingEnvironment.MapPath(resourceXmlPath));

                XmlNodeList elementDataList = resourceXMLDoc.GetElementsByTagName("data");
                foreach (XmlNode node in elementDataList)
                {
                    if (!KeyValuePair.ContainsKey(node.Attributes["name"].Value))
                    {
                        //Logger.WriteLog(LogLevel.DEBUG, "KEY:" + node.Attributes["name"].Value + ",VALUE: " + node.FirstChild.InnerText);
                        KeyValuePair.Add(node.Attributes["name"].Value, node.FirstChild.InnerText);
                    }
                }
            }
            catch(Exception ex)
            {
                Logger.WriteException(LogLevel.ERROR, "ERROR READING RESOURCES XML", ex);
            }
        }

        public string GetResourceValue(string Key)
        {
            if (KeyValuePair.ContainsKey(Key))
            {
                return KeyValuePair[Key];
            }
            else
            {
                return "";
            }
        }
    }
}