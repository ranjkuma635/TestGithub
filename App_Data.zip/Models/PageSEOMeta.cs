﻿
namespace Emaar.PierSeven.Web.Models
{
    /// <summary>
    /// SEO related items
    /// </summary>
    public class PageSEOMeta
    {
        /// <summary>
        /// Gets or sets the PageType
        /// </summary>
        public string OgType { get; set; }

        /// <summary>
        /// Gets or sets the SEOTitle
        /// </summary>
        public string SEOTitle { get; set; }

        /// <summary>
        /// Gets or sets the SEODescription
        /// </summary>
        public string SEODescription { get; set; }

        /// <summary>
        /// Gets or sets the SEOKeywords
        /// </summary>
        public string SEOKeywords { get; set; }

        /// <summary>
        /// Gets or sets the OgTitle
        /// </summary>
        public string OgTitle { get; set; }

        /// <summary>
        /// Gets or sets the OgDescription
        /// </summary>
        public string OgDescription { get; set; }

        /// <summary>
        /// Gets or sets the OgImage
        /// </summary>
        public string OgImageUrl { get; set; }

        /// <summary>
        /// Get or set seo url
        /// </summary>
        public string SEOUrl { get; set; }
        
    }
}
