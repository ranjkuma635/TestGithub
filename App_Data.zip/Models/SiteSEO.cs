﻿namespace Emaar.PierSeven.Web.Models
{
    
    public class SiteSEO
    {
        public string SEOTitle { get; set; }
        public string SEODescription { get; set; }
        public string Keywords { get; set; }
        public string SEOURLText { get; set; }
    }
}