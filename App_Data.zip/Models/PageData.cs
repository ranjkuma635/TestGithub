﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Emaar.PierSeven.Web.Models
{
    public class PageData
    {
        
        public string PublicationID { get; set; }        
        public string PageType { get; set; }
        public string NavParent { get; set; }
        public string StructureGroupID { get; set; }
        public string PageTitle { get; set; }
        public string PageURI { get; set; }
        public string CustomPageTitle { get; set; }
    }
}