﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Emaar.PierSeven.Web.Models
{
    public class Subscribe
    {
        /// <summary>
        /// Gets or sets the Full Name
        /// </summary>
        [Required(ErrorMessage="Please enter full name.")]
        [RegularExpression("^[a-zA-z .]*$", ErrorMessage = "Alphabet only in the Name.")]
        [Display(Name = "Full Name")]
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets the Contact Number
        /// </summary>
        [Required(ErrorMessage="Please enter contact number.")]  
        [RegularExpression("^[0-9 ]*$", ErrorMessage="Numeric only for Phone number")]
        [Display(Name = "Contact Number")]
        public string Contact { get; set; }
        

        /// <summary>
        /// Gets or sets the Email Address
        /// </summary>
        [Required(ErrorMessage = "Valid Email address required.")]
        [RegularExpression(@"\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*", ErrorMessage = "Valid Email address required.")]
        [Display(Name = "Email Address")]
        public string EmailId { get; set; }

        /// <summary>
        /// Gets or sets the Comments/Enquiry
        /// </summary>        
        [RegularExpression(@"[a-zA-Z0-9.,;:()\r\n |\s]{1,500}", ErrorMessage="Number and Alphabet only in the Message")]
        [Display(Name = "Comment/Enquiry")]
        public string Message { get; set; }
    }
}