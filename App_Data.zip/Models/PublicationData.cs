﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Emaar.PierSeven.Web.Models
{
    public class PublicationData
    {
        public string PublicationID { get; set; }
        public string PublicationTitle { get; set; }
        public string PublicationKey { get; set; }
        public string PublicationPath { get; set; }
        public string PublicationURL { get; set; }
        public string PublicationMediaPath { get; set; }
        public string PublicationMediaUrl { get; set; }
    }
}