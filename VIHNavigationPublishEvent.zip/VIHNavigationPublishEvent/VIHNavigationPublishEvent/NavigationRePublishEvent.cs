﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Tridion.ContentManager;
using Tridion.ContentManager.CommunicationManagement;
using Tridion.ContentManager.ContentManagement;
using Tridion.ContentManager.Extensibility;
using Tridion.ContentManager.Extensibility.Events;
using Tridion.ContentManager.Publishing;

namespace VIHNavigationPublishEvent
{
    [TcmExtension("NavigationRePublishEventExtension")]
    public class NavigationRePublishEvent : TcmExtension
    {
        public NavigationRePublishEvent()
        {
            EventSystem.Subscribe<Page, PublishEventArgs>(NavigationPublish, EventPhases.TransactionCommitted);
            EventSystem.Subscribe<Page, UnPublishEventArgs>(NavigationUnPublish, EventPhases.TransactionCommitted);
        }
        
        private void NavigationPublish(Page page, PublishEventArgs args, EventPhases phases)
        {
            try
            {
                Session session = page.Session;
                WriteLog("Started: " + page.Id);
                Publication publication = page.ContextRepository as Publication;
                int pubId = publication.Id.ItemId;
                string pageUri = "tcm:" + pubId + "-58491-64";
                string ptUri = "tcm:" + pubId + "-58460-128";
                Page navigationPage = session.GetObject(pageUri) as Page;
                PageTemplate pageTemplate = session.GetObject(ptUri) as PageTemplate;
                bool includeCP = args.PublishInstruction.ResolveInstruction.IncludeChildPublications;

                if (page.PageTemplate.Id == ptUri)
                {
                    List<IdentifiableObject> items = new List<IdentifiableObject>();
                    items.Add(navigationPage);
                    //List<TargetType> pubTarget = new List<TargetType> { new TargetType(new TcmUri(1, ItemType.TargetType), session) };
                    ResolveInstruction resolveInstruction = new ResolveInstruction(session) { IncludeChildPublications = includeCP };
                    PublishInstruction instruction = new PublishInstruction(session)
                    {
                        DeployAt = DateTime.Now.AddMinutes(2),
                        StartAt = DateTime.Now.AddMinutes(2),
                        ResolveInstruction = resolveInstruction
                    };

                    PublishEngine.Publish(items, instruction, args.Targets.Cast<TargetType>(), PublishPriority.Normal);
                    WriteLog("Finished: " + page.Id);
                }
            }
            catch (Exception ex)
            {
                WriteLog(ex.Message + Environment.NewLine + ex.StackTrace + ex.InnerException);
            }
        }

        private void NavigationUnPublish(Page page, UnPublishEventArgs args, EventPhases phases)
        {
            try
            {
                Session session = page.Session;
                WriteLog("Started: " + page.Id);
                Publication publication = page.ContextRepository as Publication;
                int pubId = publication.Id.ItemId;
                string pageUri = "tcm:" + pubId + "-58491-64";
                string ptUri = "tcm:" + pubId + "-58460-128";
                Page navigationPage = session.GetObject(pageUri) as Page;
                PageTemplate pageTemplate = session.GetObject(ptUri) as PageTemplate;
                bool includeCP = args.UnPublishInstruction.ResolveInstruction.IncludeChildPublications;
                if (page.PageTemplate.Id == ptUri)
                {
                    List<IdentifiableObject> items = new List<IdentifiableObject>();
                    items.Add(navigationPage);
                    ResolveInstruction resolveInstruction = new ResolveInstruction(session) { IncludeChildPublications = includeCP };
                    PublishInstruction instruction = new PublishInstruction(session)
                    {
                        DeployAt = DateTime.Now.AddMinutes(2),
                        StartAt = DateTime.Now.AddMinutes(2),
                        ResolveInstruction = resolveInstruction
                    };

                    PublishEngine.Publish(items, instruction, args.Targets.Cast<TargetType>(), PublishPriority.Normal);
                    WriteLog("Finished: " + page.Id);
                }
            }
            catch (Exception ex)
            {
                WriteLog(ex.Message + Environment.NewLine + ex.StackTrace + ex.InnerException);
            }
        }

        private void WriteLog(string logMessage)
        {
            using (StreamWriter writer = new StreamWriter(@"C:\Event\VIH\" + "EventLogs" + DateTime.Now.ToString("MM-dd-yyyy") + ".txt", true))
            {
                writer.WriteLine(DateTime.Now.ToString("MM-dd-yyyy hh:mm:ss >> ") + logMessage);
            }
        }
    }
}
